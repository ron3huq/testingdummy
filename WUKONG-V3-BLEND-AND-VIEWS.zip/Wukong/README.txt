Wukong V3: beard atlas and dense inner fur.
Blender preview, eight angles and validation reports.
Original outer hull vertices, tips and fur length are preserved; inner hair-card roots are widened by at most3.5mm. Existing beard, face, topology, weights and166bone bind data are preserved.
Native Android meshes are integrated in the FULL game overlay; this separate ZIP is the Blender/render review package. No Android/GPU verification has been claimed.
