import marshal,types,resource,zipfile,io,sys,hashlib,dis
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
resource.setrlimit(resource.RLIMIT_AS,(1500*1024**2,1500*1024**2))
apk,out,*names=sys.argv[1:];out=Path(out);out.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(apk)as z:
 with zipfile.ZipFile(io.BytesIO(z.read('assets/chaquopy/app.imy')))as app:
  c=marshal.loads(app.read('_protected_runtime.pyc')[16:])
layers=[]
for depth in range(100):
 layers.append(c)
 children=[x for x in c.co_consts if isinstance(x,types.CodeType)and x.co_name=='<module>']
 for x in c.co_consts:
  if isinstance(x,bytes)and x[:1]in(b'c',b'\xe3'):
   try:
    v=marshal.loads(x)
    if isinstance(v,types.CodeType):children.append(v)
   except (ValueError,EOFError,TypeError,MemoryError):pass
 if not children:break
 c=children[0]
const=c.co_consts;parts=next(x for x in const if isinstance(x,tuple)and len(x)==2 and all(isinstance(y,bytes)and len(y)==32 for y in x));cipher=AESGCM(bytes(a^b for a,b in zip(*parts)))
payloads={}
for layer in reversed(layers):
 ins=list(dis.get_instructions(layer))
 for j,i in enumerate(ins):
  if i.opname=='MAP_ADD' and j>=2 and ins[j-2].opname=='LOAD_CONST' and ins[j-1].opname=='LOAD_CONST':
   key,val=ins[j-2].argval,ins[j-1].argval
   if isinstance(key,str)and isinstance(val,bytes):payloads[key]=val
  if i.opname=='BUILD_CONST_KEY_MAP':
   keys=ins[j-1].argval;vals=[x.argval for x in ins[j-1-i.arg:j-1]]
   if isinstance(keys,tuple)and len(keys)==len(vals):payloads.update(zip(keys,vals))
  if i.opname=='STORE_SUBSCR' and j>=3 and ins[j-1].opname=='LOAD_CONST' and ins[j-2].opname=='LOAD_NAME' and ins[j-2].argval=='_PAYLOADS':
   val,key=ins[j-3].argval,ins[j-1].argval
   if isinstance(key,str)and isinstance(val,bytes):payloads[key]=val
for name in names:
 if name not in payloads:print(name,'not in payload');continue
 raw=payloads[name]
 data=cipher.decrypt(raw[:12],raw[12:],b'E156-V11-pyc-v1:'+name.encode()+b'\xcb\r\r\n');(out/(name+'.pyc')).write_bytes(data)
 print(name,hashlib.sha256(data).hexdigest())
