"""V19 captured packets + original V25 cup code/UI snapshots on fixture saves."""
import sys,json,copy,tempfile,types,msgpack
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from host_reference import References
BASE=Path('/workspace/apk73-work/rc22-host/base');STAGE=Path('/workspace/apk73-work/rc22-full/payload')
sys.meta_path.insert(0,References('/workspace/apk73-inputs/decoded/73efootball-V19.1.apk',BASE))
import club_store,cup_entry,my_league,opponent_squad
originals=(my_league.prepare,my_league.start,my_league.finish,opponent_squad.preset)
responses={}
for p in(BASE/'outputs/reference/decrypted').glob('*_resp.txt'):
 try:
  obj=msgpack.unpackb(p.read_bytes(),raw=False,strict_map_key=False)
  if isinstance(obj,dict):responses[p.name.split('_gate_',1)[-1].removesuffix('_resp.txt')]=obj
 except (ValueError,msgpack.UnpackException,UnicodeError):pass
class Logic:
 def __init__(self,conn):self.conn=conn;self.responses=responses;self.templates={}
 def handle(self,mid,req):
  response=cup_entry.handle(self,mid,req)
  if response is not None:return response
  response=copy.deepcopy(self.responses.get(mid,dict(result='NOERR')));response.update(msgid=mid,rqid=req.get('rqid'))
  return cup_entry.project(self,response)if mid in cup_entry.LIST_COMMANDS else response
with tempfile.TemporaryDirectory()as tmp:
 conn=club_store.connect(Path(tmp)/'fixture.sqlite3');club_store.seed(conn);conn.commit()
 sentinel='normal-My-League-untouched';club_store.set_meta(conn,'my_league_state_v1',sentinel);conn.commit()
 gateway=types.ModuleType('fixture_gateway');gateway._logic=Logic(conn);gateway.manage=lambda *a:'original-manage'
 sys.path.insert(0,str(STAGE/'assets/gateway-release/work/tools'));import rc22_v25_events
 assert rc22_v25_events.install(gateway)
 assert not rc22_v25_events.install(gateway)
 assert originals==(my_league.prepare,my_league.start,my_league.finish,opponent_squad.preset)
 assert gateway.manage('not-a-cup-action')=='original-manage'
 # Guard against accidental activation of the old My League bridge.
 legacy=rc22_v25_events._modules['my_league_e112_candidate']
 legacy.activate_group=lambda *a:(_ for _ in()).throw(AssertionError('legacy My League group was activated'))
 entries=gateway._logic.handle('CMD_GET_EVENT_LIST_AND_LOG',dict(rqid=1))
 listed={e['event_id']for e in entries['event_list']}
 assert {1120006,1120010}<=listed,listed
 snapshots={}
 for spec in ['ucl','wc']:
  donor=rc22_v25_events._modules['cup_entry'];s=donor.cup_spec.SPECS[spec];service=donor._ucl_service(gateway._logic,s);state=service._ensure_entered()
  assert len(state['teams'])==32 and len(state['groups'])==8 and not s.knockout_two_legs
  response=gateway._logic.handle('CMD_GET_EVENT_COMPE_INFO',dict(event_id=s.group_event_id,match_category='EVENT_COM',rqid=2))
  assert response['result']=='NOERR',response
  snap=json.loads(gateway.manage('ucl_ui_snapshot',json.dumps(dict(eventId=s.group_event_id))))
  assert snap['entered']and len(snap['groups'])==8,snap
  snapshots[spec]=dict(event_id=s.group_event_id,group_count=len(snap['groups']),snapshot_keys=sorted(snap))
 assert club_store.get_meta(conn,'my_league_state_v1')==sentinel
 assert club_store.get_meta(conn,'my_league_ucl_group_active','0')=='0'
 assert not any(n.startswith('ucl_lp_')for n in sys.modules)
 print(json.dumps(dict(passed=True,original_v25_event_ids=True,v19_captured_messagepack_templates=True,private_donor_modules=len(rc22_v25_events._modules),global_my_league_and_opponent_functions_preserved=True,no_legacy_my_league_activation=True,no_rc21_ucl_imports=True,events=snapshots,normal_save_unchanged=True,android_java_opener_not_executed=True,phone_verified=False),indent=2))
