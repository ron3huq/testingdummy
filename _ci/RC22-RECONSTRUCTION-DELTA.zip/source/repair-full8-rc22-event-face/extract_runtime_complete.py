import zipfile,io,marshal,sys,hashlib
from pathlib import Path
path='/workspace/apk73-inputs/v25-decoded/73efootball-V25.apk'
with zipfile.ZipFile(path)as z:
 with zipfile.ZipFile(io.BytesIO(z.read('assets/chaquopy/app.imy')))as app:c=marshal.loads(app.read('_protected_runtime.pyc')[16:])
saved=list(sys.meta_path);ns=dict(__name__='_protected_runtime_reference',__file__='/workspace/apk73-work/rc22-research/_protected_runtime.py')
try:exec(c,ns)
finally:sys.meta_path[:]=saved
payloads=ns.get('_PAYLOADS',{});print('complete payload modules',len(payloads));print('native keys',[k for k in payloads if 'native_dv' in k]);print('decoder functions',[k for k,v in ns.items()if callable(v)and any(s in k.lower()for s in ['code','decrypt','exec'])])
sys.path.insert(0,'/workspace/testingdummy/source/repair-full8-rc22-event-face')
from host_reference import References
ref=References(path,'/workspace/apk73-work/rc22-host/base')
import dis,types
for name in ['cup_spec','cup16_mode','cup16_service','ucl_mode','ucl_group_bridge','ucl_service','wc_field','user_compe_service','cup_entry','opponent_squad','my_league_opponents','my_league_e112_candidate','embedded_gateway','native_dv_formations']:
 raw=payloads[name];data=ref.cipher.decrypt(raw[:12],raw[12:],b'E156-V11-pyc-v1:'+name.encode()+b'\xcb\r\r\n')
 dest=Path('/workspace/apk73-inputs/v25-python')/(name+'.pyc');old=hashlib.sha256(dest.read_bytes()).hexdigest()if dest.exists()else None;dest.write_bytes(data);print('CHANGED'if old!=hashlib.sha256(data).hexdigest()else 'EXACT',name);c=marshal.loads(data[16:]);print(name,hashlib.sha256(data).hexdigest(),'imports',[i.argval for i in dis.get_instructions(c)if i.opname=='IMPORT_NAME'],'functions',[x.co_name for x in c.co_consts if isinstance(x,types.CodeType)])
