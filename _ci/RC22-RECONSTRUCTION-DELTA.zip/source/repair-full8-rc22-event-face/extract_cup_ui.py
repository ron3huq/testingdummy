import sys,types,marshal,json,hashlib,dis,builtins
from pathlib import Path
sys.path.insert(0,'/workspace/testingdummy/source/repair-full8-rc22-event-face')
from host_reference import References
root=Path('/workspace/apk73-work/rc22-host/base');sys.meta_path.insert(0,References('/workspace/apk73-inputs/v25-decoded/73efootball-V25.apk',root))
stub=types.ModuleType('editor_appearance_runtime');stub.install=lambda *a,**k:None;sys.modules['editor_appearance_runtime']=stub
import embedded_gateway as donor
objects={n:f for n,f in vars(donor).items()if isinstance(f,types.FunctionType)and(n.startswith('_cup_')or n=='consume_cup_ui_event')and 'previous'not in n}
constants={n:v for n,v in vars(donor).items()if n.startswith('_CUP_')or n in ['_last_cup_event','_pending_cup_ui_event']}
bindings={};queue=list(objects)
def globals_used(c):
 out={i.argval for i in dis.get_instructions(c)if i.opname=='LOAD_GLOBAL'}
 for child in c.co_consts:
  if isinstance(child,types.CodeType):out.update(globals_used(child))
 return out
while queue:
 n=queue.pop()
 for key in globals_used(objects[n].__code__):
  if key in objects or key in constants or key in bindings or key in ('_logic','_root')or key not in vars(donor):continue
  v=vars(donor)[key]
  if isinstance(v,types.ModuleType):bindings[key]={'module':v.__name__}
  elif isinstance(v,types.FunctionType):
   if v.__globals__ is vars(donor):objects[key]=v;queue.append(key)
   else:bindings[key]={'module':v.__module__,'qualname':v.__qualname__}
  elif isinstance(v,type)and v not in (int,str,bool,float):bindings[key]={'module':v.__module__,'qualname':v.__qualname__}
  else:constants[key]=v
functions={n:(f.__code__,f.__defaults__,f.__kwdefaults__)for n,f in objects.items()}
def freeze(v):
 if isinstance(v,types.FunctionType):
  assert v.__closure__ is None
  return {'__function__':(v.__code__,v.__defaults__,v.__kwdefaults__)}
 if isinstance(v,type) and v in (int,str,bool,float):return {'__python_type__':v.__name__}
 if isinstance(v,range):return {'__range__':[v.start,v.stop,v.step]}
 if isinstance(v,dict):return {k:freeze(x)for k,x in v.items()}
 if isinstance(v,tuple):return tuple(freeze(x)for x in v)
 if isinstance(v,list):return [freeze(x)for x in v]
 return v
constants={k:freeze(v)for k,v in constants.items()}
for n,(c,defaults,kw)in functions.items():print(n,'globals',c.co_names,'defaults',defaults)

for key,val in constants.items():
 try:marshal.dumps(val)
 except ValueError:
  print('UNSERIALIZABLE',key,repr(val)[:1800])
b=marshal.dumps(dict(functions=functions,constants=constants,bindings=bindings));p=Path('/workspace/apk73-work/rc22-research/rc22_v25_cup_ui.marshal');p.write_bytes(b);print('extracted',len(functions),'constants',list(constants),'sha256',hashlib.sha256(b).hexdigest())

print("bindings",bindings)
