"""Refresh only face mesh chunks in an already built palette stage.
Full fresh builds use build_face.py; this avoids lossy texture recompression.
"""
from pathlib import Path
import sys,json,struct
SRC=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(Path(__file__).parent),str(SRC/'repair-full8-rc7'),str(SRC/'repair-full8-rc9-ucl'),'/workspace/apk73-work/rc7/source/repair-full8-rc4']
from iostore import Toc
from ci_bundle import Bundle
from zen_clone import rename
from mesh_tools import Mesh
from face_mesh import build_mesh
BASE='/Game/Assets/character/RealFace/'
def run(root,report_path):
 root=Path(root);live=root/'assets/gateway-release/livedata';logs=json.loads((SRC/'repair-full8-rc7/mesh-ranges.json').read_text());lowlogs=json.loads((SRC/'repair-full8-rc9-ucl/low-ranges.json').read_text());prior=json.loads(Path(report_path).read_text());reports=[]
 for variant,suffix in enumerate(['','ep00v0313','ep01v0291','lg00v0000']):
  toc=Toc(str(live/f'pc{9356+variant}_mobile_and.utoc'));old=Bundle(toc);name='SK_RG28'+suffix+'_Face';path='character/RealFace/'+name+'.uasset';raw=old.files[path][1];log=logs[name.replace('RG28','RG27')]
  authored=Toc(str(live/f'pc{9352+variant}_mobile_and.utoc'));authpath=next(p for p in authored.files if p.endswith(name.replace('RG28','RG27')+'.uasset'));weights=Mesh(authored.read(authored.files[authpath]),log,lod_index=1).weights
  native=Toc(str(live/f'pc{9340+variant}_mobile_and.utoc'));native_name='SK_RV8D'+suffix+'_Face';native_path=next(p for p in native.files if p.endswith(native_name+'.uasset'));mesh,_,check=build_mesh(raw,log,native.read(native.files[native_path]),lowlogs[native_name],weights)
  for palette in range(1,7):
   profile='R9B'+str(palette);number=9384+variant*6+palette-1;mapping={}
   for p in old.files:
    if not p.endswith('.uasset'):continue
    n=Path(p).stem
    if n.startswith('SK_')or(n.startswith('MI_')and'_Head_Face'in n)or(n.startswith('T_')and n.endswith('_Face_D')):mapping[BASE+n]=BASE+n.replace('RG2801',profile+'01').replace('RG28',profile)
    elif n.startswith('T_')and n.endswith(('_Face_SRO','_Face_N')):mapping[BASE+n]=BASE+n.replace('RG28','R9B2')
   newname=name.replace('RG28',profile);repl={}
   for a,b in mapping.items():repl[a]=b;repl[Path(a).name]=Path(b).name
   updated=rename(mesh,repl,BASE+name,BASE+newname,imports=mapping)
   target=Bundle(Toc(str(live/f'pc{number}_mobile_and.utoc')));dest='character/RealFace/'+newname+'.uasset';target.files[dest]=(target.files[dest][0],updated);target.base=toc;target.output_name=f'pc{number}_mobile_and';target.write(live)
   row=next(dict(r)for r in prior if r['profile']==profile and r['variant']==(suffix or'base'));row.update(check);reports.append(row)
 Path(report_path).write_text(json.dumps(reports,indent=2)+'\n');return len(reports)
if __name__=='__main__':print('Refreshed mesh chunks:',run(*sys.argv[1:]))
