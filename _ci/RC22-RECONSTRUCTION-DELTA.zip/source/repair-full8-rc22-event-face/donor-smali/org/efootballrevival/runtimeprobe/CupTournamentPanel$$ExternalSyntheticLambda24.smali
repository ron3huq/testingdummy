.class public final synthetic Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda24;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

.field public final synthetic f$1:J

.field public final synthetic f$2:Landroid/widget/TextView;


# direct methods
.method public synthetic constructor <init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;JLandroid/widget/TextView;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda24;->f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    iput-wide p2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda24;->f$1:J

    iput-object p4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda24;->f$2:Landroid/widget/TextView;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda24;->f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    iget-wide v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda24;->f$1:J

    iget-object v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda24;->f$2:Landroid/widget/TextView;

    invoke-virtual {v0, v1, v2, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->lambda$resetButton$16$org-efootballrevival-runtimeprobe-CupTournamentPanel(JLandroid/widget/TextView;)V

    return-void
.end method
