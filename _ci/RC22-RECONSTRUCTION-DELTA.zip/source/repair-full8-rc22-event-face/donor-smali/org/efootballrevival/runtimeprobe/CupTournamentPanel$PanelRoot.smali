.class final Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;
.super Landroid/widget/FrameLayout;
.source "CupTournamentPanel.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "PanelRoot"
.end annotation


# instance fields
.field private final backdrop:Landroid/graphics/Bitmap;

.field private final hole:Landroid/graphics/Rect;

.field private final paint:Landroid/graphics/Paint;

.field final synthetic this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;


# direct methods
.method constructor <init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Landroid/content/Context;Landroid/graphics/Bitmap;)V
    .registers 4

    .line 467
    iput-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    .line 468
    invoke-direct {p0, p2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 464
    new-instance p1, Landroid/graphics/Rect;

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    iput-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->hole:Landroid/graphics/Rect;

    .line 465
    new-instance p1, Landroid/graphics/Paint;

    const/4 p2, 0x2

    invoke-direct {p1, p2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->paint:Landroid/graphics/Paint;

    .line 469
    iput-object p3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->backdrop:Landroid/graphics/Bitmap;

    const/4 p1, 0x0

    .line 470
    invoke-virtual {p0, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->setWillNotDraw(Z)V

    return-void
.end method


# virtual methods
.method inHole(FF)Z
    .registers 4

    .line 500
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->hole:Landroid/graphics/Rect;

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p2

    invoke-virtual {v0, p1, p2}, Landroid/graphics/Rect;->contains(II)Z

    move-result p1

    return p1
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 8

    .line 484
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 485
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->hole:Landroid/graphics/Rect;

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->clipOutRect(Landroid/graphics/Rect;)Z

    .line 486
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->backdrop:Landroid/graphics/Bitmap;

    if-eqz v0, :cond_60

    .line 487
    invoke-virtual {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->getWidth()I

    move-result v0

    int-to-float v0, v0

    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->backdrop:Landroid/graphics/Bitmap;

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v0, v1

    invoke-virtual {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->getHeight()I

    move-result v1

    int-to-float v1, v1

    iget-object v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->backdrop:Landroid/graphics/Bitmap;

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v1, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v0

    .line 488
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->backdrop:Landroid/graphics/Bitmap;

    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v1

    int-to-float v1, v1

    mul-float/2addr v1, v0

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    .line 489
    iget-object v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->backdrop:Landroid/graphics/Bitmap;

    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v2

    int-to-float v2, v2

    mul-float/2addr v2, v0

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v0

    .line 490
    invoke-virtual {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->getWidth()I

    move-result v2

    sub-int/2addr v2, v1

    div-int/lit8 v2, v2, 0x2

    .line 491
    invoke-virtual {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->getHeight()I

    move-result v3

    sub-int/2addr v3, v0

    div-int/lit8 v3, v3, 0x2

    .line 492
    iget-object v4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->backdrop:Landroid/graphics/Bitmap;

    new-instance v5, Landroid/graphics/Rect;

    add-int/2addr v1, v2

    add-int/2addr v0, v3

    invoke-direct {v5, v2, v3, v1, v0}, Landroid/graphics/Rect;-><init>(IIII)V

    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->paint:Landroid/graphics/Paint;

    const/4 v1, 0x0

    invoke-virtual {p1, v4, v1, v5, v0}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    goto :goto_66

    :cond_60
    const v0, -0xf5e592

    .line 494
    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->drawColor(I)V

    .line 496
    :goto_66
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method protected onSizeChanged(IIII)V
    .registers 5

    .line 479
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/FrameLayout;->onSizeChanged(IIII)V

    .line 480
    iget-object p3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    invoke-static {p3, p1, p2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$100(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;II)V

    return-void
.end method

.method setHole(IIII)V
    .registers 6

    .line 474
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->hole:Landroid/graphics/Rect;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/graphics/Rect;->set(IIII)V

    .line 475
    invoke-virtual {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->invalidate()V

    return-void
.end method
