.class final Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;
.super Landroid/widget/FrameLayout;
.source "CupTournamentPanel.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "BracketBoard"
.end annotation


# instance fields
.field private final COUNT:[I

.field private final FIRST:[I

.field private final ROUND:[I

.field private final cards:[[Landroid/view/View;

.field private final fixedHeight:I

.field private final gap:I

.field private final headerHeight:I

.field private final linePaint:Landroid/graphics/Paint;

.field private final rowHeight:I

.field final synthetic this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;


# direct methods
.method constructor <init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Landroid/content/Context;Lorg/json/JSONArray;ZII)V
    .registers 15

    .line 2094
    iput-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    .line 2095
    invoke-direct {p0, p2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    const/4 p2, 0x7

    new-array v0, p2, [I

    .line 2084
    fill-array-data v0, :array_102

    iput-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->ROUND:[I

    new-array v0, p2, [I

    .line 2085
    fill-array-data v0, :array_114

    iput-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->FIRST:[I

    new-array v0, p2, [I

    .line 2086
    fill-array-data v0, :array_126

    iput-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->COUNT:[I

    .line 2087
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->linePaint:Landroid/graphics/Paint;

    const/16 v2, 0x18

    .line 2089
    invoke-static {p1, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$400(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;I)I

    move-result v2

    iput v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->headerHeight:I

    const/16 v2, 0x10

    .line 2090
    invoke-static {p1, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$400(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;I)I

    move-result v2

    iput v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->gap:I

    new-array v2, p2, [[Landroid/view/View;

    .line 2091
    iput-object v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->cards:[[Landroid/view/View;

    .line 2096
    iput p5, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->rowHeight:I

    .line 2097
    iput p6, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->fixedHeight:I

    const/4 p5, 0x0

    .line 2098
    invoke-virtual {p0, p5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->setWillNotDraw(Z)V

    .line 2099
    sget-object p6, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, p6}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 2100
    invoke-static {p1, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$400(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;I)I

    move-result p6

    int-to-float p6, p6

    const/high16 v2, 0x40000000    # 2.0f

    invoke-static {v2, p6}, Ljava/lang/Math;->max(FF)F

    move-result p6

    invoke-virtual {v0, p6}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const p6, -0x66000001

    .line 2101
    invoke-virtual {v0, p6}, Landroid/graphics/Paint;->setColor(I)V

    move p6, p5

    :goto_59
    if-ge p6, p2, :cond_100

    .line 2103
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->ROUND:[I

    aget v0, v0, p6

    invoke-virtual {p3, v0}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v0

    const/4 v2, 0x0

    if-nez v0, :cond_68

    move-object v0, v2

    goto :goto_6e

    :cond_68
    const-string v3, "matches"

    .line 2104
    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    .line 2105
    :goto_6e
    iget-object v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->cards:[[Landroid/view/View;

    iget-object v4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->COUNT:[I

    aget v4, v4, p6

    new-array v4, v4, [Landroid/view/View;

    aput-object v4, v3, p6

    .line 2106
    invoke-static {}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$500()[Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->ROUND:[I

    aget v4, v4, p6

    aget-object v3, v3, v4

    invoke-static {p1, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$600(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x3

    if-ne p6, v4, :cond_8c

    const/16 v5, -0x1eb6

    goto :goto_8d

    :cond_8c
    const/4 v5, -0x1

    :goto_8d
    const/16 v6, 0xe

    invoke-static {p1, v3, v6, v5, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$700(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v3

    const/16 v5, 0x11

    .line 2107
    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setGravity(I)V

    const v5, 0x40ffffff    # 7.9999995f

    const/16 v6, 0x8

    .line 2108
    invoke-static {p1, v5, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$800(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2109
    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "title"

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, p6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/widget/TextView;->setTag(Ljava/lang/Object;)V

    .line 2110
    new-instance v5, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v6, -0x2

    iget v7, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->headerHeight:I

    invoke-direct {v5, v6, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p0, v3, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    move v3, p5

    .line 2111
    :goto_c1
    iget-object v5, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->COUNT:[I

    aget v5, v5, p6

    if-ge v3, v5, :cond_fc

    if-nez v0, :cond_cb

    move-object v5, v2

    goto :goto_d4

    .line 2112
    :cond_cb
    iget-object v5, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->FIRST:[I

    aget v5, v5, p6

    add-int/2addr v5, v3

    invoke-virtual {v0, v5}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v5

    :goto_d4
    if-nez v5, :cond_d7

    goto :goto_f9

    .line 2114
    :cond_d7
    invoke-static {p1, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$900(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Lorg/json/JSONObject;)Landroid/view/View;

    move-result-object v5

    if-ne p6, v4, :cond_eb

    if-eqz p4, :cond_eb

    const v6, -0x1f56d6

    const/16 v7, 0xc

    .line 2115
    invoke-static {p1, v6, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$800(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2116
    :cond_eb
    iget-object v6, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->cards:[[Landroid/view/View;

    aget-object v6, v6, p6

    aput-object v5, v6, v3

    .line 2117
    new-instance v6, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v6, p5, p5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p0, v5, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_f9
    add-int/lit8 v3, v3, 0x1

    goto :goto_c1

    :cond_fc
    add-int/lit8 p6, p6, 0x1

    goto/16 :goto_59

    :cond_100
    return-void

    nop

    :array_102
    .array-data 4
        0x0
        0x1
        0x2
        0x3
        0x2
        0x1
        0x0
    .end array-data

    :array_114
    .array-data 4
        0x0
        0x0
        0x0
        0x0
        0x1
        0x2
        0x4
    .end array-data

    :array_126
    .array-data 4
        0x4
        0x2
        0x1
        0x1
        0x1
        0x2
        0x4
    .end array-data
.end method

.method private centre(III)F
    .registers 6

    .line 2132
    iget v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->headerHeight:I

    sub-int/2addr p3, v0

    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    const/4 v1, 0x6

    invoke-static {v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$400(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;I)I

    move-result v0

    sub-int/2addr p3, v0

    int-to-float p3, p3

    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->COUNT:[I

    aget p1, v0, p1

    int-to-float p1, p1

    div-float/2addr p3, p1

    .line 2133
    iget p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->headerHeight:I

    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    invoke-static {v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$400(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;I)I

    move-result v0

    add-int/2addr p1, v0

    int-to-float p1, p1

    int-to-float p2, p2

    const/high16 v0, 0x3f000000    # 0.5f

    add-float/2addr p2, v0

    mul-float/2addr p3, p2

    add-float/2addr p1, p3

    return p1
.end method

.method private columnWidth(I)I
    .registers 3

    .line 2128
    iget v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->gap:I

    mul-int/lit8 v0, v0, 0x6

    sub-int/2addr p1, v0

    div-int/lit8 p1, p1, 0x7

    return p1
.end method

.method private connect(Landroid/graphics/Canvas;IIII)V
    .registers 13

    .line 2170
    invoke-virtual {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->getHeight()I

    move-result v0

    .line 2171
    iget v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->gap:I

    if-lez p4, :cond_d

    add-int/2addr v1, p5

    mul-int/2addr v1, p2

    add-int/2addr v1, p5

    int-to-float p5, v1

    goto :goto_10

    :cond_d
    add-int/2addr p5, v1

    mul-int/2addr p5, p2

    int-to-float p5, p5

    .line 2172
    :goto_10
    iget v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->gap:I

    mul-int v2, p4, v1

    int-to-float v2, v2

    const/high16 v3, 0x40000000    # 2.0f

    div-float/2addr v2, v3

    add-float/2addr v2, p5

    mul-int/2addr p4, v1

    int-to-float p4, p4

    add-float/2addr p4, p5

    .line 2174
    new-instance v1, Landroid/graphics/Path;

    invoke-direct {v1}, Landroid/graphics/Path;-><init>()V

    const/4 v3, 0x0

    .line 2175
    :goto_22
    iget-object v4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->COUNT:[I

    aget v4, v4, p3

    if-ge v3, v4, :cond_62

    .line 2176
    invoke-direct {p0, p3, v3, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->centre(III)F

    move-result v4

    .line 2177
    iget-object v5, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->COUNT:[I

    aget v6, v5, p2

    aget v5, v5, p3

    mul-int/lit8 v5, v5, 0x2

    if-ne v6, v5, :cond_55

    mul-int/lit8 v5, v3, 0x2

    .line 2178
    invoke-direct {p0, p2, v5, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->centre(III)F

    move-result v6

    add-int/lit8 v5, v5, 0x1

    .line 2179
    invoke-direct {p0, p2, v5, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->centre(III)F

    move-result v5

    .line 2180
    invoke-virtual {v1, p5, v6}, Landroid/graphics/Path;->moveTo(FF)V

    .line 2181
    invoke-virtual {v1, v2, v6}, Landroid/graphics/Path;->lineTo(FF)V

    .line 2182
    invoke-virtual {v1, v2, v5}, Landroid/graphics/Path;->lineTo(FF)V

    .line 2183
    invoke-virtual {v1, p5, v5}, Landroid/graphics/Path;->lineTo(FF)V

    .line 2184
    invoke-virtual {v1, v2, v4}, Landroid/graphics/Path;->moveTo(FF)V

    .line 2185
    invoke-virtual {v1, p4, v4}, Landroid/graphics/Path;->lineTo(FF)V

    goto :goto_5f

    .line 2187
    :cond_55
    invoke-direct {p0, p2, v3, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->centre(III)F

    move-result v4

    .line 2188
    invoke-virtual {v1, p5, v4}, Landroid/graphics/Path;->moveTo(FF)V

    .line 2189
    invoke-virtual {v1, p4, v4}, Landroid/graphics/Path;->lineTo(FF)V

    :goto_5f
    add-int/lit8 v3, v3, 0x1

    goto :goto_22

    .line 2192
    :cond_62
    iget-object p2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->linePaint:Landroid/graphics/Paint;

    invoke-virtual {p1, v1, p2}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    return-void
.end method


# virtual methods
.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 11

    .line 2196
    invoke-virtual {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->getWidth()I

    move-result v0

    invoke-direct {p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->columnWidth(I)I

    move-result v0

    const/4 v1, 0x0

    move v3, v1

    :goto_a
    const/4 v7, 0x3

    if-ge v3, v7, :cond_19

    add-int/lit8 v7, v3, 0x1

    const/4 v5, 0x1

    move-object v1, p0

    move-object v2, p1

    move v4, v7

    move v6, v0

    .line 2197
    invoke-direct/range {v1 .. v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->connect(Landroid/graphics/Canvas;IIII)V

    move v3, v7

    goto :goto_a

    :cond_19
    const/4 v1, 0x6

    move v8, v1

    :goto_1b
    if-le v8, v7, :cond_2a

    add-int/lit8 v4, v8, -0x1

    const/4 v5, -0x1

    move-object v1, p0

    move-object v2, p1

    move v3, v8

    move v6, v0

    .line 2198
    invoke-direct/range {v1 .. v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->connect(Landroid/graphics/Canvas;IIII)V

    add-int/lit8 v8, v8, -0x1

    goto :goto_1b

    :cond_2a
    return-void
.end method

.method protected onLayout(ZIIII)V
    .registers 14

    sub-int/2addr p4, p2

    sub-int/2addr p5, p3

    .line 2139
    invoke-direct {p0, p4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->columnWidth(I)I

    move-result p1

    const/4 p2, 0x0

    move p3, p2

    :goto_8
    const/4 p4, 0x7

    if-ge p3, p4, :cond_9c

    .line 2141
    iget p4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->gap:I

    add-int/2addr p4, p1

    mul-int/2addr p4, p3

    move v0, p2

    .line 2142
    :goto_10
    invoke-virtual {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->getChildCount()I

    move-result v1

    const/high16 v2, 0x40000000    # 2.0f

    if-ge v0, v1, :cond_4b

    .line 2143
    invoke-virtual {p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    .line 2144
    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "title"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_48

    .line 2145
    invoke-static {p1, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v3

    iget v4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->headerHeight:I

    .line 2146
    invoke-static {v4, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    .line 2145
    invoke-virtual {v1, v3, v2}, Landroid/view/View;->measure(II)V

    add-int v2, p4, p1

    .line 2147
    iget v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->headerHeight:I

    invoke-virtual {v1, p4, p2, v2, v3}, Landroid/view/View;->layout(IIII)V

    :cond_48
    add-int/lit8 v0, v0, 0x1

    goto :goto_10

    :cond_4b
    move v0, p2

    .line 2150
    :goto_4c
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->COUNT:[I

    aget v1, v1, p3

    if-ge v0, v1, :cond_98

    .line 2151
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->cards:[[Landroid/view/View;

    aget-object v1, v1, p3

    aget-object v1, v1, v0

    if-nez v1, :cond_5b

    goto :goto_95

    .line 2153
    :cond_5b
    invoke-direct {p0, p3, v0, p5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->centre(III)F

    move-result v3

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v3

    .line 2154
    iget v4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->rowHeight:I

    iget v5, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->headerHeight:I

    sub-int v5, p5, v5

    int-to-float v5, v5

    iget-object v6, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->COUNT:[I

    aget v6, v6, p3

    int-to-float v6, v6

    div-float/2addr v5, v6

    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    iget-object v6, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    const/4 v7, 0x6

    invoke-static {v6, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$400(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;I)I

    move-result v6

    sub-int/2addr v5, v6

    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v4

    .line 2155
    invoke-static {p1, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v5

    .line 2156
    invoke-static {v4, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v6

    .line 2155
    invoke-virtual {v1, v5, v6}, Landroid/view/View;->measure(II)V

    .line 2157
    div-int/lit8 v4, v4, 0x2

    sub-int v5, v3, v4

    add-int v6, p4, p1

    add-int/2addr v3, v4

    invoke-virtual {v1, p4, v5, v6, v3}, Landroid/view/View;->layout(IIII)V

    :goto_95
    add-int/lit8 v0, v0, 0x1

    goto :goto_4c

    :cond_98
    add-int/lit8 p3, p3, 0x1

    goto/16 :goto_8

    :cond_9c
    return-void
.end method

.method protected onMeasure(II)V
    .registers 5

    .line 2163
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p1

    .line 2164
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v0

    const/high16 v1, 0x40000000    # 2.0f

    if-ne v0, v1, :cond_11

    .line 2165
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p2

    goto :goto_15

    :cond_11
    invoke-virtual {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->totalHeight()I

    move-result p2

    .line 2164
    :goto_15
    invoke-virtual {p0, p1, p2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->setMeasuredDimension(II)V

    return-void
.end method

.method totalHeight()I
    .registers 5

    .line 2123
    iget v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->fixedHeight:I

    if-lez v0, :cond_5

    return v0

    .line 2124
    :cond_5
    iget v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->headerHeight:I

    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    const/4 v2, 0x6

    invoke-static {v1, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$400(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;I)I

    move-result v1

    add-int/2addr v0, v1

    iget v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->rowHeight:I

    iget-object v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    invoke-static {v3, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$400(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;I)I

    move-result v2

    add-int/2addr v1, v2

    mul-int/lit8 v1, v1, 0x4

    add-int/2addr v0, v1

    return v0
.end method
