.class final Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$StarBadge;
.super Landroid/view/View;
.source "CupTournamentPanel.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "StarBadge"
.end annotation


# instance fields
.field private final paint:Landroid/graphics/Paint;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .registers 3

    .line 840
    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 837
    new-instance p1, Landroid/graphics/Paint;

    const/4 v0, 0x1

    invoke-direct {p1, v0}, Landroid/graphics/Paint;-><init>(I)V

    iput-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$StarBadge;->paint:Landroid/graphics/Paint;

    return-void
.end method


# virtual methods
.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 13

    .line 844
    invoke-virtual {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$StarBadge;->getWidth()I

    move-result v0

    int-to-float v0, v0

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    invoke-virtual {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$StarBadge;->getHeight()I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v2, v1

    invoke-static {v0, v2}, Ljava/lang/Math;->min(FF)F

    move-result v1

    const/high16 v3, 0x3f800000    # 1.0f

    sub-float/2addr v1, v3

    .line 845
    iget-object v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$StarBadge;->paint:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 846
    iget-object v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$StarBadge;->paint:Landroid/graphics/Paint;

    const v4, 0x3db851ec    # 0.09f

    mul-float/2addr v4, v1

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 847
    iget-object v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$StarBadge;->paint:Landroid/graphics/Paint;

    const/16 v5, -0x1eb6

    invoke-virtual {v3, v5}, Landroid/graphics/Paint;->setColor(I)V

    const v3, 0x3f6b851f    # 0.92f

    mul-float v5, v1, v3

    .line 848
    iget-object v6, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$StarBadge;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v2, v5, v6}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 849
    iget-object v5, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$StarBadge;->paint:Landroid/graphics/Paint;

    sget-object v6, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v5, 0x0

    move v6, v5

    :goto_3f
    const/16 v7, 0x8

    if-ge v6, v7, :cond_65

    const-wide v7, 0x401921fb54442d18L    # 6.283185307179586

    int-to-double v9, v6

    mul-double/2addr v9, v7

    const-wide/high16 v7, 0x4020000000000000L    # 8.0

    div-double/2addr v9, v7

    .line 852
    invoke-static {v9, v10}, Ljava/lang/Math;->cos(D)D

    move-result-wide v7

    double-to-float v7, v7

    mul-float/2addr v7, v1

    mul-float/2addr v7, v3

    add-float/2addr v7, v0

    invoke-static {v9, v10}, Ljava/lang/Math;->sin(D)D

    move-result-wide v8

    double-to-float v8, v8

    mul-float/2addr v8, v1

    mul-float/2addr v8, v3

    add-float/2addr v8, v2

    iget-object v9, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$StarBadge;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v7, v8, v4, v9}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    add-int/lit8 v6, v6, 0x1

    goto :goto_3f

    .line 855
    :cond_65
    new-instance v3, Landroid/graphics/Path;

    invoke-direct {v3}, Landroid/graphics/Path;-><init>()V

    :goto_6a
    const/16 v4, 0xa

    if-ge v5, v4, :cond_a4

    const-wide v6, 0x400921fb54442d18L    # Math.PI

    int-to-double v8, v5

    mul-double/2addr v8, v6

    const-wide/high16 v6, 0x4014000000000000L    # 5.0

    div-double/2addr v8, v6

    const-wide v6, -0x4006de04abbbd2e8L    # -1.5707963267948966

    add-double/2addr v8, v6

    .line 858
    rem-int/lit8 v4, v5, 0x2

    if-nez v4, :cond_86

    const v4, 0x3f0ccccd    # 0.55f

    goto :goto_89

    :cond_86
    const v4, 0x3e6b851f    # 0.23f

    :goto_89
    mul-float/2addr v4, v1

    .line 859
    invoke-static {v8, v9}, Ljava/lang/Math;->cos(D)D

    move-result-wide v6

    double-to-float v6, v6

    mul-float/2addr v6, v4

    add-float/2addr v6, v0

    invoke-static {v8, v9}, Ljava/lang/Math;->sin(D)D

    move-result-wide v7

    double-to-float v7, v7

    mul-float/2addr v7, v4

    add-float/2addr v7, v2

    if-nez v5, :cond_9e

    .line 860
    invoke-virtual {v3, v6, v7}, Landroid/graphics/Path;->moveTo(FF)V

    goto :goto_a1

    :cond_9e
    invoke-virtual {v3, v6, v7}, Landroid/graphics/Path;->lineTo(FF)V

    :goto_a1
    add-int/lit8 v5, v5, 0x1

    goto :goto_6a

    .line 862
    :cond_a4
    invoke-virtual {v3}, Landroid/graphics/Path;->close()V

    .line 863
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$StarBadge;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v3, v0}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    return-void
.end method
