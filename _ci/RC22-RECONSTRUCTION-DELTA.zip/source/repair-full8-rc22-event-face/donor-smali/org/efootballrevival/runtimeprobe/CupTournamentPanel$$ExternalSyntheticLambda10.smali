.class public final synthetic Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda10;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/content/DialogInterface$OnDismissListener;


# instance fields
.field public final synthetic f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;


# direct methods
.method public synthetic constructor <init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda10;->f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    return-void
.end method


# virtual methods
.method public final onDismiss(Landroid/content/DialogInterface;)V
    .registers 3

    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda10;->f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    invoke-virtual {v0, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->lambda$new$5$org-efootballrevival-runtimeprobe-CupTournamentPanel(Landroid/content/DialogInterface;)V

    return-void
.end method
