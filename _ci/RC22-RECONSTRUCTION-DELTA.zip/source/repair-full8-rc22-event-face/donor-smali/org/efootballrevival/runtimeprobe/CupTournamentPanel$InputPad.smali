.class final Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;
.super Landroid/view/View;
.source "CupTournamentPanel.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "InputPad"
.end annotation


# instance fields
.field private originX:I

.field private originY:I

.field final synthetic this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;


# direct methods
.method constructor <init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Landroid/content/Context;)V
    .registers 3

    .line 514
    iput-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;->this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    .line 515
    invoke-direct {p0, p2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 8

    .line 524
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-ne v0, v1, :cond_33

    .line 525
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;->this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    invoke-static {v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$200(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_32

    const/4 v3, 0x2

    new-array v3, v3, [I

    .line 528
    invoke-virtual {v0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->getLocationOnScreen([I)V

    .line 529
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result v4

    aget v5, v3, v1

    int-to-float v5, v5

    sub-float/2addr v4, v5

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    move-result p1

    aget v2, v3, v2

    int-to-float v2, v2

    sub-float/2addr p1, v2

    invoke-virtual {v0, v4, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->inHole(FF)Z

    move-result p1

    if-eqz p1, :cond_32

    iget-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;->this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    invoke-static {p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$000(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V

    :cond_32
    return v1

    .line 533
    :cond_33
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;->this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    invoke-static {v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$200(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;

    move-result-object v0

    if-eqz v0, :cond_5d

    .line 534
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;->this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    invoke-static {v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$300(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)Z

    move-result v1

    if-eqz v1, :cond_44

    goto :goto_5d

    .line 535
    :cond_44
    invoke-static {p1}, Landroid/view/MotionEvent;->obtain(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    move-result-object p1

    .line 537
    :try_start_48
    iget v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;->originX:I

    int-to-float v1, v1

    iget v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;->originY:I

    int-to-float v3, v3

    invoke-virtual {p1, v1, v3}, Landroid/view/MotionEvent;->offsetLocation(FF)V

    .line 538
    invoke-virtual {v0, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z
    :try_end_54
    .catchall {:try_start_48 .. :try_end_54} :catchall_58

    .line 540
    invoke-virtual {p1}, Landroid/view/MotionEvent;->recycle()V

    return v2

    :catchall_58
    move-exception v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->recycle()V

    .line 541
    throw v0

    :cond_5d
    :goto_5d
    return v2
.end method

.method setOrigin(II)V
    .registers 3

    .line 519
    iput p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;->originX:I

    .line 520
    iput p2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;->originY:I

    return-void
.end method
