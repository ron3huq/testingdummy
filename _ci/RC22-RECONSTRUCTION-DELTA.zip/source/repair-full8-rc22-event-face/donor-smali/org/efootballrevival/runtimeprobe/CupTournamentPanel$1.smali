.class Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$1;
.super Landroid/app/AlertDialog;
.source "CupTournamentPanel.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;-><init>(Landroid/app/Activity;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

.field final synthetic val$holeRight:I

.field final synthetic val$holeTop:I


# direct methods
.method constructor <init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Landroid/content/Context;III)V
    .registers 6

    .line 320
    iput-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$1;->this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    iput p4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$1;->val$holeRight:I

    iput p5, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$1;->val$holeTop:I

    invoke-direct {p0, p2, p3}, Landroid/app/AlertDialog;-><init>(Landroid/content/Context;I)V

    return-void
.end method


# virtual methods
.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 4

    .line 325
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v1, 0x4

    if-ne v0, v1, :cond_2b

    .line 326
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    const/4 v1, 0x0

    cmpl-float v0, v0, v1

    if-ltz v0, :cond_2b

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    iget v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$1;->val$holeRight:I

    int-to-float v1, v1

    cmpg-float v0, v0, v1

    if-gez v0, :cond_2b

    .line 327
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    move-result v0

    iget v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$1;->val$holeTop:I

    int-to-float v1, v1

    cmpl-float v0, v0, v1

    if-ltz v0, :cond_2b

    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$1;->this$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    invoke-static {v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->access$000(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V

    .line 328
    :cond_2b
    invoke-super {p0, p1}, Landroid/app/AlertDialog;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    return p1
.end method
