.class final Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;
.super Landroid/graphics/drawable/Drawable;
.source "CupTournamentPanel.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "ScreenBackdrop"
.end annotation


# instance fields
.field private final bitmap:Landroid/graphics/Bitmap;

.field private final paint:Landroid/graphics/Paint;

.field private final target:Landroid/graphics/Rect;


# direct methods
.method constructor <init>(Landroid/graphics/Bitmap;II)V
    .registers 10

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v3, p3

    .line 808
    invoke-direct/range {v0 .. v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;-><init>(Landroid/graphics/Bitmap;IIII)V

    return-void
.end method

.method constructor <init>(Landroid/graphics/Bitmap;IIII)V
    .registers 10

    .line 812
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 803
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;->paint:Landroid/graphics/Paint;

    .line 813
    iput-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;->bitmap:Landroid/graphics/Bitmap;

    int-to-float v0, p2

    .line 814
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v0, v2

    int-to-float v2, p3

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v3

    int-to-float v3, v3

    div-float/2addr v2, v3

    invoke-static {v0, v2}, Ljava/lang/Math;->max(FF)F

    move-result v0

    .line 815
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v2

    int-to-float v2, v2

    mul-float/2addr v2, v0

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    .line 816
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result p1

    int-to-float p1, p1

    mul-float/2addr p1, v0

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    sub-int/2addr p2, v2

    .line 817
    div-int/2addr p2, v1

    sub-int/2addr p2, p4

    sub-int/2addr p3, p1

    .line 818
    div-int/2addr p3, v1

    sub-int/2addr p3, p5

    .line 819
    new-instance p4, Landroid/graphics/Rect;

    add-int/2addr v2, p2

    add-int/2addr p1, p3

    invoke-direct {p4, p2, p3, v2, p1}, Landroid/graphics/Rect;-><init>(IIII)V

    iput-object p4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;->target:Landroid/graphics/Rect;

    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .registers 6

    .line 823
    invoke-virtual {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    .line 824
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 825
    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/Rect;)Z

    .line 826
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;->bitmap:Landroid/graphics/Bitmap;

    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;->target:Landroid/graphics/Rect;

    iget-object v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;->paint:Landroid/graphics/Paint;

    const/4 v3, 0x0

    invoke-virtual {p1, v0, v3, v1, v2}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    .line 827
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method public getOpacity()I
    .registers 2

    const/4 v0, -0x1

    return v0
.end method

.method public setAlpha(I)V
    .registers 3

    .line 830
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;->paint:Landroid/graphics/Paint;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setAlpha(I)V

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .registers 3

    .line 831
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;->paint:Landroid/graphics/Paint;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    return-void
.end method
