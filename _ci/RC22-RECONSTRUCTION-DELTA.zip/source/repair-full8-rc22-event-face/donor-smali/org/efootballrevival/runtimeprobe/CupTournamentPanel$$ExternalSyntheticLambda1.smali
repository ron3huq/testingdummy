.class public final synthetic Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;I)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda1;->f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    iput p2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda1;->f$1:I

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda1;->f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    iget v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda1;->f$1:I

    invoke-virtual {v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->lambda$resetCup$19$org-efootballrevival-runtimeprobe-CupTournamentPanel(I)V

    return-void
.end method
