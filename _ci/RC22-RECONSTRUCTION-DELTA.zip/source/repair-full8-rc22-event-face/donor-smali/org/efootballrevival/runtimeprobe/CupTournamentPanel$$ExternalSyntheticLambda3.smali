.class public final synthetic Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;


# direct methods
.method public synthetic constructor <init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda3;->f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda3;->f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    invoke-virtual {v0, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->lambda$celebrationScene$9$org-efootballrevival-runtimeprobe-CupTournamentPanel(Landroid/view/View;)V

    return-void
.end method
