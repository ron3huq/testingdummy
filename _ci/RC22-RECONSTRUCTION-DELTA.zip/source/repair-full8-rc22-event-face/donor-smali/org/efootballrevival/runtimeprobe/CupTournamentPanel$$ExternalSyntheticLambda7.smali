.class public final synthetic Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

.field public final synthetic f$1:Ljava/util/concurrent/FutureTask;

.field public final synthetic f$2:J


# direct methods
.method public synthetic constructor <init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Ljava/util/concurrent/FutureTask;J)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda7;->f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    iput-object p2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda7;->f$1:Ljava/util/concurrent/FutureTask;

    iput-wide p3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda7;->f$2:J

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda7;->f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda7;->f$1:Ljava/util/concurrent/FutureTask;

    iget-wide v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda7;->f$2:J

    invoke-virtual {v0, v1, v2, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->lambda$refresh$8$org-efootballrevival-runtimeprobe-CupTournamentPanel(Ljava/util/concurrent/FutureTask;J)V

    return-void
.end method
