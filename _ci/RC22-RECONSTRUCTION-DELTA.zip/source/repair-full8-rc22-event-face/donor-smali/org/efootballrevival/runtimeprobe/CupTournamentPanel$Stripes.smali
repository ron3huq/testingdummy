.class final Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$Stripes;
.super Landroid/graphics/drawable/Drawable;
.source "CupTournamentPanel.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Stripes"
.end annotation


# instance fields
.field private final clip:Landroid/graphics/Path;

.field private final paint:Landroid/graphics/Paint;

.field private final radius:F

.field private final step:F


# direct methods
.method constructor <init>(IFFF)V
    .registers 7

    .line 776
    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    .line 771
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$Stripes;->paint:Landroid/graphics/Paint;

    .line 772
    new-instance v1, Landroid/graphics/Path;

    invoke-direct {v1}, Landroid/graphics/Path;-><init>()V

    iput-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$Stripes;->clip:Landroid/graphics/Path;

    .line 777
    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColor(I)V

    .line 778
    invoke-virtual {v0, p2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/high16 p1, 0x41000000    # 8.0f

    add-float/2addr p3, p2

    .line 779
    invoke-static {p1, p3}, Ljava/lang/Math;->max(FF)F

    move-result p1

    iput p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$Stripes;->step:F

    .line 780
    iput p4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$Stripes;->radius:F

    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .registers 10

    .line 784
    invoke-virtual {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$Stripes;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    .line 785
    invoke-virtual {v0}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_b

    return-void

    .line 786
    :cond_b
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$Stripes;->clip:Landroid/graphics/Path;

    invoke-virtual {v1}, Landroid/graphics/Path;->reset()V

    .line 787
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$Stripes;->clip:Landroid/graphics/Path;

    new-instance v2, Landroid/graphics/RectF;

    invoke-direct {v2, v0}, Landroid/graphics/RectF;-><init>(Landroid/graphics/Rect;)V

    iget v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$Stripes;->radius:F

    sget-object v4, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    invoke-virtual {v1, v2, v3, v3, v4}, Landroid/graphics/Path;->addRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Path$Direction;)V

    .line 788
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 789
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$Stripes;->clip:Landroid/graphics/Path;

    invoke-virtual {p1, v1}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    .line 790
    iget v1, v0, Landroid/graphics/Rect;->left:I

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v2

    sub-int/2addr v1, v2

    int-to-float v1, v1

    :goto_2e
    iget v2, v0, Landroid/graphics/Rect;->right:I

    int-to-float v2, v2

    cmpg-float v2, v1, v2

    if-gez v2, :cond_4d

    .line 791
    iget v2, v0, Landroid/graphics/Rect;->bottom:I

    int-to-float v4, v2

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v2

    int-to-float v2, v2

    add-float v5, v1, v2

    iget v2, v0, Landroid/graphics/Rect;->top:I

    int-to-float v6, v2

    iget-object v7, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$Stripes;->paint:Landroid/graphics/Paint;

    move-object v2, p1

    move v3, v1

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 790
    iget v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$Stripes;->step:F

    add-float/2addr v1, v2

    goto :goto_2e

    .line 793
    :cond_4d
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method public getOpacity()I
    .registers 2

    const/4 v0, -0x3

    return v0
.end method

.method public setAlpha(I)V
    .registers 3

    .line 796
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$Stripes;->paint:Landroid/graphics/Paint;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setAlpha(I)V

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .registers 3

    .line 797
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$Stripes;->paint:Landroid/graphics/Paint;

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    return-void
.end method
