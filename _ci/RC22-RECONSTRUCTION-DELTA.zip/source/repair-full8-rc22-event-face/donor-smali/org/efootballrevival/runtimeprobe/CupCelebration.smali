.class public final Lorg/efootballrevival/runtimeprobe/CupCelebration;
.super Landroid/view/View;
.source "CupCelebration.java"


# static fields
.field private static final SKETCH_H:F = 410.0f

.field private static final SKETCH_W:F = 900.0f

.field public static volatile startMs:J

.field private static trophyUcl:Landroid/graphics/Bitmap;

.field private static trophyWorld:Landroid/graphics/Bitmap;


# instance fields
.field private final championId:I

.field private final championName:Ljava/lang/String;

.field private final draws:I

.field private final english:Z

.field private final goalsAgainst:I

.field private final goalsFor:I

.field private final gold:I

.field private final goldHi:I

.field private final label:[Ljava/lang/String;

.field private final line:I

.field private final muted:I

.field private final note:[Ljava/lang/String;

.field private final opponent:[Ljava/lang/String;

.field private final opponentId:[I

.field private final paint:Landroid/graphics/Paint;

.field private final path:Landroid/graphics/Path;

.field private final played:I

.field private final rect:Landroid/graphics/RectF;

.field private final result:[Ljava/lang/String;

.field private final rows:I

.field private final score:[Ljava/lang/String;

.field private final section:[Ljava/lang/String;

.field private final specks:[[F

.field private final text:Landroid/graphics/Paint;

.field private final title:Ljava/lang/String;

.field private final trophy:Landroid/graphics/Bitmap;

.field private final wins:I

.field private final worldCup:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 37
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    sput-wide v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->startMs:J

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lorg/json/JSONObject;ZZLjava/lang/String;)V
    .registers 14

    .line 71
    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 60
    new-instance v0, Landroid/graphics/Paint;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    .line 61
    new-instance v0, Landroid/graphics/Paint;

    const/4 v2, 0x1

    invoke-direct {v0, v2}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    .line 62
    new-instance v0, Landroid/graphics/Path;

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    iput-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->path:Landroid/graphics/Path;

    .line 63
    new-instance v0, Landroid/graphics/RectF;

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    iput-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rect:Landroid/graphics/RectF;

    .line 72
    iput-boolean p3, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->worldCup:Z

    .line 73
    iput-boolean p4, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->english:Z

    .line 74
    iput-object p5, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->title:Ljava/lang/String;

    if-eqz p3, :cond_2d

    const p4, -0x264ba6

    goto :goto_30

    :cond_2d
    const p4, -0x604701

    .line 75
    :goto_30
    iput p4, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->gold:I

    if-eqz p3, :cond_38

    const p4, -0x91c5f

    goto :goto_3b

    :cond_38
    const p4, -0x1d1401

    .line 76
    :goto_3b
    iput p4, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->goldHi:I

    if-eqz p3, :cond_43

    const p4, -0x5c131b33

    goto :goto_46

    :cond_43
    const p4, -0x59291f01

    .line 77
    :goto_46
    iput p4, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->muted:I

    if-eqz p3, :cond_4e

    const p4, 0x38d9b45a

    goto :goto_51

    :cond_4e
    const p4, 0x3d9fb8ff

    .line 78
    :goto_51
    iput p4, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->line:I

    const-string p4, "championName"

    const-string p5, ""

    .line 79
    invoke-virtual {p2, p4, p5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p4

    iput-object p4, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->championName:Ljava/lang/String;

    const-string p4, "championId"

    .line 80
    invoke-virtual {p2, p4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result p4

    iput p4, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->championId:I

    const-string p4, "played"

    .line 81
    invoke-virtual {p2, p4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result p4

    iput p4, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->played:I

    const-string p4, "win"

    .line 82
    invoke-virtual {p2, p4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result p4

    iput p4, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->wins:I

    const-string p4, "draw"

    .line 83
    invoke-virtual {p2, p4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result p4

    iput p4, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->draws:I

    const-string p4, "goalsFor"

    .line 84
    invoke-virtual {p2, p4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result p5

    iput p5, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->goalsFor:I

    const-string p5, "goalsAgainst"

    .line 85
    invoke-virtual {p2, p5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    iput v0, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->goalsAgainst:I

    const-string v0, "rows"

    .line 86
    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p2

    const/4 v0, 0x0

    if-nez p2, :cond_98

    move v3, v0

    goto :goto_9c

    .line 87
    :cond_98
    invoke-virtual {p2}, Lorg/json/JSONArray;->length()I

    move-result v3

    :goto_9c
    iput v3, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rows:I

    .line 88
    new-array v4, v3, [Ljava/lang/String;

    iput-object v4, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->section:[Ljava/lang/String;

    .line 89
    new-array v4, v3, [Ljava/lang/String;

    iput-object v4, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->label:[Ljava/lang/String;

    .line 90
    new-array v4, v3, [Ljava/lang/String;

    iput-object v4, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->opponent:[Ljava/lang/String;

    .line 91
    new-array v4, v3, [I

    iput-object v4, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->opponentId:[I

    .line 92
    new-array v4, v3, [Ljava/lang/String;

    iput-object v4, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->score:[Ljava/lang/String;

    .line 93
    new-array v4, v3, [Ljava/lang/String;

    iput-object v4, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->result:[Ljava/lang/String;

    .line 94
    new-array v3, v3, [Ljava/lang/String;

    iput-object v3, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->note:[Ljava/lang/String;

    move v3, v0

    .line 95
    :goto_bb
    iget v4, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rows:I

    if-ge v3, v4, :cond_124

    .line 96
    invoke-virtual {p2, v3}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    .line 97
    iget-object v5, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->section:[Ljava/lang/String;

    const-string v6, "section"

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v5, v3

    .line 98
    iget-object v5, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->label:[Ljava/lang/String;

    const-string v6, "label"

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v5, v3

    .line 99
    iget-object v5, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->opponent:[Ljava/lang/String;

    const-string v6, "opponent"

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v5, v3

    .line 100
    iget-object v5, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->opponentId:[I

    const-string v6, "opponentId"

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v6

    aput v6, v5, v3

    .line 101
    iget-object v5, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->score:[Ljava/lang/String;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, p4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v7, " \u2013 "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    aput-object v6, v5, v3

    .line 102
    iget-object v5, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->result:[Ljava/lang/String;

    const-string v6, "result"

    const-string v7, "W"

    invoke-virtual {v4, v6, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    aput-object v6, v5, v3

    .line 103
    iget-object v5, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->note:[Ljava/lang/String;

    const-string v6, "note"

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    aput-object v4, v5, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_bb

    .line 105
    :cond_124
    invoke-static {p1, p3}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->trophyFor(Landroid/content/Context;Z)Landroid/graphics/Bitmap;

    move-result-object p1

    iput-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->trophy:Landroid/graphics/Bitmap;

    .line 106
    new-instance p1, Ljava/util/Random;

    const-wide/32 p2, 0x13528f0

    invoke-direct {p1, p2, p3}, Ljava/util/Random;-><init>(J)V

    const/16 p2, 0x2e

    new-array p2, p2, [[F

    .line 107
    iput-object p2, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->specks:[[F

    move p2, v0

    .line 108
    :goto_139
    iget-object p3, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->specks:[[F

    array-length p4, p3

    if-ge p2, p4, :cond_1a3

    const/4 p4, 0x7

    new-array p4, p4, [F

    .line 109
    invoke-virtual {p1}, Ljava/util/Random;->nextFloat()F

    move-result p5

    const/high16 v3, 0x437a0000    # 250.0f

    mul-float/2addr p5, v3

    const/high16 v3, 0x428c0000    # 70.0f

    add-float/2addr p5, v3

    aput p5, p4, v0

    invoke-virtual {p1}, Ljava/util/Random;->nextFloat()F

    move-result p5

    const/high16 v3, 0x43a00000    # 320.0f

    mul-float/2addr p5, v3

    const/high16 v3, 0x42700000    # 60.0f

    add-float/2addr p5, v3

    aput p5, p4, v2

    .line 110
    invoke-virtual {p1}, Ljava/util/Random;->nextFloat()F

    move-result p5

    const v3, 0x3fb33333    # 1.4f

    mul-float/2addr p5, v3

    const v3, 0x3ecccccd    # 0.4f

    add-float/2addr p5, v3

    const/4 v3, 0x2

    aput p5, p4, v3

    invoke-virtual {p1}, Ljava/util/Random;->nextFloat()F

    move-result p5

    const v3, 0x3e3851ec    # 0.18f

    mul-float/2addr p5, v3

    const v3, 0x3d4ccccd    # 0.05f

    add-float/2addr p5, v3

    aput p5, p4, v1

    .line 111
    invoke-virtual {p1}, Ljava/util/Random;->nextFloat()F

    move-result p5

    const/high16 v3, 0x3f000000    # 0.5f

    sub-float/2addr p5, v3

    const v3, 0x3df5c28f    # 0.12f

    mul-float/2addr p5, v3

    const/4 v3, 0x4

    aput p5, p4, v3

    invoke-virtual {p1}, Ljava/util/Random;->nextFloat()F

    move-result p5

    const v3, 0x40c8f5c3    # 6.28f

    mul-float/2addr p5, v3

    const/4 v3, 0x5

    aput p5, p4, v3

    invoke-virtual {p1}, Ljava/util/Random;->nextFloat()F

    move-result p5

    const v3, 0x3ca3d70a    # 0.02f

    mul-float/2addr p5, v3

    const v3, 0x3c03126f    # 0.008f

    add-float/2addr p5, v3

    const/4 v3, 0x6

    aput p5, p4, v3

    aput-object p4, p3, p2

    add-int/lit8 p2, p2, 0x1

    goto :goto_139

    :cond_1a3
    return-void
.end method

.method private alpha(IF)I
    .registers 4

    ushr-int/lit8 v0, p1, 0x18

    and-int/lit16 v0, v0, 0xff

    int-to-float v0, v0

    .line 146
    invoke-static {p2}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->clamp01(F)F

    move-result p2

    mul-float/2addr v0, p2

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result p2

    shl-int/lit8 p2, p2, 0x18

    const v0, 0xffffff

    and-int/2addr p1, v0

    or-int/2addr p1, p2

    return p1
.end method

.method private static clamp01(F)F
    .registers 3

    const/4 v0, 0x0

    cmpg-float v1, p0, v0

    if-gez v1, :cond_7

    :goto_5
    move p0, v0

    goto :goto_e

    :cond_7
    const/high16 v0, 0x3f800000    # 1.0f

    cmpl-float v1, p0, v0

    if-lez v1, :cond_e

    goto :goto_5

    :cond_e
    :goto_e
    return p0
.end method

.method private drawBackdrop(Landroid/graphics/Canvas;FFFFF)V
    .registers 26

    move-object/from16 v0, p0

    move-object/from16 v7, p1

    move/from16 v8, p6

    .line 167
    iget-boolean v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->worldCup:Z

    if-eqz v1, :cond_18

    const v1, -0xf8d5e8

    const v2, -0xfcf0f7

    const v3, -0xf0b5d4

    filled-new-array {v3, v1, v2}, [I

    move-result-object v1

    goto :goto_25

    :cond_18
    const v1, -0xf5e59e

    const v2, -0xfcf8e0

    const v3, -0xe4c558

    .line 168
    filled-new-array {v3, v1, v2}, [I

    move-result-object v1

    :goto_25
    move-object v13, v1

    const/high16 v1, 0x43580000    # 216.0f

    mul-float v1, v1, p4

    add-float v10, p5, v1

    const/high16 v1, 0x3f000000    # 0.5f

    mul-float v11, p3, v1

    .line 171
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    new-instance v2, Landroid/graphics/RadialGradient;

    invoke-static/range {p2 .. p3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    const v4, 0x3f47ae14    # 0.78f

    mul-float v12, v3, v4

    const/4 v6, 0x3

    new-array v14, v6, [F

    fill-array-data v14, :array_150

    sget-object v15, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    move-object v9, v2

    invoke-direct/range {v9 .. v15}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    const/4 v2, 0x0

    const/4 v3, 0x0

    .line 173
    iget-object v9, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    move-object/from16 v1, p1

    move/from16 v4, p2

    move/from16 v5, p3

    move v10, v6

    move-object v6, v9

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 174
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    const/4 v9, 0x0

    invoke-virtual {v1, v9}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    const v1, 0x3e99999a    # 0.3f

    const/high16 v2, 0x40000000    # 2.0f

    .line 176
    invoke-static {v8, v1, v2}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->ramp(FFF)F

    move-result v1

    invoke-static {v1}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->easeOut(F)F

    move-result v1

    cmpl-float v4, v1, v3

    const/high16 v5, 0x432f0000    # 175.0f

    if-lez v4, :cond_d3

    .line 178
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    new-instance v6, Landroid/graphics/LinearGradient;

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    const v11, 0x3f666666    # 0.9f

    mul-float v15, p3, v11

    const v11, 0x3e19999a    # 0.15f

    mul-float/2addr v1, v11

    const/16 v11, -0x1356

    invoke-direct {v0, v11, v1}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v16

    const v17, 0xffecaa

    sget-object v18, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    move-object v11, v6

    move v1, v15

    invoke-direct/range {v11 .. v18}, Landroid/graphics/LinearGradient;-><init>(FFFFIILandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 180
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->path:Landroid/graphics/Path;

    invoke-virtual {v4}, Landroid/graphics/Path;->reset()V

    .line 181
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->path:Landroid/graphics/Path;

    mul-float v6, p4, v5

    add-float v6, p5, v6

    const/high16 v11, 0x41b00000    # 22.0f

    mul-float v11, v11, p4

    sub-float v12, v6, v11

    invoke-virtual {v4, v12, v3}, Landroid/graphics/Path;->moveTo(FF)V

    .line 182
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->path:Landroid/graphics/Path;

    add-float/2addr v11, v6

    invoke-virtual {v4, v11, v3}, Landroid/graphics/Path;->lineTo(FF)V

    .line 183
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->path:Landroid/graphics/Path;

    const/high16 v11, 0x43160000    # 150.0f

    mul-float v11, v11, p4

    add-float v12, v6, v11

    invoke-virtual {v4, v12, v1}, Landroid/graphics/Path;->lineTo(FF)V

    .line 184
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->path:Landroid/graphics/Path;

    sub-float/2addr v6, v11

    invoke-virtual {v4, v6, v1}, Landroid/graphics/Path;->lineTo(FF)V

    .line 185
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->path:Landroid/graphics/Path;

    invoke-virtual {v1}, Landroid/graphics/Path;->close()V

    .line 186
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->path:Landroid/graphics/Path;

    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v7, v1, v4}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 187
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, v9}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    :cond_d3
    const v1, 0x3ecccccd    # 0.4f

    .line 190
    invoke-static {v8, v1, v2}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->ramp(FFF)F

    move-result v1

    invoke-static {v1}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->easeOut(F)F

    move-result v1

    cmpl-float v3, v1, v3

    if-lez v3, :cond_115

    mul-float v3, p4, v5

    add-float v3, p5, v3

    const/high16 v4, 0x432a0000    # 170.0f

    mul-float v4, v4, p4

    .line 194
    iget-object v5, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    new-instance v6, Landroid/graphics/RadialGradient;

    const/high16 v8, 0x43020000    # 130.0f

    mul-float v8, v8, p4

    iget v11, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->goldHi:I

    const v12, 0x3eae147b    # 0.34f

    mul-float/2addr v1, v12

    invoke-direct {v0, v11, v1}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v15

    const v16, 0xffffff

    sget-object v17, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    move-object v11, v6

    move v12, v3

    move v13, v4

    move v14, v8

    invoke-direct/range {v11 .. v17}, Landroid/graphics/RadialGradient;-><init>(FFFIILandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v5, v6}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 196
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v7, v3, v4, v8, v1}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 197
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, v9}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 200
    :cond_115
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/RadialGradient;

    div-float v12, p2, v2

    div-float v13, p3, v2

    invoke-static/range {p2 .. p3}, Ljava/lang/Math;->max(FF)F

    move-result v2

    const v4, 0x3f1eb852    # 0.62f

    mul-float v14, v2, v4

    const/high16 v2, -0x74000000

    const/4 v4, 0x0

    filled-new-array {v4, v4, v2}, [I

    move-result-object v15

    new-array v2, v10, [F

    fill-array-data v2, :array_15a

    sget-object v17, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    move-object v11, v3

    move-object/from16 v16, v2

    invoke-direct/range {v11 .. v17}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    const/4 v2, 0x0

    const/4 v3, 0x0

    .line 202
    iget-object v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    move-object/from16 v1, p1

    move/from16 v4, p2

    move/from16 v5, p3

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 203
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, v9}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    return-void

    :array_150
    .array-data 4
        0x0
        0x3ee66666    # 0.45f
        0x3f800000    # 1.0f
    .end array-data

    :array_15a
    .array-data 4
        0x0
        0x3f0ccccd    # 0.55f
        0x3f800000    # 1.0f
    .end array-data
.end method

.method private drawLeft(Landroid/graphics/Canvas;FFF)V
    .registers 32

    move-object/from16 v0, p0

    move-object/from16 v7, p1

    move/from16 v8, p4

    const/high16 v1, 0x432f0000    # 175.0f

    mul-float v1, v1, p2

    add-float v9, p3, v1

    const v1, 0x3e99999a    # 0.3f

    const/high16 v10, 0x40000000    # 2.0f

    .line 220
    invoke-static {v8, v1, v10}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->ramp(FFF)F

    move-result v2

    const v3, 0x3fcccccd    # 1.6f

    .line 221
    invoke-static {v8, v1, v3}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->ramp(FFF)F

    move-result v11

    const/high16 v1, 0x43560000    # 214.0f

    mul-float v1, v1, p2

    const/high16 v3, 0x41d00000    # 26.0f

    mul-float v4, p2, v3

    .line 223
    invoke-static {v2}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->easeOut(F)F

    move-result v2

    const/high16 v12, 0x3f800000    # 1.0f

    sub-float v2, v12, v2

    mul-float/2addr v2, v3

    mul-float v2, v2, p2

    add-float/2addr v4, v2

    .line 224
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->trophy:Landroid/graphics/Bitmap;

    const/16 v13, 0xff

    const/high16 v14, 0x437f0000    # 255.0f

    const/4 v15, 0x0

    const/4 v6, 0x0

    if-eqz v2, :cond_dd

    cmpl-float v3, v11, v6

    if-lez v3, :cond_dd

    .line 225
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v2

    int-to-float v2, v2

    mul-float/2addr v2, v1

    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->trophy:Landroid/graphics/Bitmap;

    invoke-virtual {v3}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v3

    int-to-float v3, v3

    div-float/2addr v2, v3

    .line 226
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rect:Landroid/graphics/RectF;

    div-float/2addr v2, v10

    sub-float v5, v9, v2

    add-float/2addr v2, v9

    add-float/2addr v1, v4

    invoke-virtual {v3, v5, v4, v2, v1}, Landroid/graphics/RectF;->set(FFFF)V

    const/high16 v3, 0x42700000    # 60.0f

    mul-float v3, v3, p2

    add-float v24, v1, v3

    const/16 v16, 0x0

    move v4, v1

    move-object/from16 v1, p1

    move/from16 v25, v2

    move v2, v5

    move v3, v4

    move v10, v4

    move/from16 v4, v25

    move/from16 v26, v5

    move/from16 v5, v24

    move-object/from16 v6, v16

    .line 229
    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->saveLayer(FFFFLandroid/graphics/Paint;)I

    move-result v6

    .line 230
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    const/high16 v1, -0x40800000    # -1.0f

    .line 231
    invoke-virtual {v7, v12, v1, v9, v10}, Landroid/graphics/Canvas;->scale(FFFF)V

    .line 232
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    mul-float/2addr v11, v14

    invoke-static {v11}, Ljava/lang/Math;->round(F)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 233
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->trophy:Landroid/graphics/Bitmap;

    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rect:Landroid/graphics/RectF;

    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v7, v1, v15, v2, v3}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 234
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->restore()V

    .line 235
    new-instance v12, Landroid/graphics/Paint;

    invoke-direct {v12}, Landroid/graphics/Paint;-><init>()V

    .line 236
    new-instance v1, Landroid/graphics/PorterDuffXfermode;

    sget-object v2, Landroid/graphics/PorterDuff$Mode;->DST_IN:Landroid/graphics/PorterDuff$Mode;

    invoke-direct {v1, v2}, Landroid/graphics/PorterDuffXfermode;-><init>(Landroid/graphics/PorterDuff$Mode;)V

    invoke-virtual {v12, v1}, Landroid/graphics/Paint;->setXfermode(Landroid/graphics/Xfermode;)Landroid/graphics/Xfermode;

    .line 237
    new-instance v1, Landroid/graphics/LinearGradient;

    const/16 v17, 0x0

    const/16 v19, 0x0

    const v21, 0x48ffffff

    const v22, 0xffffff

    sget-object v23, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    move-object/from16 v16, v1

    move/from16 v18, v10

    move/from16 v20, v24

    invoke-direct/range {v16 .. v23}, Landroid/graphics/LinearGradient;-><init>(FFFFIILandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v12, v1}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    move-object/from16 v1, p1

    move/from16 v2, v26

    move v3, v10

    move v10, v6

    move-object v6, v12

    .line 239
    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 240
    invoke-virtual {v7, v10}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 241
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-static {v11}, Ljava/lang/Math;->round(F)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 242
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->trophy:Landroid/graphics/Bitmap;

    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rect:Landroid/graphics/RectF;

    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v7, v1, v15, v2, v3}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 243
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, v13}, Landroid/graphics/Paint;->setAlpha(I)V

    :cond_dd
    const v10, 0x3f99999a    # 1.2f

    .line 246
    invoke-static {v8, v10, v10}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->ramp(FFF)F

    move-result v1

    .line 247
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 248
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 249
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/high16 v3, 0x3f000000    # 0.5f

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setLetterSpacing(F)V

    .line 250
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/high16 v4, 0x41400000    # 12.0f

    mul-float v4, v4, p2

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 251
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    iget v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->gold:I

    invoke-direct {v0, v4, v1}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v1

    invoke-virtual {v2, v1}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v1, 0x40400000    # 3.0f

    mul-float v1, v1, p2

    add-float/2addr v1, v9

    const/high16 v2, 0x438a0000    # 276.0f

    mul-float v2, v2, p2

    .line 252
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const-string v5, "CHAMPIONS"

    invoke-virtual {v7, v5, v1, v2, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 253
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/4 v11, 0x0

    invoke-virtual {v1, v11}, Landroid/graphics/Paint;->setLetterSpacing(F)V

    const/high16 v1, 0x3fc00000    # 1.5f

    .line 255
    invoke-static {v8, v1, v10}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->ramp(FFF)F

    move-result v1

    .line 256
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Typeface;->SERIF:Landroid/graphics/Typeface;

    const/4 v5, 0x1

    invoke-static {v4, v5}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 257
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/high16 v4, 0x42000000    # 32.0f

    mul-float v4, v4, p2

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 258
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    iget v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->goldHi:I

    invoke-direct {v0, v4, v1}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 259
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->championName:Ljava/lang/String;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v2

    const/high16 v4, 0x41f00000    # 30.0f

    mul-float v4, v4, p2

    .line 261
    iget v5, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->championId:I

    if-lez v5, :cond_15e

    invoke-static {v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->crestBitmap(I)Landroid/graphics/Bitmap;

    move-result-object v5

    goto :goto_15f

    :cond_15e
    move-object v5, v15

    :goto_15f
    const/high16 v6, 0x41200000    # 10.0f

    if-eqz v5, :cond_167

    mul-float v12, p2, v6

    add-float/2addr v12, v4

    goto :goto_168

    :cond_167
    move v12, v11

    :goto_168
    add-float/2addr v2, v12

    const/high16 v12, 0x40000000    # 2.0f

    div-float/2addr v2, v12

    sub-float v2, v9, v2

    if-eqz v5, :cond_197

    .line 265
    iget-object v12, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rect:Landroid/graphics/RectF;

    const/high16 v16, 0x43940000    # 296.0f

    mul-float v3, p2, v16

    add-float v11, v2, v4

    add-float v10, v3, v4

    invoke-virtual {v12, v2, v3, v11, v10}, Landroid/graphics/RectF;->set(FFFF)V

    .line 266
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    mul-float/2addr v1, v14

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-virtual {v3, v1}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 267
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rect:Landroid/graphics/RectF;

    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v7, v5, v15, v1, v3}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 268
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, v13}, Landroid/graphics/Paint;->setAlpha(I)V

    mul-float v1, p2, v6

    add-float/2addr v4, v1

    add-float/2addr v2, v4

    .line 271
    :cond_197
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 272
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->championName:Ljava/lang/String;

    const/high16 v3, 0x43a00000    # 320.0f

    mul-float v3, v3, p2

    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    invoke-virtual {v7, v1, v2, v3, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    const v1, 0x3fd9999a    # 1.7f

    const v2, 0x3f99999a    # 1.2f

    .line 274
    invoke-static {v8, v1, v2}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->ramp(FFF)F

    move-result v1

    invoke-static {v1}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->easeOut(F)F

    move-result v1

    const/4 v2, 0x0

    cmpl-float v3, v1, v2

    if-lez v3, :cond_200

    .line 276
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/LinearGradient;

    const/high16 v4, 0x42960000    # 75.0f

    mul-float v4, v4, p2

    sub-float v19, v9, v4

    const/16 v20, 0x0

    add-float v21, v9, v4

    const/16 v22, 0x0

    iget v5, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->gold:I

    const v6, 0xffffff

    and-int v10, v5, v6

    and-int/2addr v6, v5

    filled-new-array {v10, v5, v6}, [I

    move-result-object v23

    const/16 v24, 0x0

    sget-object v25, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    move-object/from16 v18, v3

    invoke-direct/range {v18 .. v25}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    mul-float/2addr v4, v1

    sub-float v2, v9, v4

    const/high16 v1, 0x43a60000    # 332.0f

    mul-float v3, p2, v1

    add-float/2addr v4, v9

    const v1, 0x43a68000    # 333.0f

    mul-float v1, v1, p2

    const/high16 v5, 0x3f000000    # 0.5f

    add-float/2addr v5, v1

    .line 278
    iget-object v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    move-object/from16 v1, p1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 279
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, v15}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    :cond_200
    const v1, 0x3f99999a    # 1.2f

    const/high16 v2, 0x40000000    # 2.0f

    .line 282
    invoke-static {v8, v2, v1}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->ramp(FFF)F

    move-result v1

    .line 283
    iget v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->played:I

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    iget v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->wins:I

    invoke-static {v3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    iget v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->draws:I

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    iget v5, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->goalsFor:I

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    filled-new-array {v2, v3, v4, v5}, [Ljava/lang/String;

    move-result-object v2

    .line 284
    iget-boolean v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->english:Z

    if-eqz v3, :cond_236

    const-string v3, "DRAWN"

    const-string v4, "GOALS"

    const-string v5, "PLAYED"

    const-string v6, "WON"

    filled-new-array {v5, v6, v3, v4}, [Ljava/lang/String;

    move-result-object v3

    goto :goto_242

    :cond_236
    const-string v3, "\u5e73"

    const-string v4, "\u8fdb\u7403"

    const-string v5, "\u573a\u6b21"

    const-string v6, "\u80dc"

    .line 285
    filled-new-array {v5, v6, v3, v4}, [Ljava/lang/String;

    move-result-object v3

    :goto_242
    const/4 v4, 0x4

    new-array v5, v4, [F

    .line 286
    fill-array-data v5, :array_2ba

    .line 287
    iget-object v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v8, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v6, v8}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    const/4 v6, 0x0

    :goto_250
    if-ge v6, v4, :cond_2b9

    .line 289
    iget-object v8, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v10, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v8, v10}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 290
    iget-object v8, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/high16 v10, 0x41b00000    # 22.0f

    mul-float v10, v10, p2

    invoke-virtual {v8, v10}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 291
    iget-object v8, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/4 v10, -0x1

    invoke-direct {v0, v10, v1}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v10

    invoke-virtual {v8, v10}, Landroid/graphics/Paint;->setColor(I)V

    .line 292
    aget-object v8, v2, v6

    aget v10, v5, v6

    mul-float v10, v10, p2

    add-float/2addr v10, v9

    const/high16 v11, 0x43b40000    # 360.0f

    mul-float v11, v11, p2

    iget-object v12, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v10, v11, v12}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 293
    iget-object v8, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/high16 v10, 0x41300000    # 11.0f

    mul-float v10, v10, p2

    invoke-virtual {v8, v10}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 294
    iget-object v8, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    iget-boolean v10, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->english:Z

    if-eqz v10, :cond_28f

    const v10, 0x3df5c28f    # 0.12f

    goto :goto_292

    :cond_28f
    const v10, 0x3e4ccccd    # 0.2f

    :goto_292
    invoke-virtual {v8, v10}, Landroid/graphics/Paint;->setLetterSpacing(F)V

    .line 295
    iget-object v8, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    iget v10, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->muted:I

    invoke-direct {v0, v10, v1}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v10

    invoke-virtual {v8, v10}, Landroid/graphics/Paint;->setColor(I)V

    .line 296
    aget-object v8, v3, v6

    aget v10, v5, v6

    mul-float v10, v10, p2

    add-float/2addr v10, v9

    const/high16 v11, 0x43bd0000    # 378.0f

    mul-float v11, v11, p2

    iget-object v12, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v10, v11, v12}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 297
    iget-object v8, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/4 v10, 0x0

    invoke-virtual {v8, v10}, Landroid/graphics/Paint;->setLetterSpacing(F)V

    add-int/lit8 v6, v6, 0x1

    goto :goto_250

    :cond_2b9
    return-void

    :array_2ba
    .array-data 4
        -0x3d7c0000    # -66.0f
        -0x3e500000    # -22.0f
        0x41b00000    # 22.0f
        0x42840000    # 66.0f
    .end array-data
.end method

.method private drawRight(Landroid/graphics/Canvas;FFF)V
    .registers 42

    move-object/from16 v0, p0

    move-object/from16 v7, p1

    move/from16 v8, p2

    move/from16 v9, p4

    .line 305
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 306
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v2, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 307
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const v2, 0x3e99999a    # 0.3f

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setLetterSpacing(F)V

    .line 308
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/high16 v10, 0x41400000    # 12.0f

    mul-float v11, v8, v10

    invoke-virtual {v1, v11}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 309
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    iget v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->gold:I

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v1, 0x43ba0000    # 372.0f

    mul-float/2addr v1, v8

    add-float v2, p3, v1

    const/high16 v1, 0x42580000    # 54.0f

    mul-float/2addr v1, v8

    .line 310
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const-string v4, "THE ROAD"

    invoke-virtual {v7, v4, v2, v1, v3}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 311
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v3

    add-float/2addr v3, v11

    .line 312
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/4 v12, 0x0

    invoke-virtual {v4, v12}, Landroid/graphics/Paint;->setLetterSpacing(F)V

    .line 313
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/high16 v13, 0x41500000    # 13.0f

    mul-float v5, v8, v13

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 314
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    iget v5, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->muted:I

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 315
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->title:Ljava/lang/String;

    add-float/2addr v3, v2

    iget-object v5, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    invoke-virtual {v7, v4, v3, v1, v5}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 316
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    iget v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->line:I

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v14, 0x42780000    # 62.0f

    mul-float v3, v8, v14

    const v15, 0x44598000    # 870.0f

    mul-float v1, v8, v15

    add-float v16, p3, v1

    const/high16 v6, 0x3f000000    # 0.5f

    mul-float v5, v8, v6

    const/high16 v4, 0x3f800000    # 1.0f

    .line 317
    invoke-static {v4, v5}, Ljava/lang/Math;->max(FF)F

    move-result v1

    add-float v17, v3, v1

    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    move-object/from16 v18, v1

    move-object/from16 v1, p1

    move v10, v4

    move/from16 v4, v16

    move v13, v5

    move/from16 v5, v17

    move v14, v6

    move-object/from16 v6, v18

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 320
    iget v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rows:I

    new-array v6, v1, [F

    .line 321
    new-array v5, v1, [F

    .line 322
    new-array v4, v1, [Z

    const-string v1, ""

    const/4 v3, 0x0

    move v2, v3

    const/high16 v17, 0x42780000    # 62.0f

    .line 325
    :goto_a0
    iget v15, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rows:I

    const/high16 v19, 0x40000000    # 2.0f

    const/4 v10, 0x1

    if-ge v2, v15, :cond_dc

    .line 326
    iget-object v15, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->section:[Ljava/lang/String;

    aget-object v15, v15, v2

    invoke-virtual {v15, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-nez v15, :cond_c1

    .line 327
    aput-boolean v10, v4, v2

    const/high16 v1, 0x41880000    # 17.0f

    add-float v1, v17, v1

    .line 328
    aput v1, v5, v2

    const/high16 v1, 0x41c00000    # 24.0f

    add-float v17, v17, v1

    .line 330
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->section:[Ljava/lang/String;

    aget-object v1, v1, v2

    .line 332
    :cond_c1
    iget v15, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rows:I

    sub-int/2addr v15, v10

    if-ne v2, v15, :cond_c7

    goto :goto_c8

    :cond_c7
    move v10, v3

    :goto_c8
    if-eqz v10, :cond_cd

    const/high16 v10, 0x42500000    # 52.0f

    goto :goto_cf

    :cond_cd
    const/high16 v10, 0x421c0000    # 39.0f

    :goto_cf
    div-float v15, v10, v19

    add-float v15, v17, v15

    .line 334
    aput v15, v6, v2

    add-float v17, v17, v10

    add-int/lit8 v2, v2, 0x1

    const/high16 v10, 0x3f800000    # 1.0f

    goto :goto_a0

    :cond_dc
    const v1, 0x43bd8000    # 379.0f

    mul-float/2addr v1, v8

    add-float v2, p3, v1

    const v17, 0x3fb33333    # 1.4f

    const/high16 v20, 0x40c00000    # 6.0f

    const v21, 0x3ed70a3d    # 0.42f

    if-lez v15, :cond_182

    .line 341
    iget-object v15, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    iget v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->line:I

    invoke-virtual {v15, v1}, Landroid/graphics/Paint;->setColor(I)V

    sub-float v15, v2, v8

    .line 342
    aget v1, v6, v3

    const/high16 v23, 0x41600000    # 14.0f

    sub-float v1, v1, v23

    mul-float v23, v1, v8

    add-float v24, v2, v8

    iget v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rows:I

    sub-int/2addr v1, v10

    aget v1, v6, v1

    mul-float v25, v1, v8

    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    move-object/from16 v22, v1

    const/4 v10, 0x0

    move-object/from16 v1, p1

    move/from16 v27, v2

    move v2, v15

    move v12, v3

    move/from16 v3, v23

    move-object/from16 v23, v4

    move/from16 v4, v24

    move-object/from16 v28, v5

    move/from16 v5, v25

    move-object/from16 v25, v6

    move-object/from16 v6, v22

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 343
    aget v1, v25, v12

    sub-float v2, v1, v20

    sub-float v1, v1, v20

    move v3, v12

    .line 345
    :goto_129
    iget v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rows:I

    if-ge v3, v4, :cond_144

    int-to-float v4, v3

    mul-float v4, v4, v21

    add-float v4, v4, v17

    .line 346
    invoke-static {v9, v4, v14}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->ramp(FFF)F

    move-result v4

    .line 347
    aget v5, v25, v3

    sub-float/2addr v5, v1

    mul-float/2addr v5, v4

    add-float/2addr v1, v5

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v2

    .line 348
    aget v1, v25, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_129

    :cond_144
    cmpl-float v1, v9, v17

    if-ltz v1, :cond_18c

    .line 351
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    new-instance v3, Landroid/graphics/LinearGradient;

    const/16 v30, 0x0

    aget v4, v25, v12

    sub-float v4, v4, v20

    mul-float v31, v4, v8

    const/16 v32, 0x0

    mul-float v5, v2, v8

    iget v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->gold:I

    iget v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->goldHi:I

    sget-object v36, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    move-object/from16 v29, v3

    move/from16 v33, v5

    move/from16 v34, v2

    move/from16 v35, v4

    invoke-direct/range {v29 .. v36}, Landroid/graphics/LinearGradient;-><init>(FFFFIILandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 353
    aget v1, v25, v12

    sub-float v1, v1, v20

    mul-float v3, v1, v8

    iget-object v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    move-object/from16 v1, p1

    move v2, v15

    move/from16 v4, v24

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 354
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v1, v10}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    goto :goto_18c

    :cond_182
    move/from16 v27, v2

    move v12, v3

    move-object/from16 v23, v4

    move-object/from16 v28, v5

    move-object/from16 v25, v6

    const/4 v10, 0x0

    :cond_18c
    :goto_18c
    move v14, v12

    .line 357
    :goto_18d
    iget v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rows:I

    if-ge v14, v1, :cond_53b

    int-to-float v1, v14

    mul-float v1, v1, v21

    add-float v1, v1, v17

    const v2, 0x3f333333    # 0.7f

    .line 358
    invoke-static {v9, v1, v2}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->ramp(FFF)F

    move-result v15

    .line 359
    invoke-static {v15}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->easeOut(F)F

    move-result v6

    .line 360
    aget-boolean v1, v23, v14

    const/high16 v2, 0x43c70000    # 398.0f

    const/high16 v22, 0x41280000    # 10.5f

    if-eqz v1, :cond_1ff

    .line 361
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 362
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    mul-float v3, v8, v22

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 363
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const v3, 0x3eae147b    # 0.34f

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setLetterSpacing(F)V

    .line 364
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    iget v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->gold:I

    const v4, 0x3f666666    # 0.9f

    mul-float/2addr v4, v6

    invoke-direct {v0, v3, v4}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v3

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 365
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->section:[Ljava/lang/String;

    aget-object v1, v1, v14

    const-string v3, "group"

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1e4

    iget-boolean v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->english:Z

    if-eqz v1, :cond_1e1

    const-string v1, "GROUP STAGE"

    goto :goto_1ed

    :cond_1e1
    const-string v1, "GROUP STAGE \u00b7 \u5c0f\u7ec4\u8d5b"

    goto :goto_1ed

    .line 366
    :cond_1e4
    iget-boolean v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->english:Z

    if-eqz v1, :cond_1eb

    const-string v1, "KNOCKOUT"

    goto :goto_1ed

    :cond_1eb
    const-string v1, "KNOCKOUT \u00b7 \u6dd8\u6c70\u8d5b"

    :goto_1ed
    mul-float v3, v2, v8

    add-float v3, p3, v3

    .line 367
    aget v4, v28, v14

    mul-float/2addr v4, v8

    iget-object v5, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    invoke-virtual {v7, v1, v3, v4, v5}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 368
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/4 v3, 0x0

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setLetterSpacing(F)V

    .line 370
    :cond_1ff
    iget v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rows:I

    const/4 v3, 0x1

    sub-int/2addr v1, v3

    if-ne v14, v1, :cond_208

    const/16 v24, 0x1

    goto :goto_20a

    :cond_208
    move/from16 v24, v12

    .line 371
    :goto_20a
    aget v1, v25, v14

    const/high16 v3, 0x3f800000    # 1.0f

    sub-float v4, v3, v6

    const/high16 v29, 0x41200000    # 10.0f

    mul-float v4, v4, v29

    add-float/2addr v1, v4

    mul-float v5, v1, v8

    .line 374
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    iget v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->line:I

    invoke-direct {v0, v3, v6}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v3

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 375
    aget v1, v25, v14

    const/high16 v30, 0x41d00000    # 26.0f

    if-eqz v24, :cond_22b

    move/from16 v3, v30

    goto :goto_22d

    :cond_22b
    const/high16 v3, 0x419c0000    # 19.5f

    :goto_22d
    add-float/2addr v1, v3

    mul-float v3, v1, v8

    mul-float/2addr v2, v8

    add-float v4, p3, v2

    const/high16 v1, 0x3f800000    # 1.0f

    .line 376
    invoke-static {v1, v13}, Ljava/lang/Math;->max(FF)F

    move-result v2

    add-float v31, v3, v2

    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    move-object/from16 v1, p1

    move-object/from16 v32, v2

    move v2, v4

    move v12, v4

    move/from16 v4, v16

    move v10, v5

    move/from16 v5, v31

    move v9, v6

    move-object/from16 v6, v32

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    if-eqz v24, :cond_251

    goto :goto_253

    :cond_251
    move/from16 v29, v20

    :goto_253
    mul-float v1, v29, v8

    .line 379
    aget v2, v25, v14

    mul-float/2addr v2, v8

    const v3, 0x3d4ccccd    # 0.05f

    cmpl-float v3, v15, v3

    if-lez v3, :cond_261

    const/4 v3, 0x1

    goto :goto_262

    :cond_261
    const/4 v3, 0x0

    .line 381
    :goto_262
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    if-eqz v3, :cond_26e

    if-eqz v24, :cond_26b

    iget v5, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->goldHi:I

    goto :goto_271

    :cond_26b
    iget v5, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->gold:I

    goto :goto_271

    :cond_26e
    const v5, -0xf4edd0

    :goto_271
    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 382
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    move/from16 v5, v27

    invoke-virtual {v7, v5, v2, v1, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    if-eqz v3, :cond_2a5

    .line 384
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    iget v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->gold:I

    const/high16 v15, 0x3e800000    # 0.25f

    invoke-direct {v0, v6, v15}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v6

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setColor(I)V

    const v4, 0x3fd9999a    # 1.7f

    mul-float/2addr v4, v1

    .line 385
    iget-object v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v7, v5, v2, v4, v6}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 386
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    if-eqz v24, :cond_29a

    iget v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->goldHi:I

    goto :goto_29c

    :cond_29a
    iget v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->gold:I

    :goto_29c
    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 387
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v7, v5, v2, v1, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    goto :goto_2c7

    .line 389
    :cond_2a5
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    sget-object v6, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 390
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    mul-float v6, v8, v19

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 391
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    iget v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->gold:I

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setColor(I)V

    sub-float/2addr v1, v8

    .line 392
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v7, v5, v2, v1, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 393
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v1, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    :goto_2c7
    const/high16 v1, 0x40800000    # 4.0f

    if-eqz v24, :cond_2fc

    if-eqz v3, :cond_2fc

    .line 396
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 397
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 398
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/high16 v4, 0x41300000    # 11.0f

    mul-float/2addr v4, v8

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 399
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const v4, -0xd5de00

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    mul-float v3, v8, v1

    add-float/2addr v2, v3

    .line 400
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const-string v4, "\u2605"

    invoke-virtual {v7, v4, v5, v2, v3}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 401
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 404
    :cond_2fc
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 405
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 406
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const v3, 0x3dcccccd    # 0.1f

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setLetterSpacing(F)V

    .line 407
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    invoke-virtual {v2, v11}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 408
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    iget v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->muted:I

    invoke-direct {v0, v3, v9}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setColor(I)V

    .line 409
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->label:[Ljava/lang/String;

    aget-object v2, v2, v14

    invoke-direct {v0, v2}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->localLabel(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    mul-float/2addr v1, v8

    add-float/2addr v1, v10

    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    invoke-virtual {v7, v2, v12, v1, v3}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 410
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/graphics/Paint;->setLetterSpacing(F)V

    if-eqz v24, :cond_33b

    const/high16 v30, 0x41f00000    # 30.0f

    :cond_33b
    mul-float v30, v30, v8

    const/high16 v2, 0x43f10000    # 482.0f

    mul-float/2addr v2, v8

    add-float v2, p3, v2

    .line 414
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->opponentId:[I

    aget v3, v3, v14

    if-lez v3, :cond_34d

    invoke-static {v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->crestBitmap(I)Landroid/graphics/Bitmap;

    move-result-object v3

    goto :goto_34e

    :cond_34d
    const/4 v3, 0x0

    :goto_34e
    if-eqz v3, :cond_378

    .line 416
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rect:Landroid/graphics/RectF;

    div-float v6, v30, v19

    sub-float v12, v10, v6

    add-float v15, v2, v30

    add-float/2addr v6, v10

    invoke-virtual {v4, v2, v12, v15, v6}, Landroid/graphics/RectF;->set(FFFF)V

    .line 417
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    const/high16 v6, 0x437f0000    # 255.0f

    mul-float/2addr v6, v9

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 418
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rect:Landroid/graphics/RectF;

    iget-object v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    const/4 v12, 0x0

    invoke-virtual {v7, v3, v12, v4, v6}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 419
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    const/16 v4, 0xff

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setAlpha(I)V

    goto :goto_379

    :cond_378
    const/4 v12, 0x0

    .line 422
    :goto_379
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 423
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/4 v4, 0x1

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 424
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/high16 v15, 0x41800000    # 16.0f

    if-eqz v24, :cond_38f

    const/high16 v26, 0x41980000    # 19.0f

    goto :goto_391

    :cond_38f
    move/from16 v26, v15

    :goto_391
    mul-float v4, v26, v8

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 425
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    if-eqz v24, :cond_39d

    iget v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->goldHi:I

    goto :goto_3a0

    :cond_39d
    const v4, -0x90e1e

    :goto_3a0
    invoke-direct {v0, v4, v9}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    add-float v2, v2, v30

    add-float/2addr v2, v11

    .line 427
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->opponent:[Ljava/lang/String;

    aget-object v3, v3, v14

    mul-float v4, v8, v20

    add-float/2addr v4, v10

    iget-object v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    invoke-virtual {v7, v3, v2, v4, v6}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 428
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->opponent:[Ljava/lang/String;

    aget-object v4, v4, v14

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v3

    add-float/2addr v2, v3

    .line 429
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/4 v4, 0x0

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    .line 430
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->note:[Ljava/lang/String;

    aget-object v3, v3, v14

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_44d

    .line 431
    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->note:[Ljava/lang/String;

    aget-object v3, v3, v14

    invoke-direct {v0, v3}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->localNote(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 432
    iget-object v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    mul-float v4, v8, v22

    invoke-virtual {v6, v4}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 433
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const v6, 0x3da3d70a    # 0.08f

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setLetterSpacing(F)V

    .line 434
    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    invoke-virtual {v4, v3}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v4

    mul-float v6, v8, v15

    add-float/2addr v4, v6

    .line 435
    iget-object v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rect:Landroid/graphics/RectF;

    add-float/2addr v2, v11

    const/high16 v15, 0x41100000    # 9.0f

    mul-float/2addr v15, v8

    sub-float v12, v10, v15

    add-float/2addr v4, v2

    move/from16 v29, v5

    add-float v5, v10, v15

    invoke-virtual {v6, v2, v12, v4, v5}, Landroid/graphics/RectF;->set(FFFF)V

    .line 436
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 437
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    const/high16 v4, 0x3f800000    # 1.0f

    invoke-static {v4, v8}, Ljava/lang/Math;->max(FF)F

    move-result v5

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 438
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    iget v5, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->line:I

    mul-float v6, v9, v19

    invoke-direct {v0, v5, v6}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v5

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 439
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rect:Landroid/graphics/RectF;

    iget-object v5, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v7, v2, v15, v15, v5}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 440
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 441
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    iget v5, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->gold:I

    invoke-direct {v0, v5, v9}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v5

    invoke-virtual {v2, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 442
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->rect:Landroid/graphics/RectF;

    iget v2, v2, Landroid/graphics/RectF;->left:F

    const/high16 v5, 0x41000000    # 8.0f

    mul-float/2addr v5, v8

    add-float/2addr v2, v5

    iget-object v5, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    invoke-virtual {v7, v3, v2, v1, v5}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 443
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setLetterSpacing(F)V

    goto :goto_452

    :cond_44d
    move/from16 v29, v5

    const/4 v2, 0x0

    const/high16 v4, 0x3f800000    # 1.0f

    :goto_452
    if-eqz v24, :cond_457

    const/high16 v1, 0x41700000    # 15.0f

    goto :goto_459

    :cond_457
    const/high16 v1, 0x41400000    # 12.0f

    :goto_459
    mul-float/2addr v1, v8

    div-float v3, v1, v8

    const v5, 0x44598000    # 870.0f

    sub-float v15, v5, v3

    mul-float/2addr v15, v8

    add-float v3, p3, v15

    .line 448
    iget-object v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->result:[Ljava/lang/String;

    aget-object v6, v6, v14

    const-string v12, "W"

    invoke-virtual {v12, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    .line 449
    iget-object v12, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->result:[Ljava/lang/String;

    aget-object v12, v12, v14

    const-string v15, "D"

    invoke-virtual {v15, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v6, :cond_47d

    .line 450
    iget v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->gold:I

    goto :goto_485

    :cond_47d
    if-eqz v12, :cond_482

    iget v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->muted:I

    goto :goto_485

    :cond_482
    const v6, -0x1fbaa6

    :goto_485
    if-eqz v24, :cond_498

    .line 452
    iget-object v12, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    iget v15, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->gold:I

    invoke-direct {v0, v15, v9}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v15

    invoke-virtual {v12, v15}, Landroid/graphics/Paint;->setColor(I)V

    .line 453
    iget-object v12, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v7, v3, v10, v1, v12}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    goto :goto_4c1

    .line 455
    :cond_498
    iget-object v12, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    sget-object v15, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v12, v15}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 456
    iget-object v12, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    const/high16 v15, 0x3fc00000    # 1.5f

    mul-float/2addr v15, v8

    invoke-virtual {v12, v15}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 457
    iget-object v12, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-direct {v0, v6, v9}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v15

    invoke-virtual {v12, v15}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v12, 0x3f400000    # 0.75f

    mul-float/2addr v12, v8

    sub-float v12, v1, v12

    .line 458
    iget-object v15, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {v7, v3, v10, v12, v15}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 459
    iget-object v12, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    sget-object v15, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v12, v15}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 461
    :goto_4c1
    iget-object v12, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v15, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v12, v15}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 462
    iget-object v12, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    if-eqz v24, :cond_4cf

    const/high16 v15, 0x41500000    # 13.0f

    goto :goto_4d1

    :cond_4cf
    const/high16 v15, 0x41400000    # 12.0f

    :goto_4d1
    mul-float/2addr v15, v8

    invoke-virtual {v12, v15}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 463
    iget-object v12, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v15, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v12, v15}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 464
    iget-object v12, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    if-eqz v24, :cond_4e3

    const v6, -0xe5eb00

    :cond_4e3
    invoke-direct {v0, v6, v9}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v6

    invoke-virtual {v12, v6}, Landroid/graphics/Paint;->setColor(I)V

    .line 465
    iget-object v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->result:[Ljava/lang/String;

    aget-object v6, v6, v14

    const v12, 0x4089999a    # 4.3f

    mul-float/2addr v12, v8

    add-float/2addr v12, v10

    iget-object v15, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    invoke-virtual {v7, v6, v3, v12, v15}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 466
    iget-object v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v12, Landroid/graphics/Paint$Align;->RIGHT:Landroid/graphics/Paint$Align;

    invoke-virtual {v6, v12}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 467
    iget-object v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    if-eqz v24, :cond_506

    const/high16 v12, 0x41b80000    # 23.0f

    goto :goto_508

    :cond_506
    const/high16 v12, 0x41980000    # 19.0f

    :goto_508
    mul-float/2addr v12, v8

    invoke-virtual {v6, v12}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 468
    iget-object v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    if-eqz v24, :cond_513

    iget v12, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->goldHi:I

    goto :goto_514

    :cond_513
    const/4 v12, -0x1

    :goto_514
    invoke-direct {v0, v12, v9}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v9

    invoke-virtual {v6, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 469
    iget-object v6, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->score:[Ljava/lang/String;

    aget-object v6, v6, v14

    sub-float/2addr v3, v1

    sub-float/2addr v3, v11

    const/high16 v1, 0x40e00000    # 7.0f

    mul-float/2addr v1, v8

    add-float/2addr v1, v10

    iget-object v9, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    invoke-virtual {v7, v6, v3, v1, v9}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 470
    iget-object v1, v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->text:Landroid/graphics/Paint;

    sget-object v3, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    add-int/lit8 v14, v14, 0x1

    move/from16 v9, p4

    move/from16 v27, v29

    const/4 v10, 0x0

    const/4 v12, 0x0

    goto/16 :goto_18d

    :cond_53b
    return-void
.end method

.method private drawSpecks(Landroid/graphics/Canvas;FFF)V
    .registers 16

    .line 207
    iget-boolean v0, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->worldCup:Z

    if-eqz v0, :cond_8

    const v0, -0x91c5f

    goto :goto_b

    :cond_8
    const v0, -0x3b2901

    .line 208
    :goto_b
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->specks:[[F

    array-length v2, v1

    const/4 v3, 0x0

    move v4, v3

    :goto_10
    if-ge v4, v2, :cond_60

    aget-object v5, v1, v4

    const/4 v6, 0x1

    .line 210
    aget v6, v5, v6

    const/high16 v7, 0x42700000    # 60.0f

    sub-float/2addr v6, v7

    const/4 v8, 0x3

    aget v8, v5, v8

    mul-float/2addr v8, p4

    mul-float/2addr v8, v7

    sub-float/2addr v6, v8

    const/high16 v8, 0x43a50000    # 330.0f

    rem-float/2addr v6, v8

    add-float/2addr v6, v8

    rem-float/2addr v6, v8

    add-float/2addr v6, v7

    .line 211
    aget v8, v5, v3

    const/4 v9, 0x4

    aget v9, v5, v9

    mul-float/2addr v9, p4

    mul-float/2addr v9, v7

    add-float/2addr v8, v9

    const/4 v9, 0x5

    .line 212
    aget v9, v5, v9

    const/4 v10, 0x6

    aget v10, v5, v10

    mul-float/2addr v10, p4

    mul-float/2addr v10, v7

    add-float/2addr v9, v10

    float-to-double v9, v9

    invoke-static {v9, v10}, Ljava/lang/Math;->sin(D)D

    move-result-wide v9

    double-to-float v7, v9

    invoke-static {v7}, Ljava/lang/Math;->abs(F)F

    move-result v7

    const v9, 0x3f0ccccd    # 0.55f

    mul-float/2addr v7, v9

    const/high16 v9, 0x3e800000    # 0.25f

    add-float/2addr v7, v9

    .line 213
    iget-object v9, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-direct {p0, v0, v7}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->alpha(IF)I

    move-result v7

    invoke-virtual {v9, v7}, Landroid/graphics/Paint;->setColor(I)V

    mul-float/2addr v8, p2

    add-float/2addr v8, p3

    mul-float/2addr v6, p2

    const/4 v7, 0x2

    .line 214
    aget v5, v5, v7

    mul-float/2addr v5, p2

    iget-object v7, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v8, v6, v5, v7}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_10

    :cond_60
    return-void
.end method

.method private static easeOut(F)F
    .registers 3

    .line 136
    invoke-static {p0}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->clamp01(F)F

    move-result p0

    const/high16 v0, 0x3f800000    # 1.0f

    sub-float p0, v0, p0

    mul-float v1, p0, p0

    mul-float/2addr v1, p0

    sub-float/2addr v0, v1

    return v0
.end method

.method private localLabel(Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 475
    iget-boolean v0, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->english:Z

    if-nez v0, :cond_5

    return-object p1

    .line 476
    :cond_5
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v1, -0x1

    sparse-switch v0, :sswitch_data_6a

    goto :goto_3c

    :sswitch_11
    const-string v0, "\u534a\u51b3\u8d5b"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1a

    goto :goto_3c

    :cond_1a
    const/4 v1, 0x3

    goto :goto_3c

    :sswitch_1c
    const-string v0, "\u5341\u516d\u5f3a"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_25

    goto :goto_3c

    :cond_25
    const/4 v1, 0x2

    goto :goto_3c

    :sswitch_27
    const-string v0, "\u51b3\u8d5b"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_30

    goto :goto_3c

    :cond_30
    const/4 v1, 0x1

    goto :goto_3c

    :sswitch_32
    const-string v0, "\u516b\u5f3a"

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3b

    goto :goto_3c

    :cond_3b
    const/4 v1, 0x0

    :goto_3c
    packed-switch v1, :pswitch_data_7c

    const-string v0, "[^0-9]"

    const-string v1, ""

    .line 482
    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 483
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_4e

    goto :goto_5c

    :cond_4e
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v1, "MATCHDAY "

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_5c
    return-object p1

    :pswitch_5d
    const-string p1, "SEMI-FINAL"

    return-object p1

    :pswitch_60
    const-string p1, "ROUND OF 16"

    return-object p1

    :pswitch_63
    const-string p1, "FINAL"

    return-object p1

    :pswitch_66
    const-string p1, "QUARTER-FINAL"

    return-object p1

    nop

    :sswitch_data_6a
    .sparse-switch
        0xa3b2f -> :sswitch_32
        0xa7208 -> :sswitch_27
        0x142c26e -> :sswitch_1c
        0x1431ad2 -> :sswitch_11
    .end sparse-switch

    :pswitch_data_7c
    .packed-switch 0x0
        :pswitch_66
        :pswitch_63
        :pswitch_60
        :pswitch_5d
    .end packed-switch
.end method

.method private localNote(Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 488
    iget-boolean v0, p0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->english:Z

    if-nez v0, :cond_5

    return-object p1

    :cond_5
    const-string v0, "\u70b9\u7403"

    const-string v1, "PENS"

    .line 489
    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const-string v0, "\u52a0\u65f6"

    const-string v1, "AET"

    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private static ramp(FFF)F
    .registers 3

    sub-float/2addr p0, p1

    div-float/2addr p0, p2

    .line 142
    invoke-static {p0}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->clamp01(F)F

    move-result p0

    return p0
.end method

.method public static restart()V
    .registers 2

    .line 128
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    sput-wide v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->startMs:J

    return-void
.end method

.method private static declared-synchronized trophyFor(Landroid/content/Context;Z)Landroid/graphics/Bitmap;
    .registers 5

    const-string v0, "cup-trophy/"

    const-class v1, Lorg/efootballrevival/runtimeprobe/CupCelebration;

    monitor-enter v1

    if-eqz p1, :cond_a

    .line 116
    :try_start_7
    sget-object v2, Lorg/efootballrevival/runtimeprobe/CupCelebration;->trophyWorld:Landroid/graphics/Bitmap;

    goto :goto_c

    :cond_a
    sget-object v2, Lorg/efootballrevival/runtimeprobe/CupCelebration;->trophyUcl:Landroid/graphics/Bitmap;
    :try_end_c
    .catchall {:try_start_7 .. :try_end_c} :catchall_44

    :goto_c
    if-eqz v2, :cond_10

    .line 117
    monitor-exit v1

    return-object v2

    .line 118
    :cond_10
    :try_start_10
    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object p0

    if-eqz p1, :cond_19

    const-string v2, "wc.png"

    goto :goto_1b

    :cond_19
    const-string v2, "ucl.png"

    :goto_1b
    invoke-virtual {v0, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object p0
    :try_end_23
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_23} :catch_41
    .catchall {:try_start_10 .. :try_end_23} :catchall_44

    .line 119
    :try_start_23
    invoke-static {p0}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v0

    if-eqz p1, :cond_2c

    .line 120
    sput-object v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->trophyWorld:Landroid/graphics/Bitmap;

    goto :goto_2e

    :cond_2c
    sput-object v0, Lorg/efootballrevival/runtimeprobe/CupCelebration;->trophyUcl:Landroid/graphics/Bitmap;
    :try_end_2e
    .catchall {:try_start_23 .. :try_end_2e} :catchall_35

    :goto_2e
    if-eqz p0, :cond_33

    .line 122
    :try_start_30
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_33
    .catch Ljava/lang/Exception; {:try_start_30 .. :try_end_33} :catch_41
    .catchall {:try_start_30 .. :try_end_33} :catchall_44

    .line 121
    :cond_33
    monitor-exit v1

    return-object v0

    :catchall_35
    move-exception p1

    if-eqz p0, :cond_40

    .line 118
    :try_start_38
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_3b
    .catchall {:try_start_38 .. :try_end_3b} :catchall_3c

    goto :goto_40

    :catchall_3c
    move-exception p0

    :try_start_3d
    invoke-virtual {p1, p0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_40
    :goto_40
    throw p1
    :try_end_41
    .catch Ljava/lang/Exception; {:try_start_3d .. :try_end_41} :catch_41
    .catchall {:try_start_3d .. :try_end_41} :catchall_44

    .line 123
    :catch_41
    monitor-exit v1

    const/4 p0, 0x0

    return-object p0

    :catchall_44
    move-exception p0

    monitor-exit v1

    throw p0
.end method


# virtual methods
.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 12

    .line 152
    invoke-virtual {p0}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->getWidth()I

    move-result v0

    int-to-float v3, v0

    .line 153
    invoke-virtual {p0}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->getHeight()I

    move-result v0

    int-to-float v4, v0

    const/4 v0, 0x0

    cmpg-float v1, v3, v0

    if-lez v1, :cond_40

    cmpg-float v0, v4, v0

    if-gtz v0, :cond_14

    goto :goto_40

    .line 155
    :cond_14
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    sget-wide v5, Lorg/efootballrevival/runtimeprobe/CupCelebration;->startMs:J

    sub-long/2addr v0, v5

    long-to-float v0, v0

    const/high16 v1, 0x447a0000    # 1000.0f

    div-float/2addr v0, v1

    const/high16 v1, 0x43cd0000    # 410.0f

    div-float v8, v4, v1

    const/high16 v1, 0x44610000    # 900.0f

    mul-float/2addr v1, v8

    sub-float v1, v3, v1

    const/high16 v2, 0x40000000    # 2.0f

    div-float v9, v1, v2

    move-object v1, p0

    move-object v2, p1

    move v5, v8

    move v6, v9

    move v7, v0

    .line 159
    invoke-direct/range {v1 .. v7}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->drawBackdrop(Landroid/graphics/Canvas;FFFFF)V

    .line 160
    invoke-direct {p0, p1, v8, v9, v0}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->drawSpecks(Landroid/graphics/Canvas;FFF)V

    .line 161
    invoke-direct {p0, p1, v8, v9, v0}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->drawLeft(Landroid/graphics/Canvas;FFF)V

    .line 162
    invoke-direct {p0, p1, v8, v9, v0}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->drawRight(Landroid/graphics/Canvas;FFF)V

    .line 163
    invoke-virtual {p0}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->postInvalidateOnAnimation()V

    :cond_40
    :goto_40
    return-void
.end method
