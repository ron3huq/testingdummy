.class public final Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;
.super Ljava/lang/Object;
.source "CupTournamentPanel.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;,
        Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;,
        Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$StarBadge;,
        Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;,
        Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;,
        Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$Stripes;
    }
.end annotation


# static fields
.field private static final BACKDROP_4X3_ASSET:Ljava/lang/String; = "cup-bg/ucl_bg_0403.jpg"

.field private static final BACKDROP_ASSET:Ljava/lang/String; = "cup-bg/ucl_bg.jpg"

.field private static final BACKDROP_WIDE_ASSET:Ljava/lang/String; = "cup-bg/ucl_bg_wide.jpg"

.field private static final BG_BOTTOM:I = -0xe5c220

.field private static final BG_TOP:I = -0xf5eab0

.field private static final BLUE:I = -0xf5ca01

.field private static final BLUE_DARK:I = -0xf0dc70

.field private static final CARD:I = -0x22f2eee0

.field private static final CHIP:I = 0x33ffffff

.field private static final CRESTS:Landroid/util/LruCache;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/LruCache<",
            "Ljava/lang/Integer;",
            "Landroid/graphics/Bitmap;",
            ">;"
        }
    .end annotation
.end field

.field private static final CREST_ASSET:Ljava/lang/String; = "cup-crests/crests.bin"

.field private static final DESIGN_H:F = 1126.0f

.field private static final EDGE:I = 0x33ffffff

.field private static final EN:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final GOLD_BOTTOM:I = -0x2669e6

.field private static final GOLD_TOP:I = -0x1676

.field private static final GREEN:I = -0xd11a76

.field private static final LINE:I = 0x22ffffff

.field private static final MAIN:Landroid/os/Handler;

.field private static final MATCH_MINUTES:[I

.field private static final MUTED:I = -0x564b2a

.field private static final PLATE_BOTTOM:I = -0x11efece1

.field private static final PLATE_TOP:I = -0x11d5cfb9

.field private static final ROUND_LABELS:[Ljava/lang/String;

.field private static final WHITE:I = -0x1

.field private static final YELLOW:I = -0x1eb6

.field private static backdropCache:Landroid/graphics/Bitmap;

.field private static backdropName:Ljava/lang/String;

.field private static crestIndex:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "[I>;"
        }
    .end annotation
.end field

.field private static crestPack:[B

.field private static current:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;",
            ">;"
        }
    .end annotation
.end field

.field private static volatile openRequestedAt:J

.field private static volatile prefetch:Ljava/util/concurrent/FutureTask;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/FutureTask<",
            "Lorg/json/JSONObject;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final activity:Landroid/app/Activity;

.field private barHeightPx:I

.field private barTopPx:I

.field private bracketCrestDp:I

.field private celebrationCup:Ljava/lang/String;

.field private celebrationDismissed:Z

.field private celebrationForced:Z

.field private closed:Z

.field private closing:Z

.field private final content:Landroid/widget/LinearLayout;

.field private dialog:Landroid/app/AlertDialog;

.field private english:Z

.field private eventId:I

.field private holeRightPx:I

.field private holeTopPx:I

.field private knockoutAvailPx:I

.field private final landscape:Z

.field private legacy:Landroid/widget/LinearLayout;

.field private padRight:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

.field private padTop:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

.field private panelRoot:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;

.field private panelWm:Landroid/view/WindowManager;

.field private refreshGeneration:J

.field private resetArmedAt:J

.field private roomyRows:Z

.field private rootHost:Landroid/widget/FrameLayout;

.field private safeLeftPx:I

.field private safeRightPx:I

.field private sceneH:I

.field private sceneW:I

.field private selectedGroup:I

.field private showKnockout:Z

.field private snapshot:Lorg/json/JSONObject;

.field private strip:Landroid/app/Dialog;

.field private stripHost:Landroid/widget/FrameLayout;

.field private stripLeft:Landroid/app/Dialog;

.field private final subtitle:Landroid/widget/TextView;

.field private final tabs:Landroid/widget/LinearLayout;

.field private uiContext:Landroid/content/Context;


# direct methods
.method public static synthetic $r8$lambda$-68sjJ-ZWNPA2jNf9r6UVT-RMaY(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V
    .registers 1

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->close()V

    return-void
.end method

.method public static synthetic $r8$lambda$Ks_VI8m6_aGUO3qA9N2yZYB9pnI(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V
    .registers 1

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->render()V

    return-void
.end method

.method static constructor <clinit>()V
    .registers 8

    .line 67
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->MAIN:Landroid/os/Handler;

    .line 68
    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->current:Ljava/lang/ref/WeakReference;

    .line 93
    new-instance v0, Landroid/util/LruCache;

    const/16 v1, 0x60

    invoke-direct {v0, v1}, Landroid/util/LruCache;-><init>(I)V

    sput-object v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->CRESTS:Landroid/util/LruCache;

    const/4 v0, 0x6

    new-array v0, v0, [I

    .line 1300
    fill-array-data v0, :array_24a

    sput-object v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->MATCH_MINUTES:[I

    .line 1906
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->EN:Ljava/util/Map;

    const-string v1, "\u5c0f\u7ec4\u6982\u51b5"

    const-string v2, "Group Overview"

    .line 1908
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u6b27\u6d32"

    const-string v2, "Europe"

    .line 1909
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u975e\u6d32"

    const-string v2, "Africa"

    .line 1910
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u4e2d\u5317\u7f8e"

    const-string v2, "N. America"

    .line 1911
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5357\u7f8e"

    const-string v2, "S. America"

    .line 1912
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u4e9a\u6d32"

    const-string v2, "Asia"

    .line 1913
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u6b27\u51a0 \u00b7 \u51a0\u519b\u4e4b\u8def"

    const-string v2, "UCL \u00b7 Road to the trophy"

    .line 1914
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u51a0\u519b\u4e4b\u8def"

    const-string v2, "Road to the trophy"

    .line 1915
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u8bbe\u7f6e"

    const-string v2, "Settings"

    .line 1916
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u6bd4\u8d5b\u65f6\u957f"

    const-string v2, "Match length"

    .line 1917
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5206\u949f"

    const-string v2, " min"

    .line 1918
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u91cd\u7f6e\u8d5b\u4e8b"

    const-string v2, "Reset Cup"

    .line 1919
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u518d\u70b9\u4e00\u6b21\u786e\u8ba4"

    const-string v2, "Tap again to confirm"

    .line 1920
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u6b63\u5728\u91cd\u7f6e\u8d5b\u4e8b\u2026"

    const-string v2, "Resetting the cup\u2026"

    .line 1921
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u6b27\u51a0\u5c0f\u7ec4\u8d5b"

    const-string v2, "UCL Group Stage"

    .line 1922
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5237\u65b0"

    const-string v2, "Refresh"

    .line 1923
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u6b63\u5728\u8bfb\u53d6\u8d5b\u4e8b\u8fdb\u5ea6\u2026"

    const-string v2, "Loading cup progress\u2026"

    .line 1924
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5c1a\u672a\u5efa\u7acb\u672c\u5c4a\u8d5b\u4e8b\uff0c\u8bf7\u8fd4\u56de\u540e\u91cd\u65b0\u8fdb\u5165\u3002"

    const-string v2, "No cup yet. Go back and enter again."

    .line 1925
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5c0f\u7ec4\u8d5b"

    const-string v2, "Group Stage"

    .line 1926
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u6dd8\u6c70\u8d5b"

    const-string v2, "Knockout"

    .line 1927
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u6b27\u51a0\u6dd8\u6c70\u8d5b \u00b7 "

    const-string v2, "UCL Knockout \u00b7 "

    .line 1928
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u6b27\u51a0\u5c0f\u7ec4\u8d5b \u00b7 \u6211\u7684\u5c0f\u7ec4 "

    const-string v2, "UCL Group Stage \u00b7 My Group "

    .line 1929
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5c0f\u7ec4\u8d5b\u4e4b\u8def"

    const-string v2, "Group Stage Road"

    .line 1930
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u6bd4\u8d5b\u65e5 "

    const-string v2, "Matchday "

    .line 1931
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5f85\u8d5b"

    const-string v2, "To play"

    .line 1932
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u80dc "

    const-string v2, "W "

    .line 1933
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u8d1f "

    const-string v2, "L "

    .line 1934
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5e73 "

    const-string v2, "D "

    .line 1935
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5c0f\u7ec4\u8d5b\u7ed3\u675f \u00b7 \u5c0f\u7ec4\u7b2c "

    const-string v2, "Group stage over \u00b7 Rank "

    .line 1936
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, " \u540d \u00b7 \u79ef\u5206 "

    const-string v2, " \u00b7 Points "

    .line 1937
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5df2\u664b\u7ea716\u5f3a \u00b7 \u8fd4\u56de\u6d3b\u52a8\u5217\u8868\u8fdb\u5165\u300c\u6b27\u51a0\u6dd8\u6c70\u8d5b\u300d"

    const-string v2, "Qualified for the Round of 16 \u00b7 Back to the event list and enter \u201cUCL Knockout\u201d"

    .line 1938
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u672a\u80fd\u664b\u7ea7 \u00b7 \u672c\u5c4a\u6b27\u51a0\u5230\u6b64\u7ed3\u675f"

    const-string v2, "Eliminated \u00b7 This UCL run is over"

    .line 1939
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u672c\u7ec4\u8d5b\u7a0b\u5df2\u5b8c\u6210"

    const-string v2, "All group matches played"

    .line 1940
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u4e0b\u4e00\u573a\u6bd4\u8d5b \u00b7 \u6bd4\u8d5b\u65e5 "

    const-string v2, "Next match \u00b7 Matchday "

    .line 1941
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5bf9\u624b\u8bc4\u5206"

    const-string v2, "Opponent rating"

    .line 1942
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5c0f\u7ec4 "

    const-string v2, "Group "

    .line 1943
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, " \u79ef\u5206\u699c"

    const-string v2, " Standings"

    .line 1944
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u664b\u7ea716\u5f3a\u6dd8\u6c70\u8d5b"

    const-string v2, "Qualify for Round of 16"

    .line 1945
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5c0f\u7ec4\u6dd8\u6c70"

    const-string v2, "Eliminated"

    .line 1946
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u540c\u5206\u4f9d\u6b21\u6bd4\u51c0\u80dc\u7403\u3001\u8fdb\u7403\u6570"

    const-string v3, "Tie-break: goal difference, then goals scored"

    .line 1947
    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u6211\u7684\u5c0f\u7ec4\u8d5b\u4e4b\u8def"

    const-string v3, "My Group Stage Road"

    .line 1948
    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u7403\u961f"

    const-string v3, "Team"

    .line 1949
    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u8d5b"

    const-string v3, "P"

    .line 1950
    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u80dc"

    const-string v3, "W"

    .line 1951
    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5e73"

    const-string v3, "D"

    .line 1952
    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u8d1f"

    const-string v3, "L"

    .line 1953
    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u8fdb/\u5931"

    const-string v3, "GF/GA"

    .line 1954
    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u51c0"

    const-string v3, "GD"

    .line 1955
    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5206"

    const-string v3, "Pts"

    .line 1956
    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5df2\u664b\u7ea716\u5f3a"

    const-string v3, "Qualified for the Round of 16"

    .line 1957
    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u672a\u80fd\u664b\u7ea7"

    .line 1958
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u8fd4\u56de\u6d3b\u52a8\u5217\u8868\uff0c\u8fdb\u5165\u300c\u6b27\u51a0\u6dd8\u6c70\u8d5b\u300d\u7ee7\u7eed"

    const-string v2, "Back to the event list and enter \u201cUCL Knockout\u201d to continue"

    .line 1959
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u672a\u8fdb\u5165\u5c0f\u7ec4\u524d\u4e8c\uff0c\u672c\u5c4a\u6b27\u51a0\u5230\u6b64\u7ed3\u675f"

    const-string v2, "Finished outside the top two. This UCL run is over."

    .line 1960
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u4e0b\u4e00\u573a \u00b7 \u6bd4\u8d5b\u65e5 "

    const-string v2, "Next \u00b7 Matchday "

    .line 1961
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u6dd8\u6c70\u8d5b \u00b7 "

    const-string v2, "Knockout \u00b7 "

    .line 1962
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5df2\u5b8c\u6210 "

    const-string v2, "Played "

    .line 1963
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, " \u573a"

    const-string v2, ""

    .line 1964
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\ud83c\udfc6 \u51a0\u519b \u00b7 "

    const-string v2, "\ud83c\udfc6 Champion \u00b7 "

    .line 1965
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u664b\u7ea7\u8def\u5f84\u6b63\u5728\u751f\u6210"

    const-string v2, "Preparing the road\u2026"

    .line 1966
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u4e0b\u4e00\u573a \u00b7 "

    const-string v3, "Next \u00b7 "

    .line 1967
    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, " \u8d5b\u7a0b"

    const-string v3, " Fixtures"

    .line 1968
    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "Round of 16"

    const-string v3, "16\u5f3a"

    .line 1969
    invoke-interface {v0, v3, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "Quarter-finals"

    const-string v4, "8\u5f3a"

    .line 1970
    invoke-interface {v0, v4, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "Semi-finals"

    const-string v5, "\u534a\u51b3\u8d5b"

    .line 1971
    invoke-interface {v0, v5, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "Final"

    const-string v6, "\u51b3\u8d5b"

    .line 1972
    invoke-interface {v0, v6, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u8f6e\u6b21\u6982\u89c8"

    const-string v7, "Round Overview"

    .line 1973
    invoke-interface {v0, v1, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u51a0\u519b \u00b7 "

    const-string v7, "Champion \u00b7 "

    .line 1974
    invoke-interface {v0, v1, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u6dd8\u6c70\u8d5b\u6b62\u6b65 \u00b7 \u672c\u5c4a\u6b27\u51a0\u5230\u6b64\u7ed3\u675f"

    const-string v7, "Knocked out \u00b7 This UCL run is over"

    .line 1975
    invoke-interface {v0, v1, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u664b\u7ea7\u8def\u5f84\u751f\u6210\u4e2d"

    .line 1976
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u4e0b\u4e00\u573a\u6bd4\u8d5b \u00b7 "

    const-string v2, "Next match \u00b7 "

    .line 1977
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, " \u00b7 \u5df2\u5b8c\u6210 "

    const-string v2, " \u00b7 Played "

    .line 1978
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u6b27\u51a0\u6dd8\u6c70\u8d5b \u00b7 \u5df2\u5b8c\u6210 "

    const-string v2, "UCL Knockout \u00b7 Played "

    .line 1979
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u6dd8\u6c70\u8d5b\u6b62\u6b65"

    const-string v2, "Knocked out"

    .line 1980
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u4e0b\u4e00\u573a \u00b7 VS  "

    const-string v2, "Next \u00b7 VS  "

    .line 1981
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u5f85\u5b9a"

    const-string v2, "TBD"

    .line 1982
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u8d5b\u4e8b\u6570\u636e\u6682\u65f6\u4e0d\u53ef\u7528\u3002"

    const-string v2, "Cup data is unavailable right now."

    .line 1983
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "\u91cd\u8bd5"

    const-string v2, "Retry"

    .line 1984
    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2032
    filled-new-array {v3, v4, v5, v6}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ROUND_LABELS:[Ljava/lang/String;

    return-void

    nop

    :array_24a
    .array-data 4
        0x3
        0x5
        0x8
        0xa
        0xf
        0x14
    .end array-data
.end method

.method private constructor <init>(Landroid/app/Activity;I)V
    .registers 22

    move-object/from16 v12, p0

    .line 183
    invoke-direct/range {p0 .. p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x18

    .line 115
    iput v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->bracketCrestDp:I

    const/4 v6, -0x1

    .line 128
    iput v6, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->selectedGroup:I

    const-string v1, ""

    .line 1084
    iput-object v1, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->celebrationCup:Ljava/lang/String;

    move-object/from16 v2, p1

    .line 184
    iput-object v2, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    move/from16 v1, p2

    .line 185
    iput v1, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->eventId:I

    .line 186
    invoke-static/range {p1 .. p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->launcherIsEnglish(Landroid/app/Activity;)Z

    move-result v1

    iput-boolean v1, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->english:Z

    .line 187
    invoke-virtual/range {p1 .. p1}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 188
    invoke-virtual/range {p1 .. p1}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v3

    iget v3, v3, Landroid/util/DisplayMetrics;->heightPixels:I

    if-le v1, v3, :cond_36

    const/4 v4, 0x1

    goto :goto_37

    :cond_36
    const/4 v4, 0x0

    .line 189
    :goto_37
    iput-boolean v4, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    .line 195
    new-instance v4, Landroid/graphics/Point;

    invoke-direct {v4, v1, v3}, Landroid/graphics/Point;-><init>(II)V

    .line 197
    :try_start_3e
    invoke-virtual/range {p1 .. p1}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    move-result-object v5

    invoke-interface {v5}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v5

    invoke-virtual {v5, v4}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V
    :try_end_49
    .catch Ljava/lang/Exception; {:try_start_3e .. :try_end_49} :catch_49

    .line 200
    :catch_49
    iget-boolean v5, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v5, :cond_57

    iget v5, v4, Landroid/graphics/Point;->x:I

    iget v9, v4, Landroid/graphics/Point;->y:I

    invoke-static {v5, v9}, Ljava/lang/Math;->max(II)I

    move-result v5

    move v9, v5

    goto :goto_58

    :cond_57
    move v9, v1

    .line 201
    :goto_58
    iget-boolean v5, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v5, :cond_66

    iget v5, v4, Landroid/graphics/Point;->x:I

    iget v4, v4, Landroid/graphics/Point;->y:I

    invoke-static {v5, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    move v10, v4

    goto :goto_67

    :cond_66
    move v10, v3

    .line 206
    :goto_67
    iget-boolean v4, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v4, :cond_8f

    .line 208
    :try_start_6b
    invoke-virtual/range {p1 .. p1}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    move-result-object v4

    invoke-interface {v4}, Landroid/view/WindowManager;->getCurrentWindowMetrics()Landroid/view/WindowMetrics;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/WindowMetrics;->getWindowInsets()Landroid/view/WindowInsets;

    move-result-object v4

    .line 210
    invoke-static {}, Landroid/view/WindowInsets$Type;->systemBars()I

    move-result v5

    invoke-static {}, Landroid/view/WindowInsets$Type;->displayCutout()I

    move-result v11

    or-int/2addr v5, v11

    .line 209
    invoke-virtual {v4, v5}, Landroid/view/WindowInsets;->getInsetsIgnoringVisibility(I)Landroid/graphics/Insets;

    move-result-object v4

    .line 211
    iget v5, v4, Landroid/graphics/Insets;->left:I
    :try_end_86
    .catch Ljava/lang/Exception; {:try_start_6b .. :try_end_86} :catch_8b

    .line 212
    :try_start_86
    iget v11, v4, Landroid/graphics/Insets;->right:I
    :try_end_88
    .catch Ljava/lang/Exception; {:try_start_86 .. :try_end_88} :catch_8c

    .line 213
    :try_start_88
    iget v4, v4, Landroid/graphics/Insets;->bottom:I
    :try_end_8a
    .catch Ljava/lang/Exception; {:try_start_88 .. :try_end_8a} :catch_8d

    goto :goto_92

    :catch_8b
    const/4 v5, 0x0

    :catch_8c
    const/4 v11, 0x0

    :catch_8d
    const/4 v4, 0x0

    goto :goto_92

    :cond_8f
    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v11, 0x0

    :goto_92
    int-to-float v13, v10

    const/high16 v14, 0x44870000    # 1080.0f

    div-float v14, v13, v14

    move v15, v9

    float-to-double v8, v14

    const-wide v6, 0x3fcd70a3d70a3d71L    # 0.23

    .line 218
    invoke-static {v8, v9, v6, v7}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v6

    const-wide v17, 0x4056800000000000L    # 90.0

    mul-double v6, v6, v17

    double-to-float v6, v6

    const/high16 v7, 0x41900000    # 18.0f

    mul-float/2addr v7, v14

    const v17, 0x3f1eb852    # 0.62f

    int-to-float v4, v4

    mul-float v4, v4, v17

    add-float/2addr v7, v4

    sub-float/2addr v13, v7

    sub-float/2addr v13, v6

    int-to-float v4, v5

    const/high16 v7, 0x42400000    # 48.0f

    mul-float/2addr v7, v14

    add-float/2addr v4, v7

    move/from16 v17, v1

    const-wide v0, 0x3feb333333333333L    # 0.85

    .line 220
    invoke-static {v8, v9, v0, v1}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    const-wide v8, 0x4079700000000000L    # 407.0

    mul-double/2addr v0, v8

    double-to-float v0, v0

    add-float/2addr v4, v0

    const/high16 v0, 0x41600000    # 14.0f

    mul-float/2addr v0, v14

    add-float/2addr v4, v0

    .line 222
    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v9

    const/high16 v0, 0x41400000    # 12.0f

    mul-float/2addr v14, v0

    sub-float v0, v13, v14

    .line 223
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v14

    .line 224
    iput v5, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->safeLeftPx:I

    .line 225
    iput v11, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->safeRightPx:I

    .line 226
    invoke-static {v13}, Ljava/lang/Math;->round(F)I

    move-result v0

    iput v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->barTopPx:I

    .line 227
    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v0

    iput v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->barHeightPx:I

    .line 228
    iget-boolean v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v0, :cond_f5

    move v6, v15

    goto :goto_fe

    :cond_f5
    move/from16 v1, v17

    int-to-float v1, v1

    const v4, 0x3f75c28f    # 0.96f

    mul-float/2addr v1, v4

    float-to-int v1, v1

    move v6, v1

    :goto_fe
    if-eqz v0, :cond_102

    move v8, v14

    goto :goto_109

    :cond_102
    int-to-float v0, v3

    const v1, 0x3f6147ae    # 0.88f

    mul-float/2addr v0, v1

    float-to-int v0, v0

    move v8, v0

    .line 232
    :goto_109
    new-instance v11, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v0

    invoke-direct {v11, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x1

    .line 233
    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v0, 0x16

    .line 234
    invoke-direct {v12, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    const/16 v3, 0xe

    invoke-direct {v12, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    invoke-direct {v12, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v0

    invoke-direct {v12, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-virtual {v11, v1, v4, v0, v5}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 235
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    sget-object v1, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    const v4, -0xf5eab0

    const v5, -0xe5c220

    filled-new-array {v4, v5}, [I

    move-result-object v4

    invoke-direct {v0, v1, v4}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 237
    iget-boolean v1, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    const/16 v13, 0x12

    if-eqz v1, :cond_146

    const/4 v1, 0x0

    goto :goto_14b

    :cond_146
    invoke-direct {v12, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    int-to-float v1, v1

    :goto_14b
    invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 238
    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 239
    iget-boolean v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v0, :cond_165

    .line 242
    invoke-static/range {p1 .. p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->backdropBitmap(Landroid/app/Activity;)Landroid/graphics/Bitmap;

    move-result-object v0

    if-eqz v0, :cond_163

    .line 243
    new-instance v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;

    invoke-direct {v1, v0, v15, v10}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;-><init>(Landroid/graphics/Bitmap;II)V

    invoke-virtual {v11, v1}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_163
    move-object v1, v0

    goto :goto_166

    :cond_165
    const/4 v1, 0x0

    .line 246
    :goto_166
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v4

    invoke-direct {v0, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v4, 0x10

    .line 247
    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 248
    new-instance v5, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$StarBadge;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v7

    invoke-direct {v5, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$StarBadge;-><init>(Landroid/content/Context;)V

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v13, 0x26

    invoke-direct {v12, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    invoke-direct {v12, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v13

    invoke-direct {v7, v4, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v5, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v4, "\u5c0f\u7ec4\u6982\u51b5"

    .line 249
    invoke-direct {v12, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0x1a

    const/16 v7, -0x1eb6

    const/4 v13, 0x1

    invoke-direct {v12, v4, v5, v7, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v4

    .line 250
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x2

    invoke-direct {v5, v7, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v13, 0xa

    .line 251
    invoke-direct {v12, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v13

    iput v13, v5, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 252
    invoke-virtual {v0, v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 253
    new-instance v4, Landroid/view/View;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v5

    invoke-direct {v4, v5}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const/16 v5, -0x1676

    const v13, -0x2669e6

    const/4 v7, 0x2

    .line 254
    invoke-direct {v12, v5, v13, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->vgrad(III)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 255
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v13, 0x4

    invoke-direct {v12, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v13

    const/16 v7, 0x18

    invoke-direct {v12, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    invoke-direct {v5, v13, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v7, 0xc

    .line 256
    invoke-direct {v12, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v13

    iput v13, v5, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 257
    invoke-virtual {v0, v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 258
    new-instance v4, Landroid/view/View;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v5

    invoke-direct {v4, v5}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v13, 0x3f800000    # 1.0f

    const/4 v3, 0x0

    const/4 v7, 0x1

    invoke-direct {v5, v3, v7, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v4, "\u6b27\u51a0\u5c0f\u7ec4\u8d5b"

    .line 259
    invoke-direct {v12, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0xd

    const/4 v13, -0x1

    invoke-direct {v12, v4, v5, v13, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v4

    iput-object v4, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->subtitle:Landroid/widget/TextView;

    const/16 v7, 0x11

    .line 260
    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v13, 0xe

    .line 261
    invoke-direct {v12, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    invoke-direct {v12, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v13

    invoke-virtual {v4, v7, v3, v13, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    const v7, 0x44ffffff    # 2047.9999f

    const v13, 0x18ffffff

    const/16 v3, 0x10

    .line 262
    invoke-direct {v12, v7, v13, v3, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const-string v4, "\u5237\u65b0"

    .line 263
    invoke-direct {v12, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0xd

    const/4 v7, 0x1

    const/4 v13, -0x1

    invoke-direct {v12, v4, v5, v13, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v4

    const/16 v5, 0x11

    .line 264
    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setGravity(I)V

    .line 265
    invoke-direct {v12, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {v12, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    const/4 v13, 0x0

    invoke-virtual {v4, v5, v13, v7, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    const v5, 0x18ffffff

    const v7, 0x44ffffff    # 2047.9999f

    .line 266
    invoke-direct {v12, v7, v5, v3, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v13

    invoke-virtual {v4, v13}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 267
    new-instance v3, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda8;

    invoke-direct {v3, v12}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda8;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V

    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 268
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v5, 0x20

    invoke-direct {v12, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    const/4 v13, -0x2

    invoke-direct {v3, v13, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v7, 0xc

    .line 269
    invoke-direct {v12, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v13

    iput v13, v3, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 270
    invoke-virtual {v0, v4, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v3, "\u2715"

    const/16 v4, 0x10

    const/4 v7, 0x1

    const/4 v13, -0x1

    .line 271
    invoke-direct {v12, v3, v4, v13, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v3

    const/16 v7, 0x11

    .line 272
    invoke-virtual {v3, v7}, Landroid/widget/TextView;->setGravity(I)V

    const v4, 0x55ffffff    # 3.518437E13f

    const v5, 0x44ffffff    # 2047.9999f

    const/16 v7, 0x12

    const v13, 0x18ffffff

    .line 273
    invoke-direct {v12, v5, v13, v7, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 274
    new-instance v4, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda9;

    invoke-direct {v4, v12}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda9;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 275
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v5, 0x24

    invoke-direct {v12, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    invoke-direct {v12, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {v4, v7, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v5, 0xc

    .line 276
    invoke-direct {v12, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    iput v7, v4, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 277
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v13, 0x20

    invoke-direct {v12, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v13

    const/4 v2, -0x2

    invoke-direct {v7, v2, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 278
    invoke-direct {v12, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    iput v2, v7, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 279
    iget-boolean v2, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-nez v2, :cond_2d0

    .line 280
    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->resetButton()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v0, v2, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 281
    invoke-virtual {v0, v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 283
    :cond_2d0
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x2c

    invoke-direct {v12, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v3

    const/4 v4, -0x1

    invoke-direct {v2, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v11, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 285
    new-instance v0, Landroid/widget/HorizontalScrollView;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v0, v2}, Landroid/widget/HorizontalScrollView;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x0

    .line 286
    invoke-virtual {v0, v2}, Landroid/widget/HorizontalScrollView;->setHorizontalScrollBarEnabled(Z)V

    .line 287
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v2, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->tabs:Landroid/widget/LinearLayout;

    const/16 v3, 0x10

    .line 288
    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 289
    invoke-virtual {v0, v2}, Landroid/widget/HorizontalScrollView;->addView(Landroid/view/View;)V

    .line 290
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x28

    invoke-direct {v12, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v3

    const/4 v4, -0x1

    invoke-direct {v2, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v3, 0x6

    .line 291
    invoke-direct {v12, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v3

    iput v3, v2, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 292
    invoke-virtual {v11, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 294
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v0, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->content:Landroid/widget/LinearLayout;

    const/4 v2, 0x1

    .line 295
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 296
    new-instance v3, Landroid/widget/ScrollView;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 297
    invoke-virtual {v3, v2}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    const/4 v4, 0x0

    .line 298
    invoke-virtual {v3, v4}, Landroid/widget/ScrollView;->setVerticalScrollBarEnabled(Z)V

    .line 301
    invoke-virtual {v3, v2}, Landroid/widget/ScrollView;->setVerticalFadingEdgeEnabled(Z)V

    .line 302
    iget-boolean v2, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v2, :cond_33e

    const/16 v2, 0x40

    goto :goto_340

    :cond_33e
    const/16 v2, 0x1c

    :goto_340
    invoke-direct {v12, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    invoke-virtual {v3, v2}, Landroid/widget/ScrollView;->setFadingEdgeLength(I)V

    const/4 v2, 0x2

    .line 303
    invoke-virtual {v3, v2}, Landroid/widget/ScrollView;->setOverScrollMode(I)V

    .line 304
    invoke-virtual {v3, v0}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 305
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v4, 0x0

    const/4 v5, -0x1

    invoke-direct {v0, v5, v4, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/16 v2, 0x8

    .line 306
    invoke-direct {v12, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    iput v2, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 307
    invoke-virtual {v11, v3, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 311
    iput-object v11, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->legacy:Landroid/widget/LinearLayout;

    .line 312
    iput v15, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->sceneW:I

    .line 313
    iput v10, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->sceneH:I

    .line 314
    iput v9, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeRightPx:I

    .line 315
    iput v14, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeTopPx:I

    .line 316
    iget-boolean v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v0, :cond_378

    const/4 v0, 0x0

    invoke-direct {v12, v11, v1, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->openSingleWindow(Landroid/widget/LinearLayout;Landroid/graphics/Bitmap;I)Z

    move-result v2

    if-eqz v2, :cond_378

    return-void

    .line 320
    :cond_378
    new-instance v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$1;

    const v3, 0x103023a

    move-object v0, v7

    move-object v13, v1

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    const/4 v5, 0x0

    move v4, v9

    move/from16 v17, v9

    move-object v9, v5

    move v5, v14

    invoke-direct/range {v0 .. v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$1;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Landroid/content/Context;III)V

    iput-object v7, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    .line 331
    new-instance v0, Landroid/widget/FrameLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rootHost:Landroid/widget/FrameLayout;

    .line 332
    invoke-virtual {v11}, Landroid/widget/LinearLayout;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/FrameLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 333
    invoke-virtual {v11, v9}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 334
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rootHost:Landroid/widget/FrameLayout;

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v2, -0x1

    invoke-direct {v1, v2, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v11, v1}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 335
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    iget-object v1, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rootHost:Landroid/widget/FrameLayout;

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog;->setView(Landroid/view/View;)V

    .line 336
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog;->requestWindowFeature(I)Z

    .line 337
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog;->setCanceledOnTouchOutside(Z)V

    .line 338
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    new-instance v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda10;

    invoke-direct {v1, v12}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda10;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 339
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->show()V

    .line 340
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    if-eqz v0, :cond_484

    .line 341
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const v1, 0x106000d

    invoke-virtual {v0, v1}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    .line 342
    iget-boolean v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v0, :cond_3f8

    if-eqz v13, :cond_3f8

    .line 346
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    new-instance v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;

    invoke-direct {v1, v13, v15, v10}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;-><init>(Landroid/graphics/Bitmap;II)V

    invoke-virtual {v0, v1}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 348
    :cond_3f8
    iget-boolean v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v0, :cond_407

    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/Window;->setWindowAnimations(I)V

    goto :goto_408

    :cond_407
    const/4 v1, 0x0

    .line 349
    :goto_408
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0, v1, v1, v1, v1}, Landroid/view/View;->setPadding(IIII)V

    .line 350
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    iget-boolean v1, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v1, :cond_423

    const v7, 0x800033

    goto :goto_425

    :cond_423
    const/16 v7, 0x11

    :goto_425
    invoke-virtual {v0, v7}, Landroid/view/Window;->setGravity(I)V

    .line 351
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0, v6, v8}, Landroid/view/Window;->setLayout(II)V

    .line 352
    iget-boolean v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v0, :cond_46c

    .line 354
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/view/Window;->clearFlags(I)V

    .line 355
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v11, 0x0

    invoke-virtual {v0, v11}, Landroid/view/Window;->setDimAmount(F)V

    .line 356
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const v1, 0x40328

    invoke-virtual {v0, v1}, Landroid/view/Window;->addFlags(I)V

    .line 361
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    const/4 v1, 0x3

    .line 362
    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->layoutInDisplayCutoutMode:I

    .line 363
    iget-object v1, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    invoke-virtual {v1}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    goto :goto_485

    :cond_46c
    const/4 v11, 0x0

    .line 365
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v1, 0x2

    invoke-virtual {v0, v1}, Landroid/view/Window;->addFlags(I)V

    .line 366
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    invoke-virtual {v0}, Landroid/app/AlertDialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const v1, 0x3ee66666    # 0.45f

    invoke-virtual {v0, v1}, Landroid/view/Window;->setDimAmount(F)V

    goto :goto_485

    :cond_484
    const/4 v11, 0x0

    .line 369
    :goto_485
    iget-boolean v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v0, :cond_4a5

    sub-int v6, v15, v17

    sub-int v7, v10, v14

    const/4 v8, 0x0

    const/16 v16, 0x1

    move-object/from16 v0, p0

    move-object v1, v13

    move v2, v15

    move v3, v10

    move/from16 v4, v17

    move v5, v14

    move/from16 v9, v17

    move v10, v14

    move v13, v11

    move/from16 v11, v16

    .line 371
    invoke-direct/range {v0 .. v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->coverWindow(Landroid/graphics/Bitmap;IIIIIIIIIZ)Landroid/app/Dialog;

    move-result-object v0

    iput-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->strip:Landroid/app/Dialog;

    goto :goto_4a6

    :cond_4a5
    move v13, v11

    .line 375
    :goto_4a6
    iget-boolean v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-nez v0, :cond_4d4

    .line 376
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rootHost:Landroid/widget/FrameLayout;

    invoke-virtual {v0, v13}, Landroid/widget/FrameLayout;->setAlpha(F)V

    .line 377
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rootHost:Landroid/widget/FrameLayout;

    const/16 v1, 0x12

    invoke-direct {v12, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Landroid/widget/FrameLayout;->setTranslationY(F)V

    .line 378
    iget-object v0, v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rootHost:Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Landroid/widget/FrameLayout;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v13}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const-wide/16 v1, 0x104

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    :cond_4d4
    return-void
.end method

.method static synthetic access$000(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V
    .registers 1

    .line 50
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->closeAnimated()V

    return-void
.end method

.method static synthetic access$100(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;II)V
    .registers 3

    .line 50
    invoke-direct {p0, p1, p2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->applyWindowGeometry(II)V

    return-void
.end method

.method static synthetic access$200(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;
    .registers 1

    .line 50
    iget-object p0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelRoot:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;

    return-object p0
.end method

.method static synthetic access$300(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)Z
    .registers 1

    .line 50
    iget-boolean p0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->closing:Z

    return p0
.end method

.method static synthetic access$400(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;I)I
    .registers 2

    .line 50
    invoke-direct {p0, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result p0

    return p0
.end method

.method static synthetic access$500()[Ljava/lang/String;
    .registers 1

    .line 50
    sget-object v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ROUND_LABELS:[Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$600(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    .line 50
    invoke-direct {p0, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$700(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Ljava/lang/String;IIZ)Landroid/widget/TextView;
    .registers 5

    .line 50
    invoke-direct {p0, p1, p2, p3, p4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$800(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;II)Landroid/graphics/drawable/GradientDrawable;
    .registers 3

    .line 50
    invoke-direct {p0, p1, p2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rounded(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$900(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Lorg/json/JSONObject;)Landroid/view/View;
    .registers 2

    .line 50
    invoke-direct {p0, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->bracketCard(Lorg/json/JSONObject;)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method private applyWindowGeometry(II)V
    .registers 15

    if-lez p1, :cond_b1

    if-lez p2, :cond_b1

    .line 431
    iget v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->sceneW:I

    if-ne p1, v0, :cond_e

    iget v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->sceneH:I

    if-ne p2, v0, :cond_e

    goto/16 :goto_b1

    :cond_e
    const/4 v0, 0x0

    .line 436
    :try_start_f
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    invoke-virtual {v1}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    move-result-object v1

    invoke-interface {v1}, Landroid/view/WindowManager;->getCurrentWindowMetrics()Landroid/view/WindowMetrics;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/WindowMetrics;->getWindowInsets()Landroid/view/WindowInsets;

    move-result-object v1

    .line 438
    invoke-static {}, Landroid/view/WindowInsets$Type;->systemBars()I

    move-result v2

    invoke-static {}, Landroid/view/WindowInsets$Type;->displayCutout()I

    move-result v3

    or-int/2addr v2, v3

    .line 437
    invoke-virtual {v1, v2}, Landroid/view/WindowInsets;->getInsetsIgnoringVisibility(I)Landroid/graphics/Insets;

    move-result-object v1

    .line 439
    iget v2, v1, Landroid/graphics/Insets;->left:I
    :try_end_2c
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_2c} :catch_33

    .line 440
    :try_start_2c
    iget v3, v1, Landroid/graphics/Insets;->right:I
    :try_end_2e
    .catch Ljava/lang/Exception; {:try_start_2c .. :try_end_2e} :catch_31

    .line 441
    :try_start_2e
    iget v1, v1, Landroid/graphics/Insets;->bottom:I
    :try_end_30
    .catch Ljava/lang/Exception; {:try_start_2e .. :try_end_30} :catch_35

    goto :goto_36

    :catch_31
    move v3, v0

    goto :goto_35

    :catch_33
    move v2, v0

    move v3, v2

    :catch_35
    :goto_35
    move v1, v0

    :goto_36
    int-to-float v4, p2

    const/high16 v5, 0x44870000    # 1080.0f

    div-float v5, v4, v5

    float-to-double v6, v5

    const-wide v8, 0x3fcd70a3d70a3d71L    # 0.23

    .line 445
    invoke-static {v6, v7, v8, v9}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v8

    const-wide v10, 0x4056800000000000L    # 90.0

    mul-double/2addr v8, v10

    double-to-float v8, v8

    const/high16 v9, 0x41900000    # 18.0f

    mul-float/2addr v9, v5

    const v10, 0x3f1eb852    # 0.62f

    int-to-float v1, v1

    mul-float/2addr v1, v10

    add-float/2addr v9, v1

    sub-float/2addr v4, v9

    sub-float/2addr v4, v8

    int-to-float v1, v2

    const/high16 v9, 0x42400000    # 48.0f

    mul-float/2addr v9, v5

    add-float/2addr v1, v9

    const-wide v9, 0x3feb333333333333L    # 0.85

    .line 447
    invoke-static {v6, v7, v9, v10}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v6

    const-wide v9, 0x4079700000000000L    # 407.0

    mul-double/2addr v6, v9

    double-to-float v6, v6

    add-float/2addr v1, v6

    .line 448
    iput v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->safeLeftPx:I

    .line 449
    iput v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->safeRightPx:I

    .line 450
    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v2

    iput v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->barTopPx:I

    .line 451
    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    move-result v2

    iput v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->barHeightPx:I

    const/high16 v2, 0x41600000    # 14.0f

    mul-float/2addr v2, v5

    add-float/2addr v1, v2

    .line 452
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    iput v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeRightPx:I

    const/high16 v1, 0x41400000    # 12.0f

    mul-float/2addr v5, v1

    sub-float/2addr v4, v5

    .line 453
    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v1

    iput v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeTopPx:I

    .line 454
    iput p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->sceneW:I

    .line 455
    iput p2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->sceneH:I

    .line 456
    iget-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelRoot:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;

    if-eqz p1, :cond_a0

    iget p2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeRightPx:I

    const/16 v2, 0x4e20

    invoke-virtual {p1, v0, v1, p2, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->setHole(IIII)V

    .line 457
    :cond_a0
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->layoutPads()V

    .line 458
    iget-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    if-eqz p1, :cond_b1

    sget-object p1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->MAIN:Landroid/os/Handler;

    new-instance p2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda11;

    invoke-direct {p2, p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda11;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V

    invoke-virtual {p1, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_b1
    :goto_b1
    return-void
.end method

.method private static declared-synchronized backdropBitmap(Landroid/app/Activity;)Landroid/graphics/Bitmap;
    .registers 5

    const-class v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    monitor-enter v0

    .line 79
    :try_start_3
    invoke-virtual {p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    .line 80
    iget v2, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    iget v3, v1, Landroid/util/DisplayMetrics;->heightPixels:I

    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v2

    int-to-float v2, v2

    iget v3, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    iget v1, v1, Landroid/util/DisplayMetrics;->heightPixels:I

    .line 81
    invoke-static {v3, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/4 v3, 0x1

    invoke-static {v3, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v2, v1

    const v1, 0x3ff9999a    # 1.95f

    cmpl-float v1, v2, v1

    if-ltz v1, :cond_2d

    const-string v1, "cup-bg/ucl_bg_wide.jpg"

    goto :goto_39

    :cond_2d
    const v1, 0x3fc66666    # 1.55f

    cmpl-float v1, v2, v1

    if-ltz v1, :cond_37

    const-string v1, "cup-bg/ucl_bg.jpg"

    goto :goto_39

    :cond_37
    const-string v1, "cup-bg/ucl_bg_0403.jpg"

    .line 83
    :goto_39
    sget-object v2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->backdropCache:Landroid/graphics/Bitmap;

    if-eqz v2, :cond_45

    sget-object v2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->backdropName:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2
    :try_end_43
    .catchall {:try_start_3 .. :try_end_43} :catchall_73

    if-nez v2, :cond_6f

    .line 84
    :cond_45
    :try_start_45
    invoke-virtual {p0}, Landroid/app/Activity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object p0

    invoke-virtual {p0, v1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object p0
    :try_end_4d
    .catch Ljava/lang/Exception; {:try_start_45 .. :try_end_4d} :catch_67
    .catchall {:try_start_45 .. :try_end_4d} :catchall_73

    .line 85
    :try_start_4d
    invoke-static {p0}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v2

    sput-object v2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->backdropCache:Landroid/graphics/Bitmap;

    .line 86
    sput-object v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->backdropName:Ljava/lang/String;
    :try_end_55
    .catchall {:try_start_4d .. :try_end_55} :catchall_5b

    if-eqz p0, :cond_6f

    .line 87
    :try_start_57
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_5a
    .catch Ljava/lang/Exception; {:try_start_57 .. :try_end_5a} :catch_67
    .catchall {:try_start_57 .. :try_end_5a} :catchall_73

    goto :goto_6f

    :catchall_5b
    move-exception v1

    if-eqz p0, :cond_66

    .line 84
    :try_start_5e
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_61
    .catchall {:try_start_5e .. :try_end_61} :catchall_62

    goto :goto_66

    :catchall_62
    move-exception p0

    :try_start_63
    invoke-virtual {v1, p0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_66
    :goto_66
    throw v1
    :try_end_67
    .catch Ljava/lang/Exception; {:try_start_63 .. :try_end_67} :catch_67
    .catchall {:try_start_63 .. :try_end_67} :catchall_73

    :catch_67
    move-exception p0

    :try_start_68
    const-string v1, "E112_CUP_UI"

    const-string v2, "backdrop unavailable"

    .line 88
    invoke-static {v1, v2, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 91
    :cond_6f
    :goto_6f
    sget-object p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->backdropCache:Landroid/graphics/Bitmap;
    :try_end_71
    .catchall {:try_start_68 .. :try_end_71} :catchall_73

    monitor-exit v0

    return-object p0

    :catchall_73
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method private badgeParams()Landroid/widget/LinearLayout$LayoutParams;
    .registers 4

    .line 1303
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v1, 0x26

    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    invoke-direct {v0, v2, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v1, 0xc

    .line 1304
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    return-object v0
.end method

.method private bracketCard(Lorg/json/JSONObject;)Landroid/view/View;
    .registers 12

    const-string v0, "isPlayer"

    .line 2363
    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v0

    const-string v1, "winner"

    .line 2364
    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v2

    const-string v3, ""

    if-eqz v2, :cond_11

    goto :goto_15

    :cond_11
    invoke-virtual {p1, v1, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 2365
    :goto_15
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x1

    .line 2366
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v4, 0xc

    if-eqz v0, :cond_51

    const v0, -0xc5a301

    const v5, -0xe070ab

    .line 2369
    invoke-direct {p0, v0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v0

    const v5, -0xf0dc70

    const v6, -0xf4b2d6

    invoke-direct {p0, v5, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v5

    const v6, -0x55604701

    const v7, -0x55601740

    invoke-direct {p0, v6, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v6

    invoke-direct {p0, v0, v5, v4, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    .line 2370
    sget-object v4, Landroid/graphics/drawable/GradientDrawable$Orientation;->LEFT_RIGHT:Landroid/graphics/drawable/GradientDrawable$Orientation;

    invoke-virtual {v0, v4}, Landroid/graphics/drawable/GradientDrawable;->setOrientation(Landroid/graphics/drawable/GradientDrawable$Orientation;)V

    .line 2371
    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_5b

    :cond_51
    const v0, -0x19ede7d5

    .line 2373
    invoke-direct {p0, v0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rounded(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :goto_5b
    const-string v0, "HOME"

    .line 2375
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const-string v5, "AWAY"

    invoke-virtual {v5, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    const-string v7, "home"

    invoke-direct {p0, p1, v7, v4, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->bracketRow(Lorg/json/JSONObject;Ljava/lang/String;ZZ)Landroid/view/View;

    move-result-object v4

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, -0x1

    const/4 v8, 0x0

    const/high16 v9, 0x3f800000    # 1.0f

    invoke-direct {v6, v7, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v1, v4, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2377
    new-instance v4, Landroid/view/View;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v6

    invoke-direct {v4, v6}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const v6, 0x14ffffff

    .line 2378
    invoke-virtual {v4, v6}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2379
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v6, v7, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v4, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2380
    invoke-virtual {v5, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const-string v3, "away"

    invoke-direct {p0, p1, v3, v2, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->bracketRow(Lorg/json/JSONObject;Ljava/lang/String;ZZ)Landroid/view/View;

    move-result-object p1

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, v7, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v1, p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v1
.end method

.method private bracketRow(Lorg/json/JSONObject;Ljava/lang/String;ZZ)Landroid/view/View;
    .registers 22

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    .line 2386
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v4, 0x10

    .line 2387
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/4 v4, 0x6

    .line 2388
    invoke-direct {v0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {v0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v6

    const/4 v7, 0x0

    invoke-virtual {v3, v5, v7, v6, v7}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const/16 v5, 0xa

    if-eqz p3, :cond_33

    const v6, -0x19e062a2

    const v8, -0x33f0a5c8    # -3.7578976E7f

    .line 2391
    invoke-direct {v0, v6, v8, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->hgrad(III)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_48

    :cond_33
    if-eqz p4, :cond_48

    const v6, -0x1979dcc8

    const v8, -0x33b5e9da    # -5.297577E7f

    .line 2393
    invoke-direct {v0, v6, v8, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->hgrad(III)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const v5, 0x3f4ccccd    # 0.8f

    .line 2394
    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setAlpha(F)V

    .line 2396
    :cond_48
    :goto_48
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "TeamId"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v5

    .line 2397
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, "Team"

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x1

    if-lez v5, :cond_7d

    .line 2398
    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_7d

    move v9, v8

    goto :goto_7e

    :cond_7d
    move v9, v7

    :goto_7e
    if-eqz v9, :cond_96

    .line 2400
    iget v10, v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->bracketCrestDp:I

    invoke-direct {v0, v5, v6, v10}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->plateCrest(ILjava/lang/String;I)Landroid/view/View;

    move-result-object v5

    .line 2401
    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    iput v4, v10, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 2402
    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    goto :goto_cb

    .line 2404
    :cond_96
    new-instance v5, Landroid/view/View;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v10

    invoke-direct {v5, v10}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const/16 v10, 0x14

    const v11, 0x22ffffff

    const v12, 0x33ffffff

    const v13, 0x11ffffff

    .line 2405
    invoke-direct {v0, v12, v13, v10, v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v10

    invoke-virtual {v5, v10}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2406
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    iget v11, v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->bracketCrestDp:I

    invoke-direct {v0, v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v11

    iget v12, v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->bracketCrestDp:I

    invoke-direct {v0, v12}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v12

    invoke-direct {v10, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2407
    invoke-direct {v0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    iput v4, v10, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 2408
    invoke-virtual {v3, v5, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_cb
    const/4 v4, -0x1

    if-nez v9, :cond_d2

    const v5, -0x908558

    goto :goto_d9

    :cond_d2
    if-eqz p4, :cond_d8

    const v5, -0x282411

    goto :goto_d9

    :cond_d8
    move v5, v4

    :goto_d9
    if-eqz v9, :cond_dc

    goto :goto_e2

    :cond_dc
    const-string v6, "\u5f85\u5b9a"

    .line 2411
    invoke-direct {v0, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    :goto_e2
    if-eqz v9, :cond_e8

    if-nez p4, :cond_e8

    move v9, v8

    goto :goto_e9

    :cond_e8
    move v9, v7

    :goto_e9
    const/16 v10, 0xd

    invoke-direct {v0, v6, v10, v5, v9}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v5

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v9, 0x3f800000    # 1.0f

    invoke-direct {v6, v7, v4, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v3, v5, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2412
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "Score"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_128

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v5

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    goto :goto_12a

    :cond_128
    const-string v5, ""

    .line 2414
    :goto_12a
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, "Legs"

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v6

    const-string v9, ")"

    const-string v10, "("

    const-string v12, "Pk"

    const/16 v13, 0x11

    if-eqz v6, :cond_1f3

    .line 2415
    invoke-virtual {v6}, Lorg/json/JSONArray;->length()I

    move-result v14

    if-lez v14, :cond_1f3

    .line 2416
    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    move v15, v7

    move/from16 v16, v15

    .line 2418
    :goto_157
    invoke-virtual {v6}, Lorg/json/JSONArray;->length()I

    move-result v11

    if-ge v15, v11, :cond_174

    .line 2419
    invoke-virtual {v6, v15}, Lorg/json/JSONArray;->optInt(I)I

    move-result v11

    add-int v16, v16, v11

    if-lez v15, :cond_16a

    const-string v11, "  "

    .line 2420
    invoke-virtual {v14, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 2421
    :cond_16a
    invoke-virtual {v6, v15}, Lorg/json/JSONArray;->optInt(I)I

    move-result v11

    invoke-virtual {v14, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    add-int/lit8 v15, v15, 0x1

    goto :goto_157

    .line 2423
    :cond_174
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_17f

    invoke-static/range {v16 .. v16}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    goto :goto_1bc

    .line 2424
    :cond_17f
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_1bc

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    .line 2425
    :cond_1bc
    :goto_1bc
    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0xc

    const v6, -0x463d1a

    invoke-direct {v0, v1, v2, v6, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v1

    const v2, 0x800015

    .line 2426
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setGravity(I)V

    .line 2427
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v6, 0x22

    invoke-direct {v0, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v6

    invoke-direct {v2, v6, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2428
    invoke-direct {v0, v5, v13, v4, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v1

    .line 2429
    invoke-virtual {v1, v13}, Landroid/widget/TextView;->setGravity(I)V

    .line 2430
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v5, 0x28

    invoke-direct {v0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {v2, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v3

    .line 2433
    :cond_1f3
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_236

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1, v6}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_236

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    .line 2434
    :cond_236
    invoke-direct {v0, v5, v13, v4, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v1

    .line 2435
    invoke-virtual {v1, v13}, Landroid/widget/TextView;->setGravity(I)V

    .line 2436
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v5, 0x28

    invoke-direct {v0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {v2, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v3
.end method

.method private buildScene(Lorg/json/JSONArray;Lorg/json/JSONArray;Lorg/json/JSONArray;Ljava/lang/String;IZIIIIIII)Landroid/widget/FrameLayout;
    .registers 30

    move-object/from16 v7, p0

    move-object/from16 v8, p1

    move-object/from16 v9, p4

    .line 1220
    new-instance v10, Landroid/widget/FrameLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v0

    invoke-direct {v10, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    sub-int v0, p7, p10

    sub-int v0, v0, p11

    int-to-float v11, v0

    const v0, 0x3c8f5c29    # 0.0175f

    mul-float/2addr v0, v11

    float-to-int v0, v0

    add-int v12, p10, v0

    add-int v0, p11, v0

    .line 1225
    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->sceneHeader()Landroid/widget/LinearLayout;

    move-result-object v2

    move/from16 v1, p8

    int-to-float v13, v1

    const v1, 0x3cb43958    # 0.022f

    mul-float/2addr v1, v13

    float-to-int v4, v1

    sub-int v1, p7, v12

    sub-int v14, v1, v0

    const/16 v0, 0x2c

    invoke-direct {v7, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v6

    move-object/from16 v0, p0

    move-object v1, v10

    move v3, v12

    move v5, v14

    invoke-direct/range {v0 .. v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->put(Landroid/widget/FrameLayout;Landroid/view/View;IIII)V

    .line 1226
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v0

    invoke-direct {v2, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x10

    .line 1227
    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/4 v15, 0x0

    const/4 v6, 0x1

    if-eqz p6, :cond_81

    const-string v0, "\u5c0f\u7ec4\u8d5b"

    .line 1229
    invoke-direct {v7, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v7, v0, v6, v15}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->modeChip(Ljava/lang/String;ZZ)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v0, "\u6dd8\u6c70\u8d5b"

    .line 1230
    invoke-direct {v7, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v7, v0, v15, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->modeChip(Ljava/lang/String;ZZ)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1231
    new-instance v0, Landroid/view/View;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 1232
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0xe

    invoke-direct {v7, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v3

    invoke-direct {v1, v3, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1233
    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :cond_81
    if-eqz v8, :cond_ad

    move v0, v15

    .line 1236
    :goto_84
    invoke-virtual/range {p1 .. p1}, Lorg/json/JSONArray;->length()I

    move-result v1

    if-ge v0, v1, :cond_ad

    .line 1237
    invoke-virtual {v8, v0}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v1

    if-eqz v1, :cond_aa

    const-string v3, "group"

    .line 1238
    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iget v4, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->selectedGroup:I

    if-ne v0, v4, :cond_9c

    move v4, v6

    goto :goto_9d

    :cond_9c
    move v4, v15

    :goto_9d
    const-string v5, "isOwn"

    invoke-virtual {v1, v5}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v1

    invoke-direct {v7, v3, v4, v1, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->groupTab(Ljava/lang/String;ZZI)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :cond_aa
    add-int/lit8 v0, v0, 0x1

    goto :goto_84

    :cond_ad
    const v0, 0x3ddb22d1    # 0.107f

    mul-float/2addr v0, v13

    float-to-int v4, v0

    const/16 v0, 0x26

    .line 1241
    invoke-direct {v7, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v8

    move-object/from16 v0, p0

    move-object v1, v10

    move v3, v12

    move v5, v14

    move v14, v6

    move v6, v8

    invoke-direct/range {v0 .. v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->put(Landroid/widget/FrameLayout;Landroid/view/View;IIII)V

    const v0, 0x3f05c28f    # 0.5225f

    mul-float/2addr v0, v11

    float-to-int v8, v0

    const v0, 0x3e3851ec    # 0.18f

    mul-float/2addr v0, v13

    float-to-int v6, v0

    .line 1245
    iget v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->selectedGroup:I

    move/from16 v1, p5

    if-ne v0, v1, :cond_d6

    move-object/from16 v0, p2

    move v15, v14

    goto :goto_d8

    :cond_d6
    move-object/from16 v0, p2

    :goto_d8
    invoke-direct {v7, v0, v9, v15}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->standingsCard(Lorg/json/JSONArray;Ljava/lang/String;Z)Landroid/widget/LinearLayout;

    move-result-object v2

    const/16 v0, 0xc

    invoke-direct {v7, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v0

    sub-int v0, p12, v0

    sub-int v14, v0, v6

    move-object/from16 v0, p0

    move-object v1, v10

    move v3, v12

    move v4, v6

    move v5, v8

    move v15, v6

    move v6, v14

    invoke-direct/range {v0 .. v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->put(Landroid/widget/FrameLayout;Landroid/view/View;IIII)V

    const v0, 0x3f0e147b    # 0.555f

    mul-float/2addr v0, v11

    float-to-int v0, v0

    add-int v14, p10, v0

    const v0, 0x3ed9999a    # 0.425f

    mul-float/2addr v11, v0

    float-to-int v11, v11

    .line 1248
    iget-object v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v1, "matchdays"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    iget-object v1, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v2, "standings"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1

    invoke-direct {v7, v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->roadCard(Lorg/json/JSONArray;Lorg/json/JSONArray;)Landroid/view/View;

    move-result-object v2

    const/4 v6, -0x2

    move-object/from16 v0, p0

    move-object v1, v10

    move v3, v14

    move v4, v15

    move v5, v11

    invoke-direct/range {v0 .. v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->put(Landroid/widget/FrameLayout;Landroid/view/View;IIII)V

    move-object/from16 v0, p3

    .line 1250
    invoke-direct {v7, v0, v9}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->fixturesCard(Lorg/json/JSONArray;Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    const v1, 0x3ea66666    # 0.325f

    mul-float/2addr v13, v1

    float-to-int v1, v13

    const/4 v2, -0x2

    move-object/from16 p1, p0

    move-object/from16 p2, v10

    move-object/from16 p3, v0

    move/from16 p4, v14

    move/from16 p5, v1

    move/from16 p6, v11

    move/from16 p7, v2

    invoke-direct/range {p1 .. p7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->put(Landroid/widget/FrameLayout;Landroid/view/View;IIII)V

    const/16 v0, 0x8

    .line 1252
    invoke-direct {v7, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v0

    add-int v0, p9, v0

    .line 1253
    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->nextMatchBar()Landroid/view/View;

    move-result-object v1

    add-int/2addr v12, v8

    sub-int v2, v12, v0

    move-object/from16 p3, v1

    move/from16 p4, v0

    move/from16 p5, p12

    move/from16 p6, v2

    move/from16 p7, p13

    invoke-direct/range {p1 .. p7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->put(Landroid/widget/FrameLayout;Landroid/view/View;IIII)V

    return-object v10
.end method

.method private c(Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 1997
    invoke-direct {p0, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 1998
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->worldCup()Z

    move-result v0

    if-nez v0, :cond_b

    return-object p1

    .line 1999
    :cond_b
    iget-boolean v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->english:Z

    if-eqz v0, :cond_14

    const-string v0, "UCL"

    const-string v1, "World Cup"

    goto :goto_18

    :cond_14
    const-string v0, "\u6b27\u51a0"

    const-string v1, "\u4e16\u754c\u676f"

    :goto_18
    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private card()Landroid/widget/LinearLayout;
    .registers 7

    .line 928
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 929
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v1, 0x10

    .line 930
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    const/16 v3, 0xc

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v3

    invoke-virtual {v0, v2, v4, v5, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const v2, -0x11efece1

    const v3, 0x33ffffff

    const v4, -0x11d5cfb9

    .line 931
    invoke-direct {p0, v4, v2, v1, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-object v0
.end method

.method private celebrationDue()Z
    .registers 6

    .line 1087
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    if-nez v0, :cond_6

    const/4 v0, 0x0

    goto :goto_c

    :cond_6
    const-string v1, "celebration"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    :goto_c
    const/4 v1, 0x0

    if-eqz v0, :cond_27

    const-string v2, "cupId"

    .line 1088
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->celebrationCup:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_27

    .line 1090
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->celebrationCup:Ljava/lang/String;

    .line 1091
    iput-boolean v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->celebrationDismissed:Z

    .line 1092
    iput-boolean v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->celebrationForced:Z

    .line 1094
    :cond_27
    iget-boolean v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v2, :cond_42

    iget-boolean v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->showKnockout:Z

    if-eqz v2, :cond_42

    if-eqz v0, :cond_42

    iget-boolean v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->celebrationForced:Z

    if-nez v2, :cond_41

    const-string v2, "celebrated"

    .line 1095
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_42

    iget-boolean v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->celebrationDismissed:Z

    if-nez v0, :cond_42

    :cond_41
    const/4 v1, 0x1

    :cond_42
    return v1
.end method

.method private celebrationReplayButton()Landroid/widget/TextView;
    .registers 6

    const-string v0, "\u51a0\u519b\u4e4b\u8def"

    .line 1160
    invoke-direct {p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const v1, -0xd5de00

    const/4 v2, 0x1

    const/16 v3, 0xd

    invoke-direct {p0, v0, v3, v1, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v0

    const/16 v1, 0x11

    .line 1161
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v1, 0x10

    .line 1162
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    const/4 v3, 0x0

    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    invoke-virtual {v0, v2, v3, v4, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    const v2, -0x264ba6

    const v3, -0x55000001

    const v4, -0x91c5f

    .line 1163
    invoke-direct {p0, v4, v2, v1, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1164
    new-instance v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda16;

    invoke-direct {v1, p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda16;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object v0
.end method

.method private celebrationScene(Lorg/json/JSONObject;FI)Landroid/widget/FrameLayout;
    .registers 13

    .line 1113
    new-instance v0, Landroid/content/res/Configuration;

    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    invoke-virtual {v1}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    const/16 v1, 0x120

    .line 1114
    iput v1, v0, Landroid/content/res/Configuration;->densityDpi:I

    .line 1115
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    invoke-virtual {v1, v0}, Landroid/app/Activity;->createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;

    move-result-object v0

    iput-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->uiContext:Landroid/content/Context;

    const/4 v0, 0x0

    .line 1117
    :try_start_1c
    new-instance v1, Landroid/widget/FrameLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 1118
    new-instance v2, Lorg/efootballrevival/runtimeprobe/CupCelebration;

    iget-object v4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->worldCup()Z

    move-result v6

    iget-boolean v7, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->english:Z

    const-string v3, "\u6b27\u51a0 \u00b7 \u51a0\u519b\u4e4b\u8def"

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object v3, v2

    move-object v5, p1

    invoke-direct/range {v3 .. v8}, Lorg/efootballrevival/runtimeprobe/CupCelebration;-><init>(Landroid/content/Context;Lorg/json/JSONObject;ZZLjava/lang/String;)V

    new-instance p1, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v3, 0x466

    invoke-direct {p1, p3, v3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2, p1}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string p1, "\u2715"

    const/4 v2, -0x1

    const/4 v3, 0x1

    const/16 v4, 0x10

    .line 1120
    invoke-direct {p0, p1, v4, v2, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p1

    const/16 v2, 0x11

    .line 1121
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v2, 0x12

    const v3, 0x55ffffff    # 3.518437E13f

    const v4, 0x44ffffff    # 2047.9999f

    const v5, 0x18ffffff

    .line 1122
    invoke-direct {p0, v4, v5, v2, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1123
    new-instance v2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda3;

    invoke-direct {v2, p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda3;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V

    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1124
    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v3, 0x24

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {v2, v4, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const v4, 0x800033

    .line 1125
    iput v4, v2, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 1126
    iget v4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->safeRightPx:I

    int-to-float v4, v4

    div-float/2addr v4, p2

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    sub-int v4, p3, v4

    int-to-float p3, p3

    const v5, 0x3c8f5c29    # 0.0175f

    mul-float/2addr p3, v5

    float-to-int p3, p3

    sub-int/2addr v4, p3

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result p3

    sub-int/2addr v4, p3

    iput v4, v2, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    const/16 p3, 0x1d

    .line 1127
    iput p3, v2, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .line 1128
    invoke-virtual {v1, p1, v2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 p1, 0x0

    .line 1129
    invoke-virtual {v1, p1}, Landroid/widget/FrameLayout;->setPivotX(F)V

    .line 1130
    invoke-virtual {v1, p1}, Landroid/widget/FrameLayout;->setPivotY(F)V

    .line 1131
    invoke-virtual {v1, p2}, Landroid/widget/FrameLayout;->setScaleX(F)V

    .line 1132
    invoke-virtual {v1, p2}, Landroid/widget/FrameLayout;->setScaleY(F)V
    :try_end_ad
    .catchall {:try_start_1c .. :try_end_ad} :catchall_b0

    .line 1135
    iput-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->uiContext:Landroid/content/Context;

    return-object v1

    :catchall_b0
    move-exception p1

    iput-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->uiContext:Landroid/content/Context;

    .line 1136
    throw p1
.end method

.method private cell(Ljava/lang/String;IIZI)Landroid/view/View;
    .registers 6

    .line 1693
    invoke-direct {p0, p1, p5, p3, p4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p1

    const/16 p3, 0x11

    .line 1694
    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setGravity(I)V

    .line 1695
    new-instance p3, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, p2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result p2

    const/4 p4, -0x1

    invoke-direct {p3, p2, p4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p1
.end method

.method private chipFace(ZI)Landroid/graphics/drawable/Drawable;
    .registers 6

    if-eqz p1, :cond_25

    const p1, -0xa57f01

    const v0, -0xc03d86

    .line 750
    invoke-direct {p0, p1, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result p1

    const v0, -0xf5ca01

    const v1, -0xf085bb

    invoke-direct {p0, v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v0

    const v1, -0x55000001

    const v2, -0x550d36b4

    invoke-direct {p0, v1, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v1

    invoke-direct {p0, p1, v0, p2, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    goto :goto_40

    :cond_25
    const p1, 0x40ffffff    # 7.9999995f

    const v0, 0x661b6b3f

    .line 751
    invoke-direct {p0, p1, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result p1

    const v0, 0x14ffffff

    const v1, 0x330f5a32

    invoke-direct {p0, v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v0

    const v1, 0x30ffffff

    invoke-direct {p0, p1, v0, p2, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    :goto_40
    return-object p1
.end method

.method private close()V
    .registers 3

    .line 885
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->removePads()V

    .line 886
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelRoot:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;

    if-eqz v0, :cond_12

    .line 888
    :try_start_7
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelWm:Landroid/view/WindowManager;

    invoke-interface {v1, v0}, Landroid/view/WindowManager;->removeViewImmediate(Landroid/view/View;)V
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_c} :catch_c

    :catch_c
    const/4 v0, 0x0

    .line 891
    iput-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelRoot:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;

    const/4 v0, 0x1

    .line 892
    iput-boolean v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->closed:Z

    .line 894
    :cond_12
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    if-eqz v0, :cond_19

    invoke-virtual {v0}, Landroid/app/AlertDialog;->dismiss()V

    .line 895
    :cond_19
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->strip:Landroid/app/Dialog;

    if-eqz v0, :cond_20

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    .line 896
    :cond_20
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->stripLeft:Landroid/app/Dialog;

    if-eqz v0, :cond_27

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    :cond_27
    return-void
.end method

.method private closeAnimated()V
    .registers 9

    .line 599
    iget-boolean v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->closing:Z

    if-nez v0, :cond_65

    iget-boolean v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->closed:Z

    if-eqz v0, :cond_9

    goto :goto_65

    :cond_9
    const/4 v0, 0x1

    .line 600
    iput-boolean v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->closing:Z

    .line 601
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelRoot:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;

    const-wide/16 v2, 0x1f4

    const/4 v4, 0x0

    if-eqz v1, :cond_22

    invoke-virtual {v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    invoke-virtual {v1, v4}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    invoke-virtual {v1, v2, v3}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/ViewPropertyAnimator;->start()V

    :cond_22
    const/4 v1, 0x3

    new-array v5, v1, [Landroid/app/Dialog;

    .line 602
    iget-object v6, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dialog:Landroid/app/AlertDialog;

    const/4 v7, 0x0

    aput-object v6, v5, v7

    iget-object v6, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->strip:Landroid/app/Dialog;

    aput-object v6, v5, v0

    const/4 v0, 0x2

    iget-object v6, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->stripLeft:Landroid/app/Dialog;

    aput-object v6, v5, v0

    :goto_33
    if-ge v7, v1, :cond_59

    .line 603
    aget-object v0, v5, v7

    if-eqz v0, :cond_56

    .line 604
    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v6

    if-eqz v6, :cond_56

    .line 605
    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v4}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v2, v3}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    :cond_56
    add-int/lit8 v7, v7, 0x1

    goto :goto_33

    .line 608
    :cond_59
    sget-object v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->MAIN:Landroid/os/Handler;

    new-instance v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda14;

    invoke-direct {v1, p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda14;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V

    const-wide/16 v2, 0x208

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_65
    :goto_65
    return-void
.end method

.method private closeCelebration()V
    .registers 5

    .line 1141
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    if-nez v0, :cond_6

    const/4 v0, 0x0

    goto :goto_c

    :cond_6
    const-string v1, "celebration"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    :goto_c
    const/4 v1, 0x0

    .line 1142
    iput-boolean v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->celebrationForced:Z

    const/4 v1, 0x1

    .line 1143
    iput-boolean v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->celebrationDismissed:Z

    if-eqz v0, :cond_2e

    const-string v2, "cupId"

    .line 1145
    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :try_start_1a
    const-string v3, "celebrated"

    .line 1146
    invoke-virtual {v0, v3, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;
    :try_end_1f
    .catch Lorg/json/JSONException; {:try_start_1a .. :try_end_1f} :catch_1f

    .line 1147
    :catch_1f
    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda6;

    invoke-direct {v1, p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda6;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Ljava/lang/String;)V

    const-string v2, "e112-cup-celebrated"

    invoke-direct {v0, v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 1153
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 1155
    :cond_2e
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->render()V

    return-void
.end method

.method private coverWindow(Landroid/graphics/Bitmap;IIIIIIIIIZ)Landroid/app/Dialog;
    .registers 25

    move-object v7, p0

    move/from16 v8, p6

    move/from16 v9, p7

    .line 614
    new-instance v10, Landroid/widget/FrameLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v0

    invoke-direct {v10, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    if-eqz p11, :cond_12

    .line 615
    iput-object v10, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->stripHost:Landroid/widget/FrameLayout;

    :cond_12
    const/4 v11, 0x0

    if-eqz p1, :cond_24

    .line 617
    new-instance v6, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;

    move-object v0, v6

    move-object v1, p1

    move v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    invoke-direct/range {v0 .. v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$ScreenBackdrop;-><init>(Landroid/graphics/Bitmap;IIII)V

    goto :goto_2b

    :cond_24
    const v0, -0xf5e592

    .line 618
    invoke-direct {p0, v0, v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rounded(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    .line 616
    :goto_2b
    invoke-virtual {v10, v6}, Landroid/widget/FrameLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 619
    new-instance v12, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$2;

    iget-object v2, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    const v3, 0x103023a

    move-object v0, v12

    move-object v1, p0

    move/from16 v4, p8

    move/from16 v5, p9

    move/from16 v6, p10

    invoke-direct/range {v0 .. v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$2;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Landroid/content/Context;IIII)V

    const/4 v0, 0x1

    .line 628
    invoke-virtual {v12, v0}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    .line 629
    invoke-virtual {v12, v10}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    .line 630
    invoke-virtual {v12, v11}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    .line 631
    invoke-virtual {v12}, Landroid/app/Dialog;->show()V

    .line 632
    invoke-virtual {v12}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    if-eqz v0, :cond_90

    const v1, 0x106000d

    .line 634
    invoke-virtual {v0, v1}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    .line 635
    invoke-virtual {v0, v11}, Landroid/view/Window;->setWindowAnimations(I)V

    .line 636
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1, v11, v11, v11, v11}, Landroid/view/View;->setPadding(IIII)V

    const v1, 0x800033

    .line 637
    invoke-virtual {v0, v1}, Landroid/view/Window;->setGravity(I)V

    const/4 v1, 0x2

    .line 638
    invoke-virtual {v0, v1}, Landroid/view/Window;->clearFlags(I)V

    const/4 v1, 0x0

    .line 639
    invoke-virtual {v0, v1}, Landroid/view/Window;->setDimAmount(F)V

    const v1, 0x40328

    .line 640
    invoke-virtual {v0, v1}, Landroid/view/Window;->addFlags(I)V

    .line 645
    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v1

    const/4 v2, 0x3

    .line 646
    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->layoutInDisplayCutoutMode:I

    move/from16 v2, p4

    .line 647
    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->x:I

    move/from16 v2, p5

    .line 648
    iput v2, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 649
    iput v8, v1, Landroid/view/WindowManager$LayoutParams;->width:I

    .line 650
    iput v9, v1, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 651
    invoke-virtual {v0, v1}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    .line 652
    invoke-virtual {v0, v8, v9}, Landroid/view/Window;->setLayout(II)V

    :cond_90
    return-object v12
.end method

.method static crestBitmap(I)Landroid/graphics/Bitmap;
    .registers 6

    .line 686
    sget-object v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->CRESTS:Landroid/util/LruCache;

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/util/LruCache;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/graphics/Bitmap;

    if-eqz v1, :cond_f

    return-object v1

    .line 688
    :cond_f
    sget-object v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->crestPack:[B

    .line 689
    sget-object v2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->crestIndex:Ljava/util/Map;

    const/4 v3, 0x0

    if-nez v2, :cond_18

    move-object v2, v3

    goto :goto_22

    :cond_18
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [I

    :goto_22
    if-eqz v1, :cond_3b

    if-nez v2, :cond_27

    goto :goto_3b

    :cond_27
    const/4 v3, 0x0

    .line 691
    aget v3, v2, v3

    const/4 v4, 0x1

    aget v2, v2, v4

    invoke-static {v1, v3, v2}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object v1

    if-eqz v1, :cond_3a

    .line 692
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-virtual {v0, p0, v1}, Landroid/util/LruCache;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3a
    return-object v1

    :cond_3b
    :goto_3b
    return-object v3
.end method

.method private crestView(ILjava/lang/String;I)Landroid/view/View;
    .registers 9

    if-lez p1, :cond_7

    .line 698
    invoke-static {p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->crestBitmap(I)Landroid/graphics/Bitmap;

    move-result-object v0

    goto :goto_8

    :cond_7
    const/4 v0, 0x0

    .line 699
    :goto_8
    invoke-direct {p0, p3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    if-eqz v0, :cond_28

    .line 701
    new-instance p1, Landroid/widget/ImageView;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object p2

    invoke-direct {p1, p2}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 702
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 703
    sget-object p2, Landroid/widget/ImageView$ScaleType;->FIT_CENTER:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 704
    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p2, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p1, p2}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p1

    :cond_28
    const/4 v0, 0x0

    const/4 v2, 0x1

    if-eqz p2, :cond_3c

    .line 707
    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_33

    goto :goto_3c

    :cond_33
    invoke-virtual {p2, v0, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object p2

    goto :goto_3e

    :cond_3c
    :goto_3c
    const-string p2, "?"

    :goto_3e
    mul-int/lit8 p1, p1, 0x2f

    .line 708
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result p1

    rem-int/lit16 p1, p1, 0x168

    const/16 v3, 0xc

    const/4 v4, -0x1

    .line 709
    invoke-direct {p0, p2, v3, v4, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p2

    const/16 v3, 0x11

    .line 710
    invoke-virtual {p2, v3}, Landroid/widget/TextView;->setGravity(I)V

    const/4 v3, 0x3

    new-array v3, v3, [F

    int-to-float p1, p1

    aput p1, v3, v0

    const p1, 0x3f0ccccd    # 0.55f

    aput p1, v3, v2

    const p1, 0x3f266666    # 0.65f

    const/4 v0, 0x2

    aput p1, v3, v0

    .line 711
    invoke-static {v3}, Landroid/graphics/Color;->HSVToColor([F)I

    move-result p1

    div-int/2addr p3, v0

    invoke-direct {p0, p1, p3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rounded(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 712
    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p1, v1, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p2
.end method

.method private density()F
    .registers 2

    .line 877
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    return v0
.end method

.method private designScene(Lorg/json/JSONArray;Lorg/json/JSONArray;Lorg/json/JSONArray;Ljava/lang/String;IZFI)Landroid/widget/FrameLayout;
    .registers 27

    move-object/from16 v15, p0

    move/from16 v0, p7

    .line 1189
    new-instance v1, Landroid/content/res/Configuration;

    iget-object v2, v15, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    invoke-virtual {v2}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    const/16 v2, 0x120

    .line 1191
    iput v2, v1, Landroid/content/res/Configuration;->densityDpi:I

    .line 1192
    iget-object v2, v15, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    invoke-virtual {v2, v1}, Landroid/app/Activity;->createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;

    move-result-object v1

    iput-object v1, v15, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->uiContext:Landroid/content/Context;

    const/4 v1, 0x1

    .line 1193
    iput-boolean v1, v15, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->roomyRows:Z

    const/16 v9, 0x466

    const/4 v14, 0x0

    const/4 v13, 0x0

    .line 1195
    :try_start_26
    iget v1, v15, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeRightPx:I

    int-to-float v1, v1

    div-float/2addr v1, v0

    .line 1196
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v10

    iget v1, v15, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->safeLeftPx:I

    int-to-float v1, v1

    div-float/2addr v1, v0

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v11

    iget v1, v15, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->safeRightPx:I

    int-to-float v1, v1

    div-float/2addr v1, v0

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v12

    iget v1, v15, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->barTopPx:I

    int-to-float v1, v1

    div-float/2addr v1, v0

    .line 1197
    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v16

    iget v1, v15, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->barHeightPx:I

    int-to-float v1, v1

    div-float/2addr v1, v0

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v17
    :try_end_4e
    .catchall {:try_start_26 .. :try_end_4e} :catchall_7e

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move/from16 v6, p5

    move/from16 v7, p6

    move/from16 v8, p8

    move/from16 v13, v16

    move/from16 v14, v17

    .line 1195
    :try_start_62
    invoke-direct/range {v1 .. v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->buildScene(Lorg/json/JSONArray;Lorg/json/JSONArray;Lorg/json/JSONArray;Ljava/lang/String;IZIIIIIII)Landroid/widget/FrameLayout;

    move-result-object v1

    const/4 v2, 0x0

    .line 1198
    invoke-virtual {v1, v2}, Landroid/widget/FrameLayout;->setPivotX(F)V

    .line 1199
    invoke-virtual {v1, v2}, Landroid/widget/FrameLayout;->setPivotY(F)V

    .line 1200
    invoke-virtual {v1, v0}, Landroid/widget/FrameLayout;->setScaleX(F)V

    .line 1201
    invoke-virtual {v1, v0}, Landroid/widget/FrameLayout;->setScaleY(F)V
    :try_end_73
    .catchall {:try_start_62 .. :try_end_73} :catchall_7a

    const/4 v2, 0x0

    .line 1204
    iput-object v2, v15, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->uiContext:Landroid/content/Context;

    const/4 v3, 0x0

    .line 1205
    iput-boolean v3, v15, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->roomyRows:Z

    return-object v1

    :catchall_7a
    move-exception v0

    const/4 v2, 0x0

    const/4 v3, 0x0

    goto :goto_81

    :catchall_7e
    move-exception v0

    move-object v2, v13

    move v3, v14

    .line 1204
    :goto_81
    iput-object v2, v15, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->uiContext:Landroid/content/Context;

    .line 1205
    iput-boolean v3, v15, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->roomyRows:Z

    .line 1206
    throw v0
.end method

.method private dp(I)I
    .registers 3

    int-to-float p1, p1

    .line 881
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->density()F

    move-result v0

    mul-float/2addr p1, v0

    float-to-int p1, p1

    return p1
.end method

.method private enterCelebration(Lorg/json/JSONObject;)V
    .registers 8

    .line 1099
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->legacy:Landroid/widget/LinearLayout;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1100
    iget v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->sceneH:I

    int-to-float v0, v0

    const v1, 0x448cc000    # 1126.0f

    div-float/2addr v0, v1

    .line 1101
    iget v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->sceneW:I

    int-to-float v1, v1

    div-float/2addr v1, v0

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    .line 1102
    invoke-static {}, Lorg/efootballrevival/runtimeprobe/CupCelebration;->restart()V

    .line 1103
    iget-object v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rootHost:Landroid/widget/FrameLayout;

    invoke-direct {p0, p1, v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->celebrationScene(Lorg/json/JSONObject;FI)Landroid/widget/FrameLayout;

    move-result-object v3

    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v5, 0x466

    invoke-direct {v4, v1, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v3, v4}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1104
    iget-object v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->stripHost:Landroid/widget/FrameLayout;

    if-eqz v2, :cond_45

    .line 1105
    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v2, v1, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 1106
    iget v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeRightPx:I

    neg-int v3, v3

    iput v3, v2, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 1107
    iget v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeTopPx:I

    neg-int v3, v3

    iput v3, v2, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .line 1108
    iget-object v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->stripHost:Landroid/widget/FrameLayout;

    invoke-direct {p0, p1, v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->celebrationScene(Lorg/json/JSONObject;FI)Landroid/widget/FrameLayout;

    move-result-object p1

    invoke-virtual {v3, p1, v2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_45
    return-void
.end method

.method private enterKnockoutScene(Lorg/json/JSONObject;)V
    .registers 8

    .line 2206
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->legacy:Landroid/widget/LinearLayout;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 2207
    iget v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->sceneH:I

    int-to-float v0, v0

    const v1, 0x448cc000    # 1126.0f

    div-float/2addr v0, v1

    .line 2208
    iget v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->sceneW:I

    int-to-float v1, v1

    div-float/2addr v1, v0

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    .line 2209
    iget-object v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rootHost:Landroid/widget/FrameLayout;

    invoke-direct {p0, p1, v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->knockoutScene(Lorg/json/JSONObject;FI)Landroid/widget/FrameLayout;

    move-result-object v3

    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v5, 0x466

    invoke-direct {v4, v1, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v3, v4}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2210
    iget-object v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->stripHost:Landroid/widget/FrameLayout;

    if-eqz v2, :cond_42

    .line 2211
    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v2, v1, v5}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 2212
    iget v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeRightPx:I

    neg-int v3, v3

    iput v3, v2, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 2213
    iget v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeTopPx:I

    neg-int v3, v3

    iput v3, v2, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .line 2214
    iget-object v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->stripHost:Landroid/widget/FrameLayout;

    invoke-direct {p0, p1, v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->knockoutScene(Lorg/json/JSONObject;FI)Landroid/widget/FrameLayout;

    move-result-object p1

    invoke-virtual {v3, p1, v2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_42
    return-void
.end method

.method private enterScene(Lorg/json/JSONArray;Lorg/json/JSONArray;Lorg/json/JSONArray;Ljava/lang/String;IZ)V
    .registers 21

    move-object v9, p0

    .line 1173
    iget-object v0, v9, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->legacy:Landroid/widget/LinearLayout;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1174
    iget v0, v9, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->sceneH:I

    int-to-float v0, v0

    const v1, 0x448cc000    # 1126.0f

    div-float v10, v0, v1

    .line 1175
    iget v0, v9, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->sceneW:I

    int-to-float v0, v0

    div-float/2addr v0, v10

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v11

    .line 1176
    iget-object v12, v9, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rootHost:Landroid/widget/FrameLayout;

    move-object v0, p0

    move-object v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move/from16 v5, p5

    move/from16 v6, p6

    move v7, v10

    move v8, v11

    invoke-direct/range {v0 .. v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->designScene(Lorg/json/JSONArray;Lorg/json/JSONArray;Lorg/json/JSONArray;Ljava/lang/String;IZFI)Landroid/widget/FrameLayout;

    move-result-object v0

    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v2, 0x466

    invoke-direct {v1, v11, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v12, v0, v1}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1178
    iget-object v0, v9, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->stripHost:Landroid/widget/FrameLayout;

    if-eqz v0, :cond_60

    .line 1179
    new-instance v12, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v12, v11, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 1180
    iget v0, v9, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeRightPx:I

    neg-int v0, v0

    iput v0, v12, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 1181
    iget v0, v9, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeTopPx:I

    neg-int v0, v0

    iput v0, v12, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .line 1182
    iget-object v13, v9, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->stripHost:Landroid/widget/FrameLayout;

    move-object v0, p0

    move-object v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move/from16 v5, p5

    move/from16 v6, p6

    move v7, v10

    move v8, v11

    invoke-direct/range {v0 .. v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->designScene(Lorg/json/JSONArray;Lorg/json/JSONArray;Lorg/json/JSONArray;Ljava/lang/String;IZFI)Landroid/widget/FrameLayout;

    move-result-object v0

    invoke-virtual {v13, v0, v12}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_60
    return-void
.end method

.method private fixtureRow(Lorg/json/JSONObject;Z)Landroid/view/View;
    .registers 19

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string v2, "isPlayer"

    .line 1857
    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v2

    const-string v3, "played"

    .line 1858
    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v3

    .line 1859
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v5

    invoke-direct {v4, v5}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v5, 0x10

    .line 1860
    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v5, 0x8

    .line 1861
    invoke-direct {v0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v6

    invoke-direct {v0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    const/4 v8, 0x0

    invoke-virtual {v4, v6, v8, v7, v8}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const/16 v6, 0xc

    if-eqz v2, :cond_3b

    const v7, 0x553a5cff

    const v9, 0x220a35ff

    .line 1862
    invoke-direct {v0, v7, v9, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->hgrad(III)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    goto :goto_42

    :cond_3b
    const v7, 0x8ffffff

    invoke-direct {v0, v7, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rounded(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    :goto_42
    const/4 v7, 0x1

    if-eqz v2, :cond_4f

    .line 1863
    invoke-direct {v0, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v9

    const v10, -0x33806701    # -6.7003388E7f

    invoke-virtual {v6, v9, v10}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 1864
    :cond_4f
    invoke-virtual {v4, v6}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const-string v6, "homeTeam"

    .line 1865
    invoke-virtual {v1, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/16 v10, 0xd

    const/4 v11, -0x1

    invoke-direct {v0, v9, v10, v11, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v9

    const v12, 0x800015

    .line 1866
    invoke-virtual {v9, v12}, Landroid/widget/TextView;->setGravity(I)V

    .line 1867
    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v13, 0x3f800000    # 1.0f

    invoke-direct {v12, v8, v11, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v4, v9, v12}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v9, "homeTeamId"

    .line 1868
    invoke-virtual {v1, v9}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v9

    invoke-virtual {v1, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/16 v12, 0x1e

    invoke-direct {v0, v9, v6, v12}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->plateCrest(ILjava/lang/String;I)Landroid/view/View;

    move-result-object v6

    .line 1869
    invoke-virtual {v6}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v9

    check-cast v9, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v14, 0x6

    invoke-direct {v0, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v15

    iput v15, v9, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 1870
    invoke-virtual {v4, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    if-eqz v3, :cond_b2

    .line 1871
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "homeScore"

    invoke-virtual {v1, v9}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v9

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v9, " - "

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, "awayScore"

    invoke-virtual {v1, v9}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v9

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    goto :goto_b4

    :cond_b2
    const-string v6, "VS"

    :goto_b4
    if-eqz v3, :cond_b8

    move v9, v11

    goto :goto_bb

    :cond_b8
    const v9, -0x564b2a

    :goto_bb
    const/16 v15, 0xe

    invoke-direct {v0, v6, v15, v9, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v6

    const/16 v7, 0x11

    .line 1873
    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v7, 0x9

    if-eqz v3, :cond_d8

    const v3, -0x33d8d1b8    # -4.382544E7f

    const v9, 0x55ffffff    # 3.518437E13f

    const v15, -0x33f5f2e8    # -3.618928E7f

    .line 1874
    invoke-direct {v0, v15, v3, v7, v9}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    goto :goto_e5

    :cond_d8
    const v3, 0x10ffffff

    const v9, 0x22ffffff

    const v15, 0x33ffffff

    .line 1875
    invoke-direct {v0, v15, v3, v7, v9}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    .line 1874
    :goto_e5
    invoke-virtual {v6, v3}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1876
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v7, 0x3e

    invoke-direct {v0, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    const/16 v9, 0x1a

    invoke-direct {v0, v9}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v9

    invoke-direct {v3, v7, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1877
    invoke-direct {v0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    iput v7, v3, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 1878
    invoke-direct {v0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    iput v5, v3, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 1879
    invoke-virtual {v4, v6, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v3, "awayTeamId"

    .line 1880
    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v3

    const-string v5, "awayTeam"

    invoke-virtual {v1, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v0, v3, v6, v12}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->plateCrest(ILjava/lang/String;I)Landroid/view/View;

    move-result-object v3

    .line 1881
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v6

    check-cast v6, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    iput v7, v6, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 1882
    invoke-virtual {v4, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1883
    invoke-virtual {v1, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, v10, v11, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v8, v11, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v4, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1885
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    if-eqz p2, :cond_13e

    const/16 v2, 0x22

    goto :goto_140

    :cond_13e
    const/16 v2, 0x28

    :goto_140
    invoke-direct {v0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    invoke-direct {v1, v11, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    if-eqz p2, :cond_14b

    const/4 v2, 0x2

    goto :goto_14c

    :cond_14b
    const/4 v2, 0x4

    .line 1886
    :goto_14c
    invoke-direct {v0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 1887
    invoke-virtual {v4, v1}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object v4
.end method

.method private fixturesCard(Lorg/json/JSONArray;Ljava/lang/String;)Landroid/view/View;
    .registers 4

    const/4 v0, 0x0

    .line 1829
    invoke-direct {p0, p1, p2, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->fixturesCard(Lorg/json/JSONArray;Ljava/lang/String;Z)Landroid/view/View;

    move-result-object p1

    return-object p1
.end method

.method private fixturesCard(Lorg/json/JSONArray;Ljava/lang/String;Z)Landroid/view/View;
    .registers 15

    .line 1833
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->card()Landroid/widget/LinearLayout;

    move-result-object v0

    .line 1834
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\u5c0f\u7ec4 "

    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, " \u8d5b\u7a0b"

    invoke-direct {p0, p2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/16 v1, 0x11

    const/4 v2, -0x1

    const/4 v3, 0x1

    invoke-direct {p0, p2, v1, v2, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p2

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    if-eqz p3, :cond_31

    const/16 v5, 0x1a

    goto :goto_33

    :cond_31
    const/16 v5, 0x20

    .line 1835
    :goto_33
    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {v4, v2, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1834
    invoke-virtual {v0, p2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-nez p1, :cond_40

    return-object v0

    :cond_40
    const/4 p2, 0x0

    move v4, p2

    .line 1837
    :goto_42
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v5

    if-ge v4, v5, :cond_cf

    .line 1838
    invoke-virtual {p1, v4}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v5

    if-nez v5, :cond_50

    goto/16 :goto_cb

    .line 1840
    :cond_50
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "\u6bd4\u8d5b\u65e5 "

    invoke-direct {p0, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "round"

    invoke-virtual {v5, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0xc

    invoke-direct {p0, v6, v7, v2, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v6

    .line 1841
    invoke-virtual {v6, v1}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v7, 0xb

    const v8, 0x33ffffff

    const v9, 0x55ffffff    # 3.518437E13f

    const v10, 0x1fffffff

    .line 1842
    invoke-direct {p0, v9, v10, v7, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1843
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v8, 0x4e

    invoke-direct {p0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v8

    if-eqz p3, :cond_93

    const/16 v9, 0x12

    goto :goto_95

    :cond_93
    const/16 v9, 0x16

    :goto_95
    invoke-direct {p0, v9}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v9

    invoke-direct {v7, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    if-eqz p3, :cond_a0

    const/4 v8, 0x4

    goto :goto_a2

    :cond_a0
    const/16 v8, 0x8

    .line 1844
    :goto_a2
    invoke-direct {p0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v8

    iput v8, v7, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 1845
    invoke-virtual {v0, v6, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v6, "fixtures"

    .line 1846
    invoke-virtual {v5, v6}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v5

    if-nez v5, :cond_b4

    goto :goto_cb

    :cond_b4
    move v6, p2

    .line 1848
    :goto_b5
    invoke-virtual {v5}, Lorg/json/JSONArray;->length()I

    move-result v7

    if-ge v6, v7, :cond_cb

    .line 1849
    invoke-virtual {v5, v6}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v7

    if-eqz v7, :cond_c8

    .line 1850
    invoke-direct {p0, v7, p3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->fixtureRow(Lorg/json/JSONObject;Z)Landroid/view/View;

    move-result-object v7

    invoke-virtual {v0, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :cond_c8
    add-int/lit8 v6, v6, 0x1

    goto :goto_b5

    :cond_cb
    :goto_cb
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_42

    :cond_cf
    return-object v0
.end method

.method private glass(IIII)Landroid/graphics/drawable/GradientDrawable;
    .registers 5

    .line 738
    invoke-direct {p0, p1, p2, p3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->vgrad(III)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    ushr-int/lit8 p2, p4, 0x18

    and-int/lit16 p2, p2, 0xff

    const/16 p3, 0xaa

    if-lt p2, p3, :cond_14

    const/4 p2, 0x1

    .line 739
    invoke-direct {p0, p2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result p2

    invoke-virtual {p1, p2, p4}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    :cond_14
    return-object p1
.end method

.method private groupTab(Ljava/lang/String;ZZI)Landroid/view/View;
    .registers 8

    .line 1531
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz p3, :cond_d

    const-string p1, " \u25cf"

    goto :goto_f

    :cond_d
    const-string p1, ""

    :goto_f
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    if-eqz p2, :cond_1a

    const/4 v0, -0x1

    goto :goto_1d

    :cond_1a
    const v0, -0x564b2a

    :goto_1d
    const/4 v1, 0x1

    const/16 v2, 0xe

    invoke-direct {p0, p1, v2, v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p1

    const/16 v0, 0x11

    .line 1532
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v0, 0x12

    .line 1533
    invoke-direct {p0, p2, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->chipFace(ZI)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1534
    new-instance p2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda0;

    invoke-direct {p2, p0, p4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda0;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;I)V

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1538
    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    if-eqz p3, :cond_41

    const/16 p3, 0x42

    goto :goto_43

    :cond_41
    const/16 p3, 0x36

    :goto_43
    invoke-direct {p0, p3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result p3

    const/16 p4, 0x22

    invoke-direct {p0, p4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result p4

    invoke-direct {p2, p3, p4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 p3, 0x8

    .line 1539
    invoke-direct {p0, p3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result p3

    iput p3, p2, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 1540
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p1
.end method

.method private hgrad(III)Landroid/graphics/drawable/GradientDrawable;
    .registers 4

    .line 733
    invoke-direct {p0, p1, p2, p3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->vgrad(III)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    return-object p1
.end method

.method private knockoutBanner(Lorg/json/JSONObject;)Landroid/view/View;
    .registers 11

    .line 2334
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 2335
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v2, 0x10

    .line 2336
    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v3

    const/16 v4, 0xa

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v6

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    invoke-virtual {v0, v3, v5, v6, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const-string v3, "champion"

    const-string v4, ""

    .line 2337
    invoke-virtual {p1, v3, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v5, "eliminated"

    .line 2338
    invoke-virtual {p1, v5}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v5

    const-string v6, "nextOpponent"

    .line 2339
    invoke-virtual {p1, v6, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 2341
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_42

    const v6, -0x1f56d6

    goto :goto_52

    :cond_42
    if-eqz v5, :cond_48

    const v6, -0x64d5c3

    goto :goto_52

    :cond_48
    const v6, -0xc5a301

    const v7, -0xe070ab

    invoke-direct {p0, v6, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v6

    .line 2342
    :goto_52
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_5c

    const v7, -0x85a600

    goto :goto_6c

    :cond_5c
    if-eqz v5, :cond_62

    const v7, -0xb7efe5

    goto :goto_6c

    :cond_62
    const v7, -0xf5e071

    const v8, -0xf4c2de

    invoke-direct {p0, v7, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v7

    :goto_6c
    const v8, -0x55000001

    .line 2340
    invoke-direct {p0, v6, v7, v2, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    .line 2343
    sget-object v7, Landroid/graphics/drawable/GradientDrawable$Orientation;->LEFT_RIGHT:Landroid/graphics/drawable/GradientDrawable$Orientation;

    invoke-virtual {v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setOrientation(Landroid/graphics/drawable/GradientDrawable$Orientation;)V

    const v7, 0x16ffffff

    .line 2344
    invoke-direct {p0, v6, v7, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->striped(Landroid/graphics/drawable/Drawable;II)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    invoke-virtual {v0, v6}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2345
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "\u6b27\u51a0\u6dd8\u6c70\u8d5b \u00b7 \u5df2\u5b8c\u6210 "

    invoke-direct {p0, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "played"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v7, " / "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "total"

    invoke-virtual {p1, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result p1

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, " \u573a"

    invoke-direct {p0, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 2346
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_d0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u51a0\u519b \u00b7 "

    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    goto :goto_f7

    :cond_d0
    if-eqz v5, :cond_d9

    const-string v3, "\u6dd8\u6c70\u8d5b\u6b62\u6b65"

    .line 2347
    :goto_d4
    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_f7

    :cond_d9
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_e2

    const-string v3, "\u664b\u7ea7\u8def\u5f84\u751f\u6210\u4e2d"

    goto :goto_d4

    :cond_e2
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u4e0b\u4e00\u573a \u00b7 VS  "

    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 2348
    :goto_f7
    iget-boolean v4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    const v5, -0x201901

    const/16 v6, 0xc

    const/4 v7, -0x1

    if-eqz v4, :cond_131

    const/4 v4, 0x0

    .line 2350
    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2351
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 2352
    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v8

    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    invoke-virtual {v0, v8, v4, v2, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const/16 v2, 0x12

    .line 2353
    invoke-direct {p0, v3, v2, v7, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v2

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x3f800000    # 1.0f

    const/4 v8, -0x2

    invoke-direct {v3, v4, v8, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2354
    invoke-direct {p0, p1, v6, v5, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p1

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v1, v8, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, p1, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0

    .line 2357
    :cond_131
    invoke-direct {p0, p1, v6, v5, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v4, 0x14

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {v2, v7, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, p1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2358
    invoke-direct {p0, v3, v4, v7, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p1

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v2, 0x20

    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    invoke-direct {v1, v7, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, p1, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private knockoutBar(Lorg/json/JSONObject;)Landroid/view/View;
    .registers 18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 2260
    new-instance v2, Landroid/widget/FrameLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    const-string v3, "champion"

    const-string v4, ""

    .line 2261
    invoke-virtual {v1, v3, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v5, "eliminated"

    .line 2262
    invoke-virtual {v1, v5}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v5

    const-string v6, "nextOpponent"

    .line 2263
    invoke-virtual {v1, v6, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v7, "played"

    .line 2264
    invoke-virtual {v1, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v7

    const-string v8, "total"

    const/4 v9, 0x4

    .line 2265
    invoke-virtual {v1, v8, v9}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v8

    const-string v9, "round"

    .line 2266
    invoke-virtual {v1, v9, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->roundWord(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 2267
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    const/16 v10, 0x12

    const/4 v11, -0x2

    const/4 v12, -0x1

    const/4 v13, 0x1

    const/16 v14, 0x10

    if-eqz v9, :cond_176

    if-nez v5, :cond_176

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_53

    goto/16 :goto_176

    :cond_53
    const v3, -0x19ede7d5

    .line 2276
    invoke-direct {v0, v3, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rounded(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/FrameLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2277
    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v5, 0x2e

    invoke-direct {v0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v9

    invoke-direct {v0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v15

    invoke-direct {v3, v9, v15, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    const/16 v9, 0x8

    .line 2278
    invoke-direct {v0, v9}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v15

    iput v15, v3, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    const-string v15, "nextOpponentId"

    .line 2279
    invoke-virtual {v1, v15}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v15

    invoke-direct {v0, v15, v6, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->plateCrest(ILjava/lang/String;I)Landroid/view/View;

    move-result-object v15

    invoke-virtual {v2, v15, v3}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2280
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v15

    invoke-direct {v3, v15}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 2281
    invoke-virtual {v3, v13}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2282
    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u4e0b\u4e00\u573a\u6bd4\u8d5b \u00b7 "

    invoke-direct {v0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v15, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " \u00b7 \u5df2\u5b8c\u6210 "

    invoke-direct {v0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, " / "

    invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, " \u573a"

    invoke-direct {v0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0xb

    const v7, -0x564b2a

    invoke-direct {v0, v4, v5, v7, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v4

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    .line 2283
    invoke-direct {v0, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v15

    invoke-direct {v8, v12, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2282
    invoke-virtual {v3, v4, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2284
    invoke-direct {v0, v6, v10, v12, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v4

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v8, 0x1a

    invoke-direct {v0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v8

    invoke-direct {v6, v12, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v4, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2285
    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v4, v12, v11, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    .line 2286
    invoke-direct {v0, v9}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v6

    const/16 v8, 0x2e

    invoke-direct {v0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v8

    add-int/2addr v6, v8

    const/16 v8, 0xa

    invoke-direct {v0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v8

    add-int/2addr v6, v8

    iput v6, v4, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    const/16 v6, 0x60

    .line 2287
    invoke-direct {v0, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v6

    iput v6, v4, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    .line 2288
    invoke-virtual {v2, v3, v4}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v3, "nextOpponentStrength"

    .line 2289
    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v1

    .line 2290
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 2291
    invoke-virtual {v3, v13}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2292
    invoke-virtual {v3, v13}, Landroid/widget/LinearLayout;->setGravity(I)V

    const-string v4, "\u5bf9\u624b\u8bc4\u5206"

    .line 2293
    invoke-direct {v0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x0

    invoke-direct {v0, v4, v5, v7, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v4

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v6, 0x50

    invoke-direct {v0, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    invoke-direct {v0, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v8

    invoke-direct {v5, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v4, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-lez v1, :cond_143

    .line 2294
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    goto :goto_145

    :cond_143
    const-string v1, "--"

    :goto_145
    const/16 v4, 0x18

    invoke-direct {v0, v1, v4, v12, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v1

    const/16 v4, 0x11

    .line 2295
    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setGravity(I)V

    .line 2296
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    const/16 v6, 0x1e

    invoke-direct {v0, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v6

    invoke-direct {v4, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2297
    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    const v4, 0x800015

    invoke-direct {v1, v11, v11, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    const/16 v4, 0xc

    .line 2298
    invoke-direct {v0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    iput v4, v1, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    .line 2299
    invoke-virtual {v2, v3, v1}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v2

    .line 2268
    :cond_176
    :goto_176
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_180

    const v1, -0x1f56d6

    goto :goto_189

    :cond_180
    if-eqz v5, :cond_186

    const v1, -0x64d5c3

    goto :goto_189

    :cond_186
    const v1, -0x11d5cfb9

    .line 2269
    :goto_189
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_193

    const v4, -0x85a600

    goto :goto_19c

    :cond_193
    if-eqz v5, :cond_199

    const v4, -0xb7efe5

    goto :goto_19c

    :cond_199
    const v4, -0x11efece1

    :goto_19c
    const v6, -0x55000001

    .line 2268
    invoke-direct {v0, v1, v4, v14, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/FrameLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2270
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1c2

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u51a0\u519b \u00b7 "

    invoke-direct {v0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_1d1

    :cond_1c2
    if-eqz v5, :cond_1cb

    const-string v1, "\u6dd8\u6c70\u8d5b\u6b62\u6b65 \u00b7 \u672c\u5c4a\u6b27\u51a0\u5230\u6b64\u7ed3\u675f"

    invoke-direct {v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    goto :goto_1d1

    :cond_1cb
    const-string v1, "\u664b\u7ea7\u8def\u5f84\u751f\u6210\u4e2d"

    invoke-direct {v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 2271
    :goto_1d1
    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v3, v11, v11, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    .line 2272
    invoke-direct {v0, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    iput v4, v3, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 2273
    invoke-direct {v0, v1, v10, v12, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v2, v1, v3}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v2
.end method

.method private knockoutCard(Lorg/json/JSONObject;)Landroid/view/View;
    .registers 13

    .line 1814
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->card()Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v1, "champion"

    const-string v2, ""

    .line 1815
    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 1816
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u6dd8\u6c70\u8d5b \u00b7 "

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "round"

    const-string v5, "R16"

    invoke-virtual {p1, v4, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x10

    const/16 v5, -0x1eb6

    const/4 v6, 0x1

    invoke-direct {p0, v3, v4, v5, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v3

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v7, 0x1e

    .line 1817
    invoke-direct {p0, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v8

    const/4 v9, -0x1

    invoke-direct {v4, v9, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1816
    invoke-virtual {v0, v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1818
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u5df2\u5b8c\u6210 "

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "played"

    invoke-virtual {p1, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, " / "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "total"

    invoke-virtual {p1, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, " \u573a"

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const v4, -0x564b2a

    const/4 v8, 0x0

    const/16 v10, 0xd

    invoke-direct {p0, v3, v10, v4, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v3

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v8, 0x18

    .line 1819
    invoke-direct {p0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v8

    invoke-direct {v4, v9, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1818
    invoke-virtual {v0, v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v3, "nextOpponent"

    .line 1820
    invoke-virtual {p1, v3, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 1821
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_ad

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\ud83c\udfc6 \u51a0\u519b \u00b7 "

    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_cf

    .line 1822
    :cond_ad
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_ba

    const-string p1, "\u664b\u7ea7\u8def\u5f84\u6b63\u5728\u751f\u6210"

    invoke-direct {p0, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    goto :goto_cf

    :cond_ba
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u4e0b\u4e00\u573a \u00b7 "

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 1823
    :goto_cf
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_d6

    move v5, v9

    :cond_d6
    const/16 v1, 0xf

    invoke-direct {p0, p1, v1, v5, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p1

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    .line 1824
    invoke-direct {p0, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    invoke-direct {v1, v9, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1823
    invoke-virtual {v0, p1, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private knockoutEventId()I
    .registers 4

    .line 2008
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    if-nez v0, :cond_6

    const/4 v0, 0x0

    goto :goto_c

    :cond_6
    const-string v1, "cup"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    :goto_c
    const v1, 0x111707

    if-nez v0, :cond_12

    goto :goto_18

    :cond_12
    const-string v2, "knockoutEventId"

    .line 2009
    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v1

    :goto_18
    return v1
.end method

.method private knockoutScene(Lorg/json/JSONObject;FI)Landroid/widget/FrameLayout;
    .registers 21

    move-object/from16 v8, p0

    move-object/from16 v0, p1

    move/from16 v9, p2

    .line 2219
    new-instance v1, Landroid/content/res/Configuration;

    iget-object v2, v8, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    invoke-virtual {v2}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    const/16 v2, 0x120

    .line 2220
    iput v2, v1, Landroid/content/res/Configuration;->densityDpi:I

    .line 2221
    iget-object v2, v8, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    invoke-virtual {v2, v1}, Landroid/app/Activity;->createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;

    move-result-object v1

    iput-object v1, v8, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->uiContext:Landroid/content/Context;

    .line 2223
    :try_start_21
    new-instance v11, Landroid/widget/FrameLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v11, v1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 2224
    iget v1, v8, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->safeLeftPx:I

    int-to-float v1, v1

    div-float/2addr v1, v9

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    .line 2225
    iget v2, v8, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->safeRightPx:I

    int-to-float v2, v2

    div-float/2addr v2, v9

    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    sub-int v3, p3, v1

    sub-int/2addr v3, v2

    int-to-float v3, v3

    const v4, 0x3c8f5c29    # 0.0175f

    mul-float/2addr v3, v4

    float-to-int v3, v3

    add-int v12, v1, v3

    add-int v13, v2, v3

    const-string v1, "\u8f6e\u6b21\u6982\u89c8"

    .line 2229
    invoke-direct {v8, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v8, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->sceneHeader(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v3

    const/16 v5, 0x18

    sub-int v1, p3, v12

    sub-int v14, v1, v13

    const/16 v1, 0x2c

    invoke-direct {v8, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    move-object/from16 v1, p0

    move-object v2, v11

    move v4, v12

    move v6, v14

    invoke-direct/range {v1 .. v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->put(Landroid/widget/FrameLayout;Landroid/view/View;IIII)V

    .line 2230
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v3, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v1, 0x10

    .line 2231
    invoke-virtual {v3, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    const-string v1, "\u5c0f\u7ec4\u8d5b"

    .line 2232
    invoke-direct {v8, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v15, 0x0

    invoke-direct {v8, v1, v15, v15}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->modeChip(Ljava/lang/String;ZZ)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v3, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v1, "\u6dd8\u6c70\u8d5b"

    .line 2233
    invoke-direct {v8, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x1

    invoke-direct {v8, v1, v7, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->modeChip(Ljava/lang/String;ZZ)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v3, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/16 v5, 0x78

    const/16 v1, 0x26

    .line 2234
    invoke-direct {v8, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v16

    move-object/from16 v1, p0

    move-object v2, v11

    move v4, v12

    move v6, v14

    move v15, v7

    move/from16 v7, v16

    invoke-direct/range {v1 .. v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->put(Landroid/widget/FrameLayout;Landroid/view/View;IIII)V

    const-string v1, "rounds"

    .line 2235
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    const/16 v7, 0x8

    if-eqz v4, :cond_134

    .line 2236
    invoke-virtual {v4}, Lorg/json/JSONArray;->length()I

    move-result v1

    const/4 v2, 0x4

    if-lt v1, v2, :cond_134

    .line 2238
    iget v1, v8, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeTopPx:I

    int-to-float v1, v1

    div-float/2addr v1, v9

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    add-int/lit16 v1, v1, -0xc5

    invoke-direct {v8, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    sub-int v16, v1, v2

    const/16 v1, 0x18

    .line 2239
    invoke-direct {v8, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    sub-int v1, v16, v1

    const/4 v2, 0x6

    invoke-direct {v8, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    sub-int/2addr v1, v2

    int-to-float v1, v1

    const/high16 v2, 0x40800000    # 4.0f

    div-float/2addr v1, v2

    const/16 v2, 0x54

    .line 2240
    invoke-direct {v8, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-direct {v8, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v3

    sub-int/2addr v1, v3

    invoke-static {v2, v1}, Ljava/lang/Math;->min(II)I

    move-result v6

    int-to-float v1, v6

    .line 2241
    invoke-direct {v8, v15}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v1, v2

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v1, v2

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    add-int/lit8 v1, v1, -0x5

    const/16 v2, 0x22

    invoke-static {v2, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/16 v2, 0x12

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v8, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->bracketCrestDp:I

    const-string v1, "champion"

    const-string v2, ""

    .line 2242
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_116

    move v5, v15

    goto :goto_117

    :cond_116
    const/4 v5, 0x0

    .line 2243
    :goto_117
    new-instance v15, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v3

    move-object v1, v15

    move-object/from16 v2, p0

    move v10, v7

    move/from16 v7, v16

    invoke-direct/range {v1 .. v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Landroid/content/Context;Lorg/json/JSONArray;ZII)V

    const/16 v5, 0xc5

    move-object/from16 v1, p0

    move-object v2, v11

    move-object v3, v15

    move v4, v12

    move v6, v14

    move/from16 v7, v16

    invoke-direct/range {v1 .. v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->put(Landroid/widget/FrameLayout;Landroid/view/View;IIII)V

    goto :goto_135

    :cond_134
    move v10, v7

    .line 2246
    :goto_135
    iget v1, v8, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeRightPx:I

    int-to-float v1, v1

    div-float/2addr v1, v9

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    invoke-direct {v8, v10}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    add-int v4, v1, v2

    .line 2247
    invoke-direct/range {p0 .. p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->knockoutBar(Lorg/json/JSONObject;)Landroid/view/View;

    move-result-object v3

    iget v0, v8, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->barTopPx:I

    int-to-float v0, v0

    div-float/2addr v0, v9

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v5

    sub-int v0, p3, v13

    sub-int v6, v0, v4

    iget v0, v8, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->barHeightPx:I

    int-to-float v0, v0

    div-float/2addr v0, v9

    .line 2248
    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v7

    move-object/from16 v1, p0

    move-object v2, v11

    .line 2247
    invoke-direct/range {v1 .. v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->put(Landroid/widget/FrameLayout;Landroid/view/View;IIII)V

    const/4 v0, 0x0

    .line 2249
    invoke-virtual {v11, v0}, Landroid/widget/FrameLayout;->setPivotX(F)V

    .line 2250
    invoke-virtual {v11, v0}, Landroid/widget/FrameLayout;->setPivotY(F)V

    .line 2251
    invoke-virtual {v11, v9}, Landroid/widget/FrameLayout;->setScaleX(F)V

    .line 2252
    invoke-virtual {v11, v9}, Landroid/widget/FrameLayout;->setScaleY(F)V
    :try_end_16e
    .catchall {:try_start_21 .. :try_end_16e} :catchall_172

    const/4 v1, 0x0

    .line 2255
    iput-object v1, v8, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->uiContext:Landroid/content/Context;

    return-object v11

    :catchall_172
    move-exception v0

    const/4 v1, 0x0

    iput-object v1, v8, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->uiContext:Landroid/content/Context;

    .line 2256
    throw v0
.end method

.method static synthetic lambda$openFromGateway$0(Landroid/app/Activity;I)Lorg/json/JSONObject;
    .registers 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 141
    invoke-static {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->loadCrestPack(Landroid/app/Activity;)V

    .line 142
    new-instance v0, Lorg/json/JSONObject;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "{\"eventId\":"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, "}"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v1, "ucl_ui_snapshot"

    invoke-static {p0, v1, p1}, Lorg/efootballrevival/runtimeprobe/EmbeddedGateway;->manage(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    return-object v0
.end method

.method static synthetic lambda$openFromGateway$1(I)V
    .registers 2

    const/4 v0, 0x0

    .line 150
    invoke-static {p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->openWhenReady(II)V

    return-void
.end method

.method static synthetic lambda$openWhenReady$2(II)V
    .registers 2

    add-int/lit8 p1, p1, 0x1

    .line 171
    invoke-static {p0, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->openWhenReady(II)V

    return-void
.end method

.method private static launcherIsEnglish(Landroid/app/Activity;)Z
    .registers 4

    .line 2019
    invoke-static {}, Lorg/efootballrevival/runtimeprobe/UiStrings;->language()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    :try_start_5
    const-string v2, "ui-language"

    .line 2021
    invoke-virtual {p0, v2, v1}, Landroid/app/Activity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const-string v2, "language"

    invoke-interface {p0, v2, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_11} :catch_11

    :catch_11
    if-eqz v0, :cond_1c

    const-string p0, "zh"

    .line 2024
    invoke-virtual {v0, p0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    if-nez p0, :cond_1c

    const/4 v1, 0x1

    :cond_1c
    return v1
.end method

.method private layoutPads()V
    .registers 9

    .line 560
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padTop:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    if-eqz v0, :cond_74

    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padRight:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    if-eqz v0, :cond_74

    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelWm:Landroid/view/WindowManager;

    if-nez v0, :cond_d

    goto :goto_74

    .line 561
    :cond_d
    iget v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->sceneW:I

    .line 562
    iget v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->sceneH:I

    .line 563
    iget v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeTopPx:I

    invoke-static {v2, v1}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/4 v3, 0x1

    invoke-static {v3, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    .line 564
    iget v4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeRightPx:I

    add-int/lit8 v5, v0, -0x1

    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v4

    const/4 v5, 0x0

    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    .line 566
    :try_start_29
    iget-object v6, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padTop:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    invoke-virtual {v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v6

    check-cast v6, Landroid/view/WindowManager$LayoutParams;

    .line 567
    iput v5, v6, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 568
    iput v5, v6, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 569
    iput v0, v6, Landroid/view/WindowManager$LayoutParams;->width:I

    .line 570
    iput v2, v6, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 571
    iget-object v7, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padTop:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    invoke-virtual {v7, v5, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;->setOrigin(II)V

    .line 572
    iget-object v5, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelWm:Landroid/view/WindowManager;

    iget-object v7, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padTop:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    invoke-interface {v5, v7, v6}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 573
    iget-object v5, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padRight:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    invoke-virtual {v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    check-cast v5, Landroid/view/WindowManager$LayoutParams;

    .line 574
    iput v4, v5, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 575
    iput v2, v5, Landroid/view/WindowManager$LayoutParams;->y:I

    sub-int/2addr v0, v4

    .line 576
    invoke-static {v3, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, v5, Landroid/view/WindowManager$LayoutParams;->width:I

    sub-int/2addr v1, v2

    .line 577
    invoke-static {v3, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, v5, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 578
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padRight:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    invoke-virtual {v0, v4, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;->setOrigin(II)V

    .line 579
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelWm:Landroid/view/WindowManager;

    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padRight:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    invoke-interface {v0, v1, v5}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_6b
    .catch Ljava/lang/Exception; {:try_start_29 .. :try_end_6b} :catch_6c

    goto :goto_74

    :catch_6c
    move-exception v0

    const-string v1, "E112_CUP_UI"

    const-string v2, "pad layout failed"

    .line 581
    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_74
    :goto_74
    return-void
.end method

.method private leaveScene()V
    .registers 4

    .line 1069
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rootHost:Landroid/widget/FrameLayout;

    if-eqz v0, :cond_30

    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->legacy:Landroid/widget/LinearLayout;

    if-nez v1, :cond_9

    goto :goto_30

    .line 1070
    :cond_9
    invoke-virtual {v0}, Landroid/widget/FrameLayout;->getChildCount()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_f
    if-ltz v0, :cond_23

    .line 1071
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rootHost:Landroid/widget/FrameLayout;

    invoke-virtual {v1, v0}, Landroid/widget/FrameLayout;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    iget-object v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->legacy:Landroid/widget/LinearLayout;

    if-eq v1, v2, :cond_20

    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rootHost:Landroid/widget/FrameLayout;

    invoke-virtual {v1, v0}, Landroid/widget/FrameLayout;->removeViewAt(I)V

    :cond_20
    add-int/lit8 v0, v0, -0x1

    goto :goto_f

    .line 1073
    :cond_23
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->legacy:Landroid/widget/LinearLayout;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1074
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->stripHost:Landroid/widget/FrameLayout;

    if-eqz v0, :cond_30

    invoke-virtual {v0}, Landroid/widget/FrameLayout;->removeAllViews()V

    :cond_30
    :goto_30
    return-void
.end method

.method private legend()Landroid/view/View;
    .registers 13

    .line 1576
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v1, 0x10

    .line 1577
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v2, 0x8

    .line 1578
    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v3

    const/16 v4, 0xa

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    const/4 v6, 0x2

    invoke-direct {p0, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v6

    invoke-virtual {v0, v3, v5, v2, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 1579
    iget-boolean v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->roomyRows:Z

    const/16 v3, 0x14

    const/4 v5, -0x2

    const/4 v6, 0x0

    if-nez v2, :cond_a0

    const v2, -0xe8579e

    .line 1580
    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->legendDot(I)Landroid/view/View;

    move-result-object v2

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v8

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v9

    invoke-direct {v7, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v2, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v2, "\u664b\u7ea716\u5f3a\u6dd8\u6c70\u8d5b"

    .line 1581
    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/16 v7, 0xc

    const v8, -0x564b2a

    invoke-direct {p0, v2, v7, v8, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v2

    .line 1582
    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v10

    invoke-direct {v9, v5, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v10, 0x6

    .line 1583
    invoke-direct {p0, v10}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v11

    iput v11, v9, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 1584
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    iput v1, v9, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 1585
    invoke-virtual {v0, v2, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const v1, 0x66ffffff

    .line 1586
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->legendDot(I)Landroid/view/View;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v9

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    invoke-direct {v2, v9, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v1, "\u5c0f\u7ec4\u6dd8\u6c70"

    .line 1587
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1, v7, v8, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v1

    .line 1588
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    invoke-direct {v2, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1589
    invoke-direct {p0, v10}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    iput v4, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 1590
    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1592
    :cond_a0
    new-instance v1, Landroid/view/View;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, 0x1

    const/high16 v7, 0x3f800000    # 1.0f

    invoke-direct {v2, v6, v4, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v1, "\u540c\u5206\u4f9d\u6b21\u6bd4\u51c0\u80dc\u7403\u3001\u8fdb\u7403\u6570"

    .line 1593
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0xb

    const v4, -0x817758

    invoke-direct {p0, v1, v2, v4, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v3

    invoke-direct {v2, v5, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private legendDot(I)Landroid/view/View;
    .registers 4

    .line 1598
    new-instance v0, Landroid/view/View;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x5

    .line 1599
    invoke-direct {p0, p1, p1, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->vgrad(III)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-object v0
.end method

.method private static declared-synchronized loadCrestPack(Landroid/app/Activity;)V
    .registers 13

    const-class v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    monitor-enter v0

    .line 659
    :try_start_3
    sget-object v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->crestIndex:Ljava/util/Map;
    :try_end_5
    .catchall {:try_start_3 .. :try_end_5} :catchall_ad

    if-eqz v1, :cond_9

    monitor-exit v0

    return-void

    .line 660
    :cond_9
    :try_start_9
    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V
    :try_end_e
    .catchall {:try_start_9 .. :try_end_e} :catchall_ad

    .line 661
    :try_start_e
    invoke-virtual {p0}, Landroid/app/Activity;->getAssets()Landroid/content/res/AssetManager;

    move-result-object p0

    const-string v2, "cup-crests/crests.bin"

    invoke-virtual {p0, v2}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object p0
    :try_end_18
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_18} :catch_a1
    .catchall {:try_start_e .. :try_end_18} :catchall_ad

    .line 662
    :try_start_18
    new-instance v2, Ljava/io/ByteArrayOutputStream;

    const/high16 v3, 0x200000

    invoke-direct {v2, v3}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    const/high16 v3, 0x10000

    new-array v3, v3, [B

    .line 664
    :goto_23
    invoke-virtual {p0, v3}, Ljava/io/InputStream;->read([B)I

    move-result v4

    const/4 v5, 0x0

    if-lez v4, :cond_2e

    invoke-virtual {v2, v3, v5, v4}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    goto :goto_23

    .line 665
    :cond_2e
    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2

    .line 666
    invoke-static {v2}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v3

    sget-object v4, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    invoke-virtual {v3, v4}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v3

    .line 667
    array-length v4, v2

    const/16 v6, 0x8

    if-lt v4, v6, :cond_8f

    aget-byte v4, v2, v5

    const/16 v7, 0x43

    if-ne v4, v7, :cond_8f

    const/4 v4, 0x1

    aget-byte v4, v2, v4

    const/16 v7, 0x52

    if-ne v4, v7, :cond_8f

    const/4 v4, 0x2

    aget-byte v4, v2, v4

    const/16 v7, 0x53

    if-ne v4, v7, :cond_8f

    const/4 v4, 0x3

    aget-byte v4, v2, v4

    const/16 v7, 0x54

    if-ne v4, v7, :cond_8f

    const/4 v4, 0x4

    .line 668
    invoke-virtual {v3, v4}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v4

    :goto_61
    if-ge v5, v4, :cond_8d

    mul-int/lit8 v7, v5, 0xc

    add-int/2addr v7, v6

    add-int/lit8 v8, v7, 0x4

    .line 671
    invoke-virtual {v3, v8}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v8

    add-int/lit8 v9, v7, 0x8

    .line 672
    invoke-virtual {v3, v9}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v9

    if-ltz v8, :cond_8a

    if-lez v9, :cond_8a

    add-int v10, v8, v9

    .line 673
    array-length v11, v2

    if-gt v10, v11, :cond_8a

    .line 674
    invoke-virtual {v3, v7}, Ljava/nio/ByteBuffer;->getInt(I)I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    filled-new-array {v8, v9}, [I

    move-result-object v8

    invoke-interface {v1, v7, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_8a
    add-int/lit8 v5, v5, 0x1

    goto :goto_61

    .line 677
    :cond_8d
    sput-object v2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->crestPack:[B
    :try_end_8f
    .catchall {:try_start_18 .. :try_end_8f} :catchall_95

    :cond_8f
    if-eqz p0, :cond_a9

    .line 679
    :try_start_91
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_94
    .catch Ljava/lang/Exception; {:try_start_91 .. :try_end_94} :catch_a1
    .catchall {:try_start_91 .. :try_end_94} :catchall_ad

    goto :goto_a9

    :catchall_95
    move-exception v2

    if-eqz p0, :cond_a0

    .line 661
    :try_start_98
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_9b
    .catchall {:try_start_98 .. :try_end_9b} :catchall_9c

    goto :goto_a0

    :catchall_9c
    move-exception p0

    :try_start_9d
    invoke-virtual {v2, p0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_a0
    :goto_a0
    throw v2
    :try_end_a1
    .catch Ljava/lang/Exception; {:try_start_9d .. :try_end_a1} :catch_a1
    .catchall {:try_start_9d .. :try_end_a1} :catchall_ad

    :catch_a1
    move-exception p0

    :try_start_a2
    const-string v2, "E112_CUP_UI"

    const-string v3, "crest pack unavailable"

    .line 680
    invoke-static {v2, v3, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 682
    :cond_a9
    :goto_a9
    sput-object v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->crestIndex:Ljava/util/Map;
    :try_end_ab
    .catchall {:try_start_a2 .. :try_end_ab} :catchall_ad

    .line 683
    monitor-exit v0

    return-void

    :catchall_ad
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method private static logPhase(Ljava/lang/String;)V
    .registers 6

    .line 154
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " +"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    sget-wide v3, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->openRequestedAt:J

    sub-long/2addr v1, v3

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string p0, "ms"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "E112_CUP_UI"

    invoke-static {v0, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method private matchTimeButton()Landroid/widget/TextView;
    .registers 6

    const/4 v0, -0x1

    const/4 v1, 0x1

    const-string v2, ""

    const/16 v3, 0xd

    .line 1310
    invoke-direct {p0, v2, v3, v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v0

    const/16 v1, 0x11

    .line 1311
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v1, 0xe

    .line 1312
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    const/4 v3, 0x0

    invoke-virtual {v0, v2, v3, v1, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    const v1, 0x18ffffff

    const/16 v2, 0x10

    const v4, 0x44ffffff    # 2047.9999f

    .line 1313
    invoke-direct {p0, v4, v1, v2, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1314
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    if-nez v1, :cond_35

    sget-object v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->MATCH_MINUTES:[I

    aget v1, v1, v3

    goto :goto_3f

    :cond_35
    sget-object v2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->MATCH_MINUTES:[I

    aget v2, v2, v3

    const-string v3, "matchTime"

    invoke-virtual {v1, v3, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v1

    .line 1315
    :goto_3f
    filled-new-array {v1}, [I

    move-result-object v2

    .line 1316
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u8bbe\u7f6e"

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " \u00b7 "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, "\u6bd4\u8d5b\u65f6\u957f"

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v4, " "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "\u5206\u949f"

    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1317
    new-instance v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0, v2, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda2;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;[ILandroid/widget/TextView;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object v0
.end method

.method private static mixColors(II)I
    .registers 6

    ushr-int/lit8 v0, p0, 0x18

    and-int/lit16 v0, v0, 0xff

    ushr-int/lit8 v1, p1, 0x18

    and-int/lit16 v1, v1, 0xff

    add-int/2addr v0, v1

    .line 717
    div-int/lit8 v0, v0, 0x2

    shr-int/lit8 v1, p0, 0x10

    and-int/lit16 v1, v1, 0xff

    shr-int/lit8 v2, p1, 0x10

    and-int/lit16 v2, v2, 0xff

    add-int/2addr v1, v2

    .line 718
    div-int/lit8 v1, v1, 0x2

    shr-int/lit8 v2, p0, 0x8

    and-int/lit16 v2, v2, 0xff

    shr-int/lit8 v3, p1, 0x8

    and-int/lit16 v3, v3, 0xff

    add-int/2addr v2, v3

    .line 719
    div-int/lit8 v2, v2, 0x2

    and-int/lit16 p0, p0, 0xff

    and-int/lit16 p1, p1, 0xff

    add-int/2addr p0, p1

    .line 720
    div-int/lit8 p0, p0, 0x2

    shl-int/lit8 p1, v0, 0x18

    shl-int/lit8 v0, v1, 0x10

    or-int/2addr p1, v0

    shl-int/lit8 v0, v2, 0x8

    or-int/2addr p1, v0

    or-int/2addr p0, p1

    return p0
.end method

.method private modeChip(Ljava/lang/String;ZZ)Landroid/view/View;
    .registers 7

    if-eqz p2, :cond_4

    const/4 v0, -0x1

    goto :goto_7

    :cond_4
    const v0, -0x564b2a

    :goto_7
    const/4 v1, 0x1

    const/16 v2, 0xe

    .line 1892
    invoke-direct {p0, p1, v2, v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p1

    const/16 v0, 0x11

    .line 1893
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v0, 0x12

    .line 1894
    invoke-direct {p0, p2, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->chipFace(ZI)Landroid/graphics/drawable/Drawable;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1895
    new-instance p2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda12;

    invoke-direct {p2, p0, p3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda12;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Z)V

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1899
    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 p3, 0x54

    invoke-direct {p0, p3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result p3

    const/16 v0, 0x22

    invoke-direct {p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v0

    invoke-direct {p2, p3, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 p3, 0x8

    .line 1900
    invoke-direct {p0, p3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result p3

    iput p3, p2, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 1901
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object p1
.end method

.method private myRunCard(Lorg/json/JSONArray;Lorg/json/JSONArray;)Landroid/view/View;
    .registers 16

    const-string v0, "isPlayer"

    const/4 v1, 0x0

    if-eqz p2, :cond_22

    move v2, v1

    move v3, v2

    .line 1607
    :goto_7
    invoke-virtual {p2}, Lorg/json/JSONArray;->length()I

    move-result v4

    if-ge v2, v4, :cond_23

    .line 1608
    invoke-virtual {p2, v2}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    if-eqz v4, :cond_1f

    .line 1609
    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_1f

    const-string v3, "teamId"

    invoke-virtual {v4, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v3

    :cond_1f
    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    :cond_22
    move v3, v1

    .line 1612
    :cond_23
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->card()Landroid/widget/LinearLayout;

    move-result-object p2

    const-string v2, "\u6211\u7684\u5c0f\u7ec4\u8d5b\u4e4b\u8def"

    .line 1613
    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/16 v4, 0xf

    const/4 v5, -0x1

    const/4 v6, 0x1

    invoke-direct {p0, v2, v4, v5, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v2

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v7, 0x1c

    invoke-direct {p0, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    invoke-direct {v4, v5, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p2, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1614
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v4

    invoke-direct {v2, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1615
    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->setBaselineAligned(Z)V

    if-eqz p1, :cond_a0

    move v4, v1

    .line 1617
    :goto_52
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v7

    if-ge v4, v7, :cond_a0

    .line 1618
    invoke-virtual {p1, v4}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v7

    const/4 v8, 0x0

    if-nez v7, :cond_61

    move-object v9, v8

    goto :goto_67

    :cond_61
    const-string v9, "fixtures"

    .line 1619
    invoke-virtual {v7, v9}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v9

    :goto_67
    if-eqz v9, :cond_80

    move v10, v1

    .line 1622
    :goto_6a
    invoke-virtual {v9}, Lorg/json/JSONArray;->length()I

    move-result v11

    if-ge v10, v11, :cond_80

    .line 1623
    invoke-virtual {v9, v10}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v11

    if-eqz v11, :cond_7d

    .line 1624
    invoke-virtual {v11, v0}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_7d

    move-object v8, v11

    :cond_7d
    add-int/lit8 v10, v10, 0x1

    goto :goto_6a

    :cond_80
    if-nez v8, :cond_83

    goto :goto_9d

    :cond_83
    const-string v9, "round"

    .line 1628
    invoke-virtual {v7, v9}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v7

    invoke-direct {p0, v7, v8, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->runTile(ILorg/json/JSONObject;I)Landroid/view/View;

    move-result-object v7

    .line 1629
    invoke-virtual {v2}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v8

    if-lez v8, :cond_95

    move v8, v6

    goto :goto_96

    :cond_95
    move v8, v1

    :goto_96
    invoke-direct {p0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->tileParams(Z)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v8

    .line 1628
    invoke-virtual {v2, v7, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :goto_9d
    add-int/lit8 v4, v4, 0x1

    goto :goto_52

    .line 1632
    :cond_a0
    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v0, -0x2

    invoke-direct {p1, v5, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p2, v2, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object p2
.end method

.method private nextCard()Landroid/view/View;
    .registers 13

    .line 1783
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 1784
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v2, 0x10

    .line 1785
    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v3

    const/16 v4, 0xc

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v6

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    invoke-virtual {v0, v3, v5, v6, v7}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const v3, -0xc5a301

    const v5, -0xe070ab

    .line 1786
    invoke-direct {p0, v3, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v3

    const v5, -0xf5e071

    const v6, -0xf4c2de

    invoke-direct {p0, v5, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v5

    const v6, -0x55604701

    const v7, -0x55601740

    invoke-direct {p0, v6, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v6

    invoke-direct {p0, v3, v5, v2, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    .line 1787
    sget-object v5, Landroid/graphics/drawable/GradientDrawable$Orientation;->LEFT_RIGHT:Landroid/graphics/drawable/GradientDrawable$Orientation;

    invoke-virtual {v3, v5}, Landroid/graphics/drawable/GradientDrawable;->setOrientation(Landroid/graphics/drawable/GradientDrawable$Orientation;)V

    const v5, 0x16ffffff

    .line 1788
    invoke-direct {p0, v3, v5, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->striped(Landroid/graphics/drawable/Drawable;II)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1789
    iget-object v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v5, "nextOpponent"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 1790
    iget-object v5, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v6, "played"

    invoke-virtual {v5, v6}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v5

    .line 1791
    iget-object v6, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v7, "total"

    const/4 v8, 0x3

    invoke-virtual {v6, v7, v8}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v6

    .line 1792
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    const/16 v8, 0x20

    const/16 v9, 0x14

    const/4 v10, -0x1

    if-eqz v7, :cond_12e

    iget-object v7, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v11, "groupComplete"

    invoke-virtual {v7, v11}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_12e

    .line 1793
    iget-object v3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v5, "qualified"

    invoke-virtual {v3, v5}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_91

    const v5, -0xe8579e

    goto :goto_94

    :cond_91
    const v5, -0x64d5c3

    :goto_94
    if-eqz v3, :cond_9a

    const v6, -0xf4b2d1

    goto :goto_9d

    :cond_9a
    const v6, -0xb7efe5

    :goto_9d
    const v7, -0x77000001

    .line 1794
    invoke-direct {p0, v5, v6, v2, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    const v6, 0x14ffffff

    .line 1796
    invoke-direct {p0, v5, v6, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->striped(Landroid/graphics/drawable/Drawable;II)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1797
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u5c0f\u7ec4\u8d5b\u7ed3\u675f \u00b7 \u5c0f\u7ec4\u7b2c "

    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v5, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v6, "ownRank"

    invoke-virtual {v5, v6}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, " \u540d \u00b7 \u79ef\u5206 "

    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v5, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v6, "ownPoints"

    .line 1798
    invoke-virtual {v5, v6}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const v5, -0x200916

    .line 1797
    invoke-direct {p0, v2, v4, v5, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v2

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    .line 1799
    invoke-direct {p0, v9}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v6

    invoke-direct {v4, v10, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1797
    invoke-virtual {v0, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz v3, :cond_f7

    const-string v2, "\u5df2\u664b\u7ea716\u5f3a"

    goto :goto_f9

    :cond_f7
    const-string v2, "\u672a\u80fd\u664b\u7ea7"

    .line 1800
    :goto_f9
    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {p0, v2, v9, v10, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 1801
    invoke-direct {p0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    invoke-direct {v2, v10, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1800
    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz v3, :cond_112

    const-string v1, "\u8fd4\u56de\u6d3b\u52a8\u5217\u8868\uff0c\u8fdb\u5165\u300c\u6b27\u51a0\u6dd8\u6c70\u8d5b\u300d\u7ee7\u7eed"

    goto :goto_114

    :cond_112
    const-string v1, "\u672a\u8fdb\u5165\u5c0f\u7ec4\u524d\u4e8c\uff0c\u672c\u5c4a\u6b27\u51a0\u5230\u6b64\u7ed3\u675f"

    .line 1802
    :goto_114
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0xd

    const/4 v3, 0x0

    invoke-direct {p0, v1, v2, v5, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x18

    .line 1803
    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v3

    invoke-direct {v2, v10, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1802
    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0

    .line 1806
    :cond_12e
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_13b

    const-string v2, "\u5c0f\u7ec4\u8d5b"

    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_159

    :cond_13b
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "\u4e0b\u4e00\u573a \u00b7 \u6bd4\u8d5b\u65e5 "

    invoke-direct {p0, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/2addr v5, v1

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, " / "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :goto_159
    const v5, -0x322901

    invoke-direct {p0, v2, v4, v5, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v2

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    .line 1807
    invoke-direct {p0, v9}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {v4, v10, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1806
    invoke-virtual {v0, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1808
    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_179

    const-string v2, "\u672c\u7ec4\u8d5b\u7a0b\u5df2\u5b8c\u6210"

    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_187

    :cond_179
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v4, "VS  "

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :goto_187
    invoke-direct {p0, v2, v9, v10, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 1809
    invoke-direct {p0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v3

    invoke-direct {v2, v10, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1808
    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private nextMatchBar()Landroid/view/View;
    .registers 17

    move-object/from16 v0, p0

    .line 1468
    new-instance v1, Landroid/widget/FrameLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 1469
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v3, "nextOpponent"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 1470
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    const/4 v5, 0x1

    if-eqz v3, :cond_26

    iget-object v3, v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v6, "groupComplete"

    invoke-virtual {v3, v6}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_26

    move v3, v5

    goto :goto_27

    :cond_26
    const/4 v3, 0x0

    .line 1471
    :goto_27
    iget-object v6, v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v7, "qualified"

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v6

    .line 1472
    iget-object v7, v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v8, "played"

    invoke-virtual {v7, v8}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v7

    .line 1473
    iget-object v8, v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v9, "total"

    const/4 v10, 0x3

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v8

    const/16 v9, 0x18

    const/16 v10, 0xc

    const/16 v11, 0x12

    const/4 v12, -0x2

    const/4 v13, -0x1

    const/16 v14, 0x10

    if-eqz v3, :cond_e8

    if-eqz v6, :cond_52

    const v2, -0xe8579e

    goto :goto_55

    :cond_52
    const v2, -0x64d5c3

    :goto_55
    if-eqz v6, :cond_5b

    const v3, -0xf4b2d1

    goto :goto_5e

    :cond_5b
    const v3, -0xb7efe5

    :goto_5e
    const v4, -0x55000001

    .line 1475
    invoke-direct {v0, v2, v3, v14, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/FrameLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1476
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1477
    invoke-virtual {v2, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1478
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u5c0f\u7ec4\u8d5b\u7ed3\u675f \u00b7 \u5c0f\u7ec4\u7b2c "

    invoke-direct {v0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v7, "ownRank"

    invoke-virtual {v4, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, " \u540d \u00b7 \u79ef\u5206 "

    invoke-direct {v0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v7, "ownPoints"

    .line 1479
    invoke-virtual {v4, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const v4, -0x200916

    .line 1478
    invoke-direct {v0, v3, v10, v4, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v3

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    .line 1479
    invoke-direct {v0, v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    invoke-direct {v4, v13, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1478
    invoke-virtual {v2, v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-eqz v6, :cond_bd

    const-string v3, "\u5df2\u664b\u7ea716\u5f3a \u00b7 \u8fd4\u56de\u6d3b\u52a8\u5217\u8868\u8fdb\u5165\u300c\u6b27\u51a0\u6dd8\u6c70\u8d5b\u300d"

    goto :goto_bf

    :cond_bd
    const-string v3, "\u672a\u80fd\u664b\u7ea7 \u00b7 \u672c\u5c4a\u6b27\u51a0\u5230\u6b64\u7ed3\u675f"

    .line 1480
    :goto_bf
    invoke-direct {v0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v3, v14, v13, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v3

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    .line 1481
    invoke-direct {v0, v9}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {v4, v13, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1480
    invoke-virtual {v2, v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1482
    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v3, v13, v12, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    .line 1483
    invoke-direct {v0, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    iput v4, v3, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 1484
    invoke-direct {v0, v10}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    iput v4, v3, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    .line 1485
    invoke-virtual {v1, v2, v3}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v1

    :cond_e8
    const v3, -0x11efece1

    const v6, 0x33ffffff

    const v15, -0x11d5cfb9

    .line 1488
    invoke-direct {v0, v15, v3, v14, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    invoke-virtual {v1, v3}, Landroid/widget/FrameLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1489
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_117

    .line 1490
    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v2, v12, v12, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    .line 1491
    invoke-direct {v0, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v3

    iput v3, v2, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    const-string v3, "\u672c\u7ec4\u8d5b\u7a0b\u5df2\u5b8c\u6210"

    .line 1492
    invoke-direct {v0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v0, v3, v11, v13, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v3

    invoke-virtual {v1, v3, v2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v1

    .line 1495
    :cond_117
    new-instance v3, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v6, 0x2e

    invoke-direct {v0, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v15

    invoke-direct {v0, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v10

    invoke-direct {v3, v15, v10, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    const/16 v10, 0x8

    .line 1496
    invoke-direct {v0, v10}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v15

    iput v15, v3, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 1497
    iget-object v15, v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v9, "nextOpponentId"

    invoke-virtual {v15, v9}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v9

    invoke-direct {v0, v9, v2, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->plateCrest(ILjava/lang/String;I)Landroid/view/View;

    move-result-object v9

    .line 1498
    invoke-virtual {v1, v9, v3}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1499
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v9

    invoke-direct {v3, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1500
    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1501
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v15, "\u4e0b\u4e00\u573a\u6bd4\u8d5b \u00b7 \u6bd4\u8d5b\u65e5 "

    invoke-direct {v0, v15}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v9, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/2addr v7, v5

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v7, " / "

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0xb

    const v9, -0x564b2a

    invoke-direct {v0, v7, v8, v9, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v7

    new-instance v15, Landroid/widget/LinearLayout$LayoutParams;

    .line 1502
    invoke-direct {v0, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    invoke-direct {v15, v13, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1501
    invoke-virtual {v3, v7, v15}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1503
    invoke-direct {v0, v2, v11, v13, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v2

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v7, 0x1a

    invoke-direct {v0, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    invoke-direct {v4, v13, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1504
    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v2, v13, v12, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    .line 1505
    invoke-direct {v0, v10}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    invoke-direct {v0, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v6

    add-int/2addr v4, v6

    const/16 v6, 0xa

    invoke-direct {v0, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v6

    add-int/2addr v4, v6

    iput v4, v2, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    const/16 v4, 0x60

    .line 1506
    invoke-direct {v0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    iput v4, v2, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    .line 1507
    invoke-virtual {v1, v3, v2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1508
    iget-object v2, v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v3, "nextOpponentStrength"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v2

    .line 1509
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1510
    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1511
    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->setGravity(I)V

    const-string v4, "\u5bf9\u624b\u8bc4\u5206"

    .line 1512
    invoke-direct {v0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x0

    invoke-direct {v0, v4, v8, v9, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v4

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v7, 0x50

    invoke-direct {v0, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v8

    invoke-direct {v0, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v9

    invoke-direct {v6, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v4, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-lez v2, :cond_1eb

    .line 1513
    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    goto :goto_1ed

    :cond_1eb
    const-string v2, "--"

    :goto_1ed
    const/16 v4, 0x18

    invoke-direct {v0, v2, v4, v13, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v2

    const/16 v4, 0x11

    .line 1514
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setGravity(I)V

    .line 1515
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    const/16 v6, 0x1e

    invoke-direct {v0, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v6

    invoke-direct {v4, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1516
    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    const v4, 0x800015

    invoke-direct {v2, v12, v12, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    const/16 v4, 0xc

    .line 1517
    invoke-direct {v0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    iput v4, v2, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    .line 1518
    invoke-virtual {v1, v3, v2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v1
.end method

.method public static openFromGateway(I)V
    .registers 5

    .line 135
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    sput-wide v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->openRequestedAt:J

    :try_start_6
    const-string v0, "com.epicgames.ue4.GameActivity"

    .line 137
    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const-string v1, "Get"

    const/4 v2, 0x0

    new-array v3, v2, [Ljava/lang/Class;

    invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    new-array v1, v2, [Ljava/lang/Object;

    const/4 v2, 0x0

    invoke-virtual {v0, v2, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 138
    instance-of v1, v0, Landroid/app/Activity;

    if-eqz v1, :cond_41

    .line 139
    check-cast v0, Landroid/app/Activity;

    .line 140
    new-instance v1, Ljava/util/concurrent/FutureTask;

    new-instance v2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda21;

    invoke-direct {v2, v0, p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda21;-><init>(Landroid/app/Activity;I)V

    invoke-direct {v1, v2}, Ljava/util/concurrent/FutureTask;-><init>(Ljava/util/concurrent/Callable;)V

    .line 144
    sput-object v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->prefetch:Ljava/util/concurrent/FutureTask;

    .line 145
    new-instance v0, Ljava/lang/Thread;

    const-string v2, "e112-cup-prefetch"

    invoke-direct {v0, v1, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V
    :try_end_38
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_38} :catch_39

    goto :goto_41

    :catch_39
    move-exception v0

    const-string v1, "E112_CUP_UI"

    const-string v2, "prefetch not started"

    .line 148
    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 150
    :cond_41
    :goto_41
    sget-object v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->MAIN:Landroid/os/Handler;

    new-instance v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda22;

    invoke-direct {v1, p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda22;-><init>(I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private openSingleWindow(Landroid/widget/LinearLayout;Landroid/graphics/Bitmap;I)Z
    .registers 20

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    const-string v2, "E112_CUP_UI"

    const-string v3, "single window panel + input pads, hole right="

    const/4 v4, 0x0

    const/4 v5, 0x0

    .line 388
    :try_start_a
    iget-object v6, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    invoke-virtual {v6}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v6

    invoke-virtual {v6}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v6

    .line 389
    invoke-virtual {v6}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;

    move-result-object v7

    if-nez v7, :cond_1b

    return v5

    .line 390
    :cond_1b
    new-instance v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;

    iget-object v8, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    move-object/from16 v9, p2

    invoke-direct {v7, v1, v8, v9}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Landroid/content/Context;Landroid/graphics/Bitmap;)V

    .line 391
    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 392
    new-instance v8, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v9, -0x1

    invoke-direct {v8, v9, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v7, v0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 393
    new-instance v0, Landroid/view/WindowManager$LayoutParams;

    const/4 v11, -0x1

    const/4 v12, -0x1

    const/16 v13, 0x3e8

    const/16 v14, 0x18

    const/4 v15, -0x3

    move-object v10, v0

    invoke-direct/range {v10 .. v15}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    .line 398
    invoke-virtual {v6}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;

    move-result-object v8

    iput-object v8, v0, Landroid/view/WindowManager$LayoutParams;->token:Landroid/os/IBinder;

    const v8, 0x800033

    .line 399
    iput v8, v0, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 400
    iput v5, v0, Landroid/view/WindowManager$LayoutParams;->windowAnimations:I

    const-string v8, "E263CupPanel"

    .line 401
    invoke-virtual {v0, v8}, Landroid/view/WindowManager$LayoutParams;->setTitle(Ljava/lang/CharSequence;)V

    const/4 v8, 0x3

    .line 402
    iput v8, v0, Landroid/view/WindowManager$LayoutParams;->layoutInDisplayCutoutMode:I

    .line 403
    iget-object v8, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    invoke-virtual {v8}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    move-result-object v8

    iput-object v8, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelWm:Landroid/view/WindowManager;

    .line 404
    iput-object v7, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rootHost:Landroid/widget/FrameLayout;

    .line 405
    iput-object v7, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelRoot:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;

    .line 406
    iget v8, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeTopPx:I

    iget v9, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeRightPx:I

    const/16 v10, 0x4e20

    move/from16 v11, p3

    invoke-virtual {v7, v11, v8, v9, v10}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;->setHole(IIII)V

    .line 407
    iget-object v8, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelWm:Landroid/view/WindowManager;

    invoke-interface {v8, v7, v0}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 409
    new-instance v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    iget-object v7, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    invoke-direct {v0, v1, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Landroid/content/Context;)V

    iput-object v0, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padTop:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    .line 410
    new-instance v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    iget-object v7, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    invoke-direct {v0, v1, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Landroid/content/Context;)V

    iput-object v0, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padRight:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    .line 411
    iget-object v0, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelWm:Landroid/view/WindowManager;

    iget-object v7, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padTop:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    invoke-virtual {v6}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;

    move-result-object v8

    invoke-direct {v1, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padParams(Landroid/os/IBinder;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v8

    invoke-interface {v0, v7, v8}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 412
    iget-object v0, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelWm:Landroid/view/WindowManager;

    iget-object v7, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padRight:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    invoke-virtual {v6}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;

    move-result-object v6

    invoke-direct {v1, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padParams(Landroid/os/IBinder;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v6

    invoke-interface {v0, v7, v6}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 413
    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->layoutPads()V

    .line 414
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v3, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeRightPx:I

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, " top="

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v3, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->holeTopPx:I

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_bc
    .catchall {:try_start_a .. :try_end_bc} :catchall_be

    const/4 v0, 0x1

    return v0

    :catchall_be
    move-exception v0

    const-string v3, "single window unavailable, using dialogs"

    .line 417
    invoke-static {v2, v3, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 419
    :try_start_c4
    iget-object v0, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelRoot:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;

    if-eqz v0, :cond_cd

    iget-object v2, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelWm:Landroid/view/WindowManager;

    invoke-interface {v2, v0}, Landroid/view/WindowManager;->removeViewImmediate(Landroid/view/View;)V
    :try_end_cd
    .catch Ljava/lang/Exception; {:try_start_c4 .. :try_end_cd} :catch_cd

    .line 422
    :catch_cd
    :cond_cd
    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->removePads()V

    .line 423
    iput-object v4, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelRoot:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$PanelRoot;

    .line 424
    iput-object v4, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rootHost:Landroid/widget/FrameLayout;

    return v5
.end method

.method private static openWhenReady(II)V
    .registers 6

    :try_start_0
    const-string v0, "com.epicgames.ue4.GameActivity"

    .line 159
    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const-string v1, "Get"

    const/4 v2, 0x0

    new-array v3, v2, [Ljava/lang/Class;

    invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    new-array v1, v2, [Ljava/lang/Object;

    const/4 v2, 0x0

    invoke-virtual {v0, v2, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    .line 160
    instance-of v1, v0, Landroid/app/Activity;

    if-nez v1, :cond_1b

    return-void

    .line 161
    :cond_1b
    check-cast v0, Landroid/app/Activity;

    .line 162
    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v1

    if-nez v1, :cond_76

    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v1

    if-eqz v1, :cond_2a

    goto :goto_76

    .line 163
    :cond_2a
    sget-object v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->current:Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    if-eqz v1, :cond_42

    .line 164
    iget-boolean v2, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->closed:Z

    if-nez v2, :cond_42

    iget-object v2, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    if-ne v2, v0, :cond_42

    .line 165
    iput p0, v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->eventId:I

    .line 166
    invoke-direct {v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->refresh()V

    return-void

    .line 170
    :cond_42
    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->isAttachedToWindow()Z

    move-result v1

    if-nez v1, :cond_61

    const/16 v0, 0x28

    if-ge p1, v0, :cond_60

    .line 171
    sget-object v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->MAIN:Landroid/os/Handler;

    new-instance v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda23;

    invoke-direct {v1, p0, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda23;-><init>(II)V

    const-wide/16 p0, 0x28

    invoke-virtual {v0, v1, p0, p1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_60
    return-void

    :cond_61
    const-string p1, "opening windows"

    .line 174
    invoke-static {p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->logPhase(Ljava/lang/String;)V

    .line 175
    new-instance p1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    invoke-direct {p1, v0, p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;-><init>(Landroid/app/Activity;I)V

    .line 176
    new-instance p0, Ljava/lang/ref/WeakReference;

    invoke-direct {p0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    sput-object p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->current:Ljava/lang/ref/WeakReference;

    .line 177
    invoke-direct {p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->refresh()V
    :try_end_75
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_75} :catch_77

    goto :goto_7f

    :cond_76
    :goto_76
    return-void

    :catch_77
    move-exception p0

    const-string p1, "E112_CUP_UI"

    const-string v0, "open failed"

    .line 179
    invoke-static {p1, v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_7f
    return-void
.end method

.method private padParams(Landroid/os/IBinder;)Landroid/view/WindowManager$LayoutParams;
    .registers 9

    .line 547
    new-instance v6, Landroid/view/WindowManager$LayoutParams;

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/16 v3, 0x3e8

    const v4, 0x40028

    const/4 v5, -0x3

    move-object v0, v6

    invoke-direct/range {v0 .. v5}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    .line 551
    iput-object p1, v6, Landroid/view/WindowManager$LayoutParams;->token:Landroid/os/IBinder;

    const p1, 0x800033

    .line 552
    iput p1, v6, Landroid/view/WindowManager$LayoutParams;->gravity:I

    const/4 p1, 0x0

    .line 553
    iput p1, v6, Landroid/view/WindowManager$LayoutParams;->windowAnimations:I

    const/4 p1, 0x3

    .line 554
    iput p1, v6, Landroid/view/WindowManager$LayoutParams;->layoutInDisplayCutoutMode:I

    return-object v6
.end method

.method private pillButton(Ljava/lang/String;Z)Landroid/widget/TextView;
    .registers 6

    const/4 v0, -0x1

    const/4 v1, 0x1

    const/16 v2, 0xf

    .line 919
    invoke-direct {p0, p1, v2, v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p1

    const/16 v0, 0x11

    .line 920
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v0, 0x15

    if-eqz p2, :cond_2d

    const p2, -0xa57f01

    const v1, -0xc03d86

    .line 922
    invoke-direct {p0, p2, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result p2

    const v1, -0xf5d020

    const v2, -0xf085bb

    invoke-direct {p0, v1, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v1

    const v2, -0x55000001

    invoke-direct {p0, p2, v1, v0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p2

    goto :goto_37

    :cond_2d
    const p2, 0x18ffffff

    const v1, 0x44ffffff    # 2047.9999f

    .line 923
    invoke-direct {p0, v1, p2, v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p2

    .line 921
    :goto_37
    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-object p1
.end method

.method private plateCrest(ILjava/lang/String;I)Landroid/view/View;
    .registers 8

    .line 756
    new-instance v0, Landroid/widget/FrameLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 757
    new-instance v1, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v2, 0x1

    .line 758
    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    const v2, 0x14ffffff

    .line 759
    invoke-virtual {v1, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 760
    invoke-virtual {v0, v1}, Landroid/widget/FrameLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    add-int/lit8 v1, p3, -0x8

    const/16 v2, 0xc

    .line 761
    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 762
    invoke-direct {p0, p1, p2, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->crestView(ILjava/lang/String;I)Landroid/view/View;

    move-result-object p1

    .line 763
    new-instance p2, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    const/16 v3, 0x11

    invoke-direct {p2, v2, v1, v3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V

    .line 764
    invoke-virtual {v0, p1, p2}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 765
    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, p3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result p2

    invoke-direct {p0, p3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result p3

    invoke-direct {p1, p2, p3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, p1}, Landroid/widget/FrameLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private put(Landroid/widget/FrameLayout;Landroid/view/View;IIII)V
    .registers 8

    .line 1210
    new-instance v0, Landroid/widget/FrameLayout$LayoutParams;

    invoke-direct {v0, p5, p6}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const p5, 0x800033

    .line 1211
    iput p5, v0, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 1212
    iput p3, v0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 1213
    iput p4, v0, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    .line 1214
    invoke-virtual {p1, p2, v0}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private refresh()V
    .registers 8

    .line 936
    iget-boolean v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->closed:Z

    if-nez v0, :cond_4e

    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_4e

    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v0

    if-eqz v0, :cond_15

    goto :goto_4e

    .line 937
    :cond_15
    iget-wide v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->refreshGeneration:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->refreshGeneration:J

    .line 938
    iget-object v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    if-nez v2, :cond_3a

    .line 939
    iget-object v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->content:Landroid/widget/LinearLayout;

    invoke-virtual {v2}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 940
    iget-object v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->content:Landroid/widget/LinearLayout;

    const-string v3, "\u6b63\u5728\u8bfb\u53d6\u8d5b\u4e8b\u8fdb\u5ea6\u2026"

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const v4, -0x564b2a

    const/4 v5, 0x0

    const/16 v6, 0xf

    invoke-direct {p0, v3, v6, v4, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 942
    :cond_3a
    sget-object v2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->prefetch:Ljava/util/concurrent/FutureTask;

    const/4 v3, 0x0

    .line 943
    sput-object v3, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->prefetch:Ljava/util/concurrent/FutureTask;

    .line 944
    new-instance v3, Ljava/lang/Thread;

    new-instance v4, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda7;

    invoke-direct {v4, p0, v2, v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda7;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Ljava/util/concurrent/FutureTask;J)V

    const-string v0, "e112-cup-ui"

    invoke-direct {v3, v4, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 975
    invoke-virtual {v3}, Ljava/lang/Thread;->start()V

    :cond_4e
    :goto_4e
    return-void
.end method

.method private removePads()V
    .registers 6

    const/4 v0, 0x2

    new-array v1, v0, [Landroid/view/View;

    .line 586
    iget-object v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padTop:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    const/4 v3, 0x0

    aput-object v2, v1, v3

    const/4 v2, 0x1

    iget-object v4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padRight:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    aput-object v4, v1, v2

    :goto_d
    if-ge v3, v0, :cond_1c

    aget-object v2, v1, v3

    if-nez v2, :cond_14

    goto :goto_19

    .line 589
    :cond_14
    :try_start_14
    iget-object v4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->panelWm:Landroid/view/WindowManager;

    invoke-interface {v4, v2}, Landroid/view/WindowManager;->removeViewImmediate(Landroid/view/View;)V
    :try_end_19
    .catch Ljava/lang/Exception; {:try_start_14 .. :try_end_19} :catch_19

    :catch_19
    :goto_19
    add-int/lit8 v3, v3, 0x1

    goto :goto_d

    :cond_1c
    const/4 v0, 0x0

    .line 593
    iput-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padTop:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    .line 594
    iput-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->padRight:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$InputPad;

    return-void
.end method

.method private render()V
    .registers 18

    move-object/from16 v7, p0

    .line 979
    iget-boolean v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->closed:Z

    if-nez v0, :cond_25b

    iget-object v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v0

    if-nez v0, :cond_25b

    iget-object v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    if-nez v0, :cond_14

    goto/16 :goto_25b

    .line 980
    :cond_14
    iget-object v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->content:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 981
    iget-object v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->tabs:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 982
    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->leaveScene()V

    .line 983
    iget-object v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v1, "entered"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, -0x1

    const/4 v2, 0x0

    if-nez v0, :cond_3f

    .line 984
    iget-object v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->content:Landroid/widget/LinearLayout;

    const-string v3, "\u5c1a\u672a\u5efa\u7acb\u672c\u5c4a\u8d5b\u4e8b\uff0c\u8bf7\u8fd4\u56de\u540e\u91cd\u65b0\u8fdb\u5165\u3002"

    invoke-direct {v7, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x10

    invoke-direct {v7, v3, v4, v1, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-void

    .line 987
    :cond_3f
    iget-object v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v3, "groups"

    invoke-virtual {v0, v3}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    const-string v0, "isOwn"

    if-eqz v3, :cond_63

    move v4, v2

    move v5, v4

    .line 990
    :goto_4d
    invoke-virtual {v3}, Lorg/json/JSONArray;->length()I

    move-result v6

    if-ge v4, v6, :cond_64

    .line 991
    invoke-virtual {v3, v4}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v6

    if-eqz v6, :cond_60

    .line 992
    invoke-virtual {v6, v0}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_60

    move v5, v4

    :cond_60
    add-int/lit8 v4, v4, 0x1

    goto :goto_4d

    :cond_63
    move v5, v2

    .line 995
    :cond_64
    iget v4, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->selectedGroup:I

    if-gez v4, :cond_6a

    iput v5, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->selectedGroup:I

    .line 996
    :cond_6a
    iget-object v4, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v6, "standings"

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    .line 997
    iget-object v8, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v9, "matchdays"

    invoke-virtual {v8, v9}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v8

    .line 998
    iget-object v10, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v11, "group"

    const-string v12, "A"

    invoke-virtual {v10, v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    if-eqz v3, :cond_a8

    .line 999
    iget v13, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->selectedGroup:I

    invoke-virtual {v3}, Lorg/json/JSONArray;->length()I

    move-result v14

    if-ge v13, v14, :cond_a8

    .line 1000
    iget v13, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->selectedGroup:I

    invoke-virtual {v3, v13}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v13

    if-eqz v13, :cond_a8

    .line 1002
    invoke-virtual {v13, v6}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    .line 1003
    invoke-virtual {v13, v9}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v14

    if-eqz v14, :cond_a4

    invoke-virtual {v13, v9}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v8

    .line 1004
    :cond_a4
    invoke-virtual {v13, v11, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    .line 1007
    :cond_a8
    iget-object v13, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v14, "knockout"

    invoke-virtual {v13, v14}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v13

    if-nez v13, :cond_b4

    .line 1008
    iput-boolean v2, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->showKnockout:Z

    :cond_b4
    if-eqz v13, :cond_fb

    .line 1010
    iget-object v1, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->tabs:Landroid/widget/LinearLayout;

    const-string v2, "\u5c0f\u7ec4\u8d5b"

    invoke-direct {v7, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iget-boolean v15, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->showKnockout:Z

    move-object/from16 v16, v14

    const/4 v14, 0x1

    xor-int/2addr v15, v14

    const/4 v14, 0x0

    invoke-direct {v7, v2, v15, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->modeChip(Ljava/lang/String;ZZ)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1011
    iget-object v1, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->tabs:Landroid/widget/LinearLayout;

    const-string v2, "\u6dd8\u6c70\u8d5b"

    invoke-direct {v7, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iget-boolean v14, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->showKnockout:Z

    const/4 v15, 0x1

    invoke-direct {v7, v2, v14, v15}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->modeChip(Ljava/lang/String;ZZ)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1012
    new-instance v1, Landroid/view/View;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 1013
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v14, 0xe

    invoke-direct {v7, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v14

    invoke-direct {v2, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1014
    iget-object v2, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->tabs:Landroid/widget/LinearLayout;

    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    goto :goto_fd

    :cond_fb
    move-object/from16 v16, v14

    .line 1016
    :goto_fd
    iget-boolean v1, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->showKnockout:Z

    if-eqz v1, :cond_143

    .line 1017
    iget-object v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->subtitle:Landroid/widget/TextView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\u6b27\u51a0\u6dd8\u6c70\u8d5b \u00b7 "

    invoke-direct {v7, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "round"

    const-string v3, "R16"

    invoke-virtual {v13, v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1018
    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->celebrationDue()Z

    move-result v0

    if-eqz v0, :cond_135

    .line 1019
    iget-object v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const-string v1, "celebration"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    invoke-direct {v7, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->enterCelebration(Lorg/json/JSONObject;)V

    return-void

    .line 1022
    :cond_135
    iget-boolean v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v0, :cond_13d

    .line 1023
    invoke-direct {v7, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->enterKnockoutScene(Lorg/json/JSONObject;)V

    return-void

    .line 1026
    :cond_13d
    iget-object v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->content:Landroid/widget/LinearLayout;

    invoke-direct {v7, v0, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->renderKnockout(Landroid/widget/LinearLayout;Lorg/json/JSONObject;)V

    return-void

    .line 1029
    :cond_143
    iget-object v1, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->subtitle:Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, "\u6b27\u51a0\u5c0f\u7ec4\u8d5b \u00b7 \u6211\u7684\u5c0f\u7ec4 "

    invoke-direct {v7, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v14, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    invoke-virtual {v14, v11, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v2, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1030
    iget-boolean v1, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v1, :cond_176

    if-eqz v13, :cond_16b

    const/4 v6, 0x1

    goto :goto_16c

    :cond_16b
    const/4 v6, 0x0

    :goto_16c
    move-object/from16 v0, p0

    move-object v1, v3

    move-object v2, v4

    move-object v3, v8

    move-object v4, v10

    .line 1031
    invoke-direct/range {v0 .. v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->enterScene(Lorg/json/JSONArray;Lorg/json/JSONArray;Lorg/json/JSONArray;Ljava/lang/String;IZ)V

    return-void

    :cond_176
    if-eqz v3, :cond_1a1

    const/4 v14, 0x0

    .line 1035
    :goto_179
    invoke-virtual {v3}, Lorg/json/JSONArray;->length()I

    move-result v1

    if-ge v14, v1, :cond_1a1

    .line 1036
    invoke-virtual {v3, v14}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v1

    if-nez v1, :cond_186

    goto :goto_19e

    .line 1038
    :cond_186
    iget-object v2, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->tabs:Landroid/widget/LinearLayout;

    invoke-virtual {v1, v11}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    iget v13, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->selectedGroup:I

    if-ne v14, v13, :cond_192

    const/4 v13, 0x1

    goto :goto_193

    :cond_192
    const/4 v13, 0x0

    :goto_193
    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v1

    invoke-direct {v7, v12, v13, v1, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->groupTab(Ljava/lang/String;ZZI)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :goto_19e
    add-int/lit8 v14, v14, 0x1

    goto :goto_179

    .line 1042
    :cond_1a1
    iget v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->selectedGroup:I

    if-ne v0, v5, :cond_1a7

    const/4 v0, 0x1

    goto :goto_1a8

    :cond_1a7
    const/4 v0, 0x0

    :goto_1a8
    invoke-direct {v7, v4, v10, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->standingsCard(Lorg/json/JSONArray;Ljava/lang/String;Z)Landroid/widget/LinearLayout;

    move-result-object v0

    .line 1043
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x1

    .line 1044
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1045
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x2

    const/4 v4, -0x1

    invoke-direct {v2, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1046
    iget-object v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    invoke-virtual {v0, v9}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    iget-object v2, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    invoke-virtual {v2, v6}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v2

    invoke-direct {v7, v0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->myRunCard(Lorg/json/JSONArray;Lorg/json/JSONArray;)Landroid/view/View;

    move-result-object v0

    invoke-direct {v7, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->spaced(Landroid/view/View;)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1047
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v0, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x1

    .line 1048
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1049
    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->nextCard()Landroid/view/View;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1050
    iget-object v2, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    move-object/from16 v4, v16

    invoke-virtual {v2, v4}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    if-eqz v2, :cond_203

    .line 1051
    invoke-direct {v7, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->knockoutCard(Lorg/json/JSONObject;)Landroid/view/View;

    move-result-object v2

    invoke-direct {v7, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->spaced(Landroid/view/View;)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1052
    :cond_203
    invoke-direct {v7, v8, v10}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->fixturesCard(Lorg/json/JSONArray;Ljava/lang/String;)Landroid/view/View;

    move-result-object v2

    invoke-direct {v7, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->spaced(Landroid/view/View;)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1054
    iget-boolean v2, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v2, :cond_247

    .line 1055
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v4

    invoke-direct {v2, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x0

    .line 1056
    invoke-virtual {v2, v4}, Landroid/widget/LinearLayout;->setBaselineAligned(Z)V

    .line 1057
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v6, 0x41300000    # 11.0f

    invoke-direct {v5, v4, v3, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v2, v1, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1058
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x41100000    # 9.0f

    invoke-direct {v1, v4, v3, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/16 v4, 0xc

    .line 1059
    invoke-direct {v7, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    iput v4, v1, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 1060
    invoke-virtual {v2, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1061
    iget-object v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->content:Landroid/widget/LinearLayout;

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x1

    invoke-direct {v1, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_25b

    :cond_247
    const/4 v4, -0x1

    .line 1063
    iget-object v2, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->content:Landroid/widget/LinearLayout;

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v5, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v1, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1064
    iget-object v1, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->content:Landroid/widget/LinearLayout;

    invoke-direct {v7, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->spaced(Landroid/view/View;)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :cond_25b
    :goto_25b
    return-void
.end method

.method private renderError()V
    .registers 7

    .line 2440
    iget-boolean v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->closed:Z

    if-nez v0, :cond_63

    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->isDestroyed()Z

    move-result v0

    if-eqz v0, :cond_d

    goto :goto_63

    .line 2441
    :cond_d
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->content:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 2442
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->card()Landroid/widget/LinearLayout;

    move-result-object v0

    const-string v1, "\u8d5b\u4e8b\u6570\u636e\u6682\u65f6\u4e0d\u53ef\u7528\u3002"

    .line 2443
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x10

    const/4 v3, -0x1

    const/4 v4, 0x1

    invoke-direct {p0, v1, v2, v3, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v5, 0x24

    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {v2, v3, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v1, "\u91cd\u8bd5"

    .line 2444
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p0, v1, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->pillButton(Ljava/lang/String;Z)Landroid/widget/TextView;

    move-result-object v1

    .line 2445
    new-instance v2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda13;

    invoke-direct {v2, p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda13;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2446
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v4, 0x8c

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    const/16 v5, 0x2a

    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {v2, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2447
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->content:Landroid/widget/LinearLayout;

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x2

    invoke-direct {v2, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_63
    :goto_63
    return-void
.end method

.method private renderKnockout(Landroid/widget/LinearLayout;Lorg/json/JSONObject;)V
    .registers 18

    move-object v7, p0

    move-object/from16 v8, p1

    move-object/from16 v0, p2

    .line 2039
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v2, 0x10

    .line 2040
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 2041
    iget-boolean v2, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    const/4 v3, 0x1

    xor-int/2addr v2, v3

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2042
    invoke-direct {p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->knockoutBanner(Lorg/json/JSONObject;)Landroid/view/View;

    move-result-object v2

    iget-boolean v4, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    const/4 v9, 0x0

    const/4 v10, -0x2

    const/4 v11, -0x1

    if-eqz v4, :cond_2d

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-direct {v4, v9, v11, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    goto :goto_32

    .line 2043
    :cond_2d
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v4, v11, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2042
    :goto_32
    invoke-virtual {v1, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2044
    invoke-direct {p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->roundStepper(Lorg/json/JSONObject;)Landroid/view/View;

    move-result-object v2

    .line 2045
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    iget-boolean v5, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v5, :cond_41

    move v6, v10

    goto :goto_42

    :cond_41
    move v6, v11

    :goto_42
    if-eqz v5, :cond_46

    move v5, v10

    goto :goto_4c

    :cond_46
    const/16 v5, 0x28

    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    :goto_4c
    invoke-direct {v4, v6, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2046
    iget-boolean v5, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    const/16 v6, 0xe

    if-eqz v5, :cond_5b

    invoke-direct {p0, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    iput v5, v4, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 2047
    :cond_5b
    invoke-virtual {v1, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2048
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    iget-boolean v4, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    const/16 v5, 0x2c

    if-eqz v4, :cond_6b

    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    goto :goto_6c

    :cond_6b
    move v4, v10

    :goto_6c
    invoke-direct {v2, v11, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v1, "rounds"

    .line 2049
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    if-eqz v4, :cond_146

    .line 2050
    invoke-virtual {v4}, Lorg/json/JSONArray;->length()I

    move-result v1

    const/4 v2, 0x4

    if-ge v1, v2, :cond_83

    goto/16 :goto_146

    :cond_83
    const-string v1, "champion"

    const-string v12, ""

    .line 2051
    invoke-virtual {v0, v1, v12}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    xor-int/lit8 v12, v0, 0x1

    .line 2052
    iget-boolean v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v0, :cond_98

    const/16 v0, 0x38

    goto :goto_9a

    :cond_98
    const/16 v0, 0x36

    :goto_9a
    invoke-direct {p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v0

    const/16 v1, 0x18

    .line 2054
    iput v1, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->bracketCrestDp:I

    .line 2055
    iget-boolean v13, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v13, :cond_f2

    iget v13, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->knockoutAvailPx:I

    if-lez v13, :cond_f2

    .line 2057
    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    sub-int/2addr v13, v5

    const/16 v5, 0xa

    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    sub-int/2addr v13, v5

    const/16 v5, 0x16

    .line 2058
    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    sub-int v5, v13, v5

    const/4 v14, 0x6

    invoke-direct {p0, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v14

    sub-int/2addr v5, v14

    int-to-float v5, v5

    const/high16 v14, 0x41000000    # 8.0f

    div-float/2addr v5, v14

    .line 2059
    invoke-static {v5}, Ljava/lang/Math;->round(F)I

    move-result v5

    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    sub-int/2addr v5, v2

    invoke-static {v0, v5}, Ljava/lang/Math;->min(II)I

    move-result v0

    int-to-float v2, v0

    .line 2060
    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v3

    int-to-float v3, v3

    div-float/2addr v2, v3

    const/high16 v3, 0x40000000    # 2.0f

    div-float/2addr v2, v3

    .line 2061
    invoke-static {v2}, Ljava/lang/Math;->round(F)I

    move-result v2

    add-int/lit8 v2, v2, -0x3

    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v6, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->bracketCrestDp:I

    move v5, v0

    move v6, v13

    goto :goto_f4

    :cond_f2
    move v5, v0

    move v6, v9

    .line 2063
    :goto_f4
    new-instance v13, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v2

    move-object v0, v13

    move-object v1, p0

    move-object v3, v4

    move v4, v12

    invoke-direct/range {v0 .. v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Landroid/content/Context;Lorg/json/JSONArray;ZII)V

    .line 2064
    iget-boolean v0, v7, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    const/16 v1, 0x8

    if-eqz v0, :cond_11a

    .line 2065
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-virtual {v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->totalHeight()I

    move-result v2

    invoke-direct {v0, v11, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2066
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 2067
    invoke-virtual {v8, v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_146

    .line 2069
    :cond_11a
    new-instance v0, Landroid/widget/HorizontalScrollView;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v0, v2}, Landroid/widget/HorizontalScrollView;-><init>(Landroid/content/Context;)V

    .line 2070
    invoke-virtual {v0, v9}, Landroid/widget/HorizontalScrollView;->setHorizontalScrollBarEnabled(Z)V

    .line 2071
    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v3, 0x2f8

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v3

    invoke-virtual {v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$BracketBoard;->totalHeight()I

    move-result v4

    invoke-direct {v2, v3, v4}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v13, v2}, Landroid/widget/HorizontalScrollView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2072
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v11, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2073
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    iput v1, v2, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 2074
    invoke-virtual {v8, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_146
    :goto_146
    return-void
.end method

.method private resetButton()Landroid/widget/TextView;
    .registers 6

    const-string v0, "\u91cd\u7f6e\u8d5b\u4e8b"

    .line 1343
    invoke-direct {p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, -0x1

    const/4 v2, 0x1

    const/16 v3, 0xd

    invoke-direct {p0, v0, v3, v1, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v0

    const/16 v1, 0x11

    .line 1344
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v1, 0x10

    .line 1345
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    const/4 v3, 0x0

    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    invoke-virtual {v0, v2, v3, v4, v3}, Landroid/widget/TextView;->setPadding(IIII)V

    const v2, 0x44ffffff    # 2047.9999f

    const v3, 0x18ffffff

    .line 1346
    invoke-direct {p0, v2, v3, v1, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1347
    new-instance v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda15;

    invoke-direct {v1, p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda15;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Landroid/widget/TextView;)V

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object v0
.end method

.method private resetCup()V
    .registers 6

    .line 1372
    iget-boolean v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->closed:Z

    if-eqz v0, :cond_5

    return-void

    .line 1373
    :cond_5
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->content:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 1374
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->content:Landroid/widget/LinearLayout;

    const-string v1, "\u6b63\u5728\u91cd\u7f6e\u8d5b\u4e8b\u2026"

    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const v2, -0x564b2a

    const/4 v3, 0x0

    const/16 v4, 0xf

    invoke-direct {p0, v1, v4, v2, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1375
    iget v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->eventId:I

    .line 1376
    new-instance v1, Ljava/lang/Thread;

    new-instance v2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda1;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;I)V

    const-string v0, "e112-cup-reset"

    invoke-direct {v1, v2, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 1388
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method private roadCard(Lorg/json/JSONArray;Lorg/json/JSONArray;)Landroid/view/View;
    .registers 16

    const-string v0, "isPlayer"

    const/4 v1, 0x0

    if-eqz p2, :cond_22

    move v2, v1

    move v3, v2

    .line 1395
    :goto_7
    invoke-virtual {p2}, Lorg/json/JSONArray;->length()I

    move-result v4

    if-ge v2, v4, :cond_23

    .line 1396
    invoke-virtual {p2, v2}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    if-eqz v4, :cond_1f

    .line 1397
    invoke-virtual {v4, v0}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_1f

    const-string v3, "teamId"

    invoke-virtual {v4, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v3

    :cond_1f
    add-int/lit8 v2, v2, 0x1

    goto :goto_7

    :cond_22
    move v3, v1

    .line 1400
    :cond_23
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->card()Landroid/widget/LinearLayout;

    move-result-object p2

    const/16 v2, 0xe

    .line 1401
    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    const/4 v5, 0x6

    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v6

    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-virtual {p2, v4, v6, v2, v5}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const v2, -0xc5a301

    const v4, -0xe070ab

    .line 1402
    invoke-direct {p0, v2, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v2

    const v4, -0xf5e071

    const v5, -0xf4c2de

    invoke-direct {p0, v4, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v4

    const v5, -0x55604701

    const v6, -0x55601740

    invoke-direct {p0, v5, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v5

    const/16 v6, 0x10

    invoke-direct {p0, v2, v4, v6, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {p2, v2}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const-string v2, "\u5c0f\u7ec4\u8d5b\u4e4b\u8def"

    .line 1403
    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/16 v4, 0xf

    const/4 v5, -0x1

    const/4 v6, 0x1

    invoke-direct {p0, v2, v4, v5, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v2

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v7, 0x16

    invoke-direct {p0, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    invoke-direct {v4, v5, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p2, v2, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1404
    new-instance v2, Landroid/widget/LinearLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v4

    invoke-direct {v2, v4}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1405
    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->setBaselineAligned(Z)V

    if-eqz p1, :cond_dc

    move v4, v1

    .line 1407
    :goto_8f
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v7

    if-ge v4, v7, :cond_dc

    .line 1408
    invoke-virtual {p1, v4}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v7

    const/4 v8, 0x0

    if-nez v7, :cond_9e

    move-object v9, v8

    goto :goto_a4

    :cond_9e
    const-string v9, "fixtures"

    .line 1409
    invoke-virtual {v7, v9}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v9

    :goto_a4
    if-eqz v9, :cond_bd

    move v10, v1

    .line 1412
    :goto_a7
    invoke-virtual {v9}, Lorg/json/JSONArray;->length()I

    move-result v11

    if-ge v10, v11, :cond_bd

    .line 1413
    invoke-virtual {v9, v10}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v11

    if-eqz v11, :cond_ba

    .line 1414
    invoke-virtual {v11, v0}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_ba

    move-object v8, v11

    :cond_ba
    add-int/lit8 v10, v10, 0x1

    goto :goto_a7

    :cond_bd
    if-eqz v8, :cond_d9

    const-string v9, "round"

    .line 1417
    invoke-virtual {v7, v9}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v7

    invoke-direct {p0, v7, v8, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->roadTile(ILorg/json/JSONObject;I)Landroid/view/View;

    move-result-object v7

    invoke-virtual {v2}, Landroid/widget/LinearLayout;->getChildCount()I

    move-result v8

    if-lez v8, :cond_d1

    move v8, v6

    goto :goto_d2

    :cond_d1
    move v8, v1

    :goto_d2
    invoke-direct {p0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->tileParams(Z)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v8

    invoke-virtual {v2, v7, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_d9
    add-int/lit8 v4, v4, 0x1

    goto :goto_8f

    .line 1420
    :cond_dc
    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v0, -0x2

    invoke-direct {p1, v5, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p2, v2, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object p2
.end method

.method private roadTile(ILorg/json/JSONObject;I)Landroid/view/View;
    .registers 15

    const-string v0, "homeTeamId"

    .line 1425
    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ne v0, p3, :cond_c

    move p3, v1

    goto :goto_d

    :cond_c
    move p3, v2

    :goto_d
    if-eqz p3, :cond_12

    const-string v0, "away"

    goto :goto_14

    :cond_12
    const-string v0, "home"

    :goto_14
    const-string v3, "played"

    .line 1427
    invoke-virtual {p2, v3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v3

    const-string v4, "homeScore"

    const-string v5, "awayScore"

    if-eqz v3, :cond_2a

    if-eqz p3, :cond_24

    move-object v6, v4

    goto :goto_25

    :cond_24
    move-object v6, v5

    .line 1428
    :goto_25
    invoke-virtual {p2, v6}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v6

    goto :goto_2b

    :cond_2a
    move v6, v2

    :goto_2b
    if-eqz v3, :cond_35

    if-eqz p3, :cond_30

    move-object v4, v5

    .line 1429
    :cond_30
    invoke-virtual {p2, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result p3

    goto :goto_36

    :cond_35
    move p3, v2

    .line 1430
    :goto_36
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v5

    invoke-direct {v4, v5}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v5, 0x10

    .line 1431
    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/4 v5, 0x6

    .line 1432
    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    const/4 v8, 0x4

    invoke-direct {p0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v9

    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v10

    invoke-direct {p0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v8

    invoke-virtual {v4, v7, v9, v10, v8}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const v7, 0xcffffff

    const v8, 0x33ffffff

    const/16 v9, 0xc

    .line 1433
    invoke-direct {p0, v8, v7, v9, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v7

    invoke-virtual {v4, v7}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const-string v7, "TeamId"

    .line 1434
    invoke-virtual {v0, v7}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p2, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v7

    const-string v8, "Team"

    invoke-virtual {v0, v8}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/16 v0, 0x26

    invoke-direct {p0, v7, p2, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->plateCrest(ILjava/lang/String;I)Landroid/view/View;

    move-result-object p2

    invoke-virtual {v4, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1435
    new-instance p2, Landroid/widget/LinearLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p2, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1436
    invoke-virtual {p2, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1437
    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v0

    invoke-virtual {p2, v0, v2, v2, v2}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 1438
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\u6bd4\u8d5b\u65e5 "

    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const v0, -0x564b2a

    const/16 v2, 0xa

    invoke-direct {p0, p1, v2, v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p1

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v5, 0xe

    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    const/4 v7, -0x1

    invoke-direct {v0, v7, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p2, p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-nez v3, :cond_d4

    const-string p1, "\u5f85\u8d5b"

    .line 1442
    invoke-direct {p0, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const p3, 0x55ffffff    # 3.518437E13f

    const v0, 0x22ffffff

    goto :goto_13f

    :cond_d4
    const-string p1, "-"

    if-le v6, p3, :cond_fa

    .line 1446
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u80dc "

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const p3, -0xc20a60

    const v0, -0xec65a6

    goto :goto_13f

    :cond_fa
    if-ge v6, p3, :cond_11e

    .line 1450
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u8d1f "

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const p3, -0x907e

    const v0, -0x5ed7c4

    goto :goto_13f

    .line 1454
    :cond_11e
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u5e73 "

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const p3, -0x655938

    const v0, -0xa59b7a

    .line 1458
    :goto_13f
    invoke-direct {p0, p1, v9, v7, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p1

    const/16 v1, 0x11

    .line 1459
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setGravity(I)V

    const v1, 0x66ffffff

    .line 1460
    invoke-direct {p0, p3, v0, v2, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p3

    invoke-virtual {p1, p3}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1461
    new-instance p3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v0, 0x42

    invoke-direct {p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v0

    const/16 v1, 0x14

    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    invoke-direct {p3, v0, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {p2, p1, p3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1462
    invoke-virtual {v4, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-object v4
.end method

.method private roundStepper(Lorg/json/JSONObject;)Landroid/view/View;
    .registers 18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const-string v2, "phase"

    const-string v3, "R16"

    .line 2304
    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "champion"

    const-string v4, ""

    .line 2305
    invoke-virtual {v1, v3, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v3, :cond_27

    const-string v3, "CHAMPION"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_25

    goto :goto_27

    :cond_25
    move v2, v6

    goto :goto_28

    :cond_27
    :goto_27
    move v2, v5

    :goto_28
    const-string v3, "eliminated"

    .line 2306
    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v3

    const-string v7, "played"

    .line 2307
    invoke-virtual {v1, v7}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v1

    const/4 v7, 0x4

    invoke-static {v1, v7}, Ljava/lang/Math;->min(II)I

    move-result v1

    .line 2308
    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v9

    invoke-direct {v8, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v9, 0x11

    .line 2309
    invoke-virtual {v8, v9}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v10, 0x8

    .line 2310
    invoke-direct {v0, v10}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v10

    invoke-virtual {v8, v6, v10, v6, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    move v10, v6

    :goto_51
    if-ge v10, v7, :cond_139

    if-nez v2, :cond_5a

    if-ge v10, v1, :cond_58

    goto :goto_5a

    :cond_58
    move v11, v6

    goto :goto_5b

    :cond_5a
    :goto_5a
    move v11, v5

    :goto_5b
    if-nez v2, :cond_63

    if-nez v3, :cond_63

    if-ne v10, v1, :cond_63

    move v12, v5

    goto :goto_64

    :cond_63
    move v12, v6

    :goto_64
    if-eqz v3, :cond_6a

    if-ne v10, v1, :cond_6a

    move v13, v5

    goto :goto_6b

    :cond_6a
    move v13, v6

    .line 2315
    :goto_6b
    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    if-eqz v11, :cond_75

    const-string v15, "\u2713 "

    goto :goto_7b

    :cond_75
    if-eqz v13, :cond_7a

    const-string v15, "\u2715 "

    goto :goto_7b

    :cond_7a
    move-object v15, v4

    :goto_7b
    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v15, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ROUND_LABELS:[Ljava/lang/String;

    aget-object v15, v15, v10

    invoke-direct {v0, v15}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    if-nez v11, :cond_98

    if-nez v12, :cond_98

    if-eqz v13, :cond_94

    goto :goto_98

    :cond_94
    const v15, -0x564b2a

    goto :goto_99

    :cond_98
    :goto_98
    const/4 v15, -0x1

    :goto_99
    const/16 v6, 0xc

    .line 2316
    invoke-direct {v0, v14, v6, v15, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v6

    .line 2317
    invoke-virtual {v6, v9}, Landroid/widget/TextView;->setGravity(I)V

    const v14, 0x66ffffff

    const v15, -0xc20a60

    const/16 v5, 0xe

    if-eqz v11, :cond_b4

    const v12, -0xec65a6

    .line 2318
    invoke-direct {v0, v15, v12, v5, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    goto :goto_ec

    :cond_b4
    if-eqz v12, :cond_d2

    const v12, -0xa57f01

    const v13, -0xc03d86

    .line 2319
    invoke-direct {v0, v12, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v12

    const v13, -0xf5ca01

    const v14, -0xf085bb

    invoke-direct {v0, v13, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v13

    const v14, -0x55000001

    invoke-direct {v0, v12, v13, v5, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    goto :goto_ec

    :cond_d2
    if-eqz v13, :cond_df

    const v12, -0x907e

    const v13, -0x5ed7c4

    .line 2320
    invoke-direct {v0, v12, v13, v5, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    goto :goto_ec

    :cond_df
    const v12, 0xcffffff

    const v13, 0x22ffffff

    const v14, 0x33ffffff

    .line 2321
    invoke-direct {v0, v14, v12, v5, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    .line 2318
    :goto_ec
    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    if-eqz v11, :cond_f7

    const v5, -0xf9def1

    .line 2322
    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2323
    :cond_f7
    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v12, 0x60

    invoke-direct {v0, v12}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v12

    const/16 v13, 0x1c

    invoke-direct {v0, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v13

    invoke-direct {v5, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v6, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v5, 0x3

    if-ge v10, v5, :cond_133

    .line 2325
    new-instance v5, Landroid/view/View;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v6

    invoke-direct {v5, v6}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    if-eqz v11, :cond_11a

    goto :goto_11d

    :cond_11a
    const v15, 0x44ffffff    # 2047.9999f

    .line 2326
    :goto_11d
    invoke-virtual {v5, v15}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2327
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v11, 0x12

    invoke-direct {v0, v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v11

    const/4 v12, 0x2

    invoke-direct {v0, v12}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v12

    invoke-direct {v6, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v8, v5, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_133
    add-int/lit8 v10, v10, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    goto/16 :goto_51

    :cond_139
    return-object v8
.end method

.method private static roundWord(Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    const-string v0, "R16"

    .line 2028
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b

    const-string p0, "16\u5f3a"

    goto :goto_2b

    :cond_b
    const-string v0, "QF"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_16

    const-string p0, "8\u5f3a"

    goto :goto_2b

    :cond_16
    const-string v0, "SF"

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_21

    const-string p0, "\u534a\u51b3\u8d5b"

    goto :goto_2b

    :cond_21
    const-string v0, "FINAL"

    .line 2029
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2b

    const-string p0, "\u51b3\u8d5b"

    :cond_2b
    :goto_2b
    return-object p0
.end method

.method private rounded(II)Landroid/graphics/drawable/GradientDrawable;
    .registers 4

    .line 900
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 901
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 902
    invoke-direct {p0, p2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result p1

    int-to-float p1, p1

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    return-object v0
.end method

.method private runTile(ILorg/json/JSONObject;I)Landroid/view/View;
    .registers 16

    const-string v0, "homeTeamId"

    .line 1643
    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ne v0, p3, :cond_c

    move p3, v2

    goto :goto_d

    :cond_c
    move p3, v1

    :goto_d
    if-eqz p3, :cond_12

    const-string v0, "away"

    goto :goto_14

    :cond_12
    const-string v0, "home"

    :goto_14
    const-string v3, "played"

    .line 1645
    invoke-virtual {p2, v3}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v3

    const-string v4, "homeScore"

    const-string v5, "awayScore"

    if-eqz v3, :cond_2a

    if-eqz p3, :cond_24

    move-object v6, v4

    goto :goto_25

    :cond_24
    move-object v6, v5

    .line 1646
    :goto_25
    invoke-virtual {p2, v6}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v6

    goto :goto_2b

    :cond_2a
    move v6, v1

    :goto_2b
    if-eqz v3, :cond_35

    if-eqz p3, :cond_30

    move-object v4, v5

    .line 1647
    :cond_30
    invoke-virtual {p2, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result p3

    goto :goto_36

    :cond_35
    move p3, v1

    .line 1648
    :goto_36
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v5

    invoke-direct {v4, v5}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 1649
    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1650
    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/4 v5, 0x6

    .line 1651
    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    const/16 v8, 0x8

    invoke-direct {p0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v9

    invoke-direct {p0, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {p0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v8

    invoke-virtual {v4, v7, v9, v5, v8}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const v5, 0xcffffff

    const/16 v7, 0xe

    const v8, 0x33ffffff

    .line 1652
    invoke-direct {p0, v8, v5, v7, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1653
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "\u6bd4\u8d5b\u65e5 "

    invoke-direct {p0, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const v5, -0x564b2a

    const/16 v7, 0xb

    invoke-direct {p0, p1, v7, v5, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p1

    const/16 v5, 0x11

    .line 1654
    invoke-virtual {p1, v5}, Landroid/widget/TextView;->setGravity(I)V

    .line 1655
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v9, 0x10

    invoke-direct {p0, v9}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v9

    const/4 v10, -0x1

    invoke-direct {v8, v10, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, p1, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string p1, "TeamId"

    .line 1656
    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result p1

    const-string v8, "Team"

    invoke-virtual {v0, v8}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {p2, v9}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/16 v11, 0x28

    invoke-direct {p0, p1, v9, v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->plateCrest(ILjava/lang/String;I)Landroid/view/View;

    move-result-object p1

    .line 1657
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v9

    check-cast v9, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v11, 0x4

    .line 1658
    invoke-direct {p0, v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v11

    iput v11, v9, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 1659
    iput v2, v9, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 1660
    invoke-virtual {v4, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1661
    invoke-virtual {v0, v8}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/16 p2, 0xc

    invoke-direct {p0, p1, p2, v10, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p1

    .line 1662
    invoke-virtual {p1, v5}, Landroid/widget/TextView;->setGravity(I)V

    .line 1663
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v1, 0x16

    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    invoke-direct {v0, v10, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, p1, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    if-nez v3, :cond_f6

    const-string p1, "\u5f85\u8d5b"

    .line 1667
    invoke-direct {p0, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const p3, 0x55ffffff    # 3.518437E13f

    const v0, 0x22ffffff

    goto :goto_161

    :cond_f6
    const-string p1, "-"

    if-le v6, p3, :cond_11c

    .line 1671
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "\u80dc "

    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const p3, -0xc20a60

    const v0, -0xec65a6

    goto :goto_161

    :cond_11c
    if-ge v6, p3, :cond_140

    .line 1675
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "\u8d1f "

    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const p3, -0x907e

    const v0, -0x5ed7c4

    goto :goto_161

    .line 1679
    :cond_140
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "\u5e73 "

    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const p3, -0x655938

    const v0, -0xa59b7a

    .line 1683
    :goto_161
    invoke-direct {p0, p1, p2, v10, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p1

    .line 1684
    invoke-virtual {p1, v5}, Landroid/widget/TextView;->setGravity(I)V

    const p2, 0x66ffffff

    .line 1685
    invoke-direct {p0, p3, v0, v7, p2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1686
    new-instance p2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 p3, 0x54

    invoke-direct {p0, p3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result p3

    const/16 v0, 0x18

    invoke-direct {p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v0

    invoke-direct {p2, p3, v0}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 p3, 0x2

    .line 1687
    invoke-direct {p0, p3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result p3

    iput p3, p2, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 1688
    invoke-virtual {v4, p1, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v4
.end method

.method private s(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    .line 2013
    iget-boolean v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->english:Z

    if-nez v0, :cond_5

    return-object p1

    .line 2014
    :cond_5
    sget-object v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->EN:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_10

    goto :goto_11

    :cond_10
    move-object p1, v0

    :goto_11
    return-object p1
.end method

.method private sceneHeader()Landroid/widget/LinearLayout;
    .registers 2

    const-string v0, "\u5c0f\u7ec4\u6982\u51b5"

    .line 1258
    invoke-direct {p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->sceneHeader(Ljava/lang/String;)Landroid/widget/LinearLayout;

    move-result-object v0

    return-object v0
.end method

.method private sceneHeader(Ljava/lang/String;)Landroid/widget/LinearLayout;
    .registers 14

    .line 1262
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v1, 0x10

    .line 1263
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1264
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->matchTimeButton()Landroid/widget/TextView;

    move-result-object v2

    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v4, 0x20

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    const/4 v6, -0x2

    invoke-direct {v3, v6, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1265
    new-instance v2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$StarBadge;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v3

    invoke-direct {v2, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$StarBadge;-><init>(Landroid/content/Context;)V

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->badgeParams()Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v2, 0x1a

    const/16 v3, -0x1eb6

    const/4 v5, 0x1

    .line 1266
    invoke-direct {p0, p1, v2, v3, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p1

    .line 1267
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v2, v6, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v3, 0xa

    .line 1268
    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    iput v7, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 1269
    invoke-virtual {v0, p1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1270
    new-instance p1, Landroid/view/View;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v2

    invoke-direct {p1, v2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const v2, -0x2669e6

    const/4 v7, 0x2

    const/16 v8, -0x1676

    .line 1271
    invoke-direct {p0, v8, v2, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->vgrad(III)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {p1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1272
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v7, 0x4

    invoke-direct {p0, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    const/16 v8, 0x18

    invoke-direct {p0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v8

    invoke-direct {v2, v7, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v7, 0xc

    .line 1273
    invoke-direct {p0, v7}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    iput v7, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 1274
    invoke-virtual {v0, p1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1275
    new-instance p1, Landroid/view/View;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v2

    invoke-direct {p1, v2}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v7, 0x3f800000    # 1.0f

    const/4 v8, 0x0

    invoke-direct {v2, v8, v5, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, p1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1276
    iget-boolean p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->showKnockout:Z

    if-eqz p1, :cond_b5

    iget-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    if-eqz p1, :cond_b5

    const-string v2, "celebration"

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    if-eqz p1, :cond_b5

    .line 1277
    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    invoke-direct {p1, v6, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1278
    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    iput v2, p1, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 1279
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->celebrationReplayButton()Landroid/widget/TextView;

    move-result-object v2

    invoke-virtual {v0, v2, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    :cond_b5
    const-string p1, "\u5237\u65b0"

    .line 1281
    invoke-direct {p0, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/16 v2, 0xd

    const/4 v7, -0x1

    invoke-direct {p0, p1, v2, v7, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p1

    const/16 v2, 0x11

    .line 1282
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setGravity(I)V

    .line 1283
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v9

    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v10

    invoke-virtual {p1, v9, v8, v10, v8}, Landroid/widget/TextView;->setPadding(IIII)V

    const v8, 0x44ffffff    # 2047.9999f

    const v9, 0x18ffffff

    .line 1284
    invoke-direct {p0, v8, v9, v1, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v10

    invoke-virtual {p1, v10}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1285
    new-instance v10, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda4;

    invoke-direct {v10, p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda4;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V

    invoke-virtual {p1, v10}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1286
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v11

    invoke-direct {v10, v6, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, p1, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1287
    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    invoke-direct {p1, v6, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1288
    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    iput v4, p1, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 1289
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->resetButton()Landroid/widget/TextView;

    move-result-object v4

    invoke-virtual {v0, v4, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string p1, "\u2715"

    .line 1290
    invoke-direct {p0, p1, v1, v7, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p1

    .line 1291
    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setGravity(I)V

    const/16 v1, 0x12

    const v2, 0x55ffffff    # 3.518437E13f

    .line 1292
    invoke-direct {p0, v8, v9, v1, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1293
    new-instance v1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda5;

    invoke-direct {v1, p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda5;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1294
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v2, 0x24

    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    invoke-direct {v1, v4, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1295
    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 1296
    invoke-virtual {v0, p1, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private spaced(Landroid/view/View;)Landroid/view/View;
    .registers 6

    .line 1523
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 1524
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v1, 0xc

    .line 1525
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    const/4 v2, 0x0

    invoke-virtual {v0, v2, v1, v2, v2}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 1526
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x1

    const/4 v3, -0x2

    invoke-direct {v1, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, p1, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private standingsCard(Lorg/json/JSONArray;Ljava/lang/String;Z)Landroid/widget/LinearLayout;
    .registers 15

    .line 1545
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->card()Landroid/widget/LinearLayout;

    move-result-object p3

    .line 1546
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v1, 0x10

    .line 1547
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1548
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u5c0f\u7ec4 "

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, " \u79ef\u5206\u699c"

    invoke-direct {p0, p2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v2, -0x1

    const/4 v3, 0x1

    const/16 v4, 0x11

    invoke-direct {p0, p2, v4, v2, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p2

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x20

    .line 1549
    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    const/high16 v5, 0x3f800000    # 1.0f

    const/4 v6, 0x0

    invoke-direct {v2, v6, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 1548
    invoke-virtual {v0, p2, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1550
    iget-boolean p2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->roomyRows:Z

    if-eqz p2, :cond_c2

    const p2, -0xe8579e

    .line 1551
    invoke-direct {p0, p2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->legendDot(I)Landroid/view/View;

    move-result-object p2

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v4, 0xa

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    invoke-direct {v2, v5, v7}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, p2, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string p2, "\u664b\u7ea716\u5f3a\u6dd8\u6c70\u8d5b"

    .line 1552
    invoke-direct {p0, p2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/16 v2, 0xc

    const v5, -0x564b2a

    invoke-direct {p0, p2, v2, v5, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p2

    .line 1553
    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v8

    const/4 v9, -0x2

    invoke-direct {v7, v9, v8}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v8, 0x6

    .line 1554
    invoke-direct {p0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v10

    iput v10, v7, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 1555
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    iput v1, v7, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 1556
    invoke-virtual {v0, p2, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const p2, 0x66ffffff

    .line 1557
    invoke-direct {p0, p2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->legendDot(I)Landroid/view/View;

    move-result-object p2

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v7

    invoke-direct {p0, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    invoke-direct {v1, v7, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, p2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string p2, "\u5c0f\u7ec4\u6dd8\u6c70"

    .line 1558
    invoke-direct {p0, p2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p0, p2, v2, v5, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object p2

    .line 1559
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p0, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    invoke-direct {v1, v9, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1560
    invoke-direct {p0, v8}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 1561
    invoke-virtual {v0, p2, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1563
    :cond_c2
    invoke-virtual {p3, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1564
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->tableHeader()Landroid/view/View;

    move-result-object p2

    invoke-virtual {p3, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    if-eqz p1, :cond_e4

    .line 1566
    :goto_ce
    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result p2

    if-ge v6, p2, :cond_e4

    .line 1567
    invoke-virtual {p1, v6}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object p2

    if-eqz p2, :cond_e1

    .line 1568
    invoke-direct {p0, p2, v6}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->tableRow(Lorg/json/JSONObject;I)Landroid/view/View;

    move-result-object p2

    invoke-virtual {p3, p2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :cond_e1
    add-int/lit8 v6, v6, 0x1

    goto :goto_ce

    .line 1571
    :cond_e4
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->legend()Landroid/view/View;

    move-result-object p1

    invoke-virtual {p3, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    return-object p3
.end method

.method private striped(Landroid/graphics/drawable/Drawable;II)Landroid/graphics/drawable/Drawable;
    .registers 4

    return-object p1
.end method

.method private tableHeader()Landroid/view/View;
    .registers 13

    .line 1700
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v1, 0x10

    .line 1701
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v1, 0x8

    .line 1702
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    const/4 v3, 0x0

    invoke-virtual {v0, v2, v3, v1, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const-string v5, "#"

    const/16 v6, 0x22

    const v7, -0x564b2a

    const/4 v8, 0x1

    const/16 v9, 0xc

    move-object v4, p0

    .line 1703
    invoke-direct/range {v4 .. v9}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->cell(Ljava/lang/String;IIZI)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v1, "\u7403\u961f"

    .line 1704
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const v2, -0x564b2a

    const/4 v4, 0x1

    const/16 v5, 0xc

    invoke-direct {p0, v1, v5, v2, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v1

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v5, -0x1

    invoke-direct {v2, v3, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v1, "\u8d5b"

    .line 1705
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0x1e

    const v9, -0x564b2a

    const/4 v10, 0x1

    const/16 v11, 0xc

    move-object v6, p0

    invoke-direct/range {v6 .. v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->cell(Ljava/lang/String;IIZI)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1706
    iget-boolean v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v1, :cond_a2

    const-string v1, "\u80dc"

    .line 1707
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0x1e

    const v9, -0x564b2a

    const/4 v10, 0x1

    const/16 v11, 0xc

    move-object v6, p0

    invoke-direct/range {v6 .. v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->cell(Ljava/lang/String;IIZI)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v1, "\u5e73"

    .line 1708
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-direct/range {v6 .. v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->cell(Ljava/lang/String;IIZI)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v1, "\u8d1f"

    .line 1709
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-direct/range {v6 .. v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->cell(Ljava/lang/String;IIZI)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v1, "\u8fdb/\u5931"

    .line 1710
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0x3a

    invoke-direct/range {v6 .. v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->cell(Ljava/lang/String;IIZI)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :cond_a2
    const-string v1, "\u51c0"

    .line 1712
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0x26

    const v9, -0x564b2a

    const/4 v10, 0x1

    const/16 v11, 0xc

    move-object v6, p0

    invoke-direct/range {v6 .. v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->cell(Ljava/lang/String;IIZI)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v1, "\u5206"

    .line 1713
    invoke-direct {p0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0x2c

    invoke-direct/range {v6 .. v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->cell(Ljava/lang/String;IIZI)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1714
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v2, 0x1c

    invoke-direct {p0, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    invoke-direct {v1, v5, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method private tableRow(Lorg/json/JSONObject;I)Landroid/view/View;
    .registers 20

    move-object/from16 v6, p0

    move-object/from16 v7, p1

    const-string v0, "isPlayer"

    .line 1719
    invoke-virtual {v7, v0}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;)Z

    move-result v0

    .line 1720
    new-instance v8, Landroid/widget/LinearLayout;

    invoke-direct/range {p0 .. p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v8, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v1, 0x10

    .line 1721
    invoke-virtual {v8, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v2, 0x8

    .line 1722
    invoke-direct {v6, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v3

    invoke-direct {v6, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    const/4 v9, 0x0

    invoke-virtual {v8, v3, v9, v2, v9}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    add-int/lit8 v2, p2, 0x1

    const-string v3, "rank"

    .line 1723
    invoke-virtual {v7, v3, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v2

    const v3, 0x12ffffff

    const/16 v4, 0xc

    const/4 v10, 0x2

    const/4 v11, 0x1

    if-eqz v0, :cond_66

    const v5, -0xc5a301

    const v12, -0xe070ab

    .line 1725
    invoke-direct {v6, v5, v12}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v5

    const v12, -0xf0dc70

    const v13, -0xf4b2d6

    invoke-direct {v6, v12, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v12

    const v13, -0x55604701

    const v14, -0x55601740

    invoke-direct {v6, v13, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->th(II)I

    move-result v13

    invoke-direct {v6, v5, v12, v4, v13}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    .line 1726
    sget-object v12, Landroid/graphics/drawable/GradientDrawable$Orientation;->LEFT_RIGHT:Landroid/graphics/drawable/GradientDrawable$Orientation;

    invoke-virtual {v5, v12}, Landroid/graphics/drawable/GradientDrawable;->setOrientation(Landroid/graphics/drawable/GradientDrawable$Orientation;)V

    .line 1727
    invoke-direct {v6, v5, v3, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->striped(Landroid/graphics/drawable/Drawable;II)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    invoke-virtual {v8, v3}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_8f

    :cond_66
    if-gt v2, v10, :cond_80

    const v3, 0x3030e58a

    const v5, 0x830e58a

    .line 1729
    invoke-direct {v6, v3, v5, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->hgrad(III)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    .line 1730
    invoke-direct {v6, v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    const v5, 0x2230e58a

    invoke-virtual {v3, v4, v5}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 1731
    invoke-virtual {v8, v3}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_8f

    .line 1733
    :cond_80
    rem-int/lit8 v5, p2, 0x2

    if-nez v5, :cond_85

    goto :goto_88

    :cond_85
    const v3, 0x6ffffff

    :goto_88
    invoke-direct {v6, v3, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rounded(II)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    invoke-virtual {v8, v3}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1735
    :goto_8f
    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    const/4 v12, -0x1

    if-gt v2, v10, :cond_9a

    const v4, -0xf9def1

    goto :goto_9b

    :cond_9a
    move v4, v12

    :goto_9b
    const/16 v5, 0xd

    invoke-direct {v6, v3, v5, v4, v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v3

    const/16 v13, 0x11

    .line 1736
    invoke-virtual {v3, v13}, Landroid/widget/TextView;->setGravity(I)V

    const v4, 0x66ffffff

    if-gt v2, v10, :cond_b6

    const v2, -0x920045

    const v14, -0xe8579e

    .line 1737
    invoke-direct {v6, v2, v14, v5, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    goto :goto_c0

    :cond_b6
    const v2, 0x22ffffff

    const v14, 0x33ffffff

    .line 1738
    invoke-direct {v6, v4, v2, v5, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    .line 1737
    :goto_c0
    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1739
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v4, 0x1a

    invoke-direct {v6, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v5

    invoke-direct {v6, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    invoke-direct {v2, v5, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v14, 0x4

    .line 1740
    invoke-direct {v6, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    iput v4, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    const/4 v15, 0x6

    .line 1741
    invoke-direct {v6, v15}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v4

    iput v4, v2, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 1742
    invoke-virtual {v8, v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v2, "teamId"

    .line 1743
    invoke-virtual {v7, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v2

    const-string v3, "team"

    invoke-virtual {v7, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iget-boolean v5, v6, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->roomyRows:Z

    if-eqz v5, :cond_f6

    const/16 v5, 0x34

    goto :goto_f8

    :cond_f6
    const/16 v5, 0x28

    :goto_f8
    invoke-direct {v6, v2, v4, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->plateCrest(ILjava/lang/String;I)Landroid/view/View;

    move-result-object v2

    .line 1744
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    check-cast v4, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v5, 0xa

    invoke-direct {v6, v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    iput v1, v4, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 1745
    invoke-virtual {v8, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1746
    invoke-virtual {v7, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iget-boolean v2, v6, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->roomyRows:Z

    if-eqz v2, :cond_118

    const/16 v2, 0x13

    goto :goto_11a

    :cond_118
    const/16 v2, 0x10

    :goto_11a
    invoke-direct {v6, v1, v2, v12, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v0

    const-string v1, "region"

    .line 1747
    invoke-virtual {v7, v1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v2

    const-string v4, ""

    if-eqz v2, :cond_129

    goto :goto_12d

    :cond_129
    invoke-virtual {v7, v1, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 1748
    :goto_12d
    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_17f

    .line 1750
    invoke-virtual {v7, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 1751
    new-instance v2, Landroid/text/SpannableString;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "  "

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-direct {v6, v4}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Landroid/text/SpannableString;-><init>(Ljava/lang/CharSequence;)V

    .line 1752
    new-instance v3, Landroid/text/style/RelativeSizeSpan;

    const v4, 0x3f1eb852    # 0.62f

    invoke-direct {v3, v4}, Landroid/text/style/RelativeSizeSpan;-><init>(F)V

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v4

    add-int/2addr v4, v10

    invoke-virtual {v2}, Landroid/text/SpannableString;->length()I

    move-result v5

    invoke-virtual {v2, v3, v4, v5, v9}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 1753
    new-instance v3, Landroid/text/style/ForegroundColorSpan;

    const v4, -0xd36b4

    invoke-direct {v3, v4}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    add-int/2addr v1, v10

    invoke-virtual {v2}, Landroid/text/SpannableString;->length()I

    move-result v4

    invoke-virtual {v2, v3, v1, v4, v9}, Landroid/text/SpannableString;->setSpan(Ljava/lang/Object;III)V

    .line 1754
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1756
    :cond_17f
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-direct {v1, v9, v12, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v8, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const-string v0, "played"

    .line 1757
    invoke-virtual {v7, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x1e

    const/4 v3, -0x1

    const/4 v4, 0x0

    const/16 v16, 0xe

    move-object/from16 v0, p0

    move v14, v5

    const/16 v15, 0xa

    move/from16 v5, v16

    invoke-direct/range {v0 .. v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->cell(Ljava/lang/String;IIZI)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1758
    iget-boolean v0, v6, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->landscape:Z

    if-eqz v0, :cond_21a

    const-string v0, "win"

    .line 1759
    invoke-virtual {v7, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x1e

    const/4 v3, -0x1

    const/4 v4, 0x0

    const/16 v5, 0xe

    move-object/from16 v0, p0

    invoke-direct/range {v0 .. v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->cell(Ljava/lang/String;IIZI)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v0, "draw"

    .line 1760
    invoke-virtual {v7, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v0, p0

    invoke-direct/range {v0 .. v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->cell(Ljava/lang/String;IIZI)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v0, "lose"

    .line 1761
    invoke-virtual {v7, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v0, p0

    invoke-direct/range {v0 .. v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->cell(Ljava/lang/String;IIZI)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 1762
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "goalsFor"

    invoke-virtual {v7, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "goalsAgainst"

    invoke-virtual {v7, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/16 v2, 0x3a

    const v3, -0x564b2a

    const/16 v5, 0xd

    move-object/from16 v0, p0

    invoke-direct/range {v0 .. v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->cell(Ljava/lang/String;IIZI)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :cond_21a
    const-string v0, "goalDifference"

    .line 1765
    invoke-virtual {v7, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    if-lez v0, :cond_231

    .line 1766
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "+"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_235

    :cond_231
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v1

    :goto_235
    const/16 v2, 0x26

    if-lez v0, :cond_23e

    const v0, -0xd11a76

    :goto_23c
    move v3, v0

    goto :goto_248

    :cond_23e
    if-gez v0, :cond_244

    const v0, -0x857b

    goto :goto_23c

    :cond_244
    const v0, -0x564b2a

    goto :goto_23c

    :goto_248
    const/4 v4, 0x0

    const/16 v5, 0xe

    move-object/from16 v0, p0

    invoke-direct/range {v0 .. v5}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->cell(Ljava/lang/String;IIZI)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const-string v0, "points"

    .line 1768
    invoke-virtual {v7, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x12

    const/16 v2, -0x1eb6

    invoke-direct {v6, v0, v1, v2, v11}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->text(Ljava/lang/String;IIZ)Landroid/widget/TextView;

    move-result-object v0

    .line 1769
    invoke-virtual {v0, v13}, Landroid/widget/TextView;->setGravity(I)V

    const v1, -0x33eae5d4    # -3.9086256E7f

    const v2, 0x44ffe14a

    const v3, -0x33c5bd9e    # -4.882676E7f

    .line 1770
    invoke-direct {v6, v3, v1, v15, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1771
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v2, 0x2a

    invoke-direct {v6, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    const/16 v3, 0x20

    invoke-direct {v6, v3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v3

    invoke-direct {v1, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1772
    invoke-direct {v6, v10}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v2

    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 1773
    invoke-virtual {v8, v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1774
    iget-boolean v0, v6, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->roomyRows:Z

    if-eqz v0, :cond_29d

    .line 1775
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v0, v12, v9, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    goto :goto_2a8

    .line 1776
    :cond_29d
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v1, 0x36

    invoke-direct {v6, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    invoke-direct {v0, v12, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 1777
    :goto_2a8
    iget-boolean v1, v6, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->roomyRows:Z

    if-eqz v1, :cond_2ae

    const/4 v14, 0x6

    goto :goto_2af

    :cond_2ae
    const/4 v14, 0x4

    :goto_2af
    invoke-direct {v6, v14}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result v1

    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 1778
    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-object v8
.end method

.method private text(Ljava/lang/String;IIZ)Landroid/widget/TextView;
    .registers 7

    .line 907
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 908
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    int-to-float p1, p2

    .line 909
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 910
    invoke-virtual {v0, p3}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 p1, 0x1

    if-eqz p4, :cond_1a

    const/4 p2, 0x0

    .line 911
    invoke-virtual {v0, p2, p1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    :cond_1a
    const/16 p2, 0x10

    .line 912
    invoke-virtual {v0, p2}, Landroid/widget/TextView;->setGravity(I)V

    .line 913
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 914
    sget-object p1, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    return-object v0
.end method

.method private th(II)I
    .registers 4

    .line 2004
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->worldCup()Z

    move-result v0

    if-eqz v0, :cond_7

    move p1, p2

    :cond_7
    return p1
.end method

.method private tileParams(Z)Landroid/widget/LinearLayout$LayoutParams;
    .registers 6

    .line 1637
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x2

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v3, 0x0

    invoke-direct {v0, v3, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    if-eqz p1, :cond_13

    const/16 p1, 0x8

    .line 1638
    invoke-direct {p0, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result p1

    iput p1, v0, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :cond_13
    return-object v0
.end method

.method private ui()Landroid/content/Context;
    .registers 2

    .line 873
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->uiContext:Landroid/content/Context;

    if-eqz v0, :cond_5

    goto :goto_7

    :cond_5
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    :goto_7
    return-object v0
.end method

.method private vgrad(III)Landroid/graphics/drawable/GradientDrawable;
    .registers 5

    .line 726
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 727
    invoke-static {p1, p2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->mixColors(II)I

    move-result p1

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 728
    invoke-direct {p0, p3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->dp(I)I

    move-result p1

    int-to-float p1, p1

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    return-object v0
.end method

.method private worldCup()Z
    .registers 3

    .line 1991
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    if-nez v0, :cond_6

    const/4 v0, 0x0

    goto :goto_c

    :cond_6
    const-string v1, "cup"

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    :goto_c
    if-eqz v0, :cond_1e

    const-string v1, "key"

    .line 1992
    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "wc"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1e

    const/4 v0, 0x1

    goto :goto_1f

    :cond_1e
    const/4 v0, 0x0

    :goto_1f
    return v0
.end method


# virtual methods
.method synthetic lambda$celebrationReplayButton$11$org-efootballrevival-runtimeprobe-CupTournamentPanel(Landroid/view/View;)V
    .registers 2

    .line 0
    const/4 p1, 0x1

    .line 1165
    iput-boolean p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->celebrationForced:Z

    .line 1166
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->render()V

    return-void
.end method

.method synthetic lambda$celebrationScene$9$org-efootballrevival-runtimeprobe-CupTournamentPanel(Landroid/view/View;)V
    .registers 2

    .line 1123
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->closeCelebration()V

    return-void
.end method

.method synthetic lambda$closeCelebration$10$org-efootballrevival-runtimeprobe-CupTournamentPanel(Ljava/lang/String;)V
    .registers 6

    .line 0
    const-string v0, "{\"cupId\":\""

    .line 1149
    :try_start_2
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    const-string v2, "cup_celebrated"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "\"}"

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, v2, p1}, Lorg/efootballrevival/runtimeprobe/EmbeddedGateway;->manage(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    :try_end_1a
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_1a} :catch_1b

    goto :goto_23

    :catch_1b
    move-exception p1

    const-string v0, "E112_CUP_UI"

    const-string v1, "celebration mark failed"

    .line 1151
    invoke-static {v0, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_23
    return-void
.end method

.method synthetic lambda$groupTab$20$org-efootballrevival-runtimeprobe-CupTournamentPanel(ILandroid/view/View;)V
    .registers 3

    .line 1535
    iput p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->selectedGroup:I

    .line 1536
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->render()V

    return-void
.end method

.method synthetic lambda$matchTimeButton$14$org-efootballrevival-runtimeprobe-CupTournamentPanel(I)V
    .registers 6

    .line 0
    const-string v0, "{\"matchTime\":"

    .line 1330
    :try_start_2
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    const-string v2, "cup_match_time"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, "}"

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, v2, p1}, Lorg/efootballrevival/runtimeprobe/EmbeddedGateway;->manage(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    :try_end_1a
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_1a} :catch_1b

    goto :goto_23

    :catch_1b
    move-exception p1

    const-string v0, "E112_CUP_UI"

    const-string v1, "match time save failed"

    .line 1332
    invoke-static {v0, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_23
    return-void
.end method

.method synthetic lambda$matchTimeButton$15$org-efootballrevival-runtimeprobe-CupTournamentPanel([ILandroid/widget/TextView;Landroid/view/View;)V
    .registers 8

    .line 1318
    sget-object p3, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->MATCH_MINUTES:[I

    const/4 v0, 0x0

    aget p3, p3, v0

    move v1, v0

    .line 1319
    :goto_6
    sget-object v2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->MATCH_MINUTES:[I

    array-length v3, v2

    if-ge v1, v3, :cond_16

    .line 1320
    aget v2, v2, v1

    aget v3, p1, v0

    if-le v2, v3, :cond_13

    move p3, v2

    goto :goto_16

    :cond_13
    add-int/lit8 v1, v1, 0x1

    goto :goto_6

    .line 1322
    :cond_16
    :goto_16
    aput p3, p1, v0

    .line 1323
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "\u8bbe\u7f6e"

    invoke-direct {p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " \u00b7 "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\u6bd4\u8d5b\u65f6\u957f"

    invoke-direct {p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, "\u5206\u949f"

    invoke-direct {p0, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1324
    iget-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    if-eqz p1, :cond_55

    :try_start_50
    const-string p2, "matchTime"

    .line 1325
    invoke-virtual {p1, p2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_55
    .catch Lorg/json/JSONException; {:try_start_50 .. :try_end_55} :catch_55

    .line 1328
    :catch_55
    :cond_55
    new-instance p1, Ljava/lang/Thread;

    new-instance p2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda20;

    invoke-direct {p2, p0, p3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda20;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;I)V

    const-string p3, "e112-cup-match-time"

    invoke-direct {p1, p2, p3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 1334
    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method synthetic lambda$modeChip$21$org-efootballrevival-runtimeprobe-CupTournamentPanel(ZLandroid/view/View;)V
    .registers 3

    .line 1896
    iput-boolean p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->showKnockout:Z

    .line 1897
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->render()V

    return-void
.end method

.method synthetic lambda$new$3$org-efootballrevival-runtimeprobe-CupTournamentPanel(Landroid/view/View;)V
    .registers 2

    .line 267
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->refresh()V

    return-void
.end method

.method synthetic lambda$new$4$org-efootballrevival-runtimeprobe-CupTournamentPanel(Landroid/view/View;)V
    .registers 2

    .line 274
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->close()V

    return-void
.end method

.method synthetic lambda$new$5$org-efootballrevival-runtimeprobe-CupTournamentPanel(Landroid/content/DialogInterface;)V
    .registers 2

    .line 0
    const/4 p1, 0x1

    .line 338
    iput-boolean p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->closed:Z

    return-void
.end method

.method synthetic lambda$refresh$6$org-efootballrevival-runtimeprobe-CupTournamentPanel(JLorg/json/JSONObject;)V
    .registers 6

    .line 961
    iget-wide v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->refreshGeneration:J

    cmp-long p1, p1, v0

    if-nez p1, :cond_28

    .line 962
    iput-object p3, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const/4 p1, -0x1

    .line 963
    iput p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->selectedGroup:I

    .line 964
    iget p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->eventId:I

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->knockoutEventId()I

    move-result p2

    if-ne p1, p2, :cond_1d

    const-string p1, "knockout"

    invoke-virtual {p3, p1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    if-eqz p1, :cond_1d

    const/4 p1, 0x1

    goto :goto_1e

    :cond_1d
    const/4 p1, 0x0

    :goto_1e
    iput-boolean p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->showKnockout:Z

    .line 965
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->render()V

    const-string p1, "page drawn"

    .line 966
    invoke-static {p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->logPhase(Ljava/lang/String;)V

    :cond_28
    return-void
.end method

.method synthetic lambda$refresh$7$org-efootballrevival-runtimeprobe-CupTournamentPanel(J)V
    .registers 5

    .line 972
    iget-wide v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->refreshGeneration:J

    cmp-long p1, p1, v0

    if-nez p1, :cond_9

    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->renderError()V

    :cond_9
    return-void
.end method

.method synthetic lambda$refresh$8$org-efootballrevival-runtimeprobe-CupTournamentPanel(Ljava/util/concurrent/FutureTask;J)V
    .registers 9

    .line 0
    const-string v0, "{\"eventId\":"

    const-string v1, "E112_CUP_UI"

    if-eqz p1, :cond_17

    .line 949
    :try_start_6
    sget-object v2, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v3, 0x8

    invoke-virtual {p1, v3, v4, v2}, Ljava/util/concurrent/FutureTask;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lorg/json/JSONObject;
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_10} :catch_11

    goto :goto_18

    :catch_11
    move-exception p1

    :try_start_12
    const-string v2, "prefetch unavailable, fetching again"

    .line 951
    invoke-static {v1, v2, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_17
    const/4 p1, 0x0

    :goto_18
    if-nez p1, :cond_3f

    .line 955
    iget-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    invoke-static {p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->loadCrestPack(Landroid/app/Activity;)V

    .line 956
    new-instance p1, Lorg/json/JSONObject;

    iget-object v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    const-string v3, "ucl_ui_snapshot"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->eventId:I

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, "}"

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v3, v0}, Lorg/efootballrevival/runtimeprobe/EmbeddedGateway;->manage(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    :cond_3f
    const-string v0, "snapshot ready"

    .line 958
    invoke-static {v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->logPhase(Ljava/lang/String;)V

    .line 960
    sget-object v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->MAIN:Landroid/os/Handler;

    new-instance v2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda17;

    invoke-direct {v2, p0, p2, p3, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda17;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;JLorg/json/JSONObject;)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_4e
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_4e} :catch_4f

    goto :goto_5f

    :catch_4f
    move-exception p1

    const-string v0, "snapshot failed"

    .line 970
    invoke-static {v1, v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 971
    sget-object p1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->MAIN:Landroid/os/Handler;

    new-instance v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda18;

    invoke-direct {v0, p0, p2, p3}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda18;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;J)V

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :goto_5f
    return-void
.end method

.method synthetic lambda$renderError$22$org-efootballrevival-runtimeprobe-CupTournamentPanel(Landroid/view/View;)V
    .registers 2

    .line 2445
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->refresh()V

    return-void
.end method

.method synthetic lambda$resetButton$16$org-efootballrevival-runtimeprobe-CupTournamentPanel(JLandroid/widget/TextView;)V
    .registers 6

    .line 1360
    iget-wide v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->resetArmedAt:J

    cmp-long p1, v0, p1

    if-nez p1, :cond_22

    const-wide/16 p1, 0x0

    .line 1361
    iput-wide p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->resetArmedAt:J

    const-string p1, "\u91cd\u7f6e\u8d5b\u4e8b"

    .line 1362
    invoke-direct {p0, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p3, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p1, 0x18ffffff

    const/16 p2, 0x10

    const v0, 0x44ffffff    # 2047.9999f

    .line 1363
    invoke-direct {p0, v0, p1, p2, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p1

    invoke-virtual {p3, p1}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_22
    return-void
.end method

.method synthetic lambda$resetButton$17$org-efootballrevival-runtimeprobe-CupTournamentPanel(Landroid/widget/TextView;Landroid/view/View;)V
    .registers 12

    .line 1348
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 1349
    iget-wide v2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->resetArmedAt:J

    const-wide/16 v4, 0x0

    cmp-long p2, v2, v4

    const-wide/16 v6, 0xdac

    const/16 v8, 0x10

    if-eqz p2, :cond_32

    sub-long v2, v0, v2

    cmp-long p2, v2, v6

    if-gez p2, :cond_32

    .line 1350
    iput-wide v4, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->resetArmedAt:J

    const-string p2, "\u91cd\u7f6e\u8d5b\u4e8b"

    .line 1351
    invoke-direct {p0, p2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p2, 0x18ffffff

    const v0, 0x44ffffff    # 2047.9999f

    .line 1352
    invoke-direct {p0, v0, p2, v8, v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1353
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->resetCup()V

    return-void

    .line 1356
    :cond_32
    iput-wide v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->resetArmedAt:J

    const-string p2, "\u518d\u70b9\u4e00\u6b21\u786e\u8ba4"

    .line 1357
    invoke-direct {p0, p2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->s(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p2, -0x70e9d0

    const v2, -0x55000001

    const v3, -0x1fbaa6

    .line 1358
    invoke-direct {p0, v3, p2, v8, v2}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->glass(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object p2

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1359
    sget-object p2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->MAIN:Landroid/os/Handler;

    new-instance v2, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda24;

    invoke-direct {v2, p0, v0, v1, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda24;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;JLandroid/widget/TextView;)V

    invoke-virtual {p2, v2, v6, v7}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method synthetic lambda$resetCup$18$org-efootballrevival-runtimeprobe-CupTournamentPanel()V
    .registers 2

    .line 0
    const/4 v0, 0x0

    .line 1383
    iput-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;

    const/4 v0, 0x0

    .line 1384
    iput-boolean v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->showKnockout:Z

    const/4 v0, -0x1

    .line 1385
    iput v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->selectedGroup:I

    .line 1386
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->refresh()V

    return-void
.end method

.method synthetic lambda$resetCup$19$org-efootballrevival-runtimeprobe-CupTournamentPanel(I)V
    .registers 6

    .line 0
    const-string v0, "{\"eventId\":"

    .line 1378
    :try_start_2
    iget-object v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->activity:Landroid/app/Activity;

    const-string v2, "cup_reset"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, "}"

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, v2, p1}, Lorg/efootballrevival/runtimeprobe/EmbeddedGateway;->manage(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    :try_end_1a
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_1a} :catch_1b

    goto :goto_23

    :catch_1b
    move-exception p1

    const-string v0, "E112_CUP_UI"

    const-string v1, "cup reset failed"

    .line 1380
    invoke-static {v0, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 1382
    :goto_23
    sget-object p1, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->MAIN:Landroid/os/Handler;

    new-instance v0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda19;

    invoke-direct {v0, p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda19;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method synthetic lambda$sceneHeader$12$org-efootballrevival-runtimeprobe-CupTournamentPanel(Landroid/view/View;)V
    .registers 2

    .line 1285
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->refresh()V

    return-void
.end method

.method synthetic lambda$sceneHeader$13$org-efootballrevival-runtimeprobe-CupTournamentPanel(Landroid/view/View;)V
    .registers 2

    .line 1293
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->closeAnimated()V

    return-void
.end method
