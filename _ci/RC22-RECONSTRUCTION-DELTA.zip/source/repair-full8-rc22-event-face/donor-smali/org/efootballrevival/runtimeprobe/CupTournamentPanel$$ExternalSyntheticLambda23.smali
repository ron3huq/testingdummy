.class public final synthetic Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda23;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:I

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(II)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda23;->f$0:I

    iput p2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda23;->f$1:I

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    iget v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda23;->f$0:I

    iget v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda23;->f$1:I

    invoke-static {v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->lambda$openWhenReady$2(II)V

    return-void
.end method
