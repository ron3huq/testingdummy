.class public final synthetic Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda11;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;


# direct methods
.method public synthetic constructor <init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda11;->f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda11;->f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    invoke-static {v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->$r8$lambda$Ks_VI8m6_aGUO3qA9N2yZYB9pnI(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V

    return-void
.end method
