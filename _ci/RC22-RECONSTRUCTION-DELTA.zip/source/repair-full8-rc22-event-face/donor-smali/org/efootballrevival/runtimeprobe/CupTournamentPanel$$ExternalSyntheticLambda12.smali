.class public final synthetic Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda12;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

.field public final synthetic f$1:Z


# direct methods
.method public synthetic constructor <init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Z)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda12;->f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    iput-boolean p2, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda12;->f$1:Z

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 4

    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda12;->f$0:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;

    iget-boolean v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel$$ExternalSyntheticLambda12;->f$1:Z

    invoke-virtual {v0, v1, p1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->lambda$modeChip$21$org-efootballrevival-runtimeprobe-CupTournamentPanel(ZLandroid/view/View;)V

    return-void
.end method
