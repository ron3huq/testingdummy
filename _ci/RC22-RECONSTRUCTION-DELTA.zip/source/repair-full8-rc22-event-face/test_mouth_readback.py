"""Independent ray visibility and seam checks on every cooked face variant."""
import sys,json,numpy as np
from audit_mouth import read,pose,visibility

def run(root):
    reports=[]
    for variant in ['','ep00v0313','ep01v0291','lg00v0000']:
        base=read(root,variant=variant);p,f,lab,w,rest,parents=read(root,variant=variant,palette=2)
        ids=np.flatnonzero((lab>=0)&((lab<28)|(lab==34)))
        _,inverse=np.unique(np.round(base[0][ids],4),axis=0,return_inverse=True);first=np.full(inverse.max()+1,len(ids));np.minimum.at(first,inverse,np.arange(len(ids)));references=ids[first[inverse]]
        states={}
        for label,changes in [('neutral',{}),('idle_jaw1',{8:(0,-1)}),('idle_jaw2',{8:(0,-2)}),('open_jaw5',{8:(0,-5)}),('open_jaw20',{8:(0,-20)}),('head_turn',{5:(2,5),6:(2,10),7:(2,15)})]:
            q=pose(p,w,rest,parents,changes);gap=float(np.linalg.norm(q[ids]-q[references],axis=1).max());assert np.isfinite(q).all()and gap<1e-4,(variant,label,gap)
            row=dict(finite=True,skin_seam_max_cm=gap)
            if label!='head_turn':
                views=visibility(q,f,lab,dense=label in ['neutral','idle_jaw1','idle_jaw2']);row['views']=views
                if label in ['neutral','idle_jaw1','idle_jaw2']:assert all(v[k]==0 for v in views for k in ['oral28','oral29','oral30']),(variant,label,views)
                if label=='open_jaw20':assert any(v['oral28']>0 for v in views)and any(v['oral30']>0 for v in views),'teeth were hidden instead of sealing the idle lips'
            states[label]=row
        lp,lf,ll,lw,lr,lparents=read(root,variant=variant,palette=2,lod_index=1)
        assert np.array_equal(lp,p)and np.array_equal(lf,f)
        assert np.all(lw[:,8:21]==0)
        neck=lab==34;assert np.array_equal(lw[neck],w[neck]),'far LOD changed neck/body skin weights'
        turned=pose(lp,lw,lr,lparents,{5:(2,5),6:(2,10),7:(2,15)})
        near_turn=pose(p,w,rest,parents,{5:(2,5),6:(2,10),7:(2,15)})
        assert np.max(np.linalg.norm(turned-near_turn,axis=1))<1e-4,'head/neck pops across LOD'
        assert all(row[k]==0 for row in visibility(lp,lf,ll)for k in ['oral28','oral29','oral30'])
        raised={72:(0,65),106:(0,-65)}
        original_raised=pose(base[0],base[3],base[4],base[5],raised)
        near_raised=pose(p,w,rest,parents,raised);far_raised=pose(lp,lw,lr,lparents,raised)
        assert np.max(np.linalg.norm(original_raised[neck]-near_raised[neck],axis=1))<1e-4
        assert np.max(np.linalg.norm(near_raised[neck]-far_raised[neck],axis=1))<1e-4
        reports.append(dict(variant=variant or'base',far_authored_surface_exact=True,far_neck_weights_exact=True,raised_shoulder_bones_neck_matches_RC7=True,head_turn_has_no_LOD_position_pop=True,states=states))
    return dict(passed=True,cooked_face_variants=len(reports),camera_views_per_pose=15,dense_oral_samples_per_triangle=28,idle_neutral_and_jaw1_jaw2_no_oral_samples_visible=True,open_mouth_still_shows_teeth=True,geometry_test_independent_of_texture_darkness=True,reports=reports,phone_verified=False)
if __name__=='__main__':print(json.dumps(run(sys.argv[1]),indent=2))
