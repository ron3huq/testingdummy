"""Finalize a fresh exact-RC7 stage after the RC22 build/readback checks.
This constructs a phone-test candidate, not a claim of Android verification.
"""
from pathlib import Path
import sys,shutil,json,hashlib,re,ast,importlib.util,zipfile
ROOT=Path(sys.argv[1]).resolve();REPO=Path(__file__).resolve().parents[2];SOURCE=REPO/'source';VERSION='V19.1-FULL8-RC22-RC7BASE-V25-EVENT-RONALDO2027'
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def helper(p):
 spec=importlib.util.spec_from_file_location('finalize_helper',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def main():
 gateway=ROOT/'assets/gateway-release';tools=gateway/'work/tools';validation=ROOT/'validation'
 assert sha(ROOT/'classes5.dex')=='687f574b70c37888c274bd8d9b1cf193dc3eff33d4556eb8db34d8b124a53c51','Stage must still have RC7 DEX'
 assert 'ucl_lp_install'not in(tools/'bridge_73.py').read_text()
 # Stage donor UI classes and exactly its packaged backdrop/crest resources.
 dex=Path('/workspace/apk73-work/rc22-dex');assert json.loads((dex/'dex-report.json').read_text())['passed'];shutil.copyfile(dex/'classes5.dex',ROOT/'classes5.dex')
 with zipfile.ZipFile('/workspace/apk73-inputs/v25-decoded/73efootball-V25.apk')as z:
  for name in z.namelist():
   if name.startswith(('assets/cup-bg/','assets/cup-crests/'))and not name.endswith('/'):
    p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
 # No RC21 launcher button, native rule hook or season controller is staged.
 for name in ['repair-full8-rc22-event-face']:
  shutil.copytree(SOURCE/name,ROOT/'source'/name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 old=ROOT/'source/repair-full8-rc9-ucl'
 assert old.is_relative_to(ROOT/'source')
 if old.exists():shutil.rmtree(old)
 old.mkdir()
 for name in ['audit_rig.py','bundle_tools.py','test_face_profile.py','low-ranges.json']:
  shutil.copyfile(SOURCE/'repair-full8-rc9-ucl'/name,old/name)
 # Face-only reusable helpers are retained; legacy face candidate docs/gates are
 # not asserted as current evidence and their finalizer is not used.
 old=ROOT/'source/repair-full8-rc10-face-detail'
 keep=['face_mesh.py','face_texture_base.py','profile.S','profile.ld','patch_profile.py','test_face_profile.py']
 if old.exists():shutil.rmtree(old)
 old.mkdir()
 for name in keep:shutil.copyfile(SOURCE/'repair-full8-rc10-face-detail'/name,old/name)
 for p in(SOURCE/'repair-full8-rc22-event-face/runtime').iterdir():shutil.copyfile(p,tools/p.name)
 boot=tools/'bridge_73.py';s=boot.read_text();needle='        mod_startup._python_ready=True';assert s.count(needle)==1
 boot.write_text(s.replace(needle,'        import rc22_v25_events\n        rc22_v25_events.install(module)\n'+needle))
 # Use the already emulator-checked card-specific profile selector and match
 # the selected head atlas to the same native whole-body palette.
 shutil.copyfile(ROOT/'.ci-face-detail/face-noodle.so',tools/'libnoodle_hair.so')
 shutil.copyfile(SOURCE/'repair-full8-rc10-face-detail/face-overlays/appearance_choices.py',tools/'appearance_choices.py')
 p=tools/'noodle_hair.py';s,n=re.subn(r"HOOK_SHA='[^']+'","HOOK_SHA='"+sha(tools/'libnoodle_hair.so')+"'",p.read_text());assert n==1;p.write_text(s)
 p=tools/'private_bundles.py';s=p.read_text();assert "'pc9359']"in s;p.write_text(s.replace("'pc9359']","'pc9359', "+', '.join(repr('pc%d'%i)for i in range(9384,9408))+']'))
 p=tools/'private_bundles.json';d=json.loads(p.read_text());d['resource_revision']=19022
 for i in range(9384,9408):
  for ext in ['pak','utoc','ucas']:
   q=gateway/'livedata'/('pc%d_mobile_and.%s'%(i,ext));d['files'][q.name]={'size':q.stat().st_size,'sha256':sha(q)}
 p.write_text(json.dumps(d,indent=2)+'\n')
 p=tools/'noodle_bundle.json';d=json.loads(p.read_text());d.update(version=VERSION,asset_revision=19022,native_sha256=sha(tools/'libnoodle_hair.so'))
 d['new_three_faces']['89138556572074']='R9B2';d['ronaldo2027_profile'].update(profile='R9B1..R9B6',final_face_containers='pc9384..9407',native_body_palette=2,selectable_head_and_body_palettes=list(range(1,7)),geometry_texture_weights_bind_pose_LODs='RC7 authored HQ surface, rig, neck/body and hair preserved; local lip contact and 0.6mm idle seal padding; HQ LOD0 animated facial weights, compact153 far LOD retains same surface/UV and neck/body influences; head/body use the same selected native palette. Phone unverified.',phone_verified=False)
 d['appearance_files']={name:sha(tools/name)for name in d['appearance_files']};d['appearance_overlay_sha256']=sha(tools/'myleague_editor_runtime.py');p.write_text(json.dumps(d,indent=2)+'\n')
 for name,key in [('release-manifest.json','release_id'),('ui6-runtime-manifest.json','version')]:
  p=gateway/name;d=json.loads(p.read_text());d[key]=VERSION
  if 'modules'in d:d['modules']=sorted(set(d['modules'])|{'rc22_v25_events','rc22_cup_awards'})
  p.write_text(json.dumps(d,indent=2)+'\n')
 shutil.copyfile(SOURCE/'repair-full8-rc22-event-face/README-VI.md',ROOT/'README-VI.md')
 manifest=helper(ROOT/'source/repair-full8-rc2-hf1/build_runtime_manifests.py');manifest.update(gateway);manifest.check(gateway)
 for p in tools.glob('*.py'):ast.parse(p.read_text())
 sys.path.insert(0,str(ROOT/'source/repair-full8-rc5-hf1'));from check_startup_integrity import verify;from verify_login_gate import run
 report=verify(ROOT);report.update(run(ROOT));report.update(version=VERSION,phone_verified=False)
 (validation/'full8-rc22-startup.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()
