"""Copy V25 cup panel classes into exact RC7 DEX; add an awards dialog button.
All existing RC7 classes must round-trip unchanged, including controls/launcher.
"""
from pathlib import Path
import sys,json,subprocess,hashlib,shutil,re,zipfile
ROOT=Path('/workspace/apk73-work/rc7');RESEARCH=Path(__file__).resolve().parent;OUT=Path(sys.argv[1]);OUT.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(*args):subprocess.run(list(map(str,args)),check=True,stdout=subprocess.DEVNULL)
jar=ROOT/'.ci-full8-rc5/apktool.jar';tool=ROOT/'source/repair-full8-rc4/DexTool.java';smali=OUT/'smali'
assert sha(ROOT/'classes5.dex')=='687f574b70c37888c274bd8d9b1cf193dc3eff33d4556eb8db34d8b124a53c51'
run('java','-cp',jar,tool,'d',ROOT/'classes5.dex',smali)
before={p.relative_to(smali).as_posix():sha(p)for p in smali.rglob('*.smali')}
plan=json.loads((RESEARCH/'cup-dex-plan.json').read_text());assert not any(plan[k]for k in ['missing_classes','missing_methods','missing_fields'])
for name in plan['new_classes']:
 path=Path(name+'.smali');assert path.as_posix()not in before;dest=smali/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(RESEARCH/'donor-smali'/path,dest)
cls='Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;';target=smali/'org/efootballrevival/runtimeprobe/CupTournamentPanel.smali';s=target.read_text()
for signature,register in [('nextMatchBar()Landroid/view/View;','v1'),('knockoutBar(Lorg/json/JSONObject;)Landroid/view/View;','v2')]:
 pattern=r'(\.method private '+re.escape(signature)+r'\n.*?\.end method)';match=re.search(pattern,s,re.S);assert match
 text=match.group(1);needle='    return-object '+register;assert needle in text;text=text.replace(needle,'    invoke-direct {v0, '+register+'}, '+cls+'->rc22AwardsButton(Landroid/widget/FrameLayout;)V\n\n'+needle);s=s[:match.start()]+text+s[match.end():]
s+='''
.method private rc22AwardsButton(Landroid/widget/FrameLayout;)V
    .registers 8
    const-string v0, "Thống kê"
    iget-boolean v1, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->english:Z
    if-eqz v1, :label_ready
    const-string v0, "Stats"
    :label_ready
    const/4 v1, 0x0
    invoke-direct {p0, v0, v1}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->pillButton(Ljava/lang/String;Z)Landroid/widget/TextView;
    move-result-object v0
    new-instance v1, Lorg/efootballrevival/runtimeprobe/CupAwardsClick;
    invoke-direct {v1, p0}, Lorg/efootballrevival/runtimeprobe/CupAwardsClick;-><init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;
    const/4 v2, -0x2
    const/16 v3, 0x51
    invoke-direct {v1, v2, v2, v3}, Landroid/widget/FrameLayout$LayoutParams;-><init>(III)V
    invoke-virtual {p1, v0, v1}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    return-void
.end method

.method public rc22ShowAwards()V
    .registers 7
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->snapshot:Lorg/json/JSONObject;
    if-eqz v0, :done
    const-string v1, "awardsText"
    const-string v2, "Chưa có dữ liệu thống kê."
    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    new-instance v1, Landroid/app/AlertDialog$Builder;
    invoke-direct {p0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->ui()Landroid/content/Context;
    move-result-object v2
    invoke-direct {v1, v2}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V
    const-string v2, "Thống kê giải · Ghi bàn / Kiến tạo / MOTM"
    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    invoke-virtual {v1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;
    const v2, 0x104000a
    const/4 v3, 0x0
    invoke-virtual {v1, v2, v3}, Landroid/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;
    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;
    :done
    return-void
.end method
''';target.write_text(s)
(smali/'org/efootballrevival/runtimeprobe/CupAwardsClick.smali').write_text('''
.class public final Lorg/efootballrevival/runtimeprobe/CupAwardsClick;
.super Ljava/lang/Object;
.implements Landroid/view/View$OnClickListener;
.field private final owner:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;
.method public constructor <init>(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;)V
    .registers 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput-object p1, p0, Lorg/efootballrevival/runtimeprobe/CupAwardsClick;->owner:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;
    return-void
.end method
.method public onClick(Landroid/view/View;)V
    .registers 3
    iget-object v0, p0, Lorg/efootballrevival/runtimeprobe/CupAwardsClick;->owner:Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;
    invoke-virtual {v0}, Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;->rc22ShowAwards()V
    return-void
.end method
''')
output=OUT/'classes5.dex';run('java','-cp',jar,tool,'a',smali,output);verify=OUT/'verify';run('java','-cp',jar,tool,'d',output,verify)
after={p.relative_to(verify).as_posix():sha(p)for p in verify.rglob('*.smali')};changed=[name for name,h in before.items()if after.get(name)!=h];assert not changed,changed
report=dict(passed=True,baseline_dex_sha256=sha(ROOT/'classes5.dex'),new_dex_sha256=sha(output),existing_classes_verified=len(before),changed_existing_classes=changed,added_classes=len(after)-len(before),v25_donor_classes=len(plan['new_classes']),cup_panel_added_awards_button=True,launcher_single_player_transfer_exact_rc7=True,android_java_ui_executed=False,phone_verified=False)
(OUT/'dex-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
