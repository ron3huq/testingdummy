"""Read-only donor/base Python loading for host checks; never ships APK/save."""
import runpy,sys,marshal,importlib.abc,importlib.util,zipfile,io
from pathlib import Path
class References(importlib.abc.MetaPathFinder,importlib.abc.Loader):
    def __init__(self,apk,root):
        saved=sys.argv
        try:
            sys.argv=['extract_reference',str(apk),str(root)]
            ns=runpy.run_path(str(Path(__file__).parent/'extract_reference.py'))
        finally:sys.argv=saved
        # The donor adds a compressed dictionary after its literal payloads.
        # Read its fully assembled map; restore import hooks immediately.
        with zipfile.ZipFile(apk)as z:
            with zipfile.ZipFile(io.BytesIO(z.read('assets/chaquopy/app.imy')))as app:
                code=marshal.loads(app.read('_protected_runtime.pyc')[16:])
        hooks=list(sys.meta_path);runtime=dict(__name__='_protected_runtime_reference',__file__=str(Path(root)/'_protected_runtime.py'))
        try:exec(code,runtime)
        finally:sys.meta_path[:]=hooks
        self.payloads=runtime['_PAYLOADS'];self.cipher=ns['cipher'];self.root=Path(root)
    def find_spec(self,fullname,path=None,target=None):
        if fullname in self.payloads:return importlib.util.spec_from_loader(fullname,self)
    def create_module(self,spec):return None
    def exec_module(self,module):
        name=module.__name__;raw=self.payloads[name];data=self.cipher.decrypt(raw[:12],raw[12:],b'E156-V11-pyc-v1:'+name.encode()+b'\xcb\r\r\n');module.__file__=str(self.root/'work/tools'/(name+'.py'));module.__package__='';exec(marshal.loads(data[16:]),module.__dict__)
