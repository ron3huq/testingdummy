"""Local lip-contact padding; preserve topology/weights/bind pose and body.
A small weight-aware overlap keeps an idle jaw from exposing the teeth. It does
not lock the jaw, erase teeth or alter their atlas to conceal a geometric gap.
"""
import importlib.util
from pathlib import Path
import numpy as np,struct
spec=importlib.util.spec_from_file_location('rc10_mesh_base',Path(__file__).resolve().parents[1]/'repair-full8-rc10-face-detail/face_mesh.py');_base=importlib.util.module_from_spec(spec);spec.loader.exec_module(_base)
labels=_base.labels;drawn_triangles=_base.drawn_triangles
_original=_base.lip_mesh

def lip_mesh(m):
    pos,tan,lab,report=_original(m);before=pos.copy();n=len(lab)
    weights=np.zeros((len(pos),166))
    for section in m.info:
        for i,row in enumerate(m.weights[section['basevert']:section['basevert']+section['verts']]):
            for k,v in zip(row[:4],row[4:]):weights[section['basevert']+i,section['bones'][k]]+=v/255
    jaw=weights[:,[8,9]].sum(1);direction=2*np.clip(jaw/(89/255),0,1)-1
    x,y,z=before.T;skin=np.r_[lab<28,np.zeros(len(pos)-n,bool)]
    support=np.exp(-((z-163.6)/.35)**4)*np.exp(-(abs(x)/3.25)**8)*np.clip((y-14.9)/.9,0,1)*skin
    delta=.06*direction*support;selected=np.flatnonzero(abs(delta)>1e-6);pos[:,2]+=delta
    # Rotate authored tangent frames by the change of welded geometric normals.
    faces=drawn_triangles(m,0);skin_faces=faces[np.all(skin[faces],axis=1)]
    old_cross=np.cross(before[skin_faces[:,1]]-before[skin_faces[:,0]],before[skin_faces[:,2]]-before[skin_faces[:,0]])
    new_cross=np.cross(pos[skin_faces[:,1]]-pos[skin_faces[:,0]],pos[skin_faces[:,2]]-pos[skin_faces[:,0]])
    usable=np.linalg.norm(old_cross,axis=1)>1e-6
    assert np.all((old_cross[usable]*new_cross[usable]).sum(1)>0),'lip padding inverted a drawn triangle'
    _,inverse=np.unique(np.round(before,5),axis=0,return_inverse=True)
    totals=[]
    for cross in [old_cross,new_cross]:
        normals=np.zeros((inverse.max()+1,3))
        for corner in range(3):np.add.at(normals,inverse[skin_faces[:,corner]],cross)
        normals/=np.maximum(np.linalg.norm(normals,axis=1)[:,None],1e-12);totals.append(normals[inverse[selected]])
    a,b=totals;v=np.cross(a,b);c=(a*b).sum(1);assert np.all(c>-.99)
    K=np.zeros((len(selected),3,3));K[:,0,1]=-v[:,2];K[:,0,2]=v[:,1];K[:,1,0]=v[:,2];K[:,1,2]=-v[:,0];K[:,2,0]=-v[:,1];K[:,2,1]=v[:,0]
    R=np.eye(3)+K+(K@K)/(1+c)[:,None,None]
    for offset in [0,4]:
        vectors=tan[selected,offset:offset+3].copy().view('i1')/127
        vectors=np.einsum('nij,nj->ni',R,vectors);vectors/=np.maximum(np.linalg.norm(vectors,axis=1)[:,None],1e-12)
        tan[selected,offset:offset+3]=np.rint(np.clip(vectors,-1,1)*127).astype('i1').view('u1')
    assert np.array_equal(pos[n:],m.positions[n:]);assert np.array_equal(tan[:,[3,7]],m.tangents[:,[3,7]])
    assert float(np.max(np.linalg.norm(pos-m.positions,axis=1)))<.20
    report.update(idle_lip_padding_cm=.06,idle_lip_padding_vertices=len(selected),total_face_delta_cm=float(np.max(np.linalg.norm(pos-m.positions,axis=1))),drawn_skin_triangles_inverted=0,teeth_not_moved_for_idle_seal=True,lip_weights_and_body_rig_unchanged=True)
    return pos,tan,lab,report
_base.lip_mesh=lip_mesh
build_mesh=_base.build_mesh

# Independent nearest-surface projection of a generic low mesh crossed UV
# islands around the mouth. Keep the authored surface/UVs in the far LOD too.
# Only this card is affected; its few thousand extra far vertices avoid both
# that atlas distortion and inventing a second head shape. HQ animation weights
# stay authored. Far facial influences collapse to head as in a native compact
# head LOD; the neck's body influences and all reference bones stay exact.
def low_surface(m,native,pos,tan,lab):
    ns=m.info[0]['verts'];uv=m.uv.copy();uv[np.flatnonzero(np.isin(lab,[5,10])),:2]=[.9375,.8125]
    weights=np.zeros_like(m.weights);at=native.lods[1];count=struct.unpack_from('<I',native.data,at+10)[0];bone_map=list(struct.unpack_from('<%dH'%count,native.data,at+14))
    assert len(bone_map)==153
    assert not set(range(8,21))&set(bone_map)
    for i,row in enumerate(m.global_weights(0)):
        merged={}
        for bone,value in row:
            key=7 if 8<=bone<=20 else bone
            assert key in bone_map,'far body bone missing from native compact map'
            merged[key]=merged.get(key,0)+value
        for j,(key,value)in enumerate(sorted(merged.items())):weights[i,j]=bone_map.index(key);weights[i,j+4]=value
    weights[ns:]=[0,0,0,0,255,0,0,0]
    tri=np.concatenate([drawn_triangles(m,0),drawn_triangles(m,1)])
    return (pos.copy(),tan.copy(),uv,weights,m.colors.copy(),tri,ns,m.info[0]['tris'],bone_map),0.0
_base.low_surface=low_surface
_original_lod_blob=_base.lod_blob
def lod_blob(m,geometry,required,active):
    if len(required)==153:active=list(required)
    pos,tan,uv,weights,col,tri,ns,nt,bones=geometry
    packed=weights.copy();used=sorted({int(k)for row in packed[:ns]for k,v in zip(row[:4],row[4:])if v})
    assert len(used)<=75,'mobile section exceeds conservative GPU bone capacity'
    remap={old:new for new,old in enumerate(used)}
    for i,row in enumerate(packed[:ns]):
        for j in range(4):packed[i,j]=remap[int(row[j])]if row[j+4]else 0
    compact=[bones[i]for i in used]
    geometry=(pos,tan,uv,packed,col,tri,ns,nt,compact)
    return _original_lod_blob(m,geometry,required,active)
_base.lod_blob=lod_blob
_original_build=_base.build_mesh
def build_mesh(*args):
    out,lab,report=_original_build(*args)
    report.pop('authored_facial_weights_unchanged',None);report.pop('low_native_skin_vertices',None)
    report.update(high_authored_facial_weights_unchanged=True,far_LOD_preserves_authored_surface_and_UV=True,far_LOD_face_skin_vertices=len(lab),far_facial_influences_native_head_only=True,far_neck_body_weights_preserved=True,far_active_body_bones=153,no_generic_low_mesh_projection=True,gpu_bone_maps_compacted_without_changing_global_weights=True)
    return out,lab,report
