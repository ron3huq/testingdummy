"""Package a validated stage and a small Actions reconstruction delta."""
from pathlib import Path
import json,sys,hashlib,zipfile,shutil,importlib.util
BASE_SHA='52ac78143ec80cec5e98fcc4fa3e0f692979794037525d02752747af09265bf8'
VERSION='V19.1-FULL8-RC22-RC7BASE-V25-EVENT-RONALDO2027'
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(root,baseline,out):
 root=Path(root);out=Path(out);out.mkdir(parents=True,exist_ok=True);baseline=Path(baseline);assert sha(baseline)==BASE_SHA
 required=['face-readback','mouth-readback','event-full-cycle','face-profile','dex','startup']
 reports={name:json.loads((root/'validation'/('full8-rc22-'+name+'.json')).read_text())for name in required}
 assert all(d['passed']for d in reports.values())
 assert reports['event-full-cycle']['native_packet_prepare_start_finish_cycles']==14
 assert reports['event-full-cycle']['event_panel_opener_boundary_called_for_both_cups_and_phases']
 assert reports['dex']['changed_existing_classes']==[]and reports['dex']['existing_classes_verified']==588
 tools=root/'assets/gateway-release/work/tools'
 assert not list(tools.glob('ucl_lp_*'))and not(tools/'libucl_rules.so').exists()
 assert 'ucl_lp_'not in(tools/'bridge_73.py').read_text()
 assert 'rc22_v25_events.install(module)'in(tools/'bridge_73.py').read_text()
 spec=importlib.util.spec_from_file_location('manifests',root/'source/repair-full8-rc2-hf1/build_runtime_manifests.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.check(root/'assets/gateway-release')
 prior=json.loads((root/'payload-inventory.json').read_text());names={r['path']for r in prior['files']if(root/r['path']).is_file()}
 for directory in ['assets','source/repair-full8-rc9-ucl','source/repair-full8-rc10-face-detail','source/repair-full8-rc22-event-face','validation']:
  names.update(p.relative_to(root).as_posix()for p in(root/directory).rglob('*')if p.is_file()and '__pycache__'not in p.parts)
 names|={'README-VI.md','classes5.dex'}
 for name in names:
  p=Path(name);assert '__pycache__'not in p.parts and not p.name.endswith(('.private.json','-status.json','.tmp'))and p.suffix.lower()not in{'.apk','.zip','.rar','.db','.sqlite','.sqlite3','.log','.mp4'},name
 rows=[dict(path=name,bytes=(root/name).stat().st_size,sha256=sha(root/name))for name in sorted(names)]
 (root/'payload-inventory.json').write_text(json.dumps(dict(version=VERSION,resource_revision=19022,phone_verified=False,release_status='candidate-needs-Android-validation',files=rows),indent=2)+'\n');names.add('payload-inventory.json')
 def makezip(path,paths):
  with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
   for name in sorted(paths):z.write(root/name,name)
  with zipfile.ZipFile(path)as z:assert z.testzip()is None
 archive=out/'FULL8-RC22-RC7BASE-V25-EVENT-RONALDO2027.zip';makezip(archive,names)
 baseline_hashes={}
 with zipfile.ZipFile(baseline)as z:
  for info in z.infolist():
   if not info.is_dir():baseline_hashes[info.filename]=hashlib.sha256(z.read(info)).hexdigest()
 current={r['path']:r['sha256']for r in rows};current['payload-inventory.json']=sha(root/'payload-inventory.json')
 changes={n for n in names if baseline_hashes.get(n)!=current[n]}
 delta=out/'RC22-RECONSTRUCTION-DELTA.zip';makezip(delta,changes)
 base_payload={n for n in baseline_hashes if n.startswith('assets/')or n=='classes5.dex'}
 old_changed=sorted(n for n in base_payload if current.get(n)!=baseline_hashes[n])
 assert all(n=='assets/gateway-release/work/tools/libnoodle_hair.so'for n in old_changed if n.endswith('.so'))
 assert not any(n.startswith('assets/gateway-release/livedata/')for n in old_changed)
 assert not any(n.startswith('assets/launcher/')for n in old_changed)
 with zipfile.ZipFile(archive)as z:
  assert set(z.namelist())==names
  for row in rows:
   with z.open(row['path'])as f:assert hashlib.file_digest(f,'sha256').hexdigest()==row['sha256'],row['path']
 result=dict(passed=True,version=VERSION,archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),files=len(names),all_inventory_hashes_rechecked_from_zip=True,zip_crc_passed=True,baseline_zip_sha256=BASE_SHA,baseline_payload_files=len(base_payload),unchanged_baseline_payload_files=len(base_payload)-len(old_changed),changed_baseline_payload=old_changed,old_livedata_exact=True,old_native_libraries_except_targeted_noodle_profile_exact=True,launcher_exact_RC7=True,rc21_ucl_runtime_absent=True,delta_bytes=delta.stat().st_size,delta_sha256=sha(delta),delta_files=len(changes),phone_verified=False)
 (out/'FULL8-RC22.validation.json').write_text(json.dumps(result,indent=2)+'\n');(out/'FULL8-RC22.sha256').write_text(result['sha256']+'  '+archive.name+'\n');shutil.copyfile(root/'README-VI.md',out/'README-VI.md')
 return result
if __name__=='__main__':print(json.dumps(run(*sys.argv[1:]),indent=2))
