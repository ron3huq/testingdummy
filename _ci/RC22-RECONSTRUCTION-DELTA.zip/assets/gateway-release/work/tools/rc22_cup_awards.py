"""Per-cup native-receipt ledger. Never guesses AI scorers or a MOTM."""
import json
from collections import Counter

def setup(conn):
    conn.execute('CREATE TABLE IF NOT EXISTS rc22_cup_awards(scope TEXT NOT NULL,game TEXT NOT NULL,data TEXT NOT NULL,PRIMARY KEY(scope,game))')

def native_row(conn,game):
    for table in ['e112_ucl_games','e112_cup16_games']:
        if not conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone():continue
        row=conn.execute('SELECT event_id,receipt_json FROM '+table+' WHERE game_id=?',(str(game),)).fetchone()
        if row:return int(row[0]),row[1],table
    return None

def bind(conn,response,modules):
    game=response.get('game_id')
    if game is None:return False
    found=native_row(conn,game)
    if found is None:return False
    event,receipt,table=found;spec=modules['cup_spec'].for_event(event)
    if spec is None:return False
    if conn.in_transaction:raise ValueError('Cup binding requires completed native preparation')
    mode=modules['ucl_mode'].UclMode(conn,spec)if table=='e112_ucl_games'else modules['cup16_mode'].Cup16Mode(conn,spec.knockout_compe_unit_id)
    state=mode.state(event);active=state.get('active')if state else None
    if not active or str(active.get('game_id'))!=str(game):return False
    scope=str(state.get('source_group_cup_id')or state['cup_id']);team=state.get('selected_team_id')or state['own_team_id']
    conn.execute('CREATE TABLE IF NOT EXISTS rc22_cup_bindings(game TEXT PRIMARY KEY,scope TEXT NOT NULL,event INTEGER NOT NULL,team INTEGER NOT NULL)')
    existing=conn.execute('SELECT scope,event,team FROM rc22_cup_bindings WHERE game=?',(str(game),)).fetchone()
    if existing is not None:
        if tuple(existing)!=(scope,event,team):raise ValueError('Native cup game already bound to another season')
        return False
    with conn:conn.execute('INSERT INTO rc22_cup_bindings VALUES(?,?,?,?)',(str(game),scope,event,team))
    return True

def record(conn,request,modules):
    import club_store,player_match_stats
    detail=request.get('match_result',{});game=detail.get('game_id',request.get('game_id'))
    if game is None:return False
    if conn.in_transaction:raise ValueError('Cup awards require a completed native transaction')
    setup(conn)
    if not conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='rc22_cup_bindings'").fetchone():return False
    bound=conn.execute('SELECT scope,event,team FROM rc22_cup_bindings WHERE game=?',(str(game),)).fetchone()
    native=native_row(conn,game)
    if bound is None or native is None or native[0]!=bound[1]or native[1]is None:return False
    scope,event,team=bound
    if conn.execute('SELECT 1 FROM rc22_cup_awards WHERE scope=? AND game=?',(scope,str(game))).fetchone():return False
    goals=Counter(player_match_stats._event_ids(request,'goal_player_list'));assists=Counter(player_match_stats._event_ids(request,'assist_player_list'))
    motm=set()
    for row in detail.get('myteam_player_list',[]):
        if isinstance(row,dict)and row.get('is_man_of_the_match')in(True,'YES'):
            key=player_match_stats._gid(row)
            if key is not None:motm.add(key)
    winner=next(iter(motm))if len(motm)==1 else None
    players=[]
    for pid,serial in sorted(set(goals)|set(assists)|motm):
        p=club_store.player_by_key(conn,pid,serial)or{}
        name=p.get('name')or p.get('player_name')
        if not name:
            try:
                import player_editor
                alias=player_editor.name_index().get(str(pid))
                if isinstance(alias,(list,tuple))and alias:name=alias[0]
                elif isinstance(alias,str):name=alias
            except (ImportError,OSError,ValueError):pass
        name=name or('ID '+str(pid))
        players.append(dict(id=pid,serial=serial,name=str(name),team_id=team,goals=goals[(pid,serial)],assists=assists[(pid,serial)],motm=int(winner==(pid,serial))))
    doc=dict(players=players,native_motm_identified=winner is not None,coverage_complete=False)
    with conn:conn.execute('INSERT INTO rc22_cup_awards VALUES(?,?,?)',(scope,str(game),json.dumps(doc,ensure_ascii=False)))
    return True

def snapshot(conn,spec,modules):
    setup(conn);group=modules['ucl_mode'].UclMode(conn,spec).state(spec.group_event_id)
    scope=str(group['cup_id'])if group else None
    totals={};games=0
    if scope:
        for row in conn.execute('SELECT data FROM rc22_cup_awards WHERE scope=?',(scope,)):
            games+=1;doc=json.loads(row[0])
            for p in doc['players']:
                key=(p['id'],p['serial']);target=totals.setdefault(key,dict(p,goals=0,assists=0,motm=0))
                for field in ['goals','assists','motm']:target[field]+=p[field]
    boards={}
    for field in ['goals','assists','motm']:
        rows=sorted((p for p in totals.values()if p[field]>0),key=lambda p:(-p[field],p['name'],p['id'],p['serial']))
        boards[field]=[dict(p,rank=i+1)for i,p in enumerate(rows)]
    lines=[]
    for field,label in [('goals','VUA PHÁ LƯỚI'),('assists','VUA KIẾN TẠO'),('motm','MOTM')]:
        lines.append(label)
        rows=boards[field][:10]
        lines.extend(str(p['rank'])+'. '+p['name']+' — '+str(p[field])for p in rows)
        if not rows:lines.append('Chưa có dữ liệu được ghi nhận.')
        lines.append('')
    lines.append('Chỉ thống kê cầu thủ có trong dữ liệu engine gửi. Chưa có dữ liệu cầu thủ đầy đủ cho các trận AI.')
    return dict(boards=boards,games=games,coverage_complete=False), '\n'.join(lines)
