"""V25 cup Event adapter, isolated from RC7 global cup/roster modules.
Loads fingerprinted donor bytecode with a private import graph. Native Event
command routing remains the original gateway's cup_entry integration.
"""
import builtins,hashlib,importlib.util,marshal,sys,types,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
PRIVATE='_rc22_v25_'
_installed=False
_modules={}

def install(gateway=None):
    global _installed
    if _installed:return False
    meta=json.loads((HERE/'rc22_v25_events.json').read_text())
    codes={}
    for name,row in meta['modules'].items():
        raw=(HERE/row['file']).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=row['sha256']:raise ValueError('V25 Event module checksum mismatch: '+name)
        if raw[:4]!=importlib.util.MAGIC_NUMBER:raise ValueError('V25 Event Python version mismatch')
        c=marshal.loads(raw[16:])
        if not isinstance(c,types.CodeType):raise ValueError('Invalid V25 Event code object')
        codes[name]=c
    native_import=builtins.__import__
    def scoped_import(name,globals=None,locals=None,fromlist=(),level=0):
        if level==0 and name=='my_league':return load('my_league_e112_candidate')
        if level==0 and name in codes:return load(name)
        return native_import(name,globals,locals,fromlist,level)
    def load(name):
        if name in _modules:return _modules[name]
        m=types.ModuleType(PRIVATE+name);m.__file__=str(HERE/(name+'.py'));m.__package__='';m.__builtins__=dict(vars(builtins),__import__=scoped_import)
        _modules[name]=m;sys.modules[m.__name__]=m
        try:exec(codes[name],m.__dict__)
        except BaseException:
            _modules.pop(name,None);sys.modules.pop(m.__name__,None);raise
        return m
    donor=load('cup_entry')
    if donor.cup_spec.UCL.knockout_two_legs or donor.cup_spec.WORLD_CUP.knockout_two_legs:raise ValueError('Only the donor single-leg format is supported')
    import cup_entry as original
    # Preserve module identity held by the frozen GateLogic; do not replace its
    # handle class, My League module, save, DEX, launcher or native hooks.
    original.project=donor.project;original.handle=donor.handle;original.LIST_COMMANDS=donor.LIST_COMMANDS
    if gateway is not None:install_ui(gateway,load,meta)
    _installed=True
    return True

def install_ui(gateway,load,meta):
    """Retain V25's cup UI snapshot/settings and response transformations only."""
    import functools,copy
    raw=(HERE/meta['ui_helpers']['file']).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=meta['ui_helpers']['sha256']:raise ValueError('V25 cup UI helper checksum mismatch')
    data=marshal.loads(raw);ns=dict(gateway.__dict__)
    native_import=builtins.__import__
    def scoped_import(name,globals=None,locals=None,fromlist=(),level=0):
        if level==0 and name=='my_league':return load('my_league_e112_candidate')
        if level==0 and name in meta['modules']:return load(name)
        return native_import(name,globals,locals,fromlist,level)
    ns['__builtins__']=dict(vars(builtins),__import__=scoped_import)
    def thaw(v):
        if isinstance(v,dict):
            if '__function__'in v:
                code,defaults,kw=v['__function__'];f=types.FunctionType(code,ns,code.co_name,defaults);f.__kwdefaults__=kw;return f
            if '__python_type__'in v:return getattr(builtins,v['__python_type__'])
            if '__range__'in v:return range(*v['__range__'])
            return{k:thaw(x)for k,x in v.items()}
        if isinstance(v,tuple):return tuple(thaw(x)for x in v)
        if isinstance(v,list):return [thaw(x)for x in v]
        return v
    ns.update({k:thaw(v)for k,v in data['constants'].items()})
    for key,row in data['bindings'].items():
        value=scoped_import(row['module'])
        for part in row.get('qualname','').split('.'):
            if part:value=getattr(value,part)
        ns[key]=value
    for name,(code,defaults,kw)in data['functions'].items():
        f=types.FunctionType(code,ns,name,defaults);f.__kwdefaults__=kw;ns[name]=f
    cls=type(gateway._logic);old_handle=cls.handle
    @functools.wraps(old_handle)
    def handle(logic,command,request):
        if logic is not gateway._logic:return old_handle(logic,command,request)
        ns['_logic']=logic
        conn=logic.conn
        ns['_cup_unbridge'](conn)
        ns['_cup_void_stale_match'](conn,command,request)
        ns['_cup_remember_level'](conn,command,request)
        if command=='CMD_START_GAME':request=ns['_cup_start_lineup'](conn,command,request)
        response=old_handle(logic,command,request)
        if command in ('CMD_GET_EVENT_LIST_AND_LOG','CMD_GET_EVENT_LIST_AND_INFO'):response=ns['_cup_event_levels'](conn,response)
        if command=='CMD_GET_USER_COMPE_LIST':response=ns['_cup_user_compe_closed'](response)
        if command=='CMD_GET_EVENT_COMPE_INFO':response=ns['_cup_compe_list_closed'](request,response)
        if command=='CMD_SET_MYCLUB_SPECIAL_DREAM_SQUAD_INFO':response=ns['_cup_default_lineup'](conn,request,response)
        if command=='CMD_GET_EVENT_RENTAL_PLAYER_LIST':response=ns['_cup_rental_list'](request,response)
        if command=='CMD_GET_GAMERESULT_LIST':response=ns['_cup_game_results'](conn,request,response)
        if command=='CMD_GET_VSCOM_GAME_RESULT':response=ns['_cup_result_log'](conn,command,response)
        if command=='CMD_SET_EVENT_ENTER':response=ns['_cup_enter_squad'](conn,request,response)
        if command in ('CMD_GET_VSCOM_OPPONENT','CMD_GET_MYCLUB_VSCOM_OPPONENT')and response.get('result')=='NOERR':
            import rc22_cup_awards
            rc22_cup_awards.bind(conn,response,_modules)
        if command=='CMD_GET_VSCOM_GAME_RESULT'and response.get('result')=='NOERR':
            import rc22_cup_awards
            rc22_cup_awards.record(conn,request,_modules)
        event=ns['_cup_ui_event_for_response'](command,request,response,conn)if command in ('CMD_GET_EVENT_COMPE_TOURNAMENT_MATCH_LIST','CMD_GET_EVENT_COMPE_GROUP_STAGE_DRAW','CMD_SET_EVENT_ENTER','CMD_GET_VSCOM_GAME_RESULT')else None
        if event is not None:
            ns['_last_cup_event']=event
            # The original v25 Java gateway consumes this notification after
            # handling HTTP. Invoke its same main-thread/retry opener directly
            # so RC7's HTTP server and unrelated Java controls stay intact.
            try:
                from java import jclass
                jclass('org.efootballrevival.runtimeprobe.CupTournamentPanel').openFromGateway(int(event))
            except ImportError:pass # Host fixture has no Android JVM.
        return response
    old_manage=gateway.manage
    @functools.wraps(old_manage)
    def manage(action,payload=''):
        if action in ('ucl_ui_snapshot','cup_reset','cup_match_time','cup_celebrated'):
            ensure=getattr(gateway,'_ensure_ready',None)
            if ensure is not None:ensure()
            ns['_logic']=gateway._logic
        if action=='ucl_ui_snapshot':
            event=ns['_cup_snapshot_event'](payload);reply=ns['_cup_ui_snapshot'](gateway._logic.conn,event)
            spec=ns['_cup_spec'](event)if event is not None else ns['_cup_specs']()[0]
            if spec is not None:
                import rc22_cup_awards
                reply['awards'],reply['awardsText']=rc22_cup_awards.snapshot(gateway._logic.conn,spec,_modules)
            return json.dumps(reply,ensure_ascii=False)
        if action=='cup_reset':return json.dumps(ns['_cup_reset'](gateway._logic.conn,payload,gateway._logic),ensure_ascii=False)
        if action=='cup_match_time':return json.dumps(ns['_cup_set_match_time'](gateway._logic.conn,payload),ensure_ascii=False)
        if action=='cup_celebrated':return json.dumps(ns['_cup_mark_celebrated'](gateway._logic.conn,payload),ensure_ascii=False)
        return old_manage(action,payload)
    cls.handle=handle;gateway.manage=manage;gateway._rc22_cup_ui_namespace=ns
