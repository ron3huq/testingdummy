"""Visibility measured on cooked-container readback; not an Android test."""
import sys,json,struct,math
from pathlib import Path
import numpy as np,trimesh
from scipy.spatial.transform import Rotation
from trimesh.ray.ray_pyembree import RayMeshIntersector
SRC=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(SRC/'repair-full8-rc22-event-face'),str(SRC/'repair-full8-rc10-face-detail'),str(SRC/'repair-full8-rc7'),str(SRC/'repair-full8-rc9-ucl'),str(SRC/'repair-full8-rc4'),'/workspace/apk73-work/rc7/source/repair-full8-rc4']
from iostore import Toc
from mesh_tools import Mesh
from face_mesh import labels,drawn_triangles
from validate_face import read_lod,buffers

def read(root,variant='',palette=None,lod_index=0):
    root=Path(root);live=root/'assets/gateway-release/livedata';suffix=['','ep00v0313','ep01v0291','lg00v0000'].index(variant)
    old=Toc(str(live/f'pc{9356+suffix}_mobile_and.utoc'));path=f'character/RealFace/SK_RG28{variant}_Face.uasset';raw=old.read(old.files[path]);log=json.loads((root/'source/repair-full8-rc7/mesh-ranges.json').read_text())['SK_RG27'+variant+'_Face'];m=Mesh(raw,log,lod_index=1);lab=labels(m)
    if palette is None:
        b=raw;p=m.positions;f=np.concatenate([drawn_triangles(m,0),drawn_triangles(m,1)]);w=m.weights;sections=m.info
    else:
        t=Toc(str(live/f'pc{9408+suffix*6+palette-1}_mobile_and.utoc'));b=t.read(t.files[f'character/RealFace/SK_R9C{palette}{variant}_Face.uasset']);lod=read_lod(b,m.lods[0])
        if lod_index:lod=read_lod(b,lod['end'])
        p,f,_,_,w=buffers(b,lod);sections=lod['sections']
        if lod_index and sections[0]['verts']!=len(lab):lab=np.zeros(sections[0]['verts'],int)
    weights=np.zeros((len(p),166));offset=0
    for sec in sections:
        for i in range(sec['verts']):
            for k,v in zip(w[offset+i,:4],w[offset+i,4:]):weights[offset+i,sec['bones'][k]]+=v/255
        offset+=sec['verts']
    ref=m.r['REF_BEGIN'];nb=struct.unpack_from('<I',b,ref)[0];parents=np.array([struct.unpack_from('<i',b,ref+4+i*12+8)[0]for i in range(nb)]);at=ref+4+nb*12;assert struct.unpack_from('<I',b,at)[0]==nb
    tr=np.frombuffer(b,dtype='<f4',offset=at+4,count=nb*10).reshape(nb,10);local=np.tile(np.eye(4),(nb,1,1));local[:,:3,:3]=Rotation.from_quat(tr[:,:4]).as_matrix()*tr[:,None,7:10];local[:,:3,3]=tr[:,4:7];rest=[]
    for i in range(nb):rest.append(local[i]if parents[i]<0 else rest[parents[i]]@local[i])
    return p,f,np.r_[lab,np.full(len(p)-len(lab),-1)],weights,np.array(rest),parents

def pose(p,weights,rest,parents,changes):
    posed=[]
    for i in range(len(parents)):
        inherited=np.eye(4)if parents[i]<0 else posed[parents[i]]@np.linalg.inv(rest[parents[i]])
        move=np.eye(4)
        if i in changes:
            axis,angle=changes[i];r=Rotation.from_rotvec(np.eye(3)[axis]*math.radians(angle)).as_matrix();move[:3,:3]=r;move[:3,3]=rest[i,:3,3]-r@rest[i,:3,3]
        posed.append(inherited@move@rest[i])
    trans=np.array(posed)@np.linalg.inv(rest)
    return np.einsum('vij,vj->vi',np.einsum('vb,bij->vij',weights,trans),np.c_[p,np.ones(len(p))])[:,:3]

def visibility(p,f,lab,dense=False):
    skin=(lab>=0)&(lab<28)|(lab==34);skinF=f[skin[f].all(1)];area=np.linalg.norm(np.cross(p[skinF[:,1]]-p[skinF[:,0]],p[skinF[:,2]]-p[skinF[:,0]]),axis=1);skinF=skinF[area>1e-8]
    ray=RayMeshIntersector(trimesh.Trimesh(p,skinF,process=False));out=[]
    for theta in (-30,-15,0,15,30):
        for phi in (-15,0,15):
            camera=np.array([math.sin(math.radians(theta))*200,math.cos(math.radians(theta))*200,164+math.tan(math.radians(phi))*200]);row=dict(yaw=theta,pitch=phi)
            for label in (28,29,30):
                tris=f[np.all(lab[f]==label,axis=1)];targets=np.concatenate([p[lab==label],p[tris].mean(1)])
                if dense:
                    bc=np.array([(i/6,j/6,1-(i+j)/6)for i in range(7)for j in range(7-i)])
                    targets=np.concatenate([targets,np.einsum('bi,tij->tbj',bc,p[tris]).reshape(-1,3)])
                origins=np.tile(camera,(len(targets),1));directions=targets-origins;length=np.linalg.norm(directions,axis=1);directions/=length[:,None]
                locations,index,_=ray.intersects_location(origins,directions,multiple_hits=False);occluded=np.zeros(len(targets),bool)
                occluded[index]=np.linalg.norm(locations-origins[index],axis=1)<length[index]-.002
                row['oral'+str(label)]=int((~occluded).sum())
            out.append(row)
    return out

def run(root):
    results={}
    for label,palette in [('RC7',None),('candidate',2)]:
        p,f,lab,w,rest,parents=read(root,palette=palette)
        results[label]={}
        for name,changes in [('neutral',{}),('jaw1',{8:(0,-1)}),('jaw5',{8:(0,-5)}),('jaw20',{8:(0,-20)})]:
            q=pose(p,w,rest,parents,changes);assert np.isfinite(q).all();results[label][name]=visibility(q,f,lab)
    return dict(diagnostic_only=True,states=results,phone_verified=False)
if __name__=='__main__':print(json.dumps(run(sys.argv[1]),indent=2))
