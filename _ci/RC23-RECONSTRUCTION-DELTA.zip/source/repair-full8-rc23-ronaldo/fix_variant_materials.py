"""Bind all Ronaldo variants to their matching RC23 base face material.
RC22 non-base meshes still imported the old RG28 base face material.
"""
from pathlib import Path
import sys
SRC=Path(__file__).resolve().parents[1];sys.path[:0]=[str(SRC/'repair-full8-rc4'),'/workspace/apk73-work/rc7/source/repair-full8-rc4']
from iostore import Toc
from ci_bundle import Bundle
from zen_clone import rename,pid
BASE='/Game/Assets/character/RealFace/'
def run(root):
 live=Path(root)/'assets/gateway-release/livedata'
 for variant,suffix in enumerate(['','ep00v0313','ep01v0291','lg00v0000']):
  for pal in range(1,7):
   t=Toc(str(live/f'pc{9408+variant*6+pal-1}_mobile_and.utoc'));b=Bundle(t);mapping={BASE+'MI_RG2801_Head_FaceLegacy_'+q:BASE+'MI_R9C'+str(pal)+'01_Head_FaceLegacy_'+q for q in ['HQ','MQ']};repl={}
   for a,z in mapping.items():repl[a]=z;repl[Path(a).name]=Path(z).name
   remap={pid(a):pid(z)for a,z in mapping.items()}
   for p,(ids,raw)in list(b.files.items()):
    if p.endswith('.uasset'):b.files[p]=(ids,rename(raw,repl,imports=mapping))
   for key,(fixed,deps)in list(b.entries.items()):b.entries[key]=(fixed,[remap.get(i,i)for i in deps])
   b.base=Toc(str(live/f'pc{9384+variant*6+pal-1}_mobile_and.utoc'));b.output_name=Path(t.path).stem;b.write(live)
if __name__=='__main__':run(sys.argv[1])
