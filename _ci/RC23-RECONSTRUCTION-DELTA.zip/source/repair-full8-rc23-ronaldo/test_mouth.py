"""Visibility and animation probes on cooked face assets. Does not emulate the game's animation clips."""
import sys,json,numpy as np
from audit_mouth import read,pose,visibility
from scipy.spatial.transform import Rotation

def local_pose(p,w,rest,parents,bone,axis,angle):
    posed=[];vector=rest[bone,:3,:3]@np.eye(3)[axis]
    for i in range(len(parents)):
        inherited=np.eye(4)if parents[i]<0 else posed[parents[i]]@np.linalg.inv(rest[parents[i]]);move=np.eye(4)
        if i==bone:
            rot=Rotation.from_rotvec(vector*np.deg2rad(angle)).as_matrix();move[:3,:3]=rot;move[:3,3]=rest[i,:3,3]-rot@rest[i,:3,3]
        posed.append(inherited@move@rest[i])
    trans=np.array(posed)@np.linalg.inv(rest)
    return np.einsum('vij,vj->vi',np.einsum('vb,bij->vij',w,trans),np.c_[p,np.ones(len(p))])[:,:3]

def run(root):
    reports=[]
    for variant in ['','ep00v0313','ep01v0291','lg00v0000']:
        p,f,lab,w,rest,parents=read(root,variant=variant,palette=2);states={}
        for angle in [0,1,2,3,4,5,10,20]:
            q=pose(p,w,rest,parents,{8:(0,-angle)});rows=visibility(q,f,lab,dense=angle<=4)
            if angle<=4:assert all(v[k]==0 for v in rows for k in ['oral28','oral29','oral30']),(variant,angle,rows)
            if angle==20:assert any(v['oral28']>0 for v in rows)and any(v['oral30']>0 for v in rows),'jaw/teeth animation was disabled'
            states[str(angle)]={k:max(v[k]for v in rows)for k in ['oral28','oral29','oral30']}
        local=[]
        for axis in range(3):
            for angle in [-2,2]:
                q=local_pose(p,w,rest,parents,8,axis,angle);rows=visibility(q,f,lab)
                assert all(v[k]==0 for v in rows for k in ['oral28','oral29','oral30']),(variant,axis,angle)
                local.append(dict(jaw_local_axis=axis,degrees=angle,oral_samples_visible=0))
        far=read(root,variant=variant,palette=2,lod_index=1);assert np.array_equal(p,far[0]);assert all(v[k]==0 for v in visibility(far[0],far[1],far[2])for k in ['oral28','oral29','oral30'])
        reports.append(dict(variant=variant or'base',jaw_open_degrees=states,local_axis_idle_tests=local,far_neutral_closed=True))
    return dict(passed=True,variants=4,neutral_and_small_jaw_probes_closed=True,large_opening_still_shows_teeth=True,ray_check_independent_of_dark_textures=True,does_not_emulate_actual_game_animation_clips=True,phone_verified=False,reports=reports)
if __name__=='__main__':print(json.dumps(run(sys.argv[1]),indent=2))
