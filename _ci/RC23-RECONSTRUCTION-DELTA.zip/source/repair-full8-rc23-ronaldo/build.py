"""Clone RC22 into fresh R9C assets; only lip positions/tangents and D/SRO textures change."""
from pathlib import Path
import sys,json,struct,hashlib
SRC=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(Path(__file__).parent),str(SRC/'repair-full8-rc22-event-face'),str(SRC/'repair-full8-rc7'),str(SRC/'repair-full8-rc9-ucl'),str(SRC/'repair-full8-rc10-face-detail'),str(SRC/'repair-full8-rc4'),'/workspace/apk73-work/rc7/source/repair-full8-rc4']
from iostore import Toc
from ci_bundle import Bundle
from zen_clone import rename,pid
from mesh_tools import Mesh
from face_mesh import labels
from validate_face import read_lod,buffers,global_weights
from bundle_tools import decode_first_texture
from face_patch import close_idle
from texture_patch import prepare,patch
BASE='/Game/Assets/character/RealFace/'
def mesh_patch(raw,old,log):
 m=Mesh(old,log,lod_index=1);lab=labels(m);out=bytearray(raw);start=m.lods[0];reports=[]
 for lodno in range(2):
  lod=read_lod(raw,start);p,f,tan,uv,weights=buffers(raw,lod);gw=global_weights(lod['sections'],weights);ll=__import__('numpy').r_[lab,__import__('numpy').full(len(p)-len(lab),-1)];q,t,report=close_idle(p,tan,f,ll,gw)
  po=lod['stream']+2+9+f.size*2+16;to=po+p.nbytes+26;out[po:po+p.nbytes]=q.astype('<f4').tobytes();out[to:to+tan.nbytes]=t.tobytes()
  # Far facial weights stay exactly as RC22: apply the same rest-shape edit as
  # HQ, rather than inferring lip identity from its intentionally merged rig.
  if lodno==0:highq=q;hight=t
  else:out[po:po+p.nbytes]=highq.astype('<f4').tobytes();out[to:to+tan.nbytes]=hight.tobytes()
  reports.append(report);start=lod['end']
 return bytes(out),lab,reports

def run(root,report_path):
 root=Path(root);live=root/'assets/gateway-release/livedata';logs=json.loads((root/'source/repair-full8-rc7/mesh-ranges.json').read_text());reports=[];cache={}
 for variant,suffix in enumerate(['','ep00v0313','ep01v0291','lg00v0000']):
  clean=Bundle(Toc(str(live/f'pc{9356+variant}_mobile_and.utoc')));oldname='SK_RG28'+suffix+'_Face';original=clean.files['character/RealFace/'+oldname+'.uasset'][1];log=logs[oldname.replace('RG28','RG27')];mesh=Mesh(original,log,lod_index=1)
  mat2=Bundle(Toc(str(live/f'pc{9384+variant*6+1}_mobile_and.utoc')))
  raw2=mat2.files['character/RealFace/SK_R9B2'+suffix+'_Face.uasset'][1];newmesh,lab,geo=mesh_patch(raw2,original,log)
  oldprefix='character/RealFace/T_RG28'+suffix+'_Face_';im=decode_first_texture(clean.files[oldprefix+'D.uasset'][1],clean.files[oldprefix+'D.ubulk'][1]);e=prepare(mesh,lab,im.size)
  # Store the measured atlas target source in QA; body files are unchanged.
  for pal in range(1,7):
   old=Bundle(Toc(str(live/f'pc{9384+variant*6+pal-1}_mobile_and.utoc')));mapping={BASE+Path(p).stem:BASE+Path(p).stem.replace('R9B','R9C')for p in old.files if p.endswith('.uasset')}
   for ch in ['N','SRO']:
    a=BASE+'T_R9B2'+suffix+'_Face_'+ch;mapping[a]=a.replace('R9B','R9C')
   for quality in ['HQ','MQ']:
    a=BASE+'MI_RG2801_Head_FaceLegacy_'+quality;mapping[a]=BASE+'MI_R9C'+str(pal)+'01_Head_FaceLegacy_'+quality
   remap={pid(a):pid(b)for a,b in mapping.items()};new=Bundle(old.base);new.files={};new.entries={};data=dict(old.files);checks={};prefix='character/RealFace/T_R9B'+str(pal)+suffix+'_Face_'
   # Mesh bytes are identical across palettes except resource name IDs.
   for p,(ids,b)in list(data.items()):
    if p.endswith('.uasset')and Path(p).name.startswith('SK_'):data[p]=(ids,mesh_patch(b,original,log)[0])
   dra,dbu=clean.files[oldprefix+'D.uasset'][1],clean.files[oldprefix+'D.ubulk'][1]
   dn=Path(oldprefix+'D').name;nn=Path(prefix+'D').name;dra=rename(dra,{BASE+dn:BASE+nn,dn:nn},BASE+dn,BASE+nn,imports={BASE+dn:BASE+nn})
   key=(hashlib.sha256(dra+dbu).hexdigest(),pal)
   if key not in cache:cache[key]=patch(dra,dbu,'D',pal,e)
   ra,bu,checks['D'],enamel=cache[key];data[prefix+'D.uasset']=(data[prefix+'D.uasset'][0],ra);data[prefix+'D.ubulk']=(data[prefix+'D.ubulk'][0],bu)
   if pal==2:
    ra,bu,checks['SRO'],_=patch(data[prefix+'SRO.uasset'][1],data[prefix+'SRO.ubulk'][1],'SRO',pal,e,enamel)
    data[prefix+'SRO.uasset']=(data[prefix+'SRO.uasset'][0],ra);data[prefix+'SRO.ubulk']=(data[prefix+'SRO.ubulk'][0],bu)
   for p,(ids,b)in data.items():
    name=Path(p).stem;newname=name.replace('R9B','R9C');entry=None
    if p.endswith('.uasset'):
     fixed,deps=old.entries[int.from_bytes(ids[:8],'little')];entry=(fixed,[remap.get(v,v)for v in deps]);repl={}
     for a,z in mapping.items():repl[a]=z;repl[Path(a).name]=Path(z).name
     # References to shared palette-2 N/SRO may live outside this bundle.
     for ch in ['N','SRO']:
      a=BASE+'T_R9B2'+suffix+'_Face_'+ch;z=a.replace('R9B','R9C');repl[a]=z;repl[Path(a).name]=Path(z).name;mapping[a]=z
     b=rename(b,repl,BASE+name,BASE+newname,imports=mapping)
    new.put('character/RealFace/'+newname+Path(p).suffix,struct.pack('<Q',pid(BASE+newname))+b'\0\0\0'+(b'\2'if p.endswith('.uasset')else b'\3'),b,entry)
   new.output_name=f'pc{9408+variant*6+pal-1}_mobile_and';new.write(live);reports.append(dict(variant=suffix or'base',palette=pal,container=new.output_name,geometry=geo[0],texture=checks,LOD_bone_maps_weights_and_topology_exact_RC22=True));print('Built',new.output_name,flush=True)
 Path(report_path).write_text(json.dumps(dict(passed=True,reports=reports,phone_verified=False),indent=2)+'\n')
if __name__=='__main__':run(*sys.argv[1:])
