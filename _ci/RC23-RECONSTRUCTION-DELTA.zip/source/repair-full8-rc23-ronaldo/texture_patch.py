"""Match the measured native body albedo; separate tooth enamel from dark mouth tissue."""
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
from bundle_tools import decode_first_texture
from face_texture_base import patch_blocks
import face_texture as rc22

def prepare(mesh,lab,size):
    rc22.masks(mesh,lab,size);e=rc22._EXTRA['current'];e=dict(e)
    # Shared cavity UV used by the two inner lining islands; pad its ETC/mip footprint.
    tile=Image.new('L',size);d=ImageDraw.Draw(tile);x,y=np.array(size)*[.9375,.8125];d.rectangle((x-20,y-20,x+20,y+20),fill=255)
    e['cavity']=Image.fromarray(np.maximum(np.array(e['cavity']),np.array(tile)))
    return e

def blur(a,radius):
    return np.array(Image.fromarray(np.uint8(np.clip(a,0,255))).filter(ImageFilter.GaussianBlur(radius))).astype(float)

def diffuse_image(raw,bulk,palette,e):
    im=decode_first_texture(raw,bulk);a=np.array(im).astype(float);rgb=a[:,:,:3];skin=np.array(e['skin'])>0;neck=np.array(e['neck'])>0;teeth=np.array(e['teeth'])>0;tongue=np.array(e['tongue'])>0;cavity=np.array(e['cavity'])>0
    xyz=e['xyz'];x,y,z=np.moveaxis(xyz,-1,0);v=e['valid'];lip=v&(abs(x)<3.7)&(y>15.5)&(z>162.4)&(z<165.2)
    # Normalise low-frequency photographed skin tint, preserving pore/beard detail.
    eligible=skin&~lip&~teeth&~tongue&~cavity&(rgb[:,:,0]>rgb[:,:,1]*1.08)&(rgb[:,:,1]>rgb[:,:,2]*1.05)&(rgb.mean(2)>65)
    radius=im.width/36;weight=blur(eligible*255,radius)/255;field=np.zeros_like(rgb)
    for ch in range(3):field[:,:,ch]=blur(rgb[:,:,ch]*eligible,radius)/np.maximum(weight,.005)
    target=rc22.PALETTES[palette-1];fallback=np.median(rgb[eligible],axis=0);field[weight<.02]=fallback
    gain=np.clip(target/np.maximum(field,1),.35,1.65)
    # Remove broad head/neck colour layers; retain 12% broad natural variation.
    normalised=rgb*gain;lum=np.clip((rgb/(np.maximum(field,1))).mean(2),.45,1.35)
    normalised=target*(.88*lum[:,:,None]+.12*rgb/np.maximum(fallback,1))
    # Fine chromatic skin detail remains, without bringing back the broad red cast.
    chroma=rgb/np.maximum(field,1);chroma/=np.maximum(chroma.mean(2)[:,:,None],.01)
    normalised*=np.clip(chroma,.8,1.2)
    for ch in range(3):rgb[skin,ch]=normalised[skin,ch]
    # Keep lips distinct and blend their perimeter into the same skin base.
    if lip.any():
        lip_strength=blur(lip*255,im.width/512)/255
        mix=lip_strength[:,:,None];original=np.array(im)[:,:,:3].astype(float)*np.clip(target/np.array([162.,120.,93.]),.45,1.3)
        rgb[:]=rgb*(1-mix)+original*mix
    # Teeth have their own atlas islands. Brighten only desaturated enamel,
    # while the gums and tongue remain near black with low specular response.
    high=rgb.max(2);low=rgb.min(2);enamel=teeth&(rgb.mean(2)>105)&((high-low)<70)
    tooth_rgb=rgb[enamel];luma=tooth_rgb.mean(1);new_luma=np.clip(luma*1.15+12,150,230);rgb[enamel]=tooth_rgb*(new_luma/np.maximum(luma,1))[:,None]
    gums=teeth&~enamel;rgb[gums]=np.minimum(rgb[gums]*.035,7);rgb[tongue]=np.minimum(rgb[tongue]*.025,5);rgb[cavity]=0
    changed=skin|teeth|tongue|cavity;out=Image.fromarray(np.uint8(np.rint(np.clip(a,0,255))),'RGBA')
    return out,Image.fromarray(np.uint8(changed)*255),dict(target_native_body_albedo=target.tolist(),enamel_texels=int(enamel.sum()),cavity_and_tissue_near_black=True,uniform_skin_base_without_flattening_pores=True),enamel

def patch(raw,bulk,channel,palette,e,enamel=None):
    if channel=='D':
        out,mask,report,enamel=diffuse_image(raw,bulk,palette,e)
    elif channel=='SRO':
        a=np.array(decode_first_texture(raw,bulk));t=(np.array(e['teeth'])>0);g=np.array(e['tongue'])>0;c=np.array(e['cavity'])>0
        assert enamel is not None
        dark=(t&~enamel)|g|c;a[dark,0]=0;a[dark,1]=255;a[dark,2]=0
        a[enamel,0]=35;a[enamel,1]=155;a[enamel,2]=210
        mask=Image.fromarray(np.uint8(t|g|c)*255);out=Image.fromarray(a,'RGBA');report=dict(dark_tissue_specular=0,dark_tissue_occlusion=0,enamel_keeps_visible_response=True)
    else:raise ValueError(channel)
    ra,bu,checks=patch_blocks(raw,bulk,out,mask);report.update(checks)
    return ra,bu,report,enamel
