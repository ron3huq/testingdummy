"""Incremental RC22 lip rest contact. All skin weights, sections and LOD metadata stay exact."""
import numpy as np

def close_idle(p,tan,faces,lab,global_weights):
    p=p.copy();before=p.copy();tan=tan.copy();handedness=tan[:,[3,7]].copy();skin=(lab>=0)&(lab<28)
    x,y,z=p.T;jaw=global_weights[:,8:10].sum(1)/255
    direction=2*np.clip(jaw/(89/255),0,1)-1
    support=np.exp(-((z-163.6)/.48)**4)*np.exp(-(abs(x)/3.45)**8)*np.clip((y-14.9)/.9,0,1)*skin
    p[:,2]+=.09*direction*support
    selected=np.flatnonzero(np.abs(p-before).max(1)>1e-6)
    sf=faces[skin[faces].all(1)];old=np.cross(before[sf[:,1]]-before[sf[:,0]],before[sf[:,2]]-before[sf[:,0]]);new=np.cross(p[sf[:,1]]-p[sf[:,0]],p[sf[:,2]]-p[sf[:,0]])
    valid=np.linalg.norm(old,axis=1)>1e-6
    assert np.all((old[valid]*new[valid]).sum(1)>0),'inverted external skin triangle'
    _,inv=np.unique(np.round(before,5),axis=0,return_inverse=True);normals=[]
    for cross in [old,new]:
        accum=np.zeros((inv.max()+1,3))
        for j in range(3):np.add.at(accum,inv[sf[:,j]],cross)
        accum/=np.maximum(np.linalg.norm(accum,axis=1)[:,None],1e-12);normals.append(accum[inv[selected]])
    a,b=normals;v=np.cross(a,b);c=(a*b).sum(1);assert np.all(c>-.99)
    K=np.zeros((len(selected),3,3));K[:,0,1]=-v[:,2];K[:,0,2]=v[:,1];K[:,1,0]=v[:,2];K[:,1,2]=-v[:,0];K[:,2,0]=-v[:,1];K[:,2,1]=v[:,0]
    rotation=np.eye(3)+K+(K@K)/(1+c)[:,None,None]
    for offset in [0,4]:
        q=tan[selected,offset:offset+3].copy().view('i1')/127;q=np.einsum('nij,nj->ni',rotation,q);q/=np.maximum(np.linalg.norm(q,axis=1)[:,None],1e-12);tan[selected,offset:offset+3]=np.rint(np.clip(q,-1,1)*127).astype('i1').view('u1')
    assert np.array_equal(p[~skin],before[~skin]);assert np.array_equal(tan[:,[3,7]],handedness)
    return p,tan,dict(changed_vertices=len(selected),max_incremental_delta_cm=float(np.linalg.norm(p-before,axis=1).max()),no_inverted_skin_triangles=True,skin_weights_and_LOD_layout_unchanged=True)
