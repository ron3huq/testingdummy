from pathlib import Path
import sys,hashlib,json

def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(root,baseline,repro):
 root=Path(root);baseline=Path(baseline);repro=Path(repro);changed=[];kept=0
 allowed={'assets/gateway-release/release-manifest.json','assets/gateway-release/ui6-runtime-manifest.json',*[f'assets/gateway-release/work/tools/{x}'for x in ['libnoodle_hair.so','noodle_hair.py','noodle_bundle.json','private_bundles.json','private_bundles.py']]}
 for p in (baseline/'assets').rglob('*'):
  if not p.is_file()or '__pycache__'in p.parts:continue
  n=p.relative_to(baseline).as_posix();assert(root/n).is_file()
  if sha(p)!=sha(root/n):changed.append(n);assert n in allowed,n
  else:kept+=1
 assert sha(root/'classes5.dex')==sha(baseline/'classes5.dex')
 repro_files=0
 for p in(repro/'assets/gateway-release/livedata').glob('pc94*'):
  if int(p.name[2:6])<9408:continue
  q=root/p.relative_to(repro);assert sha(p)==sha(q),p.name;repro_files+=1
 assert repro_files==72
 return dict(passed=True,baseline='verified FULL8 RC22',unchanged_existing_assets=kept,changed_existing_assets=changed,classes5_dex_exact_RC22=True,UCL_World_Cup_runtime_and_UI_exact_RC22=True,all_existing_body_hair_face_containers_exact_RC22=True,source_rebuild_byte_exact_files=repro_files,phone_verified=False)
if __name__=='__main__':print(json.dumps(run(*sys.argv[1:]),indent=2))
