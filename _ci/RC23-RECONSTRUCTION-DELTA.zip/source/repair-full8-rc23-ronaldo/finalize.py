"""Finalize RC23 on a copy of the verified RC22 FULL; preserve all unrelated payload."""
from pathlib import Path
import sys,json,hashlib,shutil,re,ast,importlib.util
SRC=Path(__file__).resolve().parents[1];VERSION='V19.1-FULL8-RC23-RC22BASE-RONALDO2027'
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def helper(p):
 s=importlib.util.spec_from_file_location('helper',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def run(root,research):
 root=Path(root);research=Path(research);g=root/'assets/gateway-release';t=g/'work/tools';v=root/'validation'
 assert sha(root/'classes5.dex')=='e8ccdde56f676f183b88db20cab13e3db085f48e4aa9537440e57251fd229170'
 for key in ['build','readback','mouth','profile']:
  doc=json.loads((research/(key+'.json')).read_text());assert doc['passed'];shutil.copy2(research/(key+'.json'),v/('full8-rc23-'+key+'.json'))
 oldso=t/'libnoodle_hair.so';prior=oldso.read_bytes();new=(research/'face-noodle.so').read_bytes();assert len(prior)==len(new);diff=[i for i in range(len(new))if prior[i]!=new[i]];assert len(diff)==1 and prior[diff[0]]==ord('B')and new[diff[0]]==ord('C'),'native patch must change only the face namespace'
 oldso.write_bytes(new)
 p=t/'noodle_hair.py';s,n=re.subn(r"HOOK_SHA='[^']+'","HOOK_SHA='"+sha(oldso)+"'",p.read_text());assert n==1;p.write_text(s)
 p=t/'private_bundles.py';s=p.read_text();needle="'pc9407']";assert needle in s;p.write_text(s.replace(needle,"'pc9407', "+', '.join(repr('pc%d'%i)for i in range(9408,9432))+']'))
 p=t/'private_bundles.json';d=json.loads(p.read_text());d['resource_revision']=19023
 for i in range(9408,9432):
  for ext in ['pak','utoc','ucas']:
   q=g/'livedata'/f'pc{i}_mobile_and.{ext}';d['files'][q.name]={'size':q.stat().st_size,'sha256':sha(q)}
 p.write_text(json.dumps(d,indent=2)+'\n')
 p=t/'noodle_bundle.json';d=json.loads(p.read_text());d.update(version=VERSION,asset_revision=19023,native_sha256=sha(oldso));d['new_three_faces']['89138556572074']='R9C2';d['ronaldo2027_profile'].update(profile='R9C1..R9C6',final_face_containers='pc9408..9431',geometry_texture_weights_bind_pose_LODs='Incremental RC22 lip rest contact; all RC22 topology/UV/skin weights/bone maps/LODs exact. Dark mouth tissues with separate clear enamel; measured uniform native body skin palette; all variant face material references corrected. Phone unverified.',phone_verified=False)
 d['appearance_files']={name:sha(t/name)for name in d['appearance_files']};p.write_text(json.dumps(d,indent=2)+'\n')
 for filename,key in [('release-manifest.json','release_id'),('ui6-runtime-manifest.json','version')]:
  p=g/filename;d=json.loads(p.read_text());d[key]=VERSION;p.write_text(json.dumps(d,indent=2)+'\n')
 shutil.copytree(SRC/'repair-full8-rc23-ronaldo',root/'source/repair-full8-rc23-ronaldo',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 shutil.copy2(SRC/'repair-full8-rc23-ronaldo/README-VI.md',root/'README-VI.md')
 m=helper(root/'source/repair-full8-rc2-hf1/build_runtime_manifests.py');m.update(g);m.check(g)
 for p in t.glob('*.py'):ast.parse(p.read_text())
 sys.path.insert(0,str(root/'source/repair-full8-rc5-hf1'));from check_startup_integrity import verify;from verify_login_gate import run as login
 report=verify(root);report.update(login(root));report.update(version=VERSION,phone_verified=False);(v/'full8-rc23-startup.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))
if __name__=='__main__':run(*sys.argv[1:])
