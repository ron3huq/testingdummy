"""Idempotent correction of externally shared palette-2 texture package IDs.
Only needed for the initial build made before mapping shared imports upfront.
"""
from pathlib import Path
import sys
SRC=Path(__file__).resolve().parents[1];sys.path[:0]=[str(SRC/'repair-full8-rc9-ucl'),str(SRC/'repair-full8-rc4'),'/workspace/apk73-work/rc7/source/repair-full8-rc4']
from iostore import Toc
from ci_bundle import Bundle
from zen_clone import pid
BASE='/Game/Assets/character/RealFace/'
def run(root):
 live=Path(root)/'assets/gateway-release/livedata'
 for variant,suffix in enumerate(['','ep00v0313','ep01v0291','lg00v0000']):
  for pal in range(1,7):
   t=Toc(str(live/f'pc{9408+variant*6+pal-1}_mobile_and.utoc'));b=Bundle(t);remap={pid(BASE+'T_R9B2'+suffix+'_Face_'+c):pid(BASE+'T_R9C2'+suffix+'_Face_'+c)for c in ['N','SRO']};changed=False
   for key,(fixed,deps)in list(b.entries.items()):
    vals=[remap.get(i,i)for i in deps];changed|=vals!=deps;b.entries[key]=(fixed,vals)
   if changed:
    b.base=Toc(str(live/f'pc{9384+variant*6+pal-1}_mobile_and.utoc'));b.output_name=Path(t.path).stem;b.write(live)
if __name__=='__main__':run(sys.argv[1])
