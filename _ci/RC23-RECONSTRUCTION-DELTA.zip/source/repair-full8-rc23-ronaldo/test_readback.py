"""Cooked RC23 vs cooked RC22: topology/rig/UV/LOD invariant, new package graph, texture readback."""
from pathlib import Path
import sys,json,struct,hashlib,numpy as np
SRC=Path(__file__).resolve().parents[1];sys.path[:0]=[str(Path(__file__).parent),str(SRC/'repair-full8-rc22-event-face'),str(SRC/'repair-full8-rc7'),str(SRC/'repair-full8-rc9-ucl'),str(SRC/'repair-full8-rc10-face-detail'),str(SRC/'repair-full8-rc4'),'/workspace/apk73-work/rc7/source/repair-full8-rc4']
from iostore import Toc
from ci_bundle import Bundle
from mesh_tools import Mesh
from validate_face import read_lod,buffers,global_weights
from face_mesh import labels
from audit_rig import names
from bundle_tools import decode_first_texture
from texture_patch import prepare
from PIL import ImageFilter
from zen_clone import pid,rename
BASE='/Game/Assets/character/RealFace/'
def run(root):
 root=Path(root);live=root/'assets/gateway-release/livedata';logs=json.loads((root/'source/repair-full8-rc7/mesh-ranges.json').read_text());results=[];tones=[]
 allpids=set();allDeps=[];oldpids=set()
 for variant,suffix in enumerate(['','ep00v0313','ep01v0291','lg00v0000']):
  origin=Toc(str(live/f'pc{9356+variant}_mobile_and.utoc'));orig=origin.read(origin.files['character/RealFace/SK_RG28'+suffix+'_Face.uasset']);m=Mesh(orig,logs['SK_RG27'+suffix+'_Face'],lod_index=1);lab=labels(m)
  for pal in range(1,7):
   old=Bundle(Toc(str(live/f'pc{9384+variant*6+pal-1}_mobile_and.utoc')));new=Bundle(Toc(str(live/f'pc{9408+variant*6+pal-1}_mobile_and.utoc')))
   allpids.update(new.entries);oldpids.update(old.entries)
   for fixed,deps in new.entries.values():allDeps+=deps
   op='character/RealFace/SK_R9B'+str(pal)+suffix+'_Face.uasset';npth=op.replace('R9B','R9C');a=old.files[op][1];b=new.files[npth][1];at=m.lods[0];changed=set();near=None
   for lodno in range(2):
    l=read_lod(a,at);nl=read_lod(b,at);assert l==nl,'LOD or GPU bone map changed';p,f,t,u,w=buffers(a,l);q,nf,nt,nu,nw=buffers(b,nl)
    assert np.array_equal(f,nf)and np.array_equal(u,nu)and np.array_equal(w,nw),'topology/UV/weights changed'
    count=len(lab);keep=np.r_[lab>=28,np.ones(len(p)-count,bool)]
    assert np.array_equal(p[keep],q[keep])and np.array_equal(t[keep],nt[keep]),'neck/oral/hair moved'
    assert np.array_equal(t[:,[3,7]],nt[:,[3,7]])
    assert np.linalg.norm(q-p,axis=1).max()<.091
    if lodno==0:near=q
    else:assert np.array_equal(q,near),'LOD rest shape mismatch'
    po=l['stream']+2+9+f.size*2+16;to=po+p.nbytes+26;changed.update(range(po,po+p.nbytes));changed.update(range(to,to+t.nbytes));at=l['end']
   # Equal-length resource renaming aside, only the reviewed vertex streams changed.
   ns=names(a);repl={n:n.replace('R9B','R9C')for n in ns if 'R9B'in n};imports={n:n.replace('R9B','R9C')for n in ns if n.startswith('/Game/')and 'R9B'in n}
   for quality in ['HQ','MQ']:
    oldmat=BASE+'MI_RG2801_Head_FaceLegacy_'+quality;newmat=BASE+'MI_R9C'+str(pal)+'01_Head_FaceLegacy_'+quality;imports[oldmat]=newmat;repl[oldmat]=newmat;repl[Path(oldmat).name]=Path(newmat).name
   expected=rename(a,repl,BASE+Path(op).stem,BASE+Path(npth).stem,imports=imports);assert len(a)==len(b)
   diffs=np.flatnonzero(np.frombuffer(expected,'u1')!=np.frombuffer(b,'u1'));assert set(diffs)<=changed
   for path,(ids,raw)in new.files.items():
    if path.endswith('.uasset'):
     ns=names(raw);assert not any('R9B'in n or ('RG28'in n and '_Head_Hair_'not in n)for n in ns),path
     assert BASE+Path(path).stem in ns,'internal package name mismatch'
   dp='character/RealFace/T_R9C'+str(pal)+suffix+'_Face_D';im=decode_first_texture(new.files[dp+'.uasset'][1],new.files[dp+'.ubulk'][1]);e=prepare(m,lab,im.size);pix=np.array(im);x,y,z=np.moveaxis(e['xyz'],-1,0);v=e['valid'];eligible=v&(pix[:,:,0]>pix[:,:,1]*1.08)&(pix[:,:,1]>pix[:,:,2]*1.05)&(pix[:,:,:3].mean(2)>65)
   local={}
   for region,sel in [('neck',z<155.8),('cheek',(z>164.5)&(z<169)&(abs(x)>3)&(y>10)),('forehead',(z>173)&(z<177)&(abs(x)<4)&(y>10))]:
    q=pix[eligible&sel,:3];assert len(q)>100;local[region]=np.median(q,axis=0).tolist()
   target=np.array([[174,137,117],[162,120,93],[162,116,85],[138,102,77],[101,74,60],[85,62,52]])[pal-1]
   for val in local.values():assert np.max(abs(np.array(val)-target))<11,(pal,local,target.tolist())
   cavity=np.array(e['cavity'].filter(ImageFilter.MinFilter(9)))>0;assert np.quantile(pix[cavity,:3],.99)<12
   tongue=np.array(e['tongue'].filter(ImageFilter.MinFilter(9)))>0;assert np.quantile(pix[tongue,:3],.95)<12
   teeth=np.array(e['teeth'].filter(ImageFilter.MinFilter(5)))>0;assert np.count_nonzero((pix[:,:,:3].mean(2)>140)&teeth)>1000
   tones.append(dict(variant=suffix or'base',palette=pal,body_target=target.tolist(),readback_medians=local))
   results.append(dict(variant=suffix or'base',palette=pal,rig_topology_UVs_weights_LOD_maps_exact_RC22=True,neck_hair_oral_positions_exact=True,new_package_names_consistent=True,cavity_and_tongue_dark=True,enamel_visible=True))
 assert oldpids.isdisjoint(allDeps),'new bundle still imports an RC22 face package'
 for dep in allDeps:
  # Native/global material/hair imports may legitimately remain external.
  if dep in oldpids:raise AssertionError('old face dependency')
 return dict(passed=True,assets=len(results),reports=results,skin_tones=tones,no_old_face_package_dependencies=True,phone_verified=False)
if __name__=='__main__':print(json.dumps(run(sys.argv[1]),indent=2))
