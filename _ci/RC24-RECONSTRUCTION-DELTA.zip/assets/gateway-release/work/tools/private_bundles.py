"""Verified private hero meshes and player photographs, without replacing the existing face pack."""
from pathlib import Path
import functools,json
from mod_integrity import digest
HERE=Path(__file__).resolve().parent
@functools.lru_cache(maxsize=1)
def verified():
 doc=json.loads((HERE/'private_bundles.json').read_text());live=HERE.parents[1]/'livedata'
 revision=doc.get('resource_revision',0)
 if type(revision)is not int or not 0<=revision<=1000000:raise ValueError('Private resource_revision must be an integer between 0 and 1000000')
 doc['resource_revision']=revision
 for name,row in doc['files'].items():
  p=live/name
  if p.stat().st_size!=row['size']or digest(p)!=row['sha256']:raise ValueError('Private hero/art payload mismatch: '+name)
 return doc

def advertise(value,port):
 if not isinstance(value,dict)or not isinstance(value.get('livedata_list'),list)or not isinstance(value.get('version_file'),str):return value
 doc=verified();version=json.loads(value['version_file']);version['dt880']=[x for x in version['dt880']if not isinstance(x,dict)or x.get('name')not in ['pc9308','pc9318','pc9319']];names=set(doc['files'])|{stem+'_mobile_and.'+ext for stem in ['pc9308','pc9318','pc9319']for ext in ['pak','utoc','ucas']};out=dict(value);out['livedata_list']=[x for x in value['livedata_list']if not isinstance(x,dict)or x.get('name')not in names]
 for container in ['pc9305', 'pc9306', 'pc9307', 'pc9310', 'pc9312', 'pc9313', 'pc9314', 'pc9315', 'pc9316', 'pc9317', 'pc9320', 'pc9321', 'pc9323', 'pc9324', 'pc9327', 'pc9328', 'pc9329', 'pc9330', 'pc9331', 'pc9332', 'pc9333', 'pc9334', 'pc9335', 'pc9336', 'pc9337', 'pc9338', 'pc9339', 'pc9340', 'pc9341', 'pc9342', 'pc9343', 'pc9344', 'pc9345', 'pc9346', 'pc9347', 'pc9348', 'pc9349', 'pc9350', 'pc9351', 'pc9352', 'pc9353', 'pc9354', 'pc9355', 'pc9356', 'pc9357', 'pc9358', 'pc9359', 'pc9384', 'pc9385', 'pc9386', 'pc9387', 'pc9388', 'pc9389', 'pc9390', 'pc9391', 'pc9392', 'pc9393', 'pc9394', 'pc9395', 'pc9396', 'pc9397', 'pc9398', 'pc9399', 'pc9400', 'pc9401', 'pc9402', 'pc9403', 'pc9404', 'pc9405', 'pc9406', 'pc9407', 'pc9408', 'pc9409', 'pc9410', 'pc9411', 'pc9412', 'pc9413', 'pc9414', 'pc9415', 'pc9416', 'pc9417', 'pc9418', 'pc9419', 'pc9420', 'pc9421', 'pc9422', 'pc9423', 'pc9424', 'pc9425', 'pc9426', 'pc9427', 'pc9428', 'pc9429', 'pc9430', 'pc9431', 'pc9432', 'pc9433', 'pc9434', 'pc9435', 'pc9436', 'pc9437', 'pc9438', 'pc9439', 'pc9440', 'pc9441', 'pc9442', 'pc9443', 'pc9444', 'pc9445', 'pc9446', 'pc9447', 'pc9448', 'pc9449', 'pc9450', 'pc9451', 'pc9452', 'pc9453', 'pc9454', 'pc9455', 'pc9456', 'pc9457', 'pc9458', 'pc9459', 'pc9460', 'pc9461', 'pc9462', 'pc9463', 'pc9464', 'pc9465', 'pc9466', 'pc9467', 'pc9468', 'pc9469', 'pc9470', 'pc9471', 'pc9472', 'pc9473', 'pc9474', 'pc9475', 'pc9476', 'pc9477', 'pc9478', 'pc9479', 'pc9480', 'pc9481', 'pc9482', 'pc9483', 'pc9484', 'pc9485', 'pc9486', 'pc9487', 'pc9488', 'pc9489', 'pc9490', 'pc9491', 'pc9492', 'pc9493', 'pc9494', 'pc9495', 'pc9496', 'pc9497', 'pc9498', 'pc9499', 'pc9500', 'pc9501', 'pc9502', 'pc9503']:
  stem=container+'_mobile_and';r={ext:doc['files'][stem+'.'+ext]for ext in ['pak','utoc','ucas']};item={'name':container,'hash':r['pak']['sha256'],'hashFileSize':r['pak']['size'],'ucas':r['ucas']['sha256'],'ucasFileSize':r['ucas']['size'],'utoc':r['utoc']['sha256'],'utocFileSize':r['utoc']['size']};prior=next((x for x in version['dt880']if isinstance(x,dict)and x.get('name')==container),None)
  if prior!=item:version['version']+=710+(doc['resource_revision']if container=='pc9323'else 0)
  version['dt880']=[x for x in version['dt880']if not isinstance(x,dict)or x.get('name')!=container]+[item]
  out['livedata_list'] +=[{'name':stem+'.'+ext,'size':r[ext]['size'],'url':'http://127.0.0.1:'+str(port)+'/livedata/'+stem+'.'+ext}for ext in ['pak','utoc','ucas']]
 if version['version']>=2**31:raise ValueError('Resource version overflow')
 out['version_file']=json.dumps(version,separators=(',',':'));return out
