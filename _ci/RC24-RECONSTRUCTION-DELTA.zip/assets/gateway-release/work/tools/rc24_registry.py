"""Verified v25 Event reference data for the existing Transfer editor.
Installed before saved Transfer profiles are validated during startup.
"""
from pathlib import Path
import copy,functools,hashlib,json
HERE=Path(__file__).resolve().parent
REFERENCE_SHA='dc56d0d35cb19159dfff65bee89fcdeae9c4ba08bb952d888b4ee049b4e03b0a'
_installed=False;_data=None

def data():
 global _data
 if _data is None:
  raw=(HERE/'rc24_event_references.json').read_bytes()
  if hashlib.sha256(raw).hexdigest()!=REFERENCE_SHA:raise ValueError('Cup editor reference checksum mismatch')
  _data=json.loads(raw)
 return _data

def install():
 global _installed
 if _installed:return False
 import transfer_editor as transfer,transfer_native_data
 refs=data();original_catalog=transfer.catalog;catalog=copy.deepcopy(original_catalog());teams={r['id']:r for r in catalog['teams']}
 for row in refs['teams'].values():
  cid,tid=row['competition'],row['team_id'];league=next(r for r in catalog['leagues']if r['id']==cid)
  if tid not in league['teams']:league['teams'].append(tid)
  teams.setdefault(tid,dict(id=tid,name=row['name']))
 catalog['teams']=list(teams.values());transfer.catalog=lambda:catalog;transfer.team_names.cache_clear()
 old_valid=transfer.valid_players
 @functools.wraps(old_valid)
 def valid_players():return old_valid()|set(refs['players'])
 transfer.valid_players=valid_players
 old_source=transfer.source
 @functools.wraps(old_source)
 def source(tid,cid):
  row=old_source(tid,cid)
  if row is not None:return row
  row=refs['teams'].get(str(cid)+':'+str(tid))
  return copy.deepcopy(row)if row else None
 transfer.source=source
 old_read=transfer_native_data.read
 @functools.wraps(old_read)
 def read(c,pid,cid):
  if int(cid)in(122,128)and str(pid)in refs['players']:
   try:
    values,src=old_read(c,pid,cid)
    if src=='native_MyLeague_record_observed':return values,src
   except ValueError:pass
   return list(refs['players'][str(pid)]['parameters'][:147]),'Verified v25 Event squad reference'
  return old_read(c,pid,cid)
 transfer_native_data.read=read
 # The old ready flag only knew phone snapshots. Published Event squad
 # packets now also supply an exact, editable lineup before Enter Game.
 old_manage=transfer.manage
 @functools.wraps(old_manage)
 def manage(c,action,request):
  reply=old_manage(c,action,request)
  if action=='ui712_transfer_list':
   cid=reply['competition']
   for row in reply['teams']:
    if str(cid)+':'+str(row['id'])in refs['teams']:row['ready']=True
  return reply
 transfer.manage=manage;_installed=True;return True
