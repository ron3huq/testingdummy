"""A curved, animated inner lip lining behind the authored vermilion.
Covers tiny UV/surface seams at rest without inflating the visible lips.
"""
import numpy as np

def lining(points,recess=.12):
 columns={}
 for p in np.asarray(points):
  key=round(float(p[0]),1)
  if key not in columns or p[1]>columns[key][1]:columns[key]=p.copy()
 line=np.array([columns[k]for k in sorted(columns)])
 assert len(line)>=3,'Too few lip-contact columns'
 # Strong lip controls stop before the mouth corners. Continue the inner
 # lining behind those corners, where otherwise a subpixel ray could reach a
 # rear tooth even though the central lip border is closed.
 extension=max(0,(6.2-float(line[-1,0]-line[0,0]))/2)
 if extension>0:
  left=(line[1]-line[0])/max(float(line[1,0]-line[0,0]),1e-5);right=(line[-1]-line[-2])/max(float(line[-1,0]-line[-2,0]),1e-5);left[1:]=np.clip(left[1:],[-1.2,-.6],[1.2,.6]);right[1:]=np.clip(right[1:],[-1.2,-.6],[1.2,.6])
  line=np.concatenate([[line[0]-left*d for d in np.linspace(extension,extension/3,3)],line,[line[-1]+right*d for d in np.linspace(extension/3,extension,3)]])
 positions=[];rows=[]
 for p in line:
  for dz,bone in [(.25,16),(-.04,16),(.04,9),(-.25,9)]:
   q=p.copy();q[1]-=recess;q[2]+=dz;positions.append(q);rows.append({7:.97,bone:.03})
 faces=[]
 for i in range(len(line)-1):
  for side in [0,2]:
   a=4*i+side;b=4*(i+1)+side
   for tri in [[a,b,a+1],[a+1,b,b+1]]:
    p=np.array(positions)[tri];normal=np.cross(p[1]-p[0],p[2]-p[0]);faces.append(tri if normal[1]>=0 else tri[::-1])
 p=np.array(positions,'<f4');t=np.tile(np.array([127,0,0,127,0,127,0,-127],'i1').view('u1'),(len(p),1));uv=np.tile(np.array([.9375,.8125,0,0],'<f2'),(len(p),1));f=np.array(faces,'<u2');col=np.full((len(p),4),255,'u1')
 return p,t,uv,rows,col,f

def seal_existing(raw,m,lab):
 import struct,importlib.util
 from pathlib import Path
 from scipy.spatial import cKDTree
 from validate_face import read_lod,buffers,global_weights
 spec=importlib.util.spec_from_file_location('rc24_native_serializer',Path(__file__).resolve().parents[1]/'repair-full8-rc10-face-detail/face_mesh.py');serializer=importlib.util.module_from_spec(spec);spec.loader.exec_module(serializer)
 high=read_lod(raw,m.lods[0]);low=read_lod(raw,high['end']);p,f,t,u,w=buffers(raw,high);gw=global_weights(high['sections'],w);ns=high['sections'][0]['verts'];nt=high['sections'][0]['tris'];x,y,z=p[:ns].T;support=(abs(x)<3.45)&(y>15.6)&(abs(z-163.6)<.48)&(lab<28);ui=np.flatnonzero(support&(gw[:ns,16]>5));li=np.flatnonzero(support&((gw[:ns,8]+gw[:ns,9])>5));distance,index=cKDTree(p[li]).query(p[ui]);pairs=[(int(a),int(li[b]))for a,b,d in zip(ui,index,distance)if d<.5];points=[(p[a]+p[b])/2 for a,b in pairs];sp,st,su,sr,sc,sf=lining(points);extra=len(sp);assert len(p)+extra<65536
 # Keep the original drawn skin and hair surfaces exactly; append only the
 # internal lining, inserting its vertices before the hair section.
 pn=np.concatenate([p[:ns],sp,p[ns:]]);tn=np.concatenate([t[:ns],st,t[ns:]]);un=np.concatenate([u[:ns],su,u[ns:]]);fn=np.concatenate([f[:nt],sf+ns,f[nt:]+extra]);ntn=nt+len(sf);nns=ns+extra
 # Colour bytes live after the weight stream; read them from the audited old
 # layout. RC23 uses the same source RG28 vertex order and full opaque colours.
 colour=m.colors.copy();cn=np.concatenate([colour[:ns],sc,colour[ns:]])
 def lod(old):
  pp,ff,tt,uu,ww=buffers(raw,old);bones=old['sections'][0]['bones'];new=np.zeros((extra,8),'u1');head=bones.index(7)
  for i,row in enumerate(sr):
   lip=16 if 16 in row else 9
   if lip in bones:new[i]=[head,bones.index(lip),0,0,247,8,0,0]
   else:new[i]=[head,0,0,0,255,0,0,0]
  wn=np.concatenate([ww[:ns],new,ww[ns:]]);geometry=pn,tn,un,wn,cn,fn,nns,ntn,bones
  return serializer.lod_blob(m,geometry,old['required'],old['active'])
 out=bytearray(raw[:m.lods[0]]+lod(high)+lod(low)+bytes.fromhex('020200000000'));em=struct.unpack_from('<I',raw,44)[0];struct.pack_into('<Q',out,em+80,struct.unpack_from('<Q',raw,em+80)[0]+len(out)-len(raw))
 return bytes(out),dict(internal_lip_lining_vertices=extra,internal_lip_lining_triangles=len(sf),all_original_outer_vertices_tangents_UVs_and_triangles_preserved=True,original_body_bone_maps_preserved=True)
