package org.efootballrevival.runtimeprobe;
import android.app.Activity; public class TransferEditor{public static void showForCup(Activity a,int n){}}
