import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from build_face import *
from audit_rig import names
root=Path(sys.argv[1]);live=root/'assets/gateway-release/livedata';logs=json.loads((root/'source/repair-full8-rc7/mesh-ranges.json').read_text())
for v,suffix in enumerate(['','ep00v0313','ep01v0291','lg00v0000']):
 original=Toc(str(live/f'pc{9356+v}_mobile_and.utoc'));p='character/RealFace/SK_RG28'+suffix+'_Face.uasset';m=Mesh(original.read(original.files[p]),logs['SK_RG27'+suffix+'_Face'],lod_index=1);lab=labels(m)
 for pal in range(1,7):
  oldt=Toc(str(live/f'pc{9408+v*6+pal-1}_mobile_and.utoc'));old=Bundle(oldt);p='character/RealFace/SK_R9C'+str(pal)+suffix+'_Face.uasset';b,report=response(old.files[p][1],m,lab);ns=names(b);repl={n:n.replace('R9C','R9D')for n in ns if 'R9C'in n};imports={n:n.replace('R9C','R9D')for n in ns if n.startswith('/Game/')and 'R9C'in n};nn=Path(p).stem.replace('R9C','R9D');b=rename(b,repl,BASE+Path(p).stem,BASE+nn,imports=imports)
  t=Toc(str(live/f'pc{9432+v*6+pal-1}_mobile_and.utoc'));new=Bundle(t);p='character/RealFace/'+nn+'.uasset';new.files[p]=(new.files[p][0],b);new.base=oldt;new.output_name=Path(t.path).stem;new.write(live)
print('Refreshed mouth controls 8/9/16/17/19; body/LOD unchanged')
