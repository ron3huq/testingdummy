"""Export the exact published v25 Event squads for early Transfer validation.
Uses reference fixtures only, never a user's DB or cached native snapshot.
"""
import sys,json,tempfile,types,copy,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent.parent/'repair-full8-rc22-event-face'))
from host_reference import References
BASE=Path('/workspace/apk73-work/rc22-host/base');STAGE=Path('/workspace/apk73-work/rc23-full/payload');sys.meta_path.insert(0,References('/workspace/apk73-inputs/decoded/73efootball-V19.1.apk',BASE))
import club_store
with tempfile.TemporaryDirectory()as tmp:
 c=club_store.connect(Path(tmp)/'fixture.sqlite3');club_store.seed(c);c.commit()
 class Logic:
  def __init__(self):self.conn=c
  def handle(self,*a):return dict(result='NOERR')
 g=types.ModuleType('gateway');g._logic=Logic();g.manage=lambda*a:'{}';sys.path.insert(0,str(STAGE/'assets/gateway-release/work/tools'));import rc22_v25_events;rc22_v25_events.install(g);opp=rc22_v25_events._modules['opponent_squad'];players={};teams={}
 for cid,source,rows in [(122,'plan',opp.plan_squads()),(128,'wcplan',opp.wc_plan_squads())]:
  for index,row in enumerate(rows):
   for card in row.get('owned_cards',{}).values():
    pid=str(card['gameplayer_id']['id'])
    if len(card.get('parameters',[]))>=147:players[pid]=copy.deepcopy(card)
   built=opp.build(c,index,source=source);assert built is not None,(cid,index);tid=int(built['team_id']);payloads=built['player_list'];plan=built['squad_data']['squad_gameplan'];settings=plan['match_plan_settings'];order=[]
   for i in settings.get('order',[]):
    if type(i)is int and 0<=i<len(payloads)and i not in order:order.append(i)
   order +=[i for i in range(len(payloads))if i not in order];formation=plan['formation'][0]['formation_offensive'];roster=[]
   for slot,i in enumerate(order):
    p=payloads[i];f=formation[slot]if slot<11 else dict(role=int(p['parameters'][0]),position_x=0,position_y=0)
    roster.append(dict(id=str(p['gameplayer_id']['id']),shirt=int(p['uniform_number']),role=f['role'],x=f['position_x'],y=f['position_y']))
   def pid_at(i):return str(payloads[i]['gameplayer_id']['id'])if type(i)is int and 0<=i<len(payloads)else None
   teams[str(cid)+':'+str(tid)]=dict(team_id=tid,competition=cid,name=built.get('user_name')or str(tid),roster=roster,captain=pid_at(settings.get('captain')),kickers=[pid_at(i)for i in settings['set_piece_taker']],source='VERIFIED_V25_EVENT_SQUAD_PACKET',verified_formation=True)
 data=dict(schema=1,source='Exact published v25 cup modules and donor squad packets',players=players,teams=teams);out=Path(sys.argv[1]);out.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':'))+'\n');print(json.dumps(dict(passed=True,players=len(players),teams=len(teams),sha256=hashlib.sha256(out.read_bytes()).hexdigest()),indent=2))
