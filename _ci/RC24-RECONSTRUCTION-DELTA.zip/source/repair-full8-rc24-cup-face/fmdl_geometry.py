"""Retarget supplied PES FMDL face/hair to the audited Android head skeleton.
Keep source face/hair topology, fit only the lower neck to native body surface.
"""
import numpy as np,collections
from scipy.spatial import cKDTree
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from FmdlFile import FmdlFile
from lip_seal import lining as inner_lip_lining
import face_mesh
nearest=getattr(face_mesh,'nearest',None)or face_mesh._base.nearest

def load(path):
 m=FmdlFile();m.readFile(str(path));return m

def convert(meshes):
 p=[];t=[];uv=[];f=[];vertices=[]
 for mesh in meshes:
  index={id(v):len(p)+i for i,v in enumerate(mesh.vertices)}
  for v in mesh.vertices:
   p.append([v.position.x*100,v.position.z*100,v.position.y*100]);uv.append([v.uv[0].u,v.uv[0].v,0,0]);t.append([v.tangent.x,v.tangent.z,v.tangent.y,v.tangent.w,v.normal.x,v.normal.z,v.normal.y,-v.tangent.w]);vertices.append(v)
  f +=[[index[id(v)]for v in reversed(face.vertices)]for face in mesh.faces]
 return np.array(p,'<f4'),np.rint(np.clip(t,-1,1)*127).astype('i1').view('u1'),np.array(uv,'<f2'),np.array(f,'<u2'),vertices

def source_weights(vertices):
 out=[]
 direct={'sk_head':7,'sk_neck':6,'sk_chest':4,'dsk_neckback':5,'dsk_scm':6,'dsk_clavicle_l':4,'dsk_clavicle_r':4,'skf_eyelid_t_l':10,'skf_eyelid_b_l':11,'skf_eyelid_t_r':12,'skf_eyelid_b_r':13}
 for v in vertices:
  row=collections.defaultdict(float);left=v.position.x>0;corner=17 if left else 19;brow=18 if left else 20
  upper=sum(w for b,w in v.boneMapping.items()if b.name.startswith('skf_lip_t_'));lower=sum(w for b,w in v.boneMapping.items()if b.name.startswith('skf_lip_b_')or b.name in ['skf_jaw','skf_doublechin']);jaw=lower/(upper+lower)if upper+lower>.05 else .5
  for bone,w in v.boneMapping.items():
   n=bone.name
   if n in direct:targets={direct[n]:1}
   elif n=='skf_jaw'or n=='skf_doublechin':targets={8:.12,7:.88}
   elif n.startswith('skf_lip_b_'):targets={9:.12,7:.88}
   elif n.startswith('skf_lip_t_'):targets={16:.12,7:.88}
   elif n.startswith('skf_lip_s_'):targets={corner:.2,7:.8}
   elif n=='skf_lip_volume':targets={16:.12*(1-jaw),9:.12*jaw,7:.88}
   elif n.startswith('skf_brow'):targets={brow:1}
   elif n=='skf_glabella':targets={18:.5,20:.5}
   elif n.startswith('skf_orbicularisoculi'):targets={10 if left else 12:1}if v.position.y*100>=169.6785 else{11 if left else 13:1}
   elif n.startswith(('skf_cheek','skf_nasolabial')):targets={7:.9,corner:.1}
   elif n.startswith('skf_nose'):targets={7:1}
   else:raise ValueError('Unmapped source face control: '+n)
   for k,a in targets.items():row[k]+=w*a
  assert row and sum(row.values())>.99
  out.append(dict(row))
 return out

def quantize(rows,bones):
 out=np.zeros((len(rows),8),'u1')
 for i,row in enumerate(rows):
  pairs=sorted(((k,v)for k,v in row.items()if v>1e-8),key=lambda kv:-kv[1])[:4];total=sum(v for k,v in pairs);values=np.array([v*255/total for k,v in pairs]);q=np.floor(values).astype(int)
  for j in np.argsort(-(values-q))[:255-q.sum()]:q[j]+=1
  for j,((k,_),v)in enumerate(zip(pairs,q)):out[i,j]=bones.index(k);out[i,j+4]=v
 assert np.all(out[:,4:].sum(1)==255);return out

def neck_fit(p,t,rows,native_positions,native_faces,native_weights,native_tangent):
 chosen=native_faces[np.all(native_positions[native_faces,2]<159.5,axis=1)];tree=cKDTree(native_positions[chosen].mean(1));moves=[];neck_native={}
 for i in np.flatnonzero(p[:,2]<158.5):
  point=p[i].astype(float);_,near=tree.query(point,k=min(48,len(chosen)));face=chosen[np.atleast_1d(near)];q,bc,j=nearest(point,native_positions[face].astype(float));v=face[j];blend=np.clip((155-point[2])/5,0,1);position_blend=np.clip((149-point[2])/6,0,1);p[i]=point*(1-position_blend)+q*position_blend;moves.append(float(np.linalg.norm(p[i]-point)))
  weights=bc@native_weights[v]/255;merged={k:a*(1-blend)for k,a in rows[i].items()}
  for k in np.flatnonzero(weights>1e-8):merged[int(k)]=merged.get(int(k),0)+weights[k]*blend
  rows[i]=merged
  for offset in [0,4]:
   a=t[i,offset:offset+3].copy().view('i1')/127;b=bc@(native_tangent[v,offset:offset+3].copy().view('i1')/127);normal=a*(1-position_blend)+b*position_blend;normal/=max(np.linalg.norm(normal),1e-9);t[i,offset:offset+3]=np.rint(np.clip(normal,-1,1)*127).astype('i1').view('u1')
  if blend==1:neck_native[int(i)]=(v.tolist(),bc.tolist())
 return dict(lower_neck_vertices=len(moves),max_neck_fit_cm=max(moves,default=0),source_upper_neck_and_head_not_projected=True),neck_native

def build(inputs,native):
 # Native arrays: positions, triangles, tangents, UVs, global weights, labels.
 np_,nf,nt,nu,nw,nlab=native;face=load(inputs/'face_high.fmdl');hair=load(inputs/'hair_high.fmdl')
 skin=[m for m in face.meshes if m.materialInstance.name=='fox_skin_mat']+[m for m in hair.meshes if m.materialInstance.name in ['fox_skin_mat','fox_head_shell_mat']]
 p,t,uv,f,verts=convert(skin);source_triangles=len(f);original=p.copy();rows=source_weights(verts);fit,neck_native=neck_fit(p,t,rows,np_,nf,nw,nt)
 upper=np.array([sum(w for b,w in v.boneMapping.items()if b.name.startswith('skf_lip_t_'))for v in verts]);lower=np.array([sum(w for b,w in v.boneMapping.items()if b.name.startswith('skf_lip_b_'))for v in verts])
 mouth=(upper+lower)>.25;front=float(np.percentile(p[mouth,1],90));seal=float(np.median(p[mouth,2]));before_contact=p.copy();ui=np.flatnonzero((upper>.7)&(p[:,1]>14));li=np.flatnonzero((lower>.7)&(p[:,1]>14));links=[]
 for a,b in [(ui,li),(li,ui)]:
  dist,ix=cKDTree(p[b]).query(p[a])
  links +=[(int(i),int(b[j]))for i,j,d in zip(a,ix,dist)if d<.18]
 contact=[];centers=[]
 if links:
  edges=np.array(links);groups=connected_components(coo_matrix((np.ones(len(edges)),(edges[:,0],edges[:,1])),shape=(len(p),len(p))),directed=False)[1]
  for group in set(groups[edges.reshape(-1)]):
   ids=np.flatnonzero(groups==group);up=upper[ids]>lower[ids]
   if up.all()or not up.any():continue
   center=p[ids].mean(0);centers.append(center);p[ids]=center;p[ids,2]+=np.where(up,-.025,.025)
   for i in ids:
    moved=0
    for k in [8,9,16,17,19]:
     value=rows[i].get(k,0);rows[i][k]=value*.25;moved+=value*.75
    rows[i][7]=rows[i].get(7,0)+moved
   contact+=ids.tolist()
 if centers:seal=float(np.median(np.array(centers)[:,2]))
 # Split only internal lip-wall UV triangles into their own dark cavity island.
 # Their positions/weights and the triangle surface stay unchanged.
 kind=np.where(p[:,2]<156,34,0).astype(int);uv[:,:2]*=.5;lining=[];p_extra=[];t_extra=[];uv_extra=[];row_extra=[];kind_extra=[]
 strength=upper+lower
 for ti,face_ids in enumerate(f):
  q=p[face_ids]
  if np.all(strength[face_ids]>.75)and np.max(abs(q[:,0]))<1.7 and q[:,1].max()<front-.8 and q[:,2].min()>seal-1.2 and q[:,2].max()<seal+1.2:
   newids=[]
   for i in face_ids:
    newids.append(len(p)+len(p_extra));p_extra.append(p[i].copy());t_extra.append(t[i].copy());u=uv[i].copy();u[:2]=[.9375,.8125];uv_extra.append(u);row_extra.append(dict(rows[i]));kind_extra.append(5)
   f[ti]=newids;lining+=newids
 if p_extra:p=np.concatenate([p,np.array(p_extra)]);t=np.concatenate([t,np.array(t_extra)]);uv=np.concatenate([uv,np.array(uv_extra)]);rows+=row_extra;kind=np.r_[kind,kind_extra]
 sp,st,su,sr,sc,sf=inner_lip_lining(centers,recess=.35);sf=sf+len(p);f=np.concatenate([f,sf]);p=np.concatenate([p,sp]);t=np.concatenate([t,st]);uv=np.concatenate([uv,su]);rows+=sr;kind=np.r_[kind,np.full(len(sp),5)]
 contact_report=dict(lip_contact_vertices=len(contact),max_local_lip_contact_delta_cm=float(np.linalg.norm(before_contact-p[:len(before_contact)],axis=1).max()),source_head_preserved_except_local_lip_contact=True)
 # Native oral/ocular islands retain real independently animated geometry.
 oral=np.flatnonzero(np.isin(nlab,[28,29,30,31,32,33]));index={int(v):len(p)+i for i,v in enumerate(oral)};of=nf[np.isin(nf,oral).all(1)];of=np.array([[index[int(i)]for i in row]for row in of],'<u2');op=np_[oral].copy();ot=nt[oral].copy();ou=nu[oral].copy();ok=nlab[oral].copy()
 omask=np.isin(ok,[28,29,30,31]);mouth_x=float(np.mean(np.array(centers)[:,0]))if centers else float(np.median(p[:len(verts)][mouth,0]));op[omask,0]=(op[omask,0]+.25)*.75+mouth_x;op[omask,2]+=seal-163.6;op[omask,1]+=front-17.0-.6
 occlusion=next(m for m in face.meshes if m.materialInstance.name=='fox_eyeOcclusion_mat');eye_points=np.array([[v.position.x*100,v.position.z*100,v.position.y*100]for v in occlusion.vertices])
 for label,left in [(32,True),(33,False)]:
  ids=np.flatnonzero(ok==label);target=eye_points[eye_points[:,0]>0]if left else eye_points[eye_points[:,0]<0];center=op[ids].mean(0);dest=target.mean(0);dest[1]-=.55;scale=np.clip(np.ptp(target[:,0])/max(np.ptp(op[ids,0]),1e-6),.8,1.0);op[ids]=(op[ids]-center)*scale+dest
 orows=[{int(k):float(w/255)for k,w in enumerate(nw[i])if w}for i in oral]
 ns=len(p)+len(op);tri=np.concatenate([f,of]);p=np.concatenate([p,op]);t=np.concatenate([t,ot]);uv=np.concatenate([uv,ou]);kind=np.r_[kind,ok];rows+=orows
 hp,ht,hu,hf,hverts=convert([m for m in hair.meshes if m.materialInstance.name=='fox_hair_mat']);hf=hf+ns;rows +=[{7:1.}for _ in hp];p=np.concatenate([p,hp]);t=np.concatenate([t,ht]);uv=np.concatenate([uv,hu]);kind=np.r_[kind,np.full(len(hp),-1)];tri=np.concatenate([tri,hf]);colors=np.full((len(p),4),255,'u1')
 assert tri.max()<len(p)<65536
 report=dict(source_skin_vertices=len(original),source_hair_vertices=len(hp),source_skin_triangles=source_triangles,internal_lip_lining_vertices=len(sp),internal_lip_lining_triangles=len(sf),source_hair_triangles=len(hf),source_skin_triangle_surface_preserved_except_lip_contact=True,source_hair_geometry_UV_preserved=True,native_oral_eyes_separate_vertices=len(oral),inner_mouth_lining_vertices=len(lining),mouth_seal_z_cm=seal,mouth_front_y_cm=front,mouth_center_x_cm=mouth_x,native_oral_arch_width_scale=.75,native_oral_recess_cm=.6,**contact_report,**fit)
 return (p,t,uv,rows,colors,tri,ns,len(f)+len(of),kind),report,neck_native
