"""Studio geometry preview only; no claim to emulate the game renderer."""
import bpy,numpy as np,sys
from pathlib import Path
from mathutils import Vector
out=Path(sys.argv[sys.argv.index('--')+1])
for year in ['2007','2020']:
 bpy.ops.wm.read_factory_settings(use_empty=True);d=np.load(out/year/'mesh.npz');p=d['p']*np.array([1,-1,1])/100;f=d['f'];uv=d['uv'];ns=int(d['skin_tris']);mesh=bpy.data.meshes.new('Cooked');mesh.from_pydata(p.tolist(),[],f.tolist());mesh.update();obj=bpy.data.objects.new(year,mesh);bpy.context.collection.objects.link(obj);layer=mesh.uv_layers.new()
 for poly in mesh.polygons:
  poly.use_smooth=True
  for li,vi in zip(poly.loop_indices,poly.vertices):layer.data[li].uv=(float(uv[vi,0]),float(1-uv[vi,1]))
 for label in ['face','hair']:
  mat=bpy.data.materials.new(label);mat.use_nodes=True;n=mat.node_tree.nodes;bs=n.get('Principled BSDF');tex=n.new('ShaderNodeTexImage');tex.image=bpy.data.images.load(str(out/year/(label+'.png')));mat.node_tree.links.new(tex.outputs['Color'],bs.inputs['Base Color']);bs.inputs['Roughness'].default_value=.75;bs.inputs['Specular IOR Level'].default_value=.15
  if label=='hair':
   mat.node_tree.links.new(tex.outputs['Alpha'],bs.inputs['Alpha']);mat.surface_render_method='DITHERED'
  mesh.materials.append(mat)
 for i,poly in enumerate(mesh.polygons):poly.material_index=int(i>=ns)
 scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=12;scene.cycles.use_denoising=False;scene.render.resolution_x=540;scene.render.resolution_y=700;scene.render.resolution_percentage=100;scene.world=bpy.data.worlds.new('Studio');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.1,.1,.1,1)
 for name,loc,power in [('Key',(-2,-3,4),380),('Fill',(2,-1,2.5),180)]:
  l=bpy.data.lights.new(name,'AREA');l.energy=power;l.size=3;o=bpy.data.objects.new(name,l);scene.collection.objects.link(o);o.location=loc;o.rotation_euler=(Vector((0,0,1.65))-o.location).to_track_quat('-Z','Y').to_euler()
 cam=bpy.data.objects.new('Camera',bpy.data.cameras.new('Camera'));scene.collection.objects.link(cam);scene.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=.46;target=Vector((0,-.05,1.63));scene.view_settings.view_transform='Standard'
 for label,loc in [('front',(0,-3,1.65)),('angle',(1.8,-3,1.65))]:
  cam.location=loc;cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(out/(year+'-'+label+'.png'));bpy.ops.render.render(write_still=True)
