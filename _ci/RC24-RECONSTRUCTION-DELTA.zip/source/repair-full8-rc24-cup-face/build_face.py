"""RC24: preserve every position/UV/LOD and arm weight; calibrate only mouth response and shading."""
from pathlib import Path
import sys,json,struct,numpy as np,hashlib
SRC=Path(__file__).resolve().parents[1];sys.path[:0]=[str(SRC/'repair-full8-rc22-event-face'),str(SRC/'repair-full8-rc7'),str(SRC/'repair-full8-rc9-ucl'),str(SRC/'repair-full8-rc10-face-detail'),str(SRC/'repair-full8-rc4'),'/workspace/apk73-work/rc7/source/repair-full8-rc4']
from iostore import Toc
from ci_bundle import Bundle
from zen_clone import rename,pid
from mesh_tools import Mesh
from validate_face import read_lod,buffers,global_weights
from face_mesh import labels
from face_texture_base import patch_blocks
from bundle_tools import decode_first_texture
from lip_seal import seal_existing
import face_texture
BASE='/Game/Assets/character/RealFace/'
def response(raw,m,lab):
 b=bytearray(raw);lod=read_lod(raw,m.lods[0]);p,f,t,u,w=buffers(raw,lod);count=len(lab);skin=(lab<28);mouth=np.zeros(len(p),float);x,y,z=p[:count].T
 # Local rig-response correction, not another inflation of lip geometry.
 support=np.exp(-(abs(x)/4.2)**8)*np.clip((y-9.8)/2.0,0,1)*np.exp(-((z-163.6)/2.3)**8)
 mouth[:count]=support*((lab<28)|np.isin(lab,[29,30]));mouth[np.flatnonzero(np.isin(lab,[29,30]))]=1
 weights=w.copy();bones=lod['sections'][0]['bones'];head=bones.index(7);global_before=global_weights(lod['sections'],w)
 for i in np.flatnonzero(mouth>1e-5):
  values={}
  for k,v in zip(w[i,:4],w[i,4:]):
   if v:values[int(k)]=values.get(int(k),0)+int(v)
  moved=0
  for k in list(values):
   if bones[k]in [8,9,16,17,19]:
    delta=int(round(values[k]*.80*mouth[i]));values[k]-=delta;moved+=delta
  values[head]=values.get(head,0)+moved;values={k:v for k,v in values.items()if v};assert len(values)<=4
  weights[i]=0
  for j,(k,v)in enumerate(sorted(values.items())):weights[i,j]=k;weights[i,j+4]=v
 assert np.all(weights[:,4:].sum(1)==255)
 weight_at=lod['stream']+2+9+f.size*2+16+p.nbytes+26+t.nbytes+8+u.nbytes+30;b[weight_at:weight_at+weights.nbytes]=weights.tobytes()
 global_after=global_weights(lod['sections'],weights);keep=np.r_[lab>=31,np.ones(len(p)-count,bool)];assert np.array_equal(global_before[keep],global_after[keep]);assert np.array_equal(weights[np.flatnonzero(lab==34)],w[np.flatnonzero(lab==34)])
 sealed,seam=seal_existing(bytes(b),m,lab)
 return sealed,dict(outer_geometry_UV_body_rest_pose_exact_RC23=True,body_neck_hair_weights_exact_RC23=True,local_mouth_jaw_lip_corner_response_scale=.20,changed_mouth_weight_vertices=int(np.count_nonzero(np.any(weights!=w,axis=1))),**seam)
def textures(raw,bulk,ch,e):
 im=decode_first_texture(raw,bulk);a=np.array(im);skin=np.array(e['skin'])>0;oral=(np.array(e['teeth'])>0)|(np.array(e['tongue'])>0)|(np.array(e['cavity'])>0);mask=oral.copy();x,y,z=e['xyz'].transpose(2,0,1)
 # The inner-lining UVs all use this padded cavity region.
 h,w=skin.shape;yy,xx=np.mgrid[:h,:w];oral|=(abs(xx-w*.9375)<21)&(abs(yy-h*.8125)<21)
 if ch=='D':
  # Remove the remaining broad red cast at the cheek/upper-neck relative to
  # the native body palette, with a continuous transition across the neck.
  blend=np.clip((z-155.5)/4,0,1)*e['valid'];a[skin,0]=np.rint(a[skin,0]*(1-.03*blend[skin])).astype('u1');a[skin,2]=np.minimum(np.rint(a[skin,2]*(1+.015*blend[skin])),255).astype('u1');a[oral,:3]=[3,3,3];mask=skin|oral
 else:
  assert ch=='SRO'
  # Same restrained response across head and upper/lower custom neck, instead
  # of the bright, different photographed specular layers retained in RC23.
  a[skin,0]=20;a[skin,1]=210;a[skin,2]=255;a[oral,0]=0;a[oral,1]=255;a[oral,2]=0;mask=skin|oral
 return patch_blocks(raw,bulk,__import__('PIL.Image',fromlist=['Image']).fromarray(a,'RGBA'),__import__('PIL.Image',fromlist=['Image']).fromarray(np.uint8(mask)*255))
def run(root,report):
 root=Path(root);live=root/'assets/gateway-release/livedata';logs=json.loads((root/'source/repair-full8-rc7/mesh-ranges.json').read_text());rows=[]
 for v,suffix in enumerate(['','ep00v0313','ep01v0291','lg00v0000']):
  original=Toc(str(live/f'pc{9356+v}_mobile_and.utoc'));p='character/RealFace/SK_RG28'+suffix+'_Face.uasset';m=Mesh(original.read(original.files[p]),logs['SK_RG27'+suffix+'_Face'],lod_index=1);lab=labels(m)
  for pal in range(1,7):
   toc=Toc(str(live/f'pc{9408+v*6+pal-1}_mobile_and.utoc'));old=Bundle(toc);data=dict(old.files);prefix='character/RealFace/T_R9C'+str(pal)+suffix+'_Face_';d=decode_first_texture(data[prefix+'D.uasset'][1],data[prefix+'D.ubulk'][1]);face_texture.masks(m,lab,d.size);e=face_texture._EXTRA['current'];checks={};geo=None
   for p,(ids,b)in list(data.items()):
    if Path(p).name.startswith('SK_'):data[p]=(ids,response(b,m,lab)[0]);geo=response(b,m,lab)[1]
   for ch in ['D','SRO']:
    if prefix+ch+'.uasset'not in data:continue
    ra,bu,info=textures(data[prefix+ch+'.uasset'][1],data[prefix+ch+'.ubulk'][1],ch,e);data[prefix+ch+'.uasset']=(data[prefix+ch+'.uasset'][0],ra);data[prefix+ch+'.ubulk']=(data[prefix+ch+'.ubulk'][0],bu);checks[ch]=info
   mapping={BASE+Path(p).stem:BASE+Path(p).stem.replace('R9C','R9D')for p in data if p.endswith('.uasset')}
   for quality in ['HQ','MQ']:
    a=BASE+'MI_R9C'+str(pal)+'01_Head_FaceLegacy_'+quality;mapping[a]=a.replace('R9C','R9D')
   for ch in ['SRO','N']:
    a=BASE+'T_R9C2'+suffix+'_Face_'+ch;mapping[a]=a.replace('R9C','R9D')
   repl={}
   for a,z in mapping.items():repl[a]=z;repl[Path(a).name]=Path(z).name
   remap={pid(a):pid(z)for a,z in mapping.items()};new=Bundle(toc);new.files={};new.entries={}
   for p,(ids,b)in data.items():
    name=Path(p).stem;nn=name.replace('R9C','R9D');entry=None
    if p.endswith('.uasset'):
     fixed,deps=old.entries[int.from_bytes(ids[:8],'little')];entry=(fixed,[remap.get(x,x)for x in deps]);b=rename(b,repl,BASE+name,BASE+nn,imports=mapping)
    new.put('character/RealFace/'+nn+Path(p).suffix,struct.pack('<Q',pid(BASE+nn))+b'\0\0\0'+(b'\2'if p.endswith('.uasset')else b'\3'),b,entry)
   new.output_name=f'pc{9432+v*6+pal-1}_mobile_and';new.write(live);rows.append(dict(variant=suffix or'base',palette=pal,geometry=geo,texture=checks));print('Built',new.output_name,flush=True)
 Path(report).write_text(json.dumps(dict(passed=True,assets=24,reports=rows,phone_verified=False),indent=2)+'\n')
if __name__=='__main__':run(*sys.argv[1:])
