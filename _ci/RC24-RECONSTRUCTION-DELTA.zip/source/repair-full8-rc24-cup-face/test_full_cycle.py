"""V19 captured packets + original V25 cup code/UI snapshots on fixture saves."""
import sys,json,copy,tempfile,types,msgpack
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent.parent/'repair-full8-rc22-event-face'))
from host_reference import References
BASE=Path('/workspace/apk73-work/rc22-host/base');STAGE=Path('/workspace/apk73-work/rc24-full/payload')
sys.meta_path.insert(0,References('/workspace/apk73-inputs/decoded/73efootball-V19.1.apk',BASE))
import club_store,cup_entry,my_league,opponent_squad
originals=(my_league.prepare,my_league.start,my_league.finish,opponent_squad.preset)
responses={}
for p in(BASE/'outputs/reference/decrypted').glob('*_resp.txt'):
 try:
  obj=msgpack.unpackb(p.read_bytes(),raw=False,strict_map_key=False)
  if isinstance(obj,dict):responses[p.name.split('_gate_',1)[-1].removesuffix('_resp.txt')]=obj
 except (ValueError,msgpack.UnpackException,UnicodeError):pass
opened=[]
class AndroidPanelBoundary:
 @staticmethod
 def openFromGateway(event):opened.append(event)
java=types.ModuleType('java')
def jclass(name):
 if name!='org.efootballrevival.runtimeprobe.CupTournamentPanel':raise ImportError('Android boundary not provided: '+name)
 return AndroidPanelBoundary
java.jclass=jclass;sys.modules['java']=java
class Logic:
 def __init__(self,conn):self.conn=conn;self.responses=responses;self.templates={}
 def handle(self,mid,req):
  response=cup_entry.handle(self,mid,req)
  if response is not None:return response
  response=copy.deepcopy(self.responses.get(mid,dict(result='NOERR')));response.update(msgid=mid,rqid=req.get('rqid'))
  return cup_entry.project(self,response)if mid in cup_entry.LIST_COMMANDS else response
with tempfile.TemporaryDirectory()as tmp:
 conn=club_store.connect(Path(tmp)/'fixture.sqlite3');club_store.seed(conn);extra=copy.deepcopy(club_store.players(conn)[0]);extra['gameplayer_id']['serial']+=1;club_store.upsert_player(conn,extra,source='host-fixture');club_store.install_special_coaches(conn);conn.commit()
 sentinel='normal-My-League-untouched';club_store.set_meta(conn,'my_league_state_v1',sentinel);conn.commit()
 gateway=types.ModuleType('fixture_gateway');gateway._logic=Logic(conn);gateway.manage=lambda *a:'original-manage'
 sys.path.insert(0,str(STAGE/'assets/gateway-release/work/tools'));import rc22_v25_events
 assert rc22_v25_events.install(gateway)
 sys.path.insert(0,'/workspace/testingdummy/source/repair-full8-rc24-cup-face/runtime')
 import rc24_cups
 assert rc24_cups.install(gateway,rc22_v25_events._modules)
 assert not rc22_v25_events.install(gateway)
 assert originals==(my_league.prepare,my_league.start,my_league.finish,opponent_squad.preset)
 assert gateway.manage('not-a-cup-action')=='original-manage'
 # Guard against accidental activation of the old My League bridge.
 legacy=rc22_v25_events._modules['my_league_e112_candidate']
 legacy.activate_group=lambda *a:(_ for _ in()).throw(AssertionError('legacy My League group was activated'))
 entries=gateway._logic.handle('CMD_GET_EVENT_LIST_AND_LOG',dict(rqid=1))
 listed={e['event_id']for e in entries['event_list']}
 assert {1120006,1120010}<=listed,listed
 snapshots={}
 for spec in ['ucl','wc']:
  donor=rc22_v25_events._modules['cup_entry'];s=donor.cup_spec.SPECS[spec];service=donor._ucl_service(gateway._logic,s);state=service._ensure_entered()
  assert len(state['teams'])==32 and len(state['groups'])==8 and not s.knockout_two_legs
  response=gateway._logic.handle('CMD_GET_EVENT_COMPE_INFO',dict(event_id=s.group_event_id,match_category='EVENT_COM',rqid=2))
  assert response['result']=='NOERR',response
  snap=json.loads(gateway.manage('ucl_ui_snapshot',json.dumps(dict(eventId=s.group_event_id))))
  assert snap['entered']and len(snap['groups'])==8,snap
  own_refs=[dict(gameplayer_id=p['gameplayer_id'])for p in club_store.players(conn)]
  assert len(own_refs)==11
  first=own_refs[0]['gameplayer_id'];second=own_refs[1]['gameplayer_id']
  for match_index in range(7):
   event=s.group_event_id if match_index<3 else s.knockout_event_id
   gateway._logic.handle('CMD_GET_EVENT_LIST_AND_LOG',dict(rqid=10+match_index))
   entered=gateway._logic.handle('CMD_SET_EVENT_ENTER',dict(event_id=event,select_team_id=club_store.club_team_id(conn),rqid=20+match_index))
   assert entered['result']=='NOERR'
   frame_command='CMD_GET_EVENT_COMPE_GROUP_STAGE_DRAW'if match_index<3 else'CMD_GET_EVENT_COMPE_TOURNAMENT_MATCH_LIST'
   frame=gateway._logic.handle(frame_command,dict(event_id=event,compe_unit_id=s.group_compe_unit_id if match_index<3 else s.knockout_compe_unit_id,rqid=25+match_index))
   assert frame['result']=='NOERR',frame
   prepared=gateway._logic.handle('CMD_GET_VSCOM_OPPONENT',dict(event_id=event,match_category='EVENT_COM',rqid=30+match_index))
   assert prepared['result']=='NOERR';assert prepared['cpu_level']=='LEGEND';gid=prepared['game_id']
   start_request=dict(event_id=event,game_id=gid,side='HOME',coach=club_store.coaches(conn)[0],player_list_home=own_refs,match_category='EVENT_COM',rqid=40+match_index)
   started=gateway._logic.handle('CMD_START_GAME',start_request)
   assert started['result']=='NOERR',started
   assert len(started['squad_data_home']['player_list'])==11
   final=match_index==6
   detail=dict(game_id=gid,pk_flag='YES'if final else'NO',abnormalend_reason='NOERR',goal_player_list=[]if final else[first,first],assist_player_list=[]if final else[second],myteam_player_list=[dict(gameplayer_id=first,is_man_of_the_match='YES',is_join_game='YES')])
   score=[dict(score_1st=0 if final else 2,score_2nd=0,score_pk=4 if final else 0),dict(score_1st=0,score_2nd=0,score_pk=3 if final else 0)]
   request=dict(event_id=event,match_result=detail,score=score,rqid=50+match_index)
   result=gateway._logic.handle('CMD_GET_VSCOM_GAME_RESULT',request)
   assert result['result']=='NOERR',result
   a=json.loads(gateway.manage('ucl_ui_snapshot',json.dumps(dict(eventId=event))))['awards']
   repeated=gateway._logic.handle('CMD_GET_VSCOM_GAME_RESULT',dict(request,rqid=60+match_index))
   b=json.loads(gateway.manage('ucl_ui_snapshot',json.dumps(dict(eventId=event))))['awards']
   assert repeated['result']=='NOERR'and a==b,'duplicate result changed cup awards'
   print(spec,'match',match_index+1,'PASS',file=sys.stderr,flush=True)
  final_state=donor._cup16_service(gateway._logic,s).mode.state(s.knockout_event_id)
  assert final_state['phase']=='CHAMPION'and not final_state.get('two_legs')
  Path('/workspace/apk73-work/rc24-research/'+spec+'-final-state.json').write_text(json.dumps(final_state,indent=2))
  award=json.loads(gateway.manage('ucl_ui_snapshot',json.dumps(dict(eventId=s.knockout_event_id))))['awards']
  assert award['games']==7,award
  own=next(p for p in award['boards']['goals']if p['id']==first['id']);assert own['goals']==12,own
  own_assists=next(p for p in award['boards']['assists']if p['id']==second['id']);assert own_assists['assists']==6,own_assists
  assert award['simulation_games']==56 and any(p['team_id']!=club_store.club_team_id(conn)for p in award['boards']['goals'])
  assert json.loads(gateway.manage('ucl_ui_snapshot',json.dumps(dict(eventId=event))))['cpuLevel']=='LEGEND'
  print('AWARDS',spec,json.dumps({k:award[k]for k in ['games','simulation_games','unattributed_goals','coverage_complete']}),file=sys.stderr)
  reset=json.loads(gateway.manage('cup_reset',json.dumps(dict(eventId=s.group_event_id))))
  fresh=json.loads(gateway.manage('ucl_ui_snapshot',json.dumps(dict(eventId=s.group_event_id))))['awards']
  assert fresh['games']==0
  import rc22_cup_awards
  assert not rc22_cup_awards.record(conn,request,rc22_v25_events._modules)
  assert json.loads(gateway.manage('ucl_ui_snapshot',json.dumps(dict(eventId=s.group_event_id))))['awards']==fresh
  snapshots[spec]=dict(event_id=s.group_event_id,group_count=len(snap['groups']),snapshot_keys=sorted(snap))
 assert club_store.get_meta(conn,'my_league_state_v1')==sentinel
 assert club_store.get_meta(conn,'my_league_ucl_group_active','0')=='0'
 assert not any(n.startswith('ucl_lp_')for n in sys.modules)
 assert {1120006,1120007,1120010,1120011}<=set(opened),opened
 print(json.dumps(dict(passed=True,original_v25_event_ids=True,v19_captured_messagepack_templates=True,private_donor_modules=len(rc22_v25_events._modules),global_my_league_and_opponent_functions_preserved=True,no_legacy_my_league_activation=True,no_rc21_ucl_imports=True,events=snapshots,normal_save_unchanged=True,complete_cups=2,native_packet_prepare_start_finish_cycles=14,duplicate_results_deduplicated=True,single_leg_knockout_and_deciding_shootout=True,cross_group_knockout_awards_scope_verified=True,new_cup_does_not_inherit_old_result_awards=True,owned_player_and_coach_fixtures=True,event_panel_opener_boundary_called_for_both_cups_and_phases=True,android_java_opener_not_executed=True,phone_verified=False),indent=2))
