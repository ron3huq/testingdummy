from pathlib import Path
import sys,subprocess,json,hashlib,re,shutil
SRC=Path(__file__).resolve().parent;ROOT=Path('/workspace/apk73-work/rc7');OUT=Path(sys.argv[1]);OUT.mkdir(parents=True,exist_ok=True);java='/usr/lib/jvm/java-21-openjdk-amd64/bin/java';jar=ROOT/'.ci-full8-rc5/apktool.jar';tool=ROOT/'source/repair-full8-rc4/DexTool.java';deps=Path('/workspace/deps/android-ui')
def run(*args):subprocess.run(list(map(str,args)),check=True,stdout=subprocess.DEVNULL)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for n in ['classes','extra','smali','verify','extra-smali']:
 shutil.rmtree(OUT/n,ignore_errors=True)
classes=OUT/'classes';run(java,'-m','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-cp',str(deps/'android.jar')+':'+str(deps/'json.jar'),'-d',classes,SRC/'java-stubs/CupTournamentPanel.java',SRC/'java-stubs/TransferEditor.java',SRC/'java/org/efootballrevival/runtimeprobe/CupExtras.java')
extra=OUT/'extra';extra.mkdir(exist_ok=True);run(java,'-cp',deps/'r8.jar','com.android.tools.r8.D8','--min-api','24','--no-desugaring','--lib',deps/'android.jar','--lib',deps/'json.jar','--output',extra,*sorted(classes.glob('org/efootballrevival/runtimeprobe/CupExtras*.class')))
smali=OUT/'smali';run(java,'-cp',jar,tool,'d','/workspace/apk73-work/rc23-full/payload/classes5.dex',smali);before={p.relative_to(smali).as_posix():sha(p)for p in smali.rglob('*.smali')};xs=OUT/'extra-smali';run(java,'-cp',jar,tool,'d',extra/'classes.dex',xs)
for p in xs.rglob('*.smali'):
 dest=smali/p.relative_to(xs);dest.parent.mkdir(exist_ok=True,parents=True);assert not dest.exists();shutil.copy2(p,dest)
p=smali/'org/efootballrevival/runtimeprobe/CupTournamentPanel.smali';s=p.read_text();cls='Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;'
new='''.method private rc22AwardsButton(Landroid/widget/FrameLayout;)V
 .registers 2
 invoke-static {p0,p1}, Lorg/efootballrevival/runtimeprobe/CupExtras;->addButtons(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Landroid/widget/FrameLayout;)V
 return-void
.end method''';s,n=re.subn(r'\.method private rc22AwardsButton\(Landroid/widget/FrameLayout;\)V.*?\.end method',lambda m:new,s,flags=re.S);assert n==1
new='''.method public rc22ShowAwards()V
 .registers 2
 const-string v0, "goals"
 invoke-static {p0,v0}, Lorg/efootballrevival/runtimeprobe/CupExtras;->show(Lorg/efootballrevival/runtimeprobe/CupTournamentPanel;Ljava/lang/String;)V
 return-void
.end method''';s,n=re.subn(r'\.method public rc22ShowAwards\(\)V.*?\.end method',lambda m:new,s,flags=re.S);assert n==1
for method,field,typ in [('rc24Activity','activity','Landroid/app/Activity;'),('rc24Snapshot','snapshot','Lorg/json/JSONObject;'),('rc24Event','eventId','I'),('rc24English','english','Z')]:
 op='iget-object'if typ.startswith('L')else'iget-boolean'if typ=='Z'else'iget';ret='return-object'if typ.startswith('L')else'return';s+=f'\n.method public {method}(){typ}\n .registers 2\n {op} v0,p0,{cls}->{field}:{typ}\n {ret} v0\n.end method\n'
for method,callee,signature,reg in [('rc24Context','ui','()Landroid/content/Context;',2),('rc24Card','card','()Landroid/widget/LinearLayout;',2),('rc24Pill','pillButton','(Ljava/lang/String;Z)Landroid/widget/TextView;',4),('rc24Text','text','(Ljava/lang/String;IIZ)Landroid/widget/TextView;',6),('rc24Crest','crestView','(ILjava/lang/String;I)Landroid/view/View;',5)]:
 args=['p'+str(i)for i in range(reg-1)];s+=f'\n.method public {method}{signature}\n .registers {reg}\n invoke-direct {{'+','.join(args)+f'}}, {cls}->{callee}{signature}\n move-result-object v0\n return-object v0\n.end method\n'
s+=f'\n.method public rc24Close()V\n .registers 1\n invoke-direct {{p0}}, {cls}->close()V\n return-void\n.end method\n';p.write_text(s)
p=smali/'org/efootballrevival/runtimeprobe/TransferEditor.smali';s=p.read_text();s+='''
.method public static showForCup(Landroid/app/Activity;I)V
 .registers 8
 new-instance v0,Lorg/json/JSONObject;
 invoke-direct {v0},Lorg/json/JSONObject;-><init>()V
 const-string v1,"competition"
 invoke-virtual {v0,v1,p1},Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
 new-instance v1,Lorg/efootballrevival/runtimeprobe/TransferEditor$$ExternalSyntheticLambda4;
 invoke-direct {v1,p0},Lorg/efootballrevival/runtimeprobe/TransferEditor$$ExternalSyntheticLambda4;-><init>(Landroid/app/Activity;)V
 const/4 v2,0x0
 const-string v3,"rc24_cup_transfer_list"
 invoke-static {p0,v2,v3,v0,v1},Lorg/efootballrevival/runtimeprobe/TransferEditor;->request(Landroid/app/Activity;Landroid/widget/Button;Ljava/lang/String;Lorg/json/JSONObject;Lorg/efootballrevival/runtimeprobe/TransferEditor$Result;)V
 return-void
.end method
''';p.write_text(s)
output=OUT/'classes5.dex';run(java,'-cp',jar,tool,'a',smali,output);verify=OUT/'verify';run(java,'-cp',jar,tool,'d',output,verify);after={p.relative_to(verify).as_posix():sha(p)for p in verify.rglob('*.smali')};changed=sorted(n for n,h in before.items()if after[n]!=h);expected=['org/efootballrevival/runtimeprobe/CupTournamentPanel.smali','org/efootballrevival/runtimeprobe/TransferEditor.smali'];assert changed==expected,changed
report=dict(passed=True,baseline_classes=len(before),unchanged_classes=len(before)-len(changed),changed_existing_classes=changed,added_classes=len(after)-len(before),donor_card_fonts_pills_crests_reused=True,java_compiled_and_DEX_roundtrip=True,new_dex_sha256=sha(output),dependencies={p.name:sha(p)for p in deps.glob('*.jar')},android_ui_executed=False,phone_verified=False);(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
