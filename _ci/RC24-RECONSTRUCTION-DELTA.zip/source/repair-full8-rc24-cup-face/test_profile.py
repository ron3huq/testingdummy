from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).parent.parent/'repair-full8-rc9-ucl'))
from test_face_profile import Runner
stage=Path(sys.argv[1]);meta=json.loads((stage/'profile-build.json').read_text());old=Runner(stage/'rc7-noodle.so');new=Runner(stage/'face-noodle.so');cards={'89138556572074':'R9D','106783356083208':'R7A','88043608522885':'R0A'};controls=[106654775417922,106782819217056,88035555413452,105756321970183,123,89138556572073,89138556572075];expected={k:v+'2'for k,v in cards.items()}
for card,prefix in cards.items():
 for pal in range(1,7):
  assert new.call(meta['configure_by_card'][card],pal)==1;expected[card]=prefix+str(pal)
  for key,value in expected.items():assert new.profile(int(key))==value
  for key in controls:assert old.profile(key)==new.profile(key)
 for value in [0,7,255]:assert new.call(meta['configure_by_card'][card],value)==0
print(json.dumps(dict(passed=True,actual_ARM64_executed=True,exact_card_profiles=cards,palette_configurations=18,independent_palette_slots=True,unrelated_card_controls=len(controls),phone_verified=False),indent=2))
