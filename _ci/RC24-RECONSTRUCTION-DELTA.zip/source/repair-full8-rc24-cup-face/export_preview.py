import sys,json,numpy as np
from pathlib import Path
from test_added_faces import Toc,decode_first_texture,read_lod,buffers,Mesh
root=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=True,parents=True);live=root/'assets/gateway-release/livedata';meta=json.loads(Path(sys.argv[3]).read_text())
for row in meta['reports']:
 if row['palette']!=2 or row['variant']:continue
 year=row['year'];d=out/year;d.mkdir(exist_ok=True);t=Toc(str(live/f'pc{row["container"]}_mobile_and.utoc'));p='character/RealFace/';name='SK_'+row['profile']+'_Face.uasset';b=t.read(t.files[p+name]);lod=read_lod(b,row['lod0_offset']);pos,f,tan,uv,w=buffers(b,lod);np.savez(d/'mesh.npz',p=pos,f=f,uv=uv,skin_tris=lod['sections'][0]['tris'])
 for short,n in [('face','T_'+row['profile']+'_Face_D'),('hair','T_'+row['profile']+'01_Hair_D')]:decode_first_texture(t.read(t.files[p+n+'.uasset']),t.read(t.files[p+n+'.ubulk'])).save(d/(short+'.png'))
