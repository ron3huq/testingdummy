"""Independent cooked-array, skinning and native skeleton checks for both new cards."""
import sys,json,struct,numpy as np
from pathlib import Path
SRC=Path(__file__).resolve().parents[1];sys.path[:0]=[str(Path(__file__).parent),str(SRC/'repair-full8-rc22-event-face'),str(SRC/'repair-full8-rc7'),str(SRC/'repair-full8-rc9-ucl'),str(SRC/'repair-full8-rc10-face-detail'),'/workspace/apk73-work/rc7/source/repair-full8-rc4']
from iostore import Toc
from ci_bundle import Bundle
from mesh_tools import Mesh
from validate_face import read_lod,buffers,global_weights
from audit_rig import names
from audit_mouth import read,pose,visibility
from bundle_tools import decode_first_texture
from PIL import ImageFilter
import face_texture
from types import SimpleNamespace

def run(root,metadata,audits):
 root=Path(root);live=root/'assets/gateway-release/livedata';meta=json.loads(Path(metadata).read_text());auditroot=Path(audits);native=read(root,palette=2);rest,parents=native[4:];old=Toc(str(live/'pc9356_mobile_and.utoc'));raw=old.read(old.files['character/RealFace/SK_RG28_Face.uasset']);m=Mesh(raw,json.loads((root/'source/repair-full8-rc7/mesh-ranges.json').read_text())['SK_RG27_Face'],lod_index=1);reference=raw[m.r['REF_BEGIN']:m.r['REF_END']];reports=[];poses={};textures={}
 for row in meta['reports']:
  audit=np.load(auditroot/(row['year']+'.npz'));t=Toc(str(live/f'pc{row["container"]}_mobile_and.utoc'));name='SK_'+row['profile']+row['variant']+'_Face';b=t.read(t.files['character/RealFace/'+name+'.uasset']);high=read_lod(b,row['lod0_offset']);low=read_lod(b,high['end']);p,f,tan,uv,w=buffers(b,high);lp,lf,lt,lu,lw=buffers(b,low)
  assert b[low['end']:]==bytes.fromhex('020200000000')
  for value,key in [(p,'positions'),(f,'faces'),(tan,'tangents'),(uv,'uv'),(w,'high_weights')]:assert np.array_equal(value,audit[key]),(row['profile'],key)
  assert np.array_equal(lp,p)and np.array_equal(lf,f)and np.array_equal(lt,tan)and np.array_equal(lu,uv)and np.array_equal(lw,audit['far_weights'])
  assert high['required']==list(range(166))and len(low['required'])==153 and low['active']==low['required']
  for lod in [high,low]:
   for section in lod['sections']:assert len(section['bones'])<=75 and set(section['bones'])<=set(lod['active'])<=set(lod['required'])
  nw=global_weights(high['sections'],w);fw=global_weights(low['sections'],lw);assert np.all(fw[:,8:21]==0);assert np.array_equal(nw[p[:,2]<150],fw[p[:,2]<150])
  delta=row['lod0_offset']-m.lods[0];assert b[m.r['REF_BEGIN']+delta:m.r['REF_END']+delta]==reference,'Native body bind pose or hierarchy changed'
  assert all('R9D'not in n for n in names(b)),'New face still imports old face material'
  if row['palette']==2 and not row['variant']:
   kind=audit['kind'];nw=nw.astype(float)/255;fw=fw.astype(float)/255;states={}
   for label,changes in [('neutral',{}),('jaw8',{8:(0,-8)}),('jaw35',{8:(0,-35)}),('lips',{9:(0,-10),16:(0,10)}),('blink',{10:(0,15),12:(0,15)}),('shoulders',{72:(0,65),106:(0,-65)})]:
    q=pose(p,nw,rest,parents,changes);assert np.isfinite(q).all();assert np.linalg.norm(q-p,axis=1).max()<100
    if label in ['neutral','jaw35']:
     visible=visibility(q,f,kind,dense=label=='neutral');states[label]={k:max(v[k]for v in visible)for k in ['oral28','oral29','oral30']}
     if label=='neutral':assert all(v[k]==0 for v in visible for k in ['oral28','oral29','oral30']),(row['year'],visible)
     else:assert any(v['oral28']>0 for v in visible),'mouth animation was disabled'
    if label in ['blink','lips']:assert np.linalg.norm(q-p,axis=1).max()>.001
    if label=='shoulders':
     far=pose(p,fw,rest,parents,changes);assert np.max(np.linalg.norm(far[p[:,2]<150]-q[p[:,2]<150],axis=1))<1e-4
   poses[row['year']]=states
   prefix='character/RealFace/T_'+row['profile']+'_Face_';im=decode_first_texture(t.read(t.files[prefix+'D.uasset']),t.read(t.files[prefix+'D.ubulk']));ns=int(audit['skin_vertices']);nt=int(audit['skin_triangles']);proxy=SimpleNamespace(uv=uv,positions=p,indices=f,info=[dict(tris=nt)]);face_texture.masks(proxy,kind[:ns],im.size);e=face_texture._EXTRA['current'];oral=(np.array(e['teeth'].filter(ImageFilter.MinFilter(7)))>0)|(np.array(e['tongue'].filter(ImageFilter.MinFilter(7)))>0);pixels=np.array(im);assert np.quantile(pixels[oral,:3],.99)<12,'Teeth/tongue too bright'
   hair='character/RealFace/T_'+row['profile']+'01_Hair_D';h=decode_first_texture(t.read(t.files[hair+'.uasset']),t.read(t.files[hair+'.ubulk']));a=np.array(h)[:,:,3];assert (a<10).sum()>100 and(a>240).sum()>100,'hair alpha was lost'
   textures[row['year']]=dict(oral_p99=float(np.quantile(pixels[oral,:3],.99)),hair_alpha_preserved=True)
  reports.append(dict(year=row['year'],profile=row['profile'],variant=row['variant']or'base',bone_maps=[len(high['sections'][0]['bones']),len(low['sections'][0]['bones'])],native_body_reference_exact=True,all_LOD_streams_valid=True))
 assert len(reports)==48
 return dict(passed=True,assets=48,source_cards={'106783356083208':'Ronaldo 2007','88043608522885':'Ronaldo Juve 2020'},reports=reports,pose_checks=poses,textures=textures,phone_verified=False)
if __name__=='__main__':print(json.dumps(run(*sys.argv[1:]),indent=2))
