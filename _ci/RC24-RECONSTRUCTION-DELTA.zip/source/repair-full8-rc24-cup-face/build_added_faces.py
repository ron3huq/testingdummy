"""Build Ronaldo 2007 / Juve 2020 from the supplied FMDL and textures.
Uses the proven RC24 Android layout, compact GPU maps and native body rest pose.
"""
from pathlib import Path
import sys,json,struct,hashlib,types,importlib.util,numpy as np
from PIL import Image,ImageFilter,ImageDraw
SRC=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(Path(__file__).parent),str(SRC/'repair-full8-rc22-event-face'),str(SRC/'repair-full8-rc7'),str(SRC/'repair-full8-rc9-ucl'),str(SRC/'repair-full8-rc10-face-detail'),str(SRC/'repair-full8-rc4'),'/workspace/apk73-work/rc7/source/repair-full8-rc4','/workspace/deps/pes-fmdl-blender/pes-fmdl']
from iostore import Toc
from ci_bundle import Bundle
from zen_clone import rename,pid
from mesh_tools import Mesh
from validate_face import read_lod,buffers,global_weights
from bundle_tools import decode_first_texture,replace_texture
import face_texture
from face_mesh import labels,drawn_triangles
from fmdl_geometry import build,quantize
spec=importlib.util.spec_from_file_location('native_lod_serializer',SRC/'repair-full8-rc10-face-detail/face_mesh.py');serializer=importlib.util.module_from_spec(spec);spec.loader.exec_module(serializer)
BASE='/Game/Assets/character/RealFace/'

def skin_image(atlas,geometry,palette):
 p,t,uv,rows,col,faces,ns,nt,kind=geometry;proxy=types.SimpleNamespace(uv=uv,positions=p,indices=faces,info=[dict(tris=nt)]);face_texture.masks(proxy,kind[:ns],atlas.size);e=face_texture._EXTRA['current'];a=np.array(atlas).astype(float);skin=np.array(e['skin'])>0;rgb=a[:,:,:3];valid=skin&(rgb[:,:,0]>rgb[:,:,1]*1.06)&(rgb[:,:,1]>rgb[:,:,2]*1.02)&(rgb.mean(2)>60);radius=atlas.width/36
 def blur(q):return np.array(Image.fromarray(np.uint8(np.clip(q,0,255))).filter(ImageFilter.GaussianBlur(radius))).astype(float)
 weight=blur(valid*255)/255;field=np.zeros_like(rgb)
 for i in range(3):field[:,:,i]=blur(rgb[:,:,i]*valid)/np.maximum(weight,.005)
 field[weight<.02]=np.median(rgb[valid],axis=0);gain=np.clip(face_texture.PALETTES[palette-1]/np.maximum(field,1),.3,2.0);rgb[skin]=np.clip(rgb[skin]*gain[skin],0,255)
 oral=(np.array(e['teeth'])>0)|(np.array(e['tongue'])>0)|(np.array(e['cavity'])>0);h,w=oral.shape;yy,xx=np.mgrid[:h,:w];oral|=(abs(xx-w*.9375)<21)&(abs(yy-h*.8125)<21);rgb[oral]=3
 return Image.fromarray(np.uint8(np.rint(np.clip(a,0,255))),'RGBA'),skin,oral

def geometry_blob(raw,m,g,low_required):
 p,t,u,rows,c,f,ns,nt,kind=g;bones=sorted({k for row in rows[:ns]for k,v in row.items()if v>1e-8});assert len(bones)<=75
 packed=quantize(rows[:ns],bones);hair=np.tile(np.array([0,0,0,0,255,0,0,0],'u1'),(len(p)-ns,1));packed=np.concatenate([packed,hair]);high=(p,t,u,packed,c,f,ns,nt,bones)
 lowrows=[]
 for row in rows[:ns]:
  merged={}
  for bone,value in row.items():
   key=7 if 8<=bone<=20 else bone;merged[key]=merged.get(key,0)+value
  lowrows.append(merged)
 lowbones=sorted({k for row in lowrows for k,v in row.items()if v>1e-8});assert set(lowbones)<=set(low_required)
 lw=np.concatenate([quantize(lowrows,lowbones),hair]);low=(p,t,u,lw,c,f,ns,nt,lowbones)
 prefix=bytearray(raw[:m.lods[0]]);lo=p.min(0);hi=p.max(0);center=(hi+lo)/2;ext=(hi-lo)/2;struct.pack_into('<7f',prefix,m.r['BOUNDS_BEGIN'],*center,*ext,float(np.linalg.norm(ext)))
 out=bytearray(prefix+serializer.lod_blob(m,high,list(range(166)),list(range(166)))+serializer.lod_blob(m,low,low_required,list(low_required))+bytes.fromhex('020200000000'));em=struct.unpack_from('<I',raw,44)[0];struct.pack_into('<Q',out,em+80,struct.unpack_from('<Q',raw,em+80)[0]+len(out)-len(raw))
 return bytes(out),dict(high_skin_bones=bones,far_skin_bones=lowbones,vertices=len(p),skin_vertices=ns,drawn_triangles=len(f),required_bones=[166,153],far_same_geometry_UV=True),packed,lw

def run(root,inputs,out_report,audit_root):
 root=Path(root);inputs=Path(inputs);audit_root=Path(audit_root);audit_root.mkdir(parents=True,exist_ok=True);live=root/'assets/gateway-release/livedata';logs=json.loads((root/'source/repair-full8-rc7/mesh-ranges.json').read_text());baseline=Bundle(Toc(str(live/'pc9433_mobile_and.utoc')));source=Bundle(Toc(str(live/'pc9356_mobile_and.utoc')));oldpath='character/RealFace/SK_RG28_Face.uasset';m=Mesh(source.files[oldpath][1],logs['SK_RG27_Face'],lod_index=1);raw=baseline.files['character/RealFace/SK_R9D2_Face.uasset'][1];hi=read_lod(raw,m.lods[0]);low=read_lod(raw,hi['end']);p,f,t,u,w=buffers(raw,hi);gw=global_weights(hi['sections'],w);lab=np.r_[labels(m),np.full(len(p)-m.info[0]['verts'],-1)];native=(p,f,t,u,gw,lab);reports=[]
 # Use source material templates; the uploaded ZIPs are treated as data only.
 oldD='character/RealFace/T_R9D2_Face_D';oldN='character/RealFace/T_R9D2_Face_N';oldS='character/RealFace/T_R9D2_Face_SRO';oldH='character/RealFace/T_RG2801_Hair_D'
 for year,prefix,first,card in [('2007','R7A',9456,106783356083208),('2020','R0A',9480,88043608522885)]:
  folder=inputs/year;g,report,neck=build(folder,native);mesh,rig,hweights,lweights=geometry_blob(raw,m,g,low['required']);pp,tt,uv,rows,colors,faces,ns,nt,kinds=g
  np.savez_compressed(audit_root/(year+'.npz'),positions=pp,tangents=tt,uv=uv,faces=faces,colors=colors,kind=kinds,high_weights=hweights,far_weights=lweights,skin_vertices=ns,skin_triangles=nt)
  atlas=decode_first_texture(baseline.files[oldD+'.uasset'][1],baseline.files[oldD+'.ubulk'][1]);face=Image.open(folder/'face_bsm_alp.png').convert('RGBA').resize((1024,1024),Image.Resampling.LANCZOS);face.putalpha(255);atlas.paste(face,(0,0));normal=decode_first_texture(baseline.files[oldN+'.uasset'][1],baseline.files[oldN+'.ubulk'][1]);a=np.array(Image.open(folder/'face_nrm.png').convert('RGBA').resize((1024,1024)),float);x=a[:,:,0]/127.5-1;y=-(a[:,:,1]/127.5-1);length=np.maximum(1,np.hypot(x,y));x/=length;y/=length;z=np.sqrt(np.maximum(0,1-x*x-y*y));im=Image.fromarray(np.uint8(np.clip((np.stack([x,y,z],-1)+1)*127.5,0,255))).convert('RGBA');normal.paste(im,(0,0));image2,skin,oral=skin_image(atlas,g,2)
  specimage=np.array(decode_first_texture(baseline.files[oldS+'.uasset'][1],baseline.files[oldS+'.ubulk'][1]));specimage[skin,0]=20;specimage[skin,1]=210;specimage[skin,2]=255;specimage[oral,0]=0;specimage[oral,1]=255;specimage[oral,2]=0
  image2.save(audit_root/(year+'-atlas.png'))
  # Face N/SRO and the new hair texture/materials are shared by all six
  # palettes and clothing variants. Only albedo and skin materials vary.
  shared={}
  for oldname,im in [(oldN,normal),(oldS,Image.fromarray(specimage,'RGBA'))]:
   ra,bu,_,_=replace_texture(baseline.files[oldname+'.uasset'][1],im,baseline.files[oldname+'.ubulk'][1]);shared[oldname+'.uasset']=(baseline.files[oldname+'.uasset'][0],ra);shared[oldname+'.ubulk']=(baseline.files[oldname+'.ubulk'][0],bu)
  assert b'PF_ETC2_RGBA\0'in source.files[oldH+'.uasset'][1],'Hair template must preserve cutout alpha'
  hair=Image.open(folder/'hair_parts_bsm_alp.png').convert('RGBA');ra,bu,_,_=replace_texture(source.files[oldH+'.uasset'][1],hair,source.files[oldH+'.ubulk'][1]);shared[oldH+'.uasset']=(source.files[oldH+'.uasset'][0],ra);shared[oldH+'.ubulk']=(source.files[oldH+'.ubulk'][0],bu)
  for quality in ['HQ','MQ']:
   path='character/RealFace/MI_RG2801_Head_Hair_'+quality+'.uasset';shared[path]=source.files[path]
  for pal in range(1,7):
   newprofile=prefix+str(pal);image=np.array(image2).astype(float);image[skin,:3]*=face_texture.PALETTES[pal-1]/face_texture.PALETTES[1];image=Image.fromarray(np.uint8(np.rint(np.clip(image,0,255))),'RGBA');ra,bu,_,_=replace_texture(baseline.files[oldD+'.uasset'][1],image,baseline.files[oldD+'.ubulk'][1]);data={oldD+'.uasset':(baseline.files[oldD+'.uasset'][0],ra),oldD+'.ubulk':(baseline.files[oldD+'.ubulk'][0],bu)}
   for quality in ['HQ','MQ']:
    path='character/RealFace/MI_R9D201_Head_FaceLegacy_'+quality+'.uasset';data[path]=baseline.files[path]
   if pal==2:data.update(shared)
   mappings={BASE+'SK_R9D2_Face':BASE+'SK_'+newprofile+'_Face',BASE+'T_R9D2_Face_D':BASE+'T_'+newprofile+'_Face_D'}
   for quality in ['HQ','MQ']:
    mappings[BASE+'MI_R9D201_Head_FaceLegacy_'+quality]=BASE+'MI_'+newprofile+'01_Head_FaceLegacy_'+quality;mappings[BASE+'MI_RG2801_Head_Hair_'+quality]=BASE+'MI_'+prefix+'201_Head_Hair_'+quality
   for ch in ['N','SRO']:mappings[BASE+'T_R9D2_Face_'+ch]=BASE+'T_'+prefix+'2_Face_'+ch
   mappings[BASE+'T_RG2801_Hair_D']=BASE+'T_'+prefix+'201_Hair_D'
   for variant,suffix in enumerate(['','ep00v0313','ep01v0291','lg00v0000']):
    mapping=dict(mappings);mapping[BASE+'SK_R9D2_Face']=BASE+'SK_'+newprofile+suffix+'_Face';allfiles=dict(data)if variant==0 else{};allfiles['character/RealFace/SK_R9D2_Face.uasset']=(baseline.files['character/RealFace/SK_R9D2_Face.uasset'][0],mesh);out=Bundle(baseline.base);out.files={};out.entries={};repl={}
    for a,b in mapping.items():repl[a]=b;repl[Path(a).name]=Path(b).name
    remap={pid(a):pid(b)for a,b in mapping.items()};lod_offset=None
    for path,(ids,b)in allfiles.items():
     name=Path(path).stem;newname=Path(mapping[BASE+name]).name;entry=None
     if path.endswith('.uasset'):
      owner=source if '_Hair_'in name or '_Head_Hair_'in name else baseline;fixed,deps=owner.entries[int.from_bytes(ids[:8],'little')];entry=(fixed,[remap.get(v,v)for v in deps]);oldsize=len(b);b=rename(b,repl,BASE+name,BASE+newname,imports=mapping)
      if name.startswith('SK_'):lod_offset=m.lods[0]+len(b)-oldsize
     out.put('character/RealFace/'+newname+Path(path).suffix,struct.pack('<Q',pid(BASE+newname))+b'\0\0\0'+(b'\2'if path.endswith('.uasset')else b'\3'),b,entry)
    number=first+variant*6+pal-1;out.output_name=f'pc{number}_mobile_and';out.write(live);reports.append(dict(year=year,card_id=card,palette=pal,variant=suffix,profile=newprofile,container=number,lod0_offset=lod_offset,geometry=report,rig=rig));print('Built',out.output_name,newprofile+suffix,flush=True)
 Path(out_report).write_text(json.dumps(dict(passed=True,assets=len(reports),reports=reports,phone_verified=False),indent=2)+'\n')
if __name__=='__main__':run(*sys.argv[1:])
