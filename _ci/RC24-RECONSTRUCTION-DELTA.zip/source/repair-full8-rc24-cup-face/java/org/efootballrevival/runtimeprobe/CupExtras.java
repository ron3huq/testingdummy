package org.efootballrevival.runtimeprobe;
import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;

/** Cup boards use the donor panel's actual fonts, cards, pills and crests. */
public final class CupExtras {
  static final int GOLD=0xffe4c377, WHITE=0xfff3f5fb, MUTED=0xffaebbd0;
  static int dp(Context c,int n){return Math.round(n*c.getResources().getDisplayMetrics().density);}
  static String word(CupTournamentPanel p,String vi,String en){return p.rc24English()?en:vi;}
  public static void addButtons(final CupTournamentPanel p,FrameLayout bar){
    Context c=p.rc24Context();LinearLayout tabs=new LinearLayout(c);tabs.setOrientation(LinearLayout.HORIZONTAL);
    String[] labels={word(p,"Ghi bàn","Scorers"),word(p,"Kiến tạo","Assists"),"Edit"};
    for(int i=0;i<labels.length;i++){
      final int action=i;TextView button=p.rc24Pill(labels[i],false);
      button.setOnClickListener(new View.OnClickListener(){public void onClick(View v){
        if(action==2){p.rc24Close();TransferEditor.showForCup(p.rc24Activity(),p.rc24Snapshot().optInt("editorCompetition",122));}
        else show(p,action==0?"goals":"assists");
      }});
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.leftMargin=dp(c,3);lp.rightMargin=dp(c,3);tabs.addView(button,lp);
    }
    FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);bar.addView(tabs,lp);
  }
  public static void show(final CupTournamentPanel p,final String field){
    final JSONObject snapshot=p.rc24Snapshot();final int event=p.rc24Event();final Context c=p.rc24Context();
    JSONObject awards=snapshot.optJSONObject("awards");JSONObject boards=awards==null?null:awards.optJSONObject("boards");
    JSONArray rows=boards==null?null:boards.optJSONArray(field);if(rows==null)rows=new JSONArray();
    final Dialog dialog=new Dialog(p.rc24Activity());dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
    LinearLayout root=p.rc24Card();root.setOrientation(LinearLayout.VERTICAL);
    TextView title=p.rc24Text(word(p,field.equals("goals")?"VUA PHÁ LƯỚI":field.equals("assists")?"VUA KIẾN TẠO":"MOTM",field.equals("goals")?"TOP SCORERS":field.equals("assists")?"TOP ASSISTS":"MOTM"),19,GOLD,true);root.addView(title);
    String cup=snapshot.optString("title",snapshot.optInt("editorCompetition",122)==122?"UEFA Champions League":"World Cup");
    TextView sub=p.rc24Text(cup,12,MUTED,false);root.addView(sub);
    LinearLayout tabs=new LinearLayout(c);String[] keys={"goals","assists","motm"};
    for(final String key:keys){TextView b=p.rc24Pill(word(p,key.equals("goals")?"Ghi bàn":key.equals("assists")?"Kiến tạo":"MOTM",key.equals("goals")?"Scorers":key.equals("assists")?"Assists":"MOTM"),key.equals(field));
      b.setOnClickListener(new View.OnClickListener(){public void onClick(View v){if(!key.equals(field)){dialog.setOnDismissListener(null);dialog.dismiss();show(p,key);}}});
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(c,2),dp(c,6),dp(c,2),dp(c,6));tabs.addView(b,lp);
    }root.addView(tabs);
    ScrollView scroll=new ScrollView(c);LinearLayout list=new LinearLayout(c);list.setOrientation(1);scroll.addView(list);
    TextView header=p.rc24Text(word(p,"HẠNG · CẦU THỦ / ĐỘI · SỐ LẦN","RANK · PLAYER / TEAM · TOTAL"),11,MUTED,true);list.addView(header);
    for(int i=0;i<rows.length();i++){
      JSONObject row=rows.optJSONObject(i);if(row==null)continue;
      LinearLayout card=p.rc24Card();card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);
      TextView rank=p.rc24Text(String.valueOf(row.optInt("rank",i+1)),15,GOLD,true);card.addView(rank,new LinearLayout.LayoutParams(dp(c,38),-2));
      View crest=p.rc24Crest(row.optInt("team_id"),row.optString("team_name"),28);card.addView(crest,new LinearLayout.LayoutParams(dp(c,34),dp(c,34)));
      LinearLayout player=new LinearLayout(c);player.setOrientation(1);player.addView(p.rc24Text(row.optString("name"),14,WHITE,true));player.addView(p.rc24Text(row.optString("team_name"),11,MUTED,false));card.addView(player,new LinearLayout.LayoutParams(0,-2,1));
      TextView count=p.rc24Text(String.valueOf(row.optInt(field)),19,GOLD,true);count.setGravity(Gravity.RIGHT);card.addView(count,new LinearLayout.LayoutParams(dp(c,48),-2));
      LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(c,4);list.addView(card,lp);
    }
    if(rows.length()==0)list.addView(p.rc24Text(word(p,"Chưa có sự kiện được ghi nhận. Chơi trận đầu tiên để bắt đầu thống kê.","No recorded events yet. Play a match to start the standings."),14,WHITE,false));
    int height=Math.min(dp(c,410),Math.round(c.getResources().getDisplayMetrics().heightPixels*.56f));root.addView(scroll,new LinearLayout.LayoutParams(-1,height));
    if(awards!=null){String notice=awards.optString("notice");TextView foot=p.rc24Text(notice,11,MUTED,false);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(c,8);root.addView(foot,lp);}
    TextView close=p.rc24Pill(word(p,"Trở lại giải","Back to cup"),false);close.setOnClickListener(new View.OnClickListener(){public void onClick(View v){dialog.dismiss();}});root.addView(close);
    dialog.setContentView(root);dialog.setOnDismissListener(new DialogInterface.OnDismissListener(){public void onDismiss(DialogInterface d){new Handler(Looper.getMainLooper()).post(new Runnable(){public void run(){CupTournamentPanel.openFromGateway(event);}});}});
    p.rc24Close();dialog.show();Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout(Math.min(dp(c,720),c.getResources().getDisplayMetrics().widthPixels-dp(c,24)),-2);}
  }
}
