"""Stage the independently tested RC24 assets/runtime; refresh nested startup pins."""
from pathlib import Path
import sys,json,hashlib,shutil,re,ast,importlib.util
SRC=Path(__file__).resolve().parent;VERSION='V19.1-FULL8-RC24-3RONALDO-V25-EVENT'
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def helper(p):
 s=importlib.util.spec_from_file_location('manifest_helper',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def run(root,research):
 root=Path(root);research=Path(research);g=root/'assets/gateway-release';t=g/'work/tools';v=root/'validation'
 for key in ['readback','added-readback','mouth','profile','event-cycle','native-opponent-stats','transfer']:
  p=research/(key+'.json');doc=json.loads(p.read_text());assert doc['passed'];shutil.copy2(p,v/('full8-rc24-'+key+'.json'))
 dex=research.parent/'rc24-dex';report=json.loads((dex/'report.json').read_text());assert report['passed'];assert sha(dex/'classes5.dex')==report['new_dex_sha256'];shutil.copy2(dex/'classes5.dex',root/'classes5.dex');shutil.copy2(dex/'report.json',v/'full8-rc24-dex.json')
 for p in (SRC/'runtime').glob('*'):
  if p.is_file():shutil.copy2(p,t/p.name)
 shutil.copy2(SRC/'face-overlay/appearance_choices.py',t/'appearance_choices.py');shutil.copy2(research/'face-noodle.so',t/'libnoodle_hair.so')
 p=t/'noodle_hair.py';s,n=re.subn(r"HOOK_SHA='[^']+'","HOOK_SHA='"+sha(t/'libnoodle_hair.so')+"'",p.read_text());assert n==1;p.write_text(s)
 p=t/'bridge_73.py';s=p.read_text()
 if 'rc24_registry.install()'not in s:s=s.replace('    transfer_editor.install(module)','    import rc24_registry\n    rc24_registry.install()\n    transfer_editor.install(module)')
 if 'rc24_cups.install('not in s:s=s.replace('        rc22_v25_events.install(module)','        rc22_v25_events.install(module)\n        import rc24_cups\n        rc24_cups.install(module,rc22_v25_events._modules)')
 assert s.index('rc24_registry.install()')<s.index('transfer_editor.install(module)');p.write_text(s)
 p=t/'private_bundles.py';s=p.read_text()
 if "'pc9503'"not in s:
  needle="'pc9431']";assert needle in s;s=s.replace(needle,"'pc9431', "+', '.join(repr('pc%d'%i)for i in range(9432,9504))+']')
 p.write_text(s)
 p=t/'private_bundles.json';d=json.loads(p.read_text());d['resource_revision']=19024
 for i in range(9432,9504):
  for ext in ['pak','utoc','ucas']:
   q=g/'livedata'/f'pc{i}_mobile_and.{ext}';d['files'][q.name]={'size':q.stat().st_size,'sha256':sha(q)}
 p.write_text(json.dumps(d,indent=2)+'\n')
 p=t/'noodle_bundle.json';d=json.loads(p.read_text());d.update(version=VERSION,asset_revision=19024,native_sha256=sha(t/'libnoodle_hair.so'));d['rc24_profile_configure']=json.loads((research/'profile-build.json').read_text())['configure_by_card'];d['new_three_faces'].update({'89138556572074':'R9D2','106783356083208':'R7A2','88043608522885':'R0A2'})
 for pid in ['106783356083208','88043608522885']:
  if pid not in d['target_card_ids']:d['target_card_ids'].append(pid)
 d['ronaldo2027_profile'].update(profile='R9D1..R9D6',final_face_containers='pc9432..9455',geometry_texture_weights_bind_pose_LODs='Original RC23 outer surfaces/UV/tangents/body bind/neck/hair weights exact. Local mouth response, animated internal lining, dark teeth/cavity, head/neck shading calibration. Phone unverified.',phone_verified=False)
 d['rc24_added_faces']={'106783356083208':{'source':'Ronaldo2007 user ZIP','profiles':'R7A1..R7A6','containers':'pc9456..9479'},'88043608522885':{'source':'Ronaldo JUVE2020 user ZIP','profiles':'R0A1..R0A6','containers':'pc9480..9503'}}
 q=t/'noodle_hair.py';text,n=re.subn(r'TARGET_CARD_IDS=\([^\n]+\)',lambda m:'TARGET_CARD_IDS='+repr(tuple(d['target_card_ids'])),q.read_text());assert n==1;q.write_text(text)
 names=set(d['appearance_files'])|{p.name for p in(SRC/'runtime').glob('*')if p.is_file()};d['appearance_files']={name:sha(t/name)for name in sorted(names)};d['appearance_overlay_sha256']=sha(t/'myleague_editor_runtime.py');p.write_text(json.dumps(d,indent=2)+'\n')
 for filename,key in [('release-manifest.json','release_id'),('ui6-runtime-manifest.json','version')]:
  p=g/filename;d=json.loads(p.read_text());d[key]=VERSION;p.write_text(json.dumps(d,indent=2)+'\n')
 shutil.copytree(SRC,root/'source'/SRC.name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'));shutil.copy2(SRC/'README-VI.md',root/'README-VI.md')
 m=helper(root/'source/repair-full8-rc2-hf1/build_runtime_manifests.py');m.update(g);m.check(g)
 for p in t.glob('*.py'):ast.parse(p.read_text())
 sys.path.insert(0,str(root/'source/repair-full8-rc5-hf1'));from check_startup_integrity import verify;from verify_login_gate import run as login
 report=verify(root);report.update(login(root));report.update(version=VERSION,phone_verified=False);(v/'full8-rc24-startup.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':run(*sys.argv[1:])
