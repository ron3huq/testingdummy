"""Read cooked RC24 streams independently; compare all original surfaces to RC23."""
import json,sys,numpy as np
from pathlib import Path
from build_face import Toc,Mesh,read_lod,buffers,global_weights,labels
from audit_mouth import read,pose,visibility
from test_mouth import local_pose

def run(root):
 root=Path(root);live=root/'assets/gateway-release/livedata';logs=json.loads((root/'source/repair-full8-rc7/mesh-ranges.json').read_text());reports=[]
 for v,suffix in enumerate(['','ep00v0313','ep01v0291','lg00v0000']):
  original=Toc(str(live/f'pc{9356+v}_mobile_and.utoc'));raw=original.read(original.files[f'character/RealFace/SK_RG28{suffix}_Face.uasset']);m=Mesh(raw,logs['SK_RG27'+suffix+'_Face'],lod_index=1)
  for pal in range(1,7):
   arrays=[];raws=[];lods=[]
   for base,prefix in [(9408,'R9C'),(9432,'R9D')]:
    t=Toc(str(live/f'pc{base+v*6+pal-1}_mobile_and.utoc'));b=t.read(t.files[f'character/RealFace/SK_{prefix}{pal}{suffix}_Face.uasset']);h=read_lod(b,m.lods[0]);l=read_lod(b,h['end']);arrays.append([buffers(b,h),buffers(b,l)]);raws.append(b);lods.append([h,l])
   ns=lods[0][0]['sections'][0]['verts'];extra=lods[1][0]['sections'][0]['verts']-ns;assert extra>0
   mapping=np.r_[np.arange(ns),np.arange(ns+extra,len(arrays[1][0][0]))]
   for j in range(2):
    op,of,ot,ou,ow=arrays[0][j];p,f,t,u,w=arrays[1][j];assert np.array_equal(op,p[mapping])and np.array_equal(ot,t[mapping])and np.array_equal(ou,u[mapping])
    oldskin=lods[0][j]['sections'][0]['tris'];assert np.array_equal(of[:oldskin],f[:oldskin]);newskin=lods[1][j]['sections'][0]['tris'];assert np.array_equal(of[oldskin:]+extra,f[newskin:])
    before=global_weights(lods[0][j]['sections'],ow);after=global_weights(lods[1][j]['sections'],w)[mapping];changed=np.any(before!=after,axis=0);assert set(np.flatnonzero(changed))<=set([7,8,9,16,17,19]);assert np.array_equal(before[ns:],after[ns:]);assert np.array_equal(before[op[:,2]<153],after[op[:,2]<153])
    if j:assert np.array_equal(before,after)
    assert len(lods[1][j]['sections'][0]['bones'])==[19,6][j];assert lods[0][j]['active']==lods[1][j]['active']and lods[0][j]['required']==lods[1][j]['required']
   assert raws[0][m.r['REF_BEGIN']:m.r['REF_END']]==raws[1][m.r['REF_BEGIN']:m.r['REF_END']]
   p,f,t,u,w=arrays[1][0];lp,lf,lt,lu,lw=arrays[1][1];assert np.array_equal(p,lp)and np.array_equal(t,lt)and np.array_equal(u,lu)and np.array_equal(f,lf)
   reports.append(dict(variant=suffix or'base',palette=pal,original_surface_positions_UVs_tangents_exact=True,neck_hair_body_weights_exact=True,native_skeleton_and_LOD_exact=True,internal_lining_vertices=extra))
 # Actual individual lip/corner controls as well as jaw; these are synthetic
 # probes, not the game's recorded animation clips.
 p,f,lab,w,rest,parents=read(root,palette=2);checks=[]
 for bone in [9,16,17,19]:
  for angle in [-5,5]:
   q=local_pose(p,w,rest,parents,bone,0,angle);assert np.isfinite(q).all();assert np.linalg.norm(q-p,axis=1).max()>.001
   rows=visibility(q,f,lab);checks.append(dict(bone=bone,degrees=angle,oral_samples_visible=sum(v[k]for v in rows for k in ['oral28','oral29','oral30'])))
   assert all(v[k]==0 for v in rows for k in ['oral28','oral29','oral30']),checks[-1]
 return dict(passed=True,assets=24,reports=reports,individual_lip_corner_probes=checks,phone_verified=False)
if __name__=='__main__':print(json.dumps(run(sys.argv[1]),indent=2))
