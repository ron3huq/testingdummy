from pathlib import Path
import sys,json,numpy as np
sys.path.insert(0,str(Path(__file__).parent))
from build_added_faces import *
root=Path(sys.argv[1]);report_path=Path(sys.argv[2]);audits=Path(sys.argv[3]);inputs=Path(sys.argv[4]);live=root/'assets/gateway-release/livedata';reports=json.loads(report_path.read_text());logs=json.loads((root/'source/repair-full8-rc7/mesh-ranges.json').read_text());base=Bundle(Toc(str(live/'pc9433_mobile_and.utoc')));src=Bundle(Toc(str(live/'pc9356_mobile_and.utoc')));m=Mesh(src.files['character/RealFace/SK_RG28_Face.uasset'][1],logs['SK_RG27_Face'],lod_index=1);raw=base.files['character/RealFace/SK_R9D2_Face.uasset'][1];a=read_lod(raw,m.lods[0]);far=read_lod(raw,a['end']);p,f,t,u,w=buffers(raw,a);lab=np.r_[labels(m),np.full(len(p)-m.info[0]['verts'],-1)];native=p,f,t,u,global_weights(a['sections'],w),lab
for year,prefix in [('2007','R7A'),('2020','R0A')]:
 g,report,neck=build(inputs/year,native);mesh,rig,hw,lw=geometry_blob(raw,m,g,far['required']);p,t,u,rows,c,f,ns,nt,k=g;np.savez_compressed(audits/(year+'.npz'),positions=p,tangents=t,uv=u,faces=f,colors=c,kind=k,high_weights=hw,far_weights=lw,skin_vertices=ns,skin_triangles=nt)
 for row in reports['reports']:
  if row['year']!=year:continue
  profile=prefix+str(row['palette']);own='SK_'+profile+row['variant']+'_Face';mapping={BASE+'SK_R9D2_Face':BASE+own,BASE+'T_R9D2_Face_D':BASE+'T_'+profile+'_Face_D'}
  for quality in ['HQ','MQ']:
   mapping[BASE+'MI_R9D201_Head_FaceLegacy_'+quality]=BASE+'MI_'+profile+'01_Head_FaceLegacy_'+quality;mapping[BASE+'MI_RG2801_Head_Hair_'+quality]=BASE+'MI_'+prefix+'201_Head_Hair_'+quality
  for ch in ['N','SRO']:mapping[BASE+'T_R9D2_Face_'+ch]=BASE+'T_'+prefix+'2_Face_'+ch
  mapping[BASE+'T_RG2801_Hair_D']=BASE+'T_'+prefix+'201_Hair_D';repl={}
  for x,y in mapping.items():repl[x]=y;repl[Path(x).name]=Path(y).name
  b=rename(mesh,repl,BASE+'SK_R9D2_Face',BASE+own,imports=mapping);toc=Toc(str(live/f'pc{row["container"]}_mobile_and.utoc'));out=Bundle(toc);dest='character/RealFace/'+own+'.uasset';out.files[dest]=(out.files[dest][0],b);out.base=base.base;out.output_name=Path(toc.path).stem;out.write(live);row.update(geometry=report,rig=rig,lod0_offset=m.lods[0]+len(b)-len(mesh))
report_path.write_text(json.dumps(reports,indent=2)+'\n');print('Refreshed 48 new face meshes and readback audit arrays')
