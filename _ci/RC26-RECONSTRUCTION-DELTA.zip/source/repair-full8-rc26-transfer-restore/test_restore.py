"""Reproduce RC25's no-capture modal; restore real public edit endpoints."""
import sys,json,copy,tempfile,types,shutil,subprocess
from pathlib import Path
SRC=Path(__file__).resolve().parent;BASE=Path('/workspace/apk73-work/rc22-host/base');STAGE=Path('/workspace/apk73-work/rc26-full/payload')
sys.path.insert(0,str(SRC.parent/'repair-full8-rc22-event-face'));from host_reference import References
sys.meta_path.insert(0,References('/workspace/apk73-inputs/decoded/73efootball-V19.1.apk',BASE))
import club_store
sys.path.insert(0,str(STAGE/'assets/gateway-release/work/tools'))
import transfer_editor as transfer,transfer_player_editor as players,myleague_editor_runtime as editor
with tempfile.TemporaryDirectory()as tmp:
 root=Path(tmp);project=root/'work/tools/myleague_editor.json';project.parent.mkdir(parents=True);shutil.copy2(STAGE/'assets/gateway-release/work/tools/myleague_editor.json',project);editor.PATH=project;editor._config=None
 c=club_store.connect(root/'fixture.sqlite3');club_store.seed(c);c.commit();gateway=types.SimpleNamespace(_logic=types.SimpleNamespace(conn=c),manage=lambda*a:'base')
 assert not transfer.manage(c,'ui712_transfer_get',dict(team_id=108,competition=122))['ready'],'RC25 regression not reproduced'
 sys.path.insert(0,str(SRC/'runtime'));import rc24_registry;rc24_registry.HERE=STAGE/'assets/gateway-release/work/tools';rc24_registry.install();transfer._conn=None;transfer.install(gateway);transfer.post_install()
 import rc25_event_editor as event
 event.load_modules()['myleague_editor_runtime'].PATH=root/'work/tools/event-transfer-editor.json';event.install(gateway)
 def request(action,req):return json.loads(gateway.manage(action,json.dumps(req)))
 checked=[]
 for cid in [122,128]:
  for row in request('ui712_transfer_list',dict(competition=cid))['teams']:
   if str(cid)+':'+str(row['id'])not in rc24_registry.data()['teams']:continue
   assert row['ready'],(cid,row)
   result=request('ui712_transfer_get',dict(team_id=row['id'],competition=cid));assert result['ready'];transfer.validate_team(result['team']);checked.append((cid,row['id']))
 assert len(checked)==72
 saved=[]
 for cid,tid in [(122,108),next(r for r in checked if r[0]==128)]:
  before=request('ui712_transfer_get',dict(team_id=tid,competition=cid))['team'];edited=copy.deepcopy(before);edited['roster'][1]['shirt'],edited['roster'][2]['shirt']=edited['roster'][2]['shirt'],edited['roster'][1]['shirt'];edited['roster'][1]['x']=19;edited['captain']=edited['roster'][3]['id'];edited['kickers']=[edited['roster'][3]['id']]*6
  assert request('ui712_transfer_save',dict(team_id=tid,competition=cid,revision=before['revision'],team=edited))['saved']
  pid=edited['roster'][1]['id'];assert request('ui712_transfer_player_apply',dict(team_id=tid,competition=cid,player_id=pid,values=dict(parameters={'14':99},foot={'42':1},skills=[0,1])))['saved']
  got=request('ui712_transfer_get',dict(team_id=tid,competition=cid))['team'];assert got['roster'][1]['shirt']==edited['roster'][1]['shirt']and got['roster'][1]['x']==19
  got=request('ui712_transfer_player_get',dict(team_id=tid,competition=cid,player_id=pid));assert got['values']['parameters']['14']==99
  traits=request('ui712_transfer_traits_get',dict(team_id=tid,competition=cid,player_id=pid));assert traits['foot']['42']==1 and traits['skills']==[0,1],traits
  # Same immutable baseline, independent saved state and scopes.
  eid=901 if cid==122 else 902;private=event.transfer().source(tid,eid);assert not private.get('ui712_transfer');assert private['roster'][1]['x']==before['roster'][1]['x'];params,_=event.modules['transfer_native_data'].read(c,pid,eid);assert params[14]!=99
  assert event.players().manage(c,'ui712_transfer_player_apply',dict(team_id=tid,competition=eid,player_id=pid,values=dict(parameters={'14':55})))['saved']
  assert request('ui712_transfer_player_get',dict(team_id=tid,competition=cid,player_id=pid))['values']['parameters']['14']==99
  saved.append(dict(competition=cid,team_id=tid,player_id=pid))
 # Reopen actual saved public profiles after early reference registration.
 transfer.profiles={};transfer._conn=None;transfer.load(c);players.restore_config(c)
 for row in saved:assert transfer.source(row['team_id'],row['competition'])['ui712_transfer']
 assert set(transfer.profiles)=={str(r['competition'])+':'+str(r['team_id'])for r in saved}
 assert all(k.startswith(('901:','902:'))for k in event.players()._profiles)
 # Fresh process: saved cards formerly rejected by the old catalogue load now.
 script='''import sys,types\nfrom pathlib import Path\nsys.path.insert(0,sys.argv[1]);from host_reference import References\nsys.meta_path.insert(0,References('/workspace/apk73-inputs/decoded/73efootball-V19.1.apk',Path('/workspace/apk73-work/rc22-host/base')))\nsys.path[:0]=[sys.argv[2],sys.argv[3]]\nimport club_store,myleague_editor_runtime as editor,rc24_registry,transfer_editor as transfer\neditor.PATH=Path(sys.argv[4]);editor._config=None\nc=club_store.connect(Path(sys.argv[5]));gateway=types.SimpleNamespace(_logic=types.SimpleNamespace(conn=c),manage=lambda*a:'base')\nrc24_registry.HERE=Path(sys.argv[3]);rc24_registry.install();transfer.install(gateway)\nassert len(transfer.profiles)==2\nassert transfer.manage(c,'ui712_transfer_get',dict(team_id=108,competition=122))['ready']\n'''
 subprocess.run([sys.executable,'-c',script,str(SRC.parent/'repair-full8-rc22-event-face'),str(SRC/'runtime'),str(STAGE/'assets/gateway-release/work/tools'),str(project),str(root/'fixture.sqlite3')],check=True)
 print(json.dumps(dict(passed=True,RC25_Barcelona_no_capture_regression_reproduced=True,public_teams_open_without_capture=len(checked),public_scopes=[122,128],team_and_player_edit_endpoints_saved_and_read_back=True,foot_and_skills_readback=True,saved_public_profiles_cold_start=True,Event_saved_edits_still_separate=True,phone_verified=False),indent=2))
