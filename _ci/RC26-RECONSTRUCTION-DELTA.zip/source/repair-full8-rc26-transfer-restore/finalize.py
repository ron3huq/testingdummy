from pathlib import Path
import json,sys,shutil,hashlib,importlib.util,ast
SRC=Path(__file__).resolve().parent;VERSION='V19.1-FULL8-RC26-TRANSFER-RESTORE'
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(root,research):
 root=Path(root);research=Path(research);g=root/'assets/gateway-release';t=g/'work/tools';baseline=Path('/workspace/apk73-work/rc25-full/payload')
 report=json.loads((research/'restore.json').read_text());assert report['passed'];shutil.copy2(research/'restore.json',root/'validation/full8-rc26-restore.json')
 for p in(SRC/'overlays').rglob('*'):
  if p.is_file():shutil.copy2(p,root/p.relative_to(SRC/'overlays'))
 for p in(SRC/'runtime').glob('*.py'):shutil.copy2(p,t/p.name)
 assert 'rc24_registry.install()'in(t/'bridge_73.py').read_text()
 assert (t/'bridge_73.py').read_text().index('rc24_registry.install()')<(t/'bridge_73.py').read_text().index('transfer_editor.install(module)')
 assert sha(root/'classes5.dex')==sha(baseline/'classes5.dex')
 for p in t.glob('*.so'):assert sha(p)==sha(baseline/p.relative_to(root))
 for p in(root/'assets/launcher').rglob('*'):
  if p.is_file():assert sha(p)==sha(baseline/p.relative_to(root))
 p=t/'private_bundles.json';d=json.loads(p.read_text());d['resource_revision']=19026;p.write_text(json.dumps(d,indent=2)+'\n')
 p=t/'noodle_bundle.json';d=json.loads(p.read_text());d.update(version=VERSION,asset_revision=19026);d['rc26_transfer_restore']='Restore immutable public reference fallback before saved-profile validation; independent public122/128 vs Event901/902 edits; prefer existing My League data';d['appearance_files']={name:sha(t/name)for name in d['appearance_files']};p.write_text(json.dumps(d,indent=2)+'\n')
 for filename,key in [('release-manifest.json','release_id'),('ui6-runtime-manifest.json','version')]:
  p=g/filename;d=json.loads(p.read_text());d[key]=VERSION;p.write_text(json.dumps(d,indent=2)+'\n')
 shutil.copytree(SRC,root/'source'/SRC.name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'));shutil.copy2(SRC/'README-VI.md',root/'README-VI.md')
 s=importlib.util.spec_from_file_location('mf',root/'source/repair-full8-rc2-hf1/build_runtime_manifests.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.update(g);m.check(g)
 for p in t.glob('*.py'):ast.parse(p.read_text())
 sys.path.insert(0,str(root/'source/repair-full8-rc5-hf1'));from check_startup_integrity import verify;from verify_login_gate import run as login
 report=verify(root);report.update(login(root));report.update(version=VERSION,all_native_libraries_exact_RC25=True,DEX_and_launcher_exact_RC25=True,phone_verified=False);(root/'validation/full8-rc26-startup.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':run(*sys.argv[1:])
