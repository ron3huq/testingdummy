"""Package a validated stage and a small Actions reconstruction delta."""
from pathlib import Path
import json,sys,hashlib,zipfile,shutil,importlib.util
BASE_SHA='38b4adb581b602a4472186c1b2c1e624fec97978130e46d71bd9374298cb5124'
VERSION='V19.1-FULL8-RC26-TRANSFER-RESTORE'
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(root,baseline,out):
 root=Path(root);out=Path(out);out.mkdir(parents=True,exist_ok=True);baseline=Path(baseline);assert sha(baseline)==BASE_SHA
 required=['restore','startup']
 reports={name:json.loads((root/'validation'/('full8-rc26-'+name+'.json')).read_text())for name in required}
 assert all(d['passed']for d in reports.values())
 tools=root/'assets/gateway-release/work/tools'
 assert not list(tools.glob('ucl_lp_*'))and not(tools/'libucl_rules.so').exists()
 assert 'ucl_lp_'not in(tools/'bridge_73.py').read_text()
 assert 'rc24_cups.install(module,rc22_v25_events._modules)'in(tools/'bridge_73.py').read_text()
 spec=importlib.util.spec_from_file_location('manifests',root/'source/repair-full8-rc2-hf1/build_runtime_manifests.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.check(root/'assets/gateway-release')
 prior=json.loads((root/'payload-inventory.json').read_text());names={r['path']for r in prior['files']if(root/r['path']).is_file()}
 for directory in ['assets','source/repair-full8-rc9-ucl','source/repair-full8-rc10-face-detail','source/repair-full8-rc22-event-face','source/repair-full8-rc26-transfer-restore','validation']:
  names.update(p.relative_to(root).as_posix()for p in(root/directory).rglob('*')if p.is_file()and '__pycache__'not in p.parts)
 names|={'README-VI.md','classes5.dex'}
 for name in names:
  p=Path(name);assert '__pycache__'not in p.parts and not p.name.endswith(('.private.json','-status.json','.tmp'))and p.suffix.lower()not in{'.apk','.zip','.rar','.db','.sqlite','.sqlite3','.log','.mp4'},name
 rows=[dict(path=name,bytes=(root/name).stat().st_size,sha256=sha(root/name))for name in sorted(names)]
 (root/'payload-inventory.json').write_text(json.dumps(dict(version=VERSION,resource_revision=19026,phone_verified=False,release_status='candidate-needs-Android-validation',files=rows),indent=2)+'\n');names.add('payload-inventory.json')
 def makezip(path,paths):
  with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
   for name in sorted(paths):z.write(root/name,name)
  with zipfile.ZipFile(path)as z:assert z.testzip()is None
 archive=out/'FULL8-RC26-TRANSFER-RESTORE.zip';makezip(archive,names)
 baseline_hashes={}
 with zipfile.ZipFile(baseline)as z:
  for info in z.infolist():
   if not info.is_dir():baseline_hashes[info.filename]=hashlib.sha256(z.read(info)).hexdigest()
 current={r['path']:r['sha256']for r in rows};current['payload-inventory.json']=sha(root/'payload-inventory.json')
 changes={n for n in names if baseline_hashes.get(n)!=current[n]}
 delta=out/'RC26-RECONSTRUCTION-DELTA.zip';makezip(delta,changes)
 base_payload={n for n in baseline_hashes if n.startswith('assets/')or n=='classes5.dex'}
 old_changed=sorted(n for n in base_payload if current.get(n)!=baseline_hashes[n])
 assert not any(n.endswith('.so')for n in old_changed)
 assert 'classes5.dex'not in old_changed
 assert not any(n.startswith('assets/gateway-release/livedata/')for n in old_changed)
 assert not any(n.startswith('assets/launcher/')for n in old_changed)
 assert 'assets/gateway-release/work/tools/myleague_custom.json'not in old_changed
 assert 'assets/gateway-release/work/tools/myleague_editor.json'not in old_changed
 assert 'assets/gateway-release/work/tools/libselect_team.so'not in old_changed
 with zipfile.ZipFile(archive)as z:
  assert set(z.namelist())==names
  for row in rows:
   with z.open(row['path'])as f:assert hashlib.file_digest(f,'sha256').hexdigest()==row['sha256'],row['path']
 result=dict(passed=True,version=VERSION,archive=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),files=len(names),all_inventory_hashes_rechecked_from_zip=True,zip_crc_passed=True,baseline_zip_sha256=BASE_SHA,baseline_payload_files=len(base_payload),unchanged_baseline_payload_files=len(base_payload)-len(old_changed),changed_baseline_payload=old_changed,old_livedata_exact=True,all_native_libraries_exact_RC25=True,DEX_and_launcher_exact_RC25=True,Ajax_configuration_and_native_emblem_exact_RC24=True,rc21_ucl_runtime_absent=True,delta_bytes=delta.stat().st_size,delta_sha256=sha(delta),delta_files=len(changes),phone_verified=False)
 (out/'FULL8-RC26.validation.json').write_text(json.dumps(result,indent=2)+'\n');(out/'FULL8-RC26.sha256').write_text(result['sha256']+'  '+archive.name+'\n');shutil.copyfile(root/'README-VI.md',out/'README-VI.md')
 return result
if __name__=='__main__':print(json.dumps(run(*sys.argv[1:]),indent=2))
