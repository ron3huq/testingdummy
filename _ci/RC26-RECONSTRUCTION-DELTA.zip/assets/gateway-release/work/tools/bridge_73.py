"""Load only the V25 face/card payload into the 73 V16 local gateway."""
import importlib.util
import sys
from pathlib import Path

def install(root, module):
    if getattr(module,'_v191_full_installed',False):return
    tools = Path(root) / 'work/tools'
    import myleague_condition
    myleague_condition.install(root,module)
    import single_player_runtime
    single_player_runtime.install(root,module)
    import v191_live
    v191_live.install(root)
    import v191_original_card
    v191_original_card.install(module)
    import full2_cards
    full2_cards.migrate(module._logic.conn)
    import mod_startup
    mod_startup.install()
    import level100
    level100.install()
    import multi_cards
    multi_cards.install()
    existing = sys.modules.get('noodle_hair')
    if existing is None:
        spec = importlib.util.spec_from_file_location('noodle_hair', tools / 'noodle_hair.py')
        existing = importlib.util.module_from_spec(spec)
        sys.modules['noodle_hair'] = existing
        spec.loader.exec_module(existing)
    import extras_runtime,manager_runtime,kits_runtime
    original = module._local_urls
    if not getattr(original, '_v25_73', False):
        def local_urls(value):
            # Preserve the 73 gateway's existing conversion and local port.
            result=v191_live.apply(original,value,8085)
            if isinstance(result,dict)and isinstance(result.get('version_file'),str)and isinstance(result.get('livedata_list'),list):
                try:
                    import json,time
                    ver=json.loads(result['version_file']);rows=[]
                    for pack in ver.get('dt880',[]):
                        for ext,key in [('pak','hash'),('utoc','utoc'),('ucas','ucas')]:
                            if key in pack:rows.append({'file':pack['name']+'_mobile_and.'+ext,'size':pack.get(key+'FileSize'),'sha256':pack[key]})
                    status={'version':'73-ui7.19','time_unix':time.time(),'manifest_version':ver.get('version'),'containers':len(ver.get('dt880',[])),'files':rows,'no_save_or_player_data':True}
                    f=tools/'ui717-live-update-status.json';tmp=f.with_suffix('.tmp');tmp.write_text(json.dumps(status,indent=2));tmp.replace(f)
                except (OSError,ValueError,KeyError,TypeError):pass
            return result
        local_urls._v25_73 = True
        module._local_urls = local_urls
    import editor_appearance_runtime
    editor_appearance_runtime.sync(module._logic.conn)
    import editor_names,editor_fast,card_rules
    editor_names.install()
    card_rules.install()
    import appearance_choices
    appearance_choices.migrate(root,module._logic.conn)
    card_rules.install_native_config(root)
    import body_dimensions
    body_dimensions.install(root,module)
    import player_model
    player_model.install(module)
    import player_tuning
    player_tuning.install(module)
    appearance_choices.install(module)
    import appearance_gear
    appearance_gear.install(module)
    import profile_editor
    profile_editor.install(module)
    import photo_editor
    photo_editor.install(module)
    import stat_editor
    stat_editor.install(module)
    import motion_editor
    motion_editor.install(module)
    import transfer_editor
    import rc24_registry
    rc24_registry.install()
    transfer_editor.install(module)
    editor_fast.install(module)
    full2_cards.install_projection()
    existing.start()
    try:
        import select_team_runtime
        select_team_runtime.start()
        import myleague_73
        myleague_73.install()
        transfer_editor.post_install()
        import rc25_event_editor
        rc25_event_editor.install(module)
        import rc25_settings
        rc25_settings.install(module)
        if not myleague_73._installed:raise RuntimeError("My League adapter did not install")
        import rc22_v25_events
        rc22_v25_events.install(module)
        import rc24_cups
        rc24_cups.install(module,rc22_v25_events._modules)
        mod_startup._python_ready=True
    except Exception as exc:
        import json
        try:(tools / 'myleague-73-status.json').write_text(json.dumps({'state':'ERROR','error':str(exc),'version':'73-ui7-full'},indent=2))
        except OSError:pass
        raise RuntimeError('UI7 Python adapter initialization failed')from exc
    single_player_runtime.start()
    import live_snapshot
    live_snapshot.install(module)
    module._v191_full_installed=True
    return existing
