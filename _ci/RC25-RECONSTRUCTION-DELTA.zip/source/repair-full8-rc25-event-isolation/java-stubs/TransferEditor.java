package org.efootballrevival.runtimeprobe;
import android.app.Activity;import android.widget.Button;import org.json.JSONObject;
public class TransferEditor{interface Result{void done(JSONObject r)throws Exception;}static void request(Activity a,Button b,String action,JSONObject p,Result r){} }
