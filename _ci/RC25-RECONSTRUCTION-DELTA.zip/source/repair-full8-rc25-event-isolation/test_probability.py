import sys,json,random,copy
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'runtime'));import rc25_probability as p
rng=random.Random(991);cases=[]
# Every table row in both orientations, with deterministic independent draws.
for gap in range(5):
 h=next(t for t,g in p.TIERS.items()if g==1);a=next(t for t,g in p.TIERS.items()if g==1+gap)
 for home,away in [(h,a),(a,h)]:
  probs=p.probability(home,away);counts=[0,0,0];n=30000
  for _ in range(n):counts[p.draw_score(rng,probs,home,away)['regulation_outcome']]+=1
  observed=[v/n for v in counts];assert max(abs(x-y)for x,y in zip(observed,probs))<.012
  cases.append(dict(gap=gap,home=home,away=away,expected=probs,observed=observed))
assert p.probability(114,100)==(.85,.10,.05);assert p.probability(100,114)==(.09,.17,.74)
assert abs(p.probability(114,100,True)[2]-.01)<1e-9
state=dict(cup_id='fixture',event_id=1120006,matches=[dict(matchday=i,index=i,home_team_id=100,away_team_id=114,home_score=0,away_score=3,played=True)for i in [1,2]])
m=dict(index=4,matchday=3,home=1,away=2,home_team_id=114,away_team_id=100,played=False);assert p.mu_losing_streak(state,m);p.simulate(state,m);assert m['rc25_probability']['mu_two_losses_penalty']
old=copy.deepcopy(m);assert p.simulate(state,m)is None and m==old
# Engine and WC records are excluded, and KO draws always resolve one leg.
for event in [1120010,1120011]:
 s=dict(state,event_id=event);q=dict(m,played=False);before=copy.deepcopy(q);assert p.simulate(s,q)is None and q==before
q=dict(m,home=0,played=False);before=copy.deepcopy(q);assert p.simulate(state,q)is None and q==before
for i in range(5000):
 result=p.draw_score(rng,p.probability(114,100),114,100,True);assert result['winner']in('H','A');assert result['home']!=result['away']or result['home_pk']!=result['away_pk']
players=[dict(name='H. Kane',goal_weight=100),dict(name='Other',goal_weight=100)];shares=p.goal_shares(players,127);assert shares[0]['goal_weight']==.36 and abs(shares[1]['goal_weight']-.64)<1e-9
# Four-pot draw, same32 teams, own index0 retained in group0, MU always Pot4.
state=json.loads(Path('/workspace/apk73-work/rc24-research/ucl-state.json').read_text());pool=list(state['teams']);p.seeded_groups(state);assert state['teams']==pool;assert 0 in state['groups'][0];assert set(sum(state['groups'],[]))==set(range(32));pots=state['rc25_pots']['pots']
for g in state['groups']:assert all(len(set(g)&set(pot))==1 for pot in pots)
if 100 in pool:assert pool.index(100)in pots[3]
for m in state['matches']:assert pool[m['home']]==m['home_team_id']and pool[m['away']]==m['away_team_id']
print(json.dumps(dict(passed=True,docx_sha256=p.SOURCE_SHA,table_trials=len(cases)*30000,cases=cases,MU_negative_form=True,pool_exact_and_four_pots=True,played_and_native_results_preserved=True,World_Cup_unchanged=True,single_leg_KO_resolves_draws=True,named_scorer_share_exact=True,advance_odds_not_forced=True,phone_verified=False),indent=2))
