from pathlib import Path
import sys,subprocess,shutil,json,hashlib,re
out=Path(sys.argv[1]);out.mkdir(exist_ok=True,parents=True);java='/usr/lib/jvm/java-21-openjdk-amd64/bin/java';base=Path('/workspace/apk73-work/rc7');jar=base/'.ci-full8-rc5/apktool.jar';tool=base/'source/repair-full8-rc4/DexTool.java'
def run(*args):subprocess.run(list(map(str,args)),check=True,stdout=subprocess.DEVNULL)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['smali','verify','classes','extra','extra-smali']:shutil.rmtree(out/n,ignore_errors=True)
smali=out/'smali';run(java,'-cp',jar,tool,'d','/workspace/apk73-work/rc24-full/payload/classes5.dex',smali);before={p.relative_to(smali).as_posix():sha(p)for p in smali.rglob('*.smali')}
p=smali/'org/efootballrevival/runtimeprobe/PrivateTools.smali';s=p.read_text();needle='    const-string v2, "transfer"';assert s.count(needle)==1
insert=''
for name,cid in [('event-ucl-edit',901),('event-wc-edit',902)]:
 label='rc25_'+str(cid);insert+=f'''    const-string v2, "{name}"
    invoke-virtual {{v2,p1}}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, :{label}
    const/16 v2, {cid}
    invoke-static {{p0,v2}}, Lorg/efootballrevival/runtimeprobe/TransferEditor;->showForCup(Landroid/app/Activity;I)V
    return-void
    :{label}
'''
insert+='''    const-string v2, "realtime-settings"
    invoke-virtual {v2,p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v2
    if-eqz v2, :rc25_settings
    invoke-static {p0}, Lorg/efootballrevival/runtimeprobe/RealtimeSettings;->show(Landroid/app/Activity;)V
    return-void
    :rc25_settings
'''
s=s.replace(needle,insert+needle);p.write_text(s)
p=smali/'org/efootballrevival/runtimeprobe/CupExtras.smali';s=p.read_text().replace('0x7a','0x385');p.write_text(s)
src=Path(__file__).resolve().parent;deps=Path('/workspace/deps/android-ui');run(java,'-m','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-cp',str(deps/'android.jar')+':'+str(deps/'json.jar'),'-d',out/'classes',src/'java-stubs/TransferEditor.java',src/'java/org/efootballrevival/runtimeprobe/RealtimeSettings.java')
(out/'extra').mkdir(exist_ok=True);run(java,'-cp',deps/'r8.jar','com.android.tools.r8.D8','--min-api','24','--no-desugaring','--lib',deps/'android.jar','--lib',deps/'json.jar','--output',out/'extra',*sorted((out/'classes').rglob('RealtimeSettings*.class')));run(java,'-cp',jar,tool,'d',out/'extra/classes.dex',out/'extra-smali')
for p in(out/'extra-smali').rglob('*.smali'):
 dest=smali/p.relative_to(out/'extra-smali');assert not dest.exists();shutil.copy2(p,dest)
run(java,'-cp',jar,tool,'a',smali,out/'classes5.dex');run(java,'-cp',jar,tool,'d',out/'classes5.dex',out/'verify');after={p.relative_to(out/'verify').as_posix():sha(p)for p in(out/'verify').rglob('*.smali')};changed=[n for n in before if before[n]!=after[n]];assert set(changed)=={'org/efootballrevival/runtimeprobe/PrivateTools.smali','org/efootballrevival/runtimeprobe/CupExtras.smali'};assert set(before)<=set(after)
report=dict(passed=True,existing_editor_and_its_all_subclasses_exact_RC24=True,classes=len(after),added_classes=len(after)-len(before),unchanged_classes=len(before)-2,changed_classes=changed,new_dex_sha256=sha(out/'classes5.dex'),phone_verified=False);(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
