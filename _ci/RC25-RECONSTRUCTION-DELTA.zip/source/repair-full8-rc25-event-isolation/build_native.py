from pathlib import Path
import os,sys,subprocess,json,hashlib
src=Path(__file__).resolve().parents[1]/'repair-full8-rc7/transfer_final.c';out=Path(sys.argv[1]);out.mkdir(exist_ok=True,parents=True);env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(out/'zig-global'),ZIG_LOCAL_CACHE_DIR=str(out/'zig-local'))
def build(p,name):
 obj=out/(name+'.o');so=out/(name+'.so')
 subprocess.run([sys.executable,'-m','ziglang','cc','-target','aarch64-freestanding','-c','-ffreestanding','-fno-stack-protector','-ffixed-x18','-fPIC','-fvisibility=hidden','-mno-outline-atomics','-O2','-g0',str(p),'-o',str(obj)],env=env,check=True)
 subprocess.run([sys.executable,'-m','ziglang','ld.lld','-shared','-Bsymbolic','-z','max-page-size=16384',str(obj),'-o',str(so)],env=env,check=True);return so
old=build(src,'old-transfer');assert hashlib.sha256(old.read_bytes()).hexdigest()=='0d0d588b4305536d3dd3db14edbeb1d6965f1957178b6a8eeedc24a33052d403'
p=out/'transfer_final.c';original=src.read_text();changed=original.replace('return c==122||','return c==901||c==902||c==122||');assert changed!=original;p.write_text(changed);new=build(p,'event-transfer');print(json.dumps(dict(passed=True,baseline_reproduced_exact=True,change='Extend native exact-scope acceptance by901/902; all old scopes retained',sha256=hashlib.sha256(new.read_bytes()).hexdigest()),indent=2))
