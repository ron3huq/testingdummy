"""Actual ARM64 eligibility and resource path hooks, with a synthetic loader."""
import sys,json,struct
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'repair-full8-rc9-ucl'))
from test_face_profile import Runner,B,END
from elftools.elf.elffile import ELFFile
from unicorn import UC_HOOK_CODE
from unicorn.arm64_const import *

def symbols(path):
 with Path(path).open('rb')as f:return {s.name:s['st_value']for s in ELFFile(f).get_section_by_name('.symtab').iter_symbols()}
def call(r,s,name,*args):
 for i,v in enumerate(args):r.u.reg_write(UC_ARM64_REG_X0+i,v)
 return r.call(s[name],args[0]if args else 0)
old=Path('/workspace/apk73-work/rc24-full/payload/assets/gateway-release/work/tools/libnoodle_hair.so');new=Path(sys.argv[1]);a=Runner(old);b=Runner(new);so=symbols(old);sn=symbols(new);cards={106783356083208:'R7A2',88043608522885:'R0A2'};controls=[89138556572074,88044950524330,106654775417922,123,106783356083209]
for pid in cards:assert call(a,so,'target_card',pid)==0 and call(b,sn,'target_card',pid)==1
for pid in controls:assert call(a,so,'target_card',pid)==call(b,sn,'target_card',pid)
reports=[];cards[89138556572074]='R9D2'
for pid,profile in cards.items():
 r=Runner(new);u=r.u;u.mem_map(0x30000000,0x10000);u.reg_write(UC_ARM64_REG_TPIDR_EL0,0x1234);ctx=0x30001000;character=0x30002000;path=0x30005000;stub=0x30000000;captured=[]
 def loader(u,addr,size,data):
  if addr!=stub:return
  pointer=u.reg_read(UC_ARM64_REG_X1);length=u.reg_read(UC_ARM64_REG_X2);captured.append(bytes(u.mem_read(pointer,length*2)).decode('utf-16le').rstrip('\0'));u.reg_write(UC_ARM64_REG_X0,42);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_LR))
 u.hook_add(UC_HOOK_CODE,loader);call(r,sn,'noodle_enable',1);call(r,sn,'configure_path',0,stub);assert call(r,sn,'enter',ctx,1)<16;u.mem_write(ctx+8,struct.pack('<Q',character));u.mem_write(character+0x10b0,struct.pack('<Q',pid));u.mem_write(character+0x10a8,struct.pack('<I',12345));u.mem_write(ctx+16,('12345\0').encode('utf-16le'))
 for variant in ['','ep00v0313','ep01v0291','lg00v0000']:
  text="SkeletalMesh'/Game/Assets/character/RealFace/SK_12345"+variant+"_Face.SK_12345"+variant+"_Face'";u.mem_write(path,(text+'\0').encode('utf-16le'));result=call(r,sn,'noodle_path_hook',0,path,len(text)+1)
  assert result==42
  assert profile in captured[-1],(pid,variant,captured[-1]);assert '12345'not in captured[-1];reports.append(dict(card_id=pid,variant=variant or'base',redirected_path=captured[-1]))
print(json.dumps(dict(passed=True,actual_ARM64_executed=True,RC24_gate_bug_reproduced=True,new_card_gates_accept=True,old_card_controls_unchanged=True,synthetic_loader=True,resource_paths=reports,phone_verified=False),indent=2))
