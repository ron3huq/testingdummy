import sys,json,struct,copy,tempfile,types,sqlite3
from pathlib import Path
sys.path[:0]=[str(Path(__file__).parent/'runtime'),str(Path(__file__).parents[1]/'repair-full8-rc9-ucl')]
import rc25_settings as settings
from test_face_profile import Runner,B
from elftools.elf.elffile import ELFFile
from unicorn import UC_HOOK_CODE
from unicorn.arm64_const import *
p=Path('/workspace/apk73-inputs/v18-decoded/lib/arm64-v8a/libefpatch.so');r=Runner(p);u=r.u;engine=0x10000000
with p.open('rb')as f:sy={s.name:s['st_value']for s in ELFFile(f).get_section_by_name('.dynsym').iter_symbols()}
for page in {(s['offset']&~4095)+n for ft in settings.FEATURES for s in ft['sites']for n in [0,4096]}:
 u.mem_map(engine+page,4096)
for ft in settings.FEATURES:
 for s in ft['sites']:u.mem_write(engine+s['offset'],int(s['stock_bytes'],16).to_bytes(s['length'],'little'))
def hook(u,addr,size,data):
 if addr==B+0x4424:u.reg_write(UC_ARM64_REG_X0,engine);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_LR))
 elif int.from_bytes(u.mem_read(addr,4),'little')==0xd4000001:u.reg_write(UC_ARM64_REG_X0,0);u.reg_write(UC_ARM64_REG_PC,addr+4)
u.hook_add(UC_HOOK_CODE,hook)
def call(name,*args):
 for i,v in enumerate(args):u.reg_write(UC_ARM64_REG_X0+i,v)
 return r.call(sy['Java_com_efpatch_Native_'+name],args[0]if args else 0)
def read(offset,size):return call('read',0,0,offset,size)
def write(offset,value,size,protection):
 n=call('write',0,0,offset,value,size,protection);return n if n<2**31 else n-2**32
count=0
for ft in settings.FEATURES:
 for i in range(len(ft['labels'])):
  d=settings.apply_feature(ft,i,read,write);assert d['readback_verified'];count+=1
 settings.apply_feature(ft,ft['stock'],read,write)
# An unknown patch is refused before any site is written.
ft=settings.FEATURES[-1];s=ft['sites'][0];u.mem_write(engine+s['offset'],bytes(s['length']));before=[read(s['offset'],s['length'])for s in ft['sites']]
try:settings.apply_feature(ft,1,read,write);raise AssertionError('conflict accepted')
except ValueError:pass
assert before==[read(s['offset'],s['length'])for s in ft['sites']]
with tempfile.TemporaryDirectory()as tmp:
 c=sqlite3.connect(Path(tmp)/'fixture.db');c.execute('CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT)');c.execute("INSERT INTO meta VALUES('ui712_transfer','{}')");c.commit();gateway=types.SimpleNamespace(_logic=types.SimpleNamespace(conn=c),manage=lambda*a:'old');settings.install(gateway);reply=json.loads(gateway.manage('rc25_settings_save',json.dumps(dict(values={'Game Speed':3,'PC Mode':1}))));assert not reply['engine_ready'];assert next(f for f in reply['features']if f['name']=='Game Speed')['status']['state']=='pending';assert c.execute("SELECT value FROM meta WHERE key='ui712_transfer'").fetchone()[0]=='{}'
 assert json.loads(c.execute('SELECT value FROM meta WHERE key=?',(settings.KEY,)).fetchone()[0])['Game Speed']==3
print(json.dumps(dict(passed=True,actual_v18_ARM64_writer_executed=True,engine_base_and_mprotect_boundaries_mocked=True,feature_count=len(settings.FEATURES),all_choices_roundtripped=count,conflicting_bytes_blocked=True,save_persists_without_engine=True,pending_not_reported_as_applied=True,old_transfer_save_unchanged=True,phone_verified=False),indent=2))
