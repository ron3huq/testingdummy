"""V19 captured packets + original V25 cup code/UI snapshots on fixture saves."""
import sys,json,copy,tempfile,types,msgpack
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent.parent/'repair-full8-rc22-event-face'))
from host_reference import References
BASE=Path('/workspace/apk73-work/rc22-host/base');STAGE=Path('/workspace/apk73-work/rc25-full/payload')
sys.meta_path.insert(0,References('/workspace/apk73-inputs/decoded/73efootball-V19.1.apk',BASE))
import club_store,cup_entry,my_league,opponent_squad
originals=(my_league.prepare,my_league.start,my_league.finish,opponent_squad.preset)
responses={}
for p in(BASE/'outputs/reference/decrypted').glob('*_resp.txt'):
 try:
  obj=msgpack.unpackb(p.read_bytes(),raw=False,strict_map_key=False)
  if isinstance(obj,dict):responses[p.name.split('_gate_',1)[-1].removesuffix('_resp.txt')]=obj
 except (ValueError,msgpack.UnpackException,UnicodeError):pass
opened=[]
class AndroidPanelBoundary:
 @staticmethod
 def openFromGateway(event):opened.append(event)
java=types.ModuleType('java')
def jclass(name):
 if name!='org.efootballrevival.runtimeprobe.CupTournamentPanel':raise ImportError('Android boundary not provided: '+name)
 return AndroidPanelBoundary
java.jclass=jclass;sys.modules['java']=java
class Logic:
 def __init__(self,conn):self.conn=conn;self.responses=responses;self.templates={}
 def handle(self,mid,req):
  response=cup_entry.handle(self,mid,req)
  if response is not None:return response
  response=copy.deepcopy(self.responses.get(mid,dict(result='NOERR')));response.update(msgid=mid,rqid=req.get('rqid'))
  return cup_entry.project(self,response)if mid in cup_entry.LIST_COMMANDS else response

import shutil
with tempfile.TemporaryDirectory()as tmp:
 root=Path(tmp);conn=club_store.connect(root/'fixture.sqlite3');club_store.seed(conn);conn.commit();gateway=types.ModuleType('fixture_gateway');gateway._logic=Logic(conn);gateway.manage=lambda*a:'original-manage'
 sys.path.insert(0,str(STAGE/'assets/gateway-release/work/tools'))
 import myleague_editor_runtime as editor,transfer_editor as transfer,transfer_player_editor as players,body_dimensions
 project=root/'work/tools/myleague_editor.json';project.parent.mkdir(parents=True);shutil.copy2(STAGE/'assets/gateway-release/work/tools/myleague_editor.json',project);editor.PATH=project;editor._config=None
 transfer.install(gateway);transfer.post_install()
 public_transfer=transfer;public_players=players;public_editor=editor
 original_catalog=copy.deepcopy(transfer.catalog());original_public_file=project.read_bytes()
 original_keys={key:club_store.get_meta(conn,key,'MISSING')for key in ['ui712_transfer','full5_transfer_players','my_league_state_v1']}
 sys.path.insert(0,str(Path(__file__).parent/'runtime'));import rc25_event_editor
 private=rc25_event_editor.load_modules();private['myleague_editor_runtime'].PATH=root/'work/tools/event-transfer-editor.json';rc25_event_editor.install(gateway)
 transfer=rc25_event_editor.transfer();players=rc25_event_editor.players();editor=rc25_event_editor.editor()

 import rc22_v25_events as port;port.install(gateway)
 sys.path.insert(0,str(Path(__file__).parent/'runtime'));import rc24_cups;rc24_cups.install(gateway,port._modules)
 modules=port._modules;opp=modules['opponent_squad'];rolemap={r['name']:r['id']for r in transfer.catalog()['roles']};saved=[]
 for cupkey,cid,source in [('ucl',901,'plan'),('wc',902,'wc_plan')]:
  spec=modules['cup_spec'].SPECS[cupkey]
  service=modules['cup_entry']._ucl_service(gateway._logic,spec);state=service._ensure_entered()
  entry=state['opponents'][0];index=entry['index'];source=entry['source'];native=opp.build(conn,index,source=source);tid=native['team_id'];formation=native['squad_data']['squad_gameplan']['formation'][0]['formation_offensive']
  roster=[]
  for i,p in enumerate(native['player_list']):
   f=formation[i]if i<11 else dict(role=5,position_x=0,position_y=0)
   roster.append(dict(id=str(p['gameplayer_id']['id']),shirt=p['uniform_number'],role=f['role'],x=f['position_x'],y=f['position_y']))
  seed=dict(team_id=tid,competition=cid,name=entry['team_name'],roster=roster,captain=roster[4]['id'],kickers=[roster[9]['id']]*6,source='HOST_NATIVE_PACKET_FIXTURE',verified_formation=True)
  transfer.validate_team(seed);transfer.profiles[transfer.key(tid,cid)]=seed
  edited=copy.deepcopy(seed);edited['roster'][1]['shirt'],edited['roster'][2]['shirt']=edited['roster'][2]['shirt'],edited['roster'][1]['shirt'];edited['roster'][1]['x']=19;edited['captain']=roster[3]['id'];edited['kickers']=[roster[3]['id'],roster[4]['id'],roster[5]['id'],None,roster[6]['id'],roster[7]['id']];edited['kits']=transfer.kit_choices(tid);edited['kits'][0],edited['kits'][1]=edited['kits'][1],edited['kits'][0]
  edited['roster'][10],edited['roster'][13]=edited['roster'][13],edited['roster'][10];edited['roster'][10].update(role=12,x=43,y=52)
  reply=transfer.manage(conn,'ui712_transfer_save',dict(team_id=tid,competition=cid,revision=transfer.revision(transfer.source(tid,cid)),team=edited));assert reply['saved']
  pid=edited['roster'][1]['id'];values=dict(parameters={'14':99},foot={'42':1,'43':1,'45':2},positions={'0':1,'1':2},skills=[0,1],celebrations={'59':1,'60':1},sleeve='long',accessories={'4':2},bandage_left=1,bandage_right=2)
  reply=players.manage(conn,'ui712_transfer_player_apply',dict(team_id=tid,competition=cid,player_id=pid,values=values));assert reply['saved']
  # Prepare through the actual Event request, not just a helper call. The
  # fixture's first group opponent may differ, so inspect the selected edited
  # opponent with the same scoped donor builder used during preparation.
  oldspec=getattr(rc24_cups._local,'spec',None);rc24_cups._local.spec=spec
  try:packet=opp.build(conn,index,source=source)
  finally:rc24_cups._local.spec=oldspec
  assert [str(p['gameplayer_id']['id'])for p in packet['player_list']]==[p['id']for p in edited['roster']]
  assert [p['uniform_number']for p in packet['player_list']]==[p['shirt']for p in edited['roster']]
  plan=packet['squad_data']['squad_gameplan'];assert plan['formation'][0]['formation_offensive'][1]['position_x']==19
  assert plan['match_plan_settings']['captain']==3;assert plan['match_plan_settings']['set_piece_taker'][3]==255;assert plan['match_plan_settings']['order'][:len(roster)]==list(range(len(roster)))
  p=next(p for p in packet['player_list']if str(p['gameplayer_id']['id'])==pid);assert p['parameters'][14]==99 and p['parameters'][42]==1 and p['parameters'][59]==1 and p['parameters'][60]==1
  listing=json.loads(gateway.manage('rc24_cup_transfer_list',json.dumps(dict(competition=cid))));assert [r['id']for r in listing['leagues']]==[901,902]
  saved.append(dict(cup=cupkey,competition=cid,team_id=tid,roster_order_shirts_formation_captain_kickers=True,player_stats_feet_positions_skills_celebrations=True,existing_transfer_save_endpoints_reused=True))
 # Use the existing atomic two-team move endpoint, then build the destination.
 spec=modules['cup_spec'].SPECS['ucl'];state=modules['cup_entry']._ucl_service(gateway._logic,spec)._ensure_entered();cid=901
 a,b=state['opponents'][:2];sr=opp.build(conn,a['index'],source=a['source']);dr=opp.build(conn,b['index'],source=b['source']);sid=sr['team_id'];did=dr['team_id']
 if isinstance(sid,list):sid=sid[0]
 if isinstance(did,list):did=did[0]
 src=transfer.source(sid,cid);dest=transfer.source(did,cid);pid=next(r['id']for r in src['roster'][11:]if r['id']not in{d['id']for d in dest['roster']})
 result=transfer.manage(conn,'ui712_transfer_move',dict(team_id=sid,competition=cid,target_team=did,player_id=pid,revision=transfer.revision(src),target_revision=transfer.revision(dest)));assert result['saved']
 rc24_cups._local.spec=spec
 try:packet=opp.build(conn,b['index'],source=b['source'])
 finally:rc24_cups._local.spec=None
 assert pid in{str(p['gameplayer_id']['id'])for p in packet['player_list']};assert pid not in{r['id']for r in transfer.source(sid,cid)['roster']}
 # Persistence uses the real existing Transfer keys and project file, and the
 # normal pre-engine edit guard remains active.
 tid=sid;cid=901;edited=transfer.source(tid,cid)
 original_loaded=body_dimensions.engine_loaded;body_dimensions.engine_loaded=lambda:True
 try:
  try:transfer.manage(conn,'ui712_transfer_save',dict(team_id=tid,competition=cid,revision=transfer.revision(transfer.source(tid,cid)),team=edited));raise AssertionError('edit while engine loaded was accepted')
  except ValueError as error:assert 'Close and reopen' in str(error)
 finally:body_dimensions.engine_loaded=original_loaded
 transfer.profiles={};transfer._conn=None;transfer.load(conn);players.restore_config(conn);assert len(players._profiles)==2
 assert all(transfer.source(row['team_id'],row['competition'])['ui712_transfer']for row in saved)
 assert public_transfer.catalog()==original_catalog
 assert project.read_bytes()==original_public_file
 assert all(club_store.get_meta(conn,key,'MISSING')==value for key,value in original_keys.items())
 assert public_transfer.profiles=={} and public_players._profiles=={}
 # Reused native installer sees both scopes without changing public config().
 assert all(r['competition']in (901,902)for r in editor.config()['teams'])
 assert not any(r['competition']in (901,902)for r in public_editor.config()['teams'])
 # Event roster map resets on ordinary competition activation.
 import select_team_runtime,ziru_data
 select_team_runtime.activate_context(901);assert [int(r['id'])for r in transfer.source(did,901)['roster']]==ziru_data.rosters()[str(did)]
 select_team_runtime.activate_context(122);assert ziru_data.rosters()[str(did)]!=[int(r['id'])for r in transfer.source(did,901)['roster']]

 # Exercise the actual Python native installer on a recording boundary.
 class Function:
  def __init__(self,name,hook):self.name=name;self.hook=hook
  def __call__(self,*args):
   self.hook.calls.append((self.name,args))
   if self.name in ['editor_add_player','editor_add_team']:return len(self.hook.calls)
   return 1
 class Hook:
  def __init__(self):self.calls=[]
  def __getattr__(self,name):
   fn=Function(name,self);setattr(self,name,fn);return fn
 hook=Hook();public_editor.install_native(hook);public_transfer.configure(hook)
 assert {args[1]for name,args in hook.calls if name=='editor_add_team'}>={901,902}
 assert {args[1]for name,args in hook.calls if name=='editor_kit_add'}>={901,902}
 assert any(name=='editor_accessory'for name,args in hook.calls)
 assert project.read_bytes()==original_public_file
 assert public_editor.config()==json.loads(original_public_file)
 # A fresh interpreter validates new v25 cards before loading saved profiles.
 import subprocess
 script="""import sys,types
from pathlib import Path
sys.path.insert(0,sys.argv[1]);from host_reference import References
sys.meta_path.insert(0,References('/workspace/apk73-inputs/decoded/73efootball-V19.1.apk',Path('/workspace/apk73-work/rc22-host/base')))
sys.path[:0]=[sys.argv[2],sys.argv[3]]
import club_store,myleague_editor_runtime as editor,transfer_editor as public,rc25_event_editor as event
editor.PATH=Path(sys.argv[4]);editor._config=None
conn=club_store.connect(Path(sys.argv[5]));gateway=types.SimpleNamespace(_logic=types.SimpleNamespace(conn=conn),manage=lambda *a:'base')
public.install(gateway);public.post_install();event.load_modules()['myleague_editor_runtime'].PATH=Path(sys.argv[6]);event.install(gateway)
assert len(event.transfer().profiles)>=3 and public.profiles=={}
assert all(p['competition']in(901,902)for p in event.transfer().profiles.values())
"""
 subprocess.run([sys.executable,'-c',script,str(Path(__file__).parent.parent/'repair-full8-rc22-event-face'),str(Path(__file__).parent/'runtime'),str(STAGE/'assets/gateway-release/work/tools'),str(project),str(root/'fixture.sqlite3'),str(editor.PATH)],check=True)
 print(json.dumps(dict(passed=True,native_combined_registration_and_scoped_kits_and_gear_verified=True,public_catalog_and_file_and_save_keys_unchanged=True,context_restores_old_rosters=True,private_event_scopes=[901,902],atomic_team_move_and_moved_card_built=True,cold_start_saved_v25_profiles_valid=True,events=saved,persistent_profiles_reload=True,pre_engine_save_guard_preserved=True,engine_visual_changes_executed=False,phone_verified=False),indent=2))
