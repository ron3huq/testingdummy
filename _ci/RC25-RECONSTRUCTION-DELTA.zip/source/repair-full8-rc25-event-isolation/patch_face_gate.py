from pathlib import Path
import sys,os,subprocess,struct,io,hashlib,json
from elftools.elf.elffile import ELFFile
src=Path(__file__).resolve().parent;out=Path(sys.argv[1]);out.mkdir(exist_ok=True,parents=True);env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(out/'zig-global'),ZIG_LOCAL_CACHE_DIR=str(out/'zig-local'))
subprocess.run([sys.executable,'-m','ziglang','cc','-target','aarch64-freestanding','-c',str(src/'profile.S'),'-o',str(out/'profile.o')],env=env,check=True)
subprocess.run([sys.executable,'-m','ziglang','ld.lld','-T',str(src/'profile.ld'),str(out/'profile.o'),'-o',str(out/'profile.elf')],env=env,check=True)
b=bytearray(Path('/workspace/apk73-work/rc24-full/payload/assets/gateway-release/work/tools/libnoodle_hair.so').read_bytes());assert hashlib.sha256(b).hexdigest()=='037d314f8d2bdacca697472e7ce67c179f997bb5041744ccbb52be7209015713'
e=ELFFile(io.BytesIO(b));new=ELFFile(io.BytesIO((out/'profile.elf').read_bytes()));text=new.get_section_by_name('.text').data();rx=next((i,s)for i,s in enumerate(e.iter_segments())if s['p_type']=='PT_LOAD'and s['p_vaddr']==0x100000);i,seg=rx;at=seg['p_offset']+4096
assert b[at:at+seg['p_filesz']-4096]==text[:seg['p_filesz']-4096]
b[at:at+len(text)]=text;ph=e['e_phoff']+i*56;struct.pack_into('<QQ',b,ph+32,4096+len(text),4096+len(text))
s=next(s for s in e.iter_segments()if s['p_type']=='PT_LOAD'and s['p_vaddr']<=0x16fc0<s['p_vaddr']+s['p_filesz']);off=s['p_offset']+0x16fc0-s['p_vaddr'];assert struct.unpack_from('<I',b,off)[0]==0xd29f00c9;struct.pack_into('<I',b,off,0x14000000|(((0x101200-0x16fc0)//4)&0x3ffffff))
s=next(s for s in e.iter_segments()if s['p_type']=='PT_LOAD'and s['p_vaddr']<=0x19698<s['p_vaddr']+s['p_filesz']);off=s['p_offset']+0x19698-s['p_vaddr'];assert struct.unpack_from('<I',b,off)[0]==0xd28eb9e8;struct.pack_into('<I',b,off,0x14000000|(((0x101280-0x19698)//4)&0x3ffffff))
p=out/'face-noodle.so';p.write_bytes(b);print(json.dumps(dict(passed=True,old_RC24_profile_router_preserved=True,old_exports_and_RVAs_preserved=True,new_card_gate_rva=0x101200,sha256=hashlib.sha256(b).hexdigest()),indent=2))
