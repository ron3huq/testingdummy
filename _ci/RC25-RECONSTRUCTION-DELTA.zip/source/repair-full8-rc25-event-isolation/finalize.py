from pathlib import Path
import sys,json,hashlib,shutil,re,importlib.util,ast
SRC=Path(__file__).resolve().parent;VERSION='V19.1-FULL8-RC25-EVENT-EDIT-V5-SETTINGS-FACEGATE'
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def helper(p):
 s=importlib.util.spec_from_file_location('manifest_helper',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def run(root,research):
 root=Path(root);research=Path(research);g=root/'assets/gateway-release';t=g/'work/tools';v=root/'validation'
 for key in ['transfer','native','probability','face-gate','settings','launcher','event-cycle','native-opponent-stats','native-build','face-build']:
  q=research/(key+'.json');assert json.loads(q.read_text())['passed'],key;shutil.copy2(q,v/('full8-rc25-'+key+'.json'))
 dex=research.parent/'rc25-dex';d=json.loads((dex/'report.json').read_text());assert d['passed']and d['new_dex_sha256']==sha(dex/'classes5.dex');shutil.copy2(dex/'classes5.dex',root/'classes5.dex');shutil.copy2(dex/'report.json',v/'full8-rc25-dex.json')
 for p in(SRC/'overlays').rglob('*'):
  if p.is_file():shutil.copy2(p,root/p.relative_to(SRC/'overlays'))
 for p in(SRC/'runtime').glob('*'):
  if p.is_file():shutil.copy2(p,t/p.name)
 shutil.copy2(research/'face/face-noodle.so',t/'libnoodle_hair.so');shutil.copy2(research/'native/event-transfer.so',t/'libtransfer_final.so');shutil.copy2('/workspace/apk73-inputs/v18-decoded/lib/arm64-v8a/libefpatch.so',t/'libv18_settings.so')
 p=t/'noodle_hair.py';s,n=re.subn(r"HOOK_SHA='[^']+'","HOOK_SHA='"+sha(t/'libnoodle_hair.so')+"'",p.read_text());assert n==1;p.write_text(s)
 p=t/'transfer_final_runtime.py';s,n=re.subn(r"HOOK_SHA='[^']+'","HOOK_SHA='"+sha(t/'libtransfer_final.so')+"'",p.read_text());assert n==1;p.write_text(s)
 assert 'rc24_registry.install()'not in(t/'bridge_73.py').read_text();assert 'rc25_event_editor.install(module)'in(t/'bridge_73.py').read_text()
 # Mutable on-device Event project is seeded at runtime, not shipped over saves.
 assert not(t/'event-transfer-editor.json').exists()
 p=t/'private_bundles.json';d=json.loads(p.read_text());d['resource_revision']=19025;p.write_text(json.dumps(d,indent=2)+'\n')
 p=t/'noodle_bundle.json';d=json.loads(p.read_text());d.update(version=VERSION,asset_revision=19025,native_sha256=sha(t/'libnoodle_hair.so'));d['rc25_changes']=dict(Event_Transfer_isolated_contexts={'UCL':901,'WorldCup':902},public_Transfer_contexts_unchanged=[122,128,473,518],UCL_AI_model='DOCX-v5; same pool; seven unspecified clubs group4 by user choice',Ajax='unchanged by final user request',new_Ronaldo_native_gates='Initial target gates for2007/2020 and resource-path gate for all3 extended; same assets as RC24',v18_settings='7features; pending/apply/readback state; identical engine hash; phone unverified')
 names=set(d['appearance_files'])|{p.name for p in(SRC/'runtime').glob('*')if p.is_file()}|{'libv18_settings.so','transfer_final_runtime.py','libtransfer_final.so','bandage_runtime.py'};d['appearance_files']={name:sha(t/name)for name in sorted(names)};d['appearance_overlay_sha256']=sha(t/'myleague_editor_runtime.py');p.write_text(json.dumps(d,indent=2)+'\n')
 for filename,key in [('release-manifest.json','release_id'),('ui6-runtime-manifest.json','version')]:
  p=g/filename;d=json.loads(p.read_text());d[key]=VERSION;p.write_text(json.dumps(d,indent=2)+'\n')
 shutil.copytree(SRC,root/'source'/SRC.name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'));shutil.copy2(SRC/'README-VI.md',root/'README-VI.md')
 m=helper(root/'source/repair-full8-rc2-hf1/build_runtime_manifests.py');m.update(g);m.check(g)
 for p in t.glob('*.py'):ast.parse(p.read_text())
 sys.path.insert(0,str(root/'source/repair-full8-rc5-hf1'));from check_startup_integrity import verify;from verify_login_gate import run as login
 report=verify(root);report.update(login(root));report.update(version=VERSION,phone_verified=False);(v/'full8-rc25-startup.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':run(*sys.argv[1:])
