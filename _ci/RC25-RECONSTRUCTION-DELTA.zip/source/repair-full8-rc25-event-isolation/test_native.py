"""Execute ARM64 scope selection and overrides; synthetic engine boundaries."""
from pathlib import Path
import sys,json,struct
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'repair-full8-rc9-ucl'))
from test_face_profile import Runner,B,END
from elftools.elf.elffile import ELFFile
from unicorn import UC_HOOK_CODE
from unicorn.arm64_const import *

def symbols(path):
 with Path(path).open('rb')as f:return {s.name:s['st_value']for s in ELFFile(f).get_section_by_name('.symtab').iter_symbols()}
def runner(path):
 r=Runner(path)
 with Path(path).open('rb')as f:
  e=ELFFile(f);rel=e.get_section_by_name('.rela.dyn')
  if rel:
   for item in rel.iter_relocations():
    assert item['r_info_type']==1027,item['r_info_type']
    r.u.mem_write(B+item['r_offset'],struct.pack('<Q',B+item['r_addend']))
 return r
def call(r,s,name,*args):
 for i,v in enumerate(args):r.u.reg_write(UC_ARM64_REG_X0+i,v)
 return r.call(s[name],args[0]if args else 0)
root=Path(sys.argv[1]);native=root/'assets/gateway-release/work/tools/libselect_team.so';r=runner(native);sy=symbols(native)
for cid in [901,122,902,128,0,518]:
 call(r,sy,'activate_context',cid);assert call(r,sy,'environment_status',0)==cid
for cid in [122,901,128,902]:
 assert call(r,sy,'editor_add_player',89138556572074,cid,0)
 assert call(r,sy,'editor_add_team',10,cid,11,255)
p=Path(sys.argv[2]);r=runner(p);sy=symbols(p);engine=0x10000000;scope=0x30000000;pid=89138556572074;record=0x30001000;data={i:70 for i in range(147)};current=[0]
addresses={engine+0x68fe720:'key',engine+0x82a84d4:'get',engine+0x82a907c:'set',scope:'scope'}
for page in {v&~4095 for v in addresses}|{record&~4095}:r.u.mem_map(page,4096)
def boundary(u,address,size,unused):
 name=addresses.get(address)
 if name is None:return
 a=[u.reg_read(UC_ARM64_REG_X0+i)for i in range(3)]
 if name=='key':u.reg_write(UC_ARM64_REG_X0,0);u.reg_write(UC_ARM64_REG_X1,pid)
 elif name=='get':u.mem_write(a[2],struct.pack('<I',data[a[1]]));u.reg_write(UC_ARM64_REG_X0,1)
 elif name=='set':data[a[1]]=a[2];u.reg_write(UC_ARM64_REG_X0,1)
 else:u.reg_write(UC_ARM64_REG_X0,current[0])
 u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_LR))
r.u.hook_add(UC_HOOK_CODE,boundary);assert call(r,sy,'final_bind',engine,scope,scope)==1
values={122:31,901:99,128:42,902:88}
for cid,v in values.items():
 row=call(r,sy,'final_add',pid,cid);assert row;assert call(r,sy,'final_parameter',row,14,v)==1
call(r,sy,'final_commit')
for cid in [122,901,128,902,122,0,901,902,128,0]:
 token=call(r,sy,'final_before_record',record,pid);current[0]=cid;call(r,sy,'final_after_record',record,pid,token);assert data[14]==values.get(cid,70),(cid,data[14]);assert data[15]==70
print(json.dumps(dict(passed=True,actual_ARM64_executed=True,select_team_accepts_separate_contexts=True,same_card_four_scopes_repeated_restore=True,unrelated_parameters_unchanged=True,synthetic_engine_boundaries=True,phone_verified=False),indent=2))
