"""Reuse saved Transfer profiles for Event packets; never copy My League seasons."""
import copy

def project_player(player,cid):
 import rc25_event_editor
 editor=rc25_event_editor.editor();transfer_player_editor=rc25_event_editor.players()
 out=editor.project(player,cid);params=list(out.get('parameters')or[])
 if len(params)>=147:
  pid=str((out.get('gameplayer_id')or{}).get('id',0));out=copy.deepcopy(out)
  for row in sorted(editor.projection_rows().get(pid,[]),key=lambda r:r['competition']!=0):
   if row['competition']not in (0,int(cid)):continue
   for field in ['parameters','position_parameters']:
    for key,value in row.get(field,{}).items():params[int(key)]=value
   if 'boosters'in row:params[144:147]=row['boosters']
  changes=transfer_player_editor._profiles.get(str(cid)+':'+pid,{})
  out['parameters']=transfer_player_editor.project_parameters(params,changes)
  if 'boosters'in changes:out['initial_booster_id_list']=list(changes['boosters'])
 return out

def apply_squad(result,team,cid):
 import rc25_event_editor
 editor=rc25_event_editor.editor();transfer_player_editor=rc25_event_editor.players()
 result=copy.deepcopy(result);rows=result.get('player_list',[]);by_id={str(p.get('gameplayer_id',{}).get('id')):p for p in rows};roster=team['roster'];ordered=[]
 for slot in roster:
  player=by_id.get(slot['id'])
  if player is None:raise ValueError('Edited cup roster card was not built: '+slot['id'])
  player=project_player(player,cid);player['uniform_number']=slot['shirt'];ordered.append(player)
 result['player_list']=ordered;squad=result.get('squad_data')
 if isinstance(squad,dict):
  squad['player_list']=[dict(gameplayer_id=copy.deepcopy(p['gameplayer_id']),uniform_number=slot['shirt'])for p,slot in zip(ordered,roster)]
  plan=squad.get('squad_gameplan')
  if isinstance(plan,dict):
   settings=plan.get('match_plan_settings')
   if isinstance(settings,dict):
    ids=[p['id']for p in roster];settings['order']=list(range(len(roster)))+[255]*(40-len(roster));settings['captain']=ids.index(team['captain'])if team.get('captain')in ids else 255;settings['set_piece_taker']=[ids.index(p)if p in ids else 255 for p in team['kickers']]
   forms=plan.get('formation',[])
   for index,form in enumerate(forms):
    for kind,offset in [('formation_offensive',0),('formation_defensive',1)]:
     plans=team.get('plans');native=plans[(index*2+offset)%4]['slots']if plans else roster[:11]
     form[kind]=[dict(role=p['role'],position_x=p['x'],position_y=p['y'])for p in native]
    form['is_position_edited']=['YES','YES']
 return result

def project_packet(response,cid):
 import rc25_event_editor
 editor=rc25_event_editor.editor()
 response=copy.deepcopy(response)
 for key in ['player_list','player_list_home','player_list_away']:
  if isinstance(response.get(key),list):response[key]=[project_player(p,cid)if isinstance(p,dict)and'parameters'in p else p for p in response[key]]
 for key in ['squad_data_home','squad_data_away']:
  squad=response.get(key)
  if isinstance(squad,dict)and isinstance(squad.get('player_list'),list):squad['player_list']=[project_player(p,cid)if isinstance(p,dict)and'parameters'in p else p for p in squad['player_list']]
 return response
