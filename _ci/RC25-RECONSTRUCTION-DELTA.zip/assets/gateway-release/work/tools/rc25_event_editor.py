"""Private instances of the existing editor: no My League catalogue/save mutation.
The GUI and editor implementations are reused, with separate persistence and
native competition contexts for UCL Event (901) / World Cup Event (902).
"""
from pathlib import Path
import builtins,copy,functools,json,sys,threading,types
HERE=Path(__file__).resolve().parent
SCOPES={'ucl':901,'wc':902};DONOR={901:122,902:128}
modules={};_installed=False;_lock=threading.RLock()
NAMES=['myleague_editor_runtime','transfer_editor','transfer_player_editor','transfer_native_data','transfer_traits']

def load_modules():
 if modules:return modules
 source_dir=Path(builtins.__import__('myleague_editor_runtime').__file__).resolve().parent
 for name in NAMES:modules[name]=types.ModuleType('rc25_event_private.'+name)
 def private_import(name,globals=None,locals=None,fromlist=(),level=0):
  if not level and name in modules:return modules[name]
  return builtins.__import__(name,globals,locals,fromlist,level)
 for name in NAMES:
  module=modules[name];module.__file__=str(source_dir/(name+'.py'));module.__package__='';module.__dict__['__builtins__']=dict(vars(builtins),__import__=private_import)
  exec(compile(Path(module.__file__).read_text(),module.__file__,'exec'),module.__dict__)
 editor=modules['myleague_editor_runtime'];transfer=modules['transfer_editor'];players=modules['transfer_player_editor'];native=modules['transfer_native_data']
 editor.PATH=HERE/'event-transfer-editor.json';editor.SCOPES={901,902};editor._config=None
 editor.requested_long_sleeves=lambda data:editor.validate(copy.deepcopy(data))
 transfer.KEY='rc25_event_transfer_teams';players.KEY='rc25_event_transfer_players';transfer.ALLOWED_COMPETITIONS=(901,902)
 # Reference data is an immutable published-v25 baseline, never the old editor
 # config, old captures, or old edited teams/cards.
 import rc24_registry
 refs=rc24_registry.data();catalog=copy.deepcopy(transfer.catalog());catalog['leagues']=[dict(id=cid,name='UCL · Event Mode'if cid==901 else'World Cup · Event Mode',teams=sorted({r['team_id']for r in refs['teams'].values()if r['competition']==donor}))for cid,donor in DONOR.items()]
 known={r['id']:r for r in catalog['teams']}
 for r in refs['teams'].values():known.setdefault(r['team_id'],dict(id=r['team_id'],name=r['name']))
 catalog['teams']=list(known.values());transfer.catalog=lambda:catalog;transfer.team_names.cache_clear();transfer.valid_players=lambda:set(refs['players'])|set(map(str,__import__('motion_editor').donors()))
 def source(tid,cid):
  if cid not in DONOR:return None
  row=transfer.profiles.get(transfer.key(tid,cid))or refs['teams'].get(str(DONOR[cid])+':'+str(tid))
  if row is None:return None
  row=copy.deepcopy(row);row['competition']=cid;return row
 transfer.source=source;transfer.captures=lambda:{}
 original_validate_kits=transfer.validate_kits
 def validate_kits(row):
  values=row.get('kits')
  if values is None:return
  if not isinstance(values,list)or len(values)!=4:raise ValueError('Four kit slots required')
  import team_kits
  checked=list(values);known=transfer.team_names()
  for i,uid in enumerate(values):
   if uid is None:continue
   transfer.integer(uid,1,2**32-1);tid,slot=divmod(uid,16384)
   # A real club can also be a retro kit-alias donor. Its native third kit
   # remains valid; the old validator confused donor IDs with virtual teams.
   stock=team_kits._ui712_original(tid)if hasattr(team_kits,'_ui712_original')else team_kits.uniform_ids(tid)
   if tid in known and slot<=15 and uid in stock:checked[i]=None
  return original_validate_kits(dict(row,kits=checked))
 transfer.validate_kits=validate_kits
 original_manage=transfer.manage
 def transfer_manage(c,action,request):
  reply=original_manage(c,action,request)
  if action=='ui712_transfer_list':
   for row in reply['teams']:row['ready']=True
  return reply
 transfer.manage=transfer_manage
 original_read=native.read
 def read(c,pid,cid):
  if cid not in DONOR:raise ValueError('Not an Event editor scope')
  if str(pid)not in refs['players']:return original_read(c,pid,cid)
  params=list(refs['players'][str(pid)]['parameters'][:147]);value=players._profiles.get(str(cid)+':'+str(pid),{});return players.project_parameters(params,value),'Verified v25 Event reference; separate Event edits'
 native.read=read
 return modules

def install(gateway):
 global _installed
 if _installed:return False
 m=load_modules();transfer=m['transfer_editor'];players=m['transfer_player_editor'];editor=m['myleague_editor_runtime'];conn=gateway._logic.conn
 with _lock:
  if not editor.PATH.exists():editor.PATH.write_text(json.dumps(editor.DEFAULT,indent=2))
  transfer.load(conn);transfer.restore_config();players.restore_config(conn)
 # Register private rows with the proven native editor. Clone the installer
 # function's globals instead of replacing public config() even temporarily.
 import myleague_editor_runtime as public
 old_native=public.install_native
 @functools.wraps(old_native)
 def install_native(hook):
  data=native_config()
  if len(data['players'])>1024 or len(data['teams'])>128:raise ValueError('Combined native editor capacity exceeded')
  g=dict(old_native.__globals__,config=lambda:data,requested_long_sleeves=lambda d:d);fn=types.FunctionType(old_native.__code__,g,old_native.__name__,old_native.__defaults__,old_native.__closure__);return fn(hook)
 public.install_native=install_native
 # Activate distinct native scopes; old context activation resets its own
 # roster map first, then only Event activation overlays Event rows.
 import select_team_runtime as native,ziru_data,team_kits
 old_activate=native.activate_context
 @functools.wraps(old_activate)
 def activate(cid):
  result=old_activate(cid)
  if int(cid)in DONOR:
   rows=ziru_data.rosters()
   for row in transfer.profiles.values():
    if row['competition']==int(cid):rows[str(row['team_id'])]=[int(p['id'])for p in row['roster']]
  return result
 native.activate_context=activate
 old_kits=team_kits.uniform_ids
 def kits(tid):
  cid=native.editor_context();row=transfer.profiles.get(transfer.key(tid,cid))if cid in DONOR else None
  if row and row.get('kits'):
   ids=[v for v in row['kits']if v is not None]
   if ids:return list(dict.fromkeys(ids))
  return old_kits(tid)
 team_kits.uniform_ids=kits
 old_manage=gateway.manage
 @functools.wraps(old_manage)
 def manage(action,payload=''):
  if action=='rc24_cup_transfer_list' or action.startswith('ui712_transfer_'):
   req=json.loads(payload or'{}');cid=req.get('competition',0)
   if action=='rc24_cup_transfer_list'and cid not in DONOR:raise ValueError('Select a separate Event editor')
   if cid in DONOR:
    with _lock:
     answer=transfer.manage(conn,'ui712_transfer_list'if action=='rc24_cup_transfer_list'else action,req)
     # Both Event choices stay inside this editor, never a My League option.
     return json.dumps(answer,ensure_ascii=False)
  return old_manage(action,payload)
 gateway.manage=manage;_installed=True;return True

def transfer():return load_modules()['transfer_editor']
def players():return load_modules()['transfer_player_editor']
def editor():return load_modules()['myleague_editor_runtime']

def native_config():
 import myleague_editor_runtime as public
 data=public.requested_long_sleeves(public.config());extra=editor().config();data['players']+=copy.deepcopy(extra['players']);data['teams']+=copy.deepcopy(extra['teams']);return data
