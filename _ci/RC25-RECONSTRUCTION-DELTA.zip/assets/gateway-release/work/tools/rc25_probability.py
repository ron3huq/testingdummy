"""User DOCX v5 W/D/L model, for unplayed UCL Event AI fixtures only.
Document title/advance and Golden Boot percentages are reference estimates, not
forced outcomes. Played/engine results and World Cup use their existing paths.
"""
import copy,hashlib,json,random,unicodedata
from pathlib import Path
TIERS={114:1,101:1,108:1,127:1,109:2,173:2,172:2,103:3,102:3,119:3,121:3,126:3,128:3,120:4,327:4,234:4,125:4,179:4,107:4,265:4,267:4,112:4,213:4,100:5,113:5,181:5,191:5,192:5,193:5,118:5,117:5,197:5,130:5,106:4,196:4,226:4,116:4,273:4,122:4,124:4}
# Stronger team's W/D/L when home vs away; equal-tier is home40/draw27/away33.
HOME=[(.40,.27,.33),(.55,.24,.21),(.68,.20,.12),(.78,.14,.08),(.85,.10,.05)]
AWAY=[(.33,.27,.40),(.42,.27,.31),(.55,.24,.21),(.66,.20,.14),(.74,.17,.09)]
SOURCE_SHA='0ff0cf85604a942ef79b75f02844688b664a8d422c4d7dfe953e5c5cfce24bd6'
PROFILES={127:[('kane',.36)],109:[('mbappe',.34)],173:[('haaland',.38)],114:[('dembele',.20),('kvaratskhelia',.20)],108:[('lewandowski',.22),('raphinha',.14),('yamal',.14)],100:[('fernandes',.12),('mbeumo',.14)]}

def probability(home,away,mu_streak=False):
 h,a=TIERS.get(int(home)),TIERS.get(int(away))
 if h is None or a is None:return None
 if h==a:p=list(HOME[0])
 elif h<a:p=list(HOME[a-h])
 else:
  win,draw,loss=AWAY[h-a];p=[loss,draw,win]
 if mu_streak:
  side=0 if int(home)==100 else 2 if int(away)==100 else None
  if side is not None:
   delta=min(.04,p[side]);p[side]-=delta;p[2-side]+=delta
 return tuple(p)

def seed(state,match):
 text='rc25-v5:'+str(state['cup_id'])+':'+str(state['event_id'])+':'+str(match.get('matchday','KO'))+':'+str(match.get('index'))+':'+str(match['home_team_id'])+':'+str(match['away_team_id'])
 return int.from_bytes(hashlib.sha256(text.encode()).digest(),'big')
def is_ucl(state):return state.get('event_id')in(1120006,1120007)
def mu_losing_streak(state,match):
 rows=[r for r in state.get('matches',[])if r.get('played')and r.get('matchday',99)<match.get('matchday',0)and 100 in(r.get('home_team_id'),r.get('away_team_id'))]
 rows.sort(key=lambda r:(r['matchday'],r.get('index',0)))
 return len(rows)>=2 and all((r['home_score']<r['away_score']if r['home_team_id']==100 else r['away_score']<r['home_score'])for r in rows[-2:])

def draw_score(rng,p,home,away,knockout=False):
 x=rng.random();outcome=0 if x<p[0]else 1 if x<p[0]+p[1]else 2
 if outcome==1:
  goals=rng.choices([0,1,2,3],[.22,.51,.24,.03])[0];h=a=goals
 else:
  winner_home=outcome==0;strong=home if TIERS[home]<TIERS[away]else away;gap=abs(TIERS[home]-TIERS[away]);dominant=(home if winner_home else away)==strong
  if dominant and gap==4:scores=[(3,0),(4,0),(4,1),(5,1),(2,0),(2,1),(3,1)];weights=[25,23,18,14,9,5,6]
  elif dominant and gap>=2:scores=[(2,0),(2,1),(3,1),(1,0),(3,0),(4,1)];weights=[25,28,22,12,9,4]
  else:scores=[(1,0),(2,1),(2,0),(3,2),(3,1),(4,2)];weights=[30,35,15,10,8,2]
  hi,lo=rng.choices(scores,weights)[0];h,a=(hi,lo)if winner_home else(lo,hi)
 hp=ap=0;winner='H'if h>a else'A'if a>h else None
 if knockout and winner is None:
  # W/D/L means regulation time. Resolve the sampled draw, preserving one leg.
  if rng.random()<.5:
   if rng.random()<p[0]/max(p[0]+p[2],1e-9):h+=1
   else:a+=1
   winner='H'if h>a else'A'
  else:
   winner='H'if rng.random()<.5 else'A';hp,ap=(5,4)if winner=='H'else(4,5)
 return dict(home=h,away=a,home_pk=hp,away_pk=ap,winner=winner,regulation_outcome=outcome)

def simulate(state,match,knockout=False):
 if not is_ucl(state)or match.get('home')in(None,0)or match.get('away')in(None,0):return None
 if match.get('played'):return None
 # Existing projected KO scores are stable; never reroll them on a UI refresh.
 old=match.get('rc25_probability')
 if old:return old.get('winner_index')
 home=int(match['home_team_id']);away=int(match['away_team_id']);streak=mu_losing_streak(state,match)if not knockout else False;p=probability(home,away,streak)
 if p is None:return None
 result=draw_score(random.Random(seed(state,match)),p,home,away,knockout);winner=match['home']if result['winner']=='H'else match['away']if result['winner']=='A'else None
 match.update(home_score=result['home'],away_score=result['away'],winner=winner,home_pk=result['home_pk'],away_pk=result['away_pk'])
 if not knockout:match['played']=True
 match['rc25_probability']=dict(model='DOCX-v5',probabilities=list(p),tiers=[TIERS[home],TIERS[away]],mu_two_losses_penalty=streak,winner_index=winner,regulation_outcome=result['regulation_outcome'],source_sha256=SOURCE_SHA)
 return winner

def seeded_groups(state):
 if state.get('event_id')!=1120006:return state
 # Keep the exact v25 pool and team indices. Only draw four pots for a new cup.
 teams=state['teams'];rng=random.Random(str(state['cup_id'])+':pots-v5');indices=list(range(len(teams)));tie={i:rng.random()for i in indices};indices.sort(key=lambda i:(TIERS.get(int(teams[i]),4),int(teams[i])==100,tie[i]));pots=[indices[i:i+8]for i in range(0,32,8)];ownpot=next(i for i,p in enumerate(pots)if 0 in p)
 for p in pots:rng.shuffle(p)
 pots[ownpot].remove(0);groups=[[0]]
 for j,p in enumerate(pots):
  if j!=ownpot:groups[0].append(p.pop())
 for _ in range(7):groups.append([p.pop()for p in pots])
 oldgroups=state['groups'];mapping={old:new for a,b in zip(oldgroups,groups)for old,new in zip(a,b)}
 for match in state['matches']:
  match['home']=mapping[match['home']];match['away']=mapping[match['away']];match['home_team_id']=teams[match['home']];match['away_team_id']=teams[match['away']];match['source']='PLAYER'if 0 in(match['home'],match['away'])else'AI'
 state['groups']=groups;state['rc25_pots']=dict(pots=[sorted(indices[i:i+8])for i in range(0,32,8)],model='DOCX-v5',pool_unchanged=True);return state

def fold(s):return ''.join(c for c in unicodedata.normalize('NFKD',s.casefold())if not unicodedata.combining(c))
def goal_shares(players,team_id):
 if not players:return players
 out=copy.deepcopy(players);special={}
 for token,share in PROFILES.get(int(team_id),[]):
  matches=[i for i,p in enumerate(out)if token in fold(p['name'])]
  if matches:special[matches[0]]=share
 total=sum(v for i,v in special.items());other=sum(p['goal_weight']for i,p in enumerate(out)if i not in special)
 for i,p in enumerate(out):p['goal_weight']=special[i]if i in special else (1-total)*p['goal_weight']/other if other else 0
 return out
