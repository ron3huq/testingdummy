"""Cup defaults, exact Transfer editor integration and cup-wide scoring ledgers."""
import copy,functools,json,threading
_local=threading.local();_installed=False

def competition(spec):return 901 if spec.key=='ucl'else 902

def defaults(conn,modules):
 import club_store
 if conn.in_transaction:return
 if club_store.get_meta(conn,'rc24_cup_legend_defaults','0')=='1':return
 with conn:
  for spec in modules['cup_spec'].SPECS.values():
   key='cup_level_'+spec.key
   if club_store.get_meta(conn,key,'NORMAL')=='NORMAL':club_store.set_meta(conn,key,'LEGEND')
  club_store.set_meta(conn,'rc24_cup_legend_defaults','1')

def install(gateway,modules):
 global _installed
 if _installed:return False
 import rc22_cup_awards,rc24_awards
 ns=gateway._rc22_cup_ui_namespace
 rc24_awards.install(modules)
 rc22_cup_awards.record=rc24_awards.record;rc22_cup_awards.snapshot=rc24_awards.snapshot
 # Native Transfer already owns the save/config, gear, skills, appearance,
 # formations, kit and responsibility editors. Reuse it, never fork its data.
 opp=modules['opponent_squad']
 import rc24_registry
 # Registry is read-only here; never patch the public Transfer module.
 old_preset=opp.preset
 @functools.wraps(old_preset)
 def preset(conn,index,source='auto'):
  row=old_preset(conn,index,source)
  if row is None:return row
  import rc25_event_editor
  transfer=rc25_event_editor.transfer()
  spec=getattr(_local,'spec',None)
  if spec is None:return row
  transfer.load(conn);tid=row.get('team_id')or row.get('base_team')
  if isinstance(tid,list):tid=tid[0]if tid else None
  if isinstance(tid,dict):tid=tid.get('base_team_id')or tid.get('id')or tid.get('team_id')
  edited=transfer.profiles.get(transfer.key(tid,competition(spec)))or transfer.profiles.get(transfer.key(tid,0))
  if not edited:return row
  row=copy.deepcopy(row);roster=edited['roster'];row['player_ids']=[int(p['id'])for p in roster]
  # Keep the original donor cards as sources. Added/moved cards resolve through
  # the same native card library used by Transfer and the donor squad builder.
  roles={r['id']:r['name']for r in transfer.catalog()['roles']}
  row['slots']=[dict(card_id=int(p['id']),position=roles.get(p['role'],'CMF'),max_ovr=None)for p in roster]
  row['formation_roles']=[roles.get(p['role'],'CMF')for p in roster[:11]]
  row['_rc24_transfer']=copy.deepcopy(edited)
  owned=row.setdefault('owned_cards',{});byid={str((v.get('gameplayer_id')or{}).get('id')):v for v in owned.values()}
  # The donor resolves plan cards by positional player_refs first. Rebuild
  # these references after reordering/transfers; keeping the old array silently
  # resolves a moved slot to the former card even if player_ids was updated.
  refs=[];payloads=row.setdefault('player_payloads',{})
  for p in roster:
   card=byid.get(p['id'])or rc24_registry.data()['players'].get(p['id'])
   if card is not None:
    card=copy.deepcopy(card);key=card['gameplayer_id'];owned[str(key['id'])+':'+str(key['serial'])]=card;refs.append((int(key['id']),int(key['serial'])));payloads[p['id']]=card
   else:refs.append((int(p['id']),0))
  row['player_refs']=refs
  return row
 opp.preset=preset
 old_build=opp.build
 @functools.wraps(old_build)
 def build(conn,index,division=None,source='auto'):
  spec=getattr(_local,'spec',None)
  item=preset(conn,index,source)if spec is not None else None
  edited=item.get('_rc24_transfer')if item else None
  # Donor cache keys omit Transfer revision. A saved/moved roster must never
  # reuse the packet cached before its edit. This is the private Event module.
  if edited:opp._CACHE.clear()
  result=old_build(conn,index,division,source)
  if result and edited:
   import rc25_transfer
   result=rc25_transfer.apply_squad(result,edited,competition(spec))
  return result
 opp.build=build
 # Award events are generated at the same time the donor simulates AI scores,
 # and saved inside that match. Old score-only history is never assigned fake
 # historical scorers. The score/winner generator itself remains unchanged.
 for name in ['ucl_mode','cup16_mode']:
  cls=modules[name].UclMode if name=='ucl_mode'else modules[name].Cup16Mode
  original=cls.__dict__['_sim_winner'].__func__
  def simulated(cls,state,match,_old=original,_is_ko=name=='cup16_mode'):
   import rc25_probability
   was=match.get('played')
   applied=rc25_probability.is_ucl(state)and not was and rc24_awards.is_ai(match)
   if applied:answer=rc25_probability.simulate(state,match,knockout=_is_ko)
   else:answer=_old(cls,state,match)
   if rc24_awards.is_ai(match)and(match.get('played')or match.get('home_score')is not None):
    conn=getattr(_local,'conn',None)
    if conn is not None:
     try:rc24_awards.simulate_events(conn,state,match,modules)
     except Exception:
      raise
   return answer
  cls._sim_winner=classmethod(simulated)
 # The donor defaults new states to Regular. Change the default without
 # removing its real seven-level menu or overwriting later manual selections.
 cls=modules['ucl_mode'].UclMode;old_new=cls._new_state
 @functools.wraps(old_new)
 def new_state(self,*a,**k):
  state=old_new(self,*a,**k);state['cpu_level']='LEGEND'
  import rc25_probability
  return rc25_probability.seeded_groups(state)
 cls._new_state=new_state
 cls=type(gateway._logic);old_handle=cls.handle
 @functools.wraps(old_handle)
 def handle(logic,command,request):
  if logic is not gateway._logic:return old_handle(logic,command,request)
  conn=logic.conn;defaults(conn,modules)
  try:event=int(request.get('event_id',0))
  except (TypeError,ValueError):event=0
  spec=modules['cup_spec'].for_event(event)
  if spec is None and command in ('CMD_START_GAME','CMD_GET_VSCOM_GAME_RESULT'):
   import rc22_cup_awards as legacy
   game=request.get('game_id')or request.get('match_result',{}).get('game_id');row=legacy.native_row(conn,game)
   if row:spec=modules['cup_spec'].for_event(row[0])
  old_conn=getattr(_local,'conn',None);old_spec=getattr(_local,'spec',None);_local.conn=conn;_local.spec=spec
  try:
   if spec is not None:
    import club_store
    if command in ('CMD_SET_EVENT_ENTER','CMD_GET_VSCOM_OPPONENT','CMD_GET_MYCLUB_VSCOM_OPPONENT','CMD_START_GAME'):
     request=dict(request)
     if not request.get('cpu_level'):request['cpu_level']=club_store.get_meta(conn,'cup_level_'+spec.key,'LEGEND')
    if command in ('CMD_GET_VSCOM_OPPONENT','CMD_GET_MYCLUB_VSCOM_OPPONENT','CMD_START_GAME'):
     import select_team_runtime
     select_team_runtime.activate_context(competition(spec))
   response=old_handle(logic,command,request)
   if spec is not None and response.get('result')=='NOERR':
    if command in ('CMD_GET_VSCOM_OPPONENT','CMD_GET_MYCLUB_VSCOM_OPPONENT','CMD_START_GAME'):
     import select_team_runtime
     select_team_runtime.activate_context(competition(spec))
    if command in ('CMD_GET_VSCOM_OPPONENT','CMD_GET_MYCLUB_VSCOM_OPPONENT','CMD_START_GAME'):
     import rc25_transfer
     response=rc25_transfer.project_packet(response,competition(spec))
    if command in ('CMD_GET_VSCOM_OPPONENT','CMD_GET_MYCLUB_VSCOM_OPPONENT','CMD_START_GAME'):rc24_awards.capture(conn,spec,request,response,modules)
   return response
  finally:_local.conn=old_conn;_local.spec=old_spec
 cls.handle=handle
 old_manage=gateway.manage
 @functools.wraps(old_manage)
 def manage(action,payload=''):
  if action=='ucl_ui_snapshot':
   defaults(gateway._logic.conn,modules);reply=json.loads(old_manage(action,payload));event=ns['_cup_snapshot_event'](payload);spec=ns['_cup_spec'](event)if event is not None else ns['_cup_specs']()[0]
   if spec:
    import club_store
    reply['cpuLevel']=club_store.get_meta(gateway._logic.conn,'cup_level_'+spec.key,'LEGEND');reply['editorCompetition']=competition(spec)
   return json.dumps(reply,ensure_ascii=False)
  return old_manage(action,payload)
 gateway.manage=manage;_installed=True;return True
