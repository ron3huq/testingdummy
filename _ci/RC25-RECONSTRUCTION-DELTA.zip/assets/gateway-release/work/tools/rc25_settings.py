"""Persistent external settings, using the exact v18-fixed native patch table.
Only known instructions on the identical verified v19 engine can be written.
"""
from pathlib import Path
import copy,ctypes as C,hashlib,json,platform,threading,time
HERE=Path(__file__).resolve().parent;KEY='rc25_realtime_settings';ENGINE_SHA='efd257d9e41b622d6ecb8f51f7b0a8ee8820113fd427c5572025df1c8eecc7b8';LIB_SHA='698c5fb4946a08af0132ac07a847edbf12d27f03bf6c375884d548296b8e5287'
FEATURES=json.loads((HERE/'rc25_settings_presets.json').read_text())
for feature in FEATURES:
 for row in feature['values']:
  for i,site in enumerate(feature['sites']):row[i]&=(1<<(site['length']*8))-1
_lock=threading.RLock();_choices={};_status={};_native=None;_started=False

def validate(values):
 if not isinstance(values,dict)or set(values)-{r['name']for r in FEATURES}:raise ValueError('Unknown match setting')
 for f in FEATURES:
  v=values.get(f['name'],f['stock'])
  if type(v)is not int or not 0<=v<len(f['labels']):raise ValueError('Invalid setting choice: '+f['name'])
 return dict(values)

def apply_feature(feature,index,read,write):
 sites=feature['sites'];before=[read(s['offset'],s['length'])for s in sites];known=[set(row[i]for row in feature['values'])for i in range(len(sites))]
 if any(value not in known[i]for i,value in enumerate(before)):raise ValueError('Setting conflicts with an existing patch: '+feature['name'])
 values=feature['values'][index];done=[]
 try:
  for site,value,prior in zip(sites,values,before):
   if value!=prior:
    if write(site['offset'],value,site['length'],site['protection'])!=0:raise ValueError('Native write failed: '+feature['name'])
    done.append((site,prior))
  if [read(s['offset'],s['length'])for s in sites]!=values:raise ValueError('Native readback failed: '+feature['name'])
 except Exception:
  for site,prior in reversed(done):write(site['offset'],prior,site['length'],site['protection'])
  raise
 return dict(state='applied',choice=index,label=feature['labels'][index],readback_verified=True)

def ready_native():
 global _native
 if _native is not None:return _native
 if platform.machine().lower()not in('aarch64','arm64'):return None
 import select_team_runtime
 if not select_team_runtime._ready.is_set():return None
 maps=Path('/proc/self/maps').read_text();paths=[line.split()[-1]for line in maps.splitlines()if 'libUE4.so'in line and line.split()[2]=='00000000']
 if not paths:return None
 path=Path(paths[0])
 with path.open('rb')as f:
  if hashlib.file_digest(f,'sha256').hexdigest()!=ENGINE_SHA:raise ValueError('Unsupported game engine')
 lib=HERE/'libv18_settings.so'
 if hashlib.sha256(lib.read_bytes()).hexdigest()!=LIB_SHA:raise ValueError('Settings native checksum mismatch')
 h=C.CDLL(str(lib));h.Java_com_efpatch_Native_base.argtypes=[C.c_void_p,C.c_void_p];h.Java_com_efpatch_Native_base.restype=C.c_uint64
 h.Java_com_efpatch_Native_read.argtypes=[C.c_void_p,C.c_void_p,C.c_uint64,C.c_int];h.Java_com_efpatch_Native_read.restype=C.c_uint64
 h.Java_com_efpatch_Native_write.argtypes=[C.c_void_p,C.c_void_p,C.c_uint64,C.c_uint64,C.c_int,C.c_int];h.Java_com_efpatch_Native_write.restype=C.c_int
 if not h.Java_com_efpatch_Native_base(None,None):return None
 _native=h;return h

def apply_pending():
 h=ready_native()
 if h is None:return False
 read=lambda offset,size:int(h.Java_com_efpatch_Native_read(None,None,offset,size));write=lambda offset,value,size,protection:int(h.Java_com_efpatch_Native_write(None,None,offset,value,size,protection))
 for f in FEATURES:
  if f['name']not in _choices:continue
  v=_choices[f['name']]
  try:_status[f['name']]=apply_feature(f,v,read,write)
  except Exception as error:_status[f['name']]=dict(state='conflict',error=str(error))
 return True

def snapshot():
 return dict(features=[dict(name=f['name'],labels=f['labels'],stock=f['stock'],selected=_choices.get(f['name'],f['stock']),status=_status.get(f['name'],dict(state='pending'if f['name']in _choices else'default')))for f in FEATURES],engine_ready=_native is not None,note='Saved settings apply after Enter Game. Time/Snow should be selected before starting a match. Applied means native bytes were read back; visual results need device confirmation.')

def install(gateway):
 global _choices,_started
 c=gateway._logic.conn;row=c.execute('SELECT value FROM meta WHERE key=?',(KEY,)).fetchone();_choices=validate(json.loads(row[0])if row else{})
 old=gateway.manage
 def manage(action,payload=''):
  if action not in('rc25_settings_get','rc25_settings_save'):return old(action,payload)
  with _lock:
   if action.endswith('_save'):
    req=json.loads(payload or'{}');values=validate(req.get('values'));updated=dict(_choices,**values)
    if c.in_transaction:raise ValueError('Another save is active')
    with c:c.execute('INSERT OR REPLACE INTO meta(key,value)VALUES(?,?)',(KEY,json.dumps(updated)))
    _choices.clear();_choices.update(updated)
   apply_pending();return json.dumps(snapshot(),ensure_ascii=False)
 gateway.manage=manage
 if not _started:
  _started=True
  if platform.machine().lower()in('aarch64','arm64'):
   def worker():
    while True:
     with _lock:
      try:
       if apply_pending():return
      except Exception as error:_status['engine']=dict(state='error',error=str(error))
     time.sleep(.5)
   threading.Thread(target=worker,name='rc25-settings',daemon=True).start()
