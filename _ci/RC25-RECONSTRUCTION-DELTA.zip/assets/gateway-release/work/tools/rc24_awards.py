"""Cup-wide goals/assists: engine receipts plus explicitly labelled AI simulation events.
Unknown native player events remain unknown; no attribution from a score alone.
"""
import copy,hashlib,json,random
from collections import Counter
_modules={}
def install(modules):_modules.update(modules)
def setup(c):
 c.execute('CREATE TABLE IF NOT EXISTS rc24_cup_rosters(game TEXT PRIMARY KEY,data TEXT NOT NULL)')
 c.execute('CREATE TABLE IF NOT EXISTS rc24_cup_awards(scope TEXT NOT NULL,game TEXT NOT NULL,data TEXT NOT NULL,PRIMARY KEY(scope,game))')
def gid(row):
 import player_match_stats
 try:return player_match_stats._gid(row)
 except (ValueError,TypeError,KeyError):return None

def names(pid):
 try:
  import editor_names
  value=editor_names.NAMES.get(str(pid))
  if value:return value
 except ImportError:pass
 try:
  import player_editor
  value=player_editor.name_index().get(str(pid))
  if isinstance(value,(tuple,list)):value=value[0]if value else None
  if value:return value
 except (ImportError,ValueError,OSError):pass
 return 'ID '+str(pid)

def states(c,spec,modules):
 group=modules['ucl_mode'].UclMode(c,spec).state(spec.group_event_id)
 ko=modules['cup16_mode'].Cup16Mode(c,spec.knockout_compe_unit_id).state(spec.knockout_event_id)
 return group,ko

def team_names(group,ko):
 out={}
 for state in [group,ko]:
  if not state:continue
  out[int(state['own_team_id'])]=state.get('own_team_name','')
  for entry in state.get('opponents',[]):
   if entry.get('team_id'):out[int(entry['team_id'])]=entry.get('team_name')or entry.get('preset_team_name')or entry.get('user_name')or str(entry['team_id'])
 return out

def capture(c,spec,request,response,modules):
 game=response.get('game_id')or request.get('game_id')
 if game is None:return False
 setup(c);import rc22_cup_awards as legacy
 row=legacy.native_row(c,game)
 if row is None:return False
 group,ko=states(c,spec,modules);state=group if row[2]=='e112_ucl_games'else ko
 if not state:return False
 active=state.get('active')or{};own=state.get('selected_team_id')or state['own_team_id'];opponent=active.get('opponent_team_id')or(response.get('team_data')or{}).get('base_team_id')or((active.get('opponent')or{}).get('team_data')or{}).get('base_team_id')
 if not opponent:
  matches=all_matches(state)
  if not matches and state.get('rounds'):
   matches=[m for r in state['rounds']for m in(r.get('matches',[])if isinstance(r,dict)else r)]
  match=next((m for m in matches if str(m.get('game_id'))==str(game)),None)
  if match:
   ht,at=match.get('home_team_id'),match.get('away_team_id');opponent=at if ht==own else ht
 docrow=c.execute('SELECT data FROM rc24_cup_rosters WHERE game=?',(str(game),)).fetchone();doc=json.loads(docrow[0])if docrow else dict(players={},own_team=own,opponent_team=opponent)
 # Donor prepare packet has its NPC list. Start packets contain both sides.
 sources=[(response.get('player_list',[]),opponent)]
 side=request.get('side','HOME');home=own if side=='HOME'else opponent;away=opponent if side=='HOME'else own
 for suffix,tid in [('home',home),('away',away)]:
  squad=response.get('squad_data_'+suffix)or{}
  sources.append((squad.get('player_list',[]),tid));sources.append((response.get('player_list_'+suffix,[]),tid))
 import club_store
 owned={gid(p):p for p in club_store.players(c)}
 for rows,tid in sources:
  for player in rows:
   if not isinstance(player,dict):continue
   key=gid(player)
   if key is None:continue
   if key in owned:tid_for_player=own
   else:tid_for_player=tid
   if tid_for_player is None:continue
   doc['players'][str(key[0])+':'+str(key[1])]=dict(id=key[0],serial=key[1],team_id=tid_for_player,name=player.get('name')or names(key[0]))
 # Own players always resolve even if a native squad packet uses just refs.
 for key,player in owned.items():
  if key:doc['players'][str(key[0])+':'+str(key[1])]=dict(id=key[0],serial=key[1],team_id=own,name=player.get('name')or names(key[0]))
 with c:c.execute('INSERT OR REPLACE INTO rc24_cup_rosters VALUES(?,?)',(str(game),json.dumps(doc,ensure_ascii=False)))
 return True

def record(c,request,modules):
 import rc22_cup_awards as legacy,player_match_stats
 setup(c);detail=request.get('match_result',{});game=detail.get('game_id',request.get('game_id'))
 if game is None or c.in_transaction:return False
 if not c.execute("SELECT 1 FROM sqlite_master WHERE type='table'AND name='rc22_cup_bindings'").fetchone():return False
 bound=c.execute('SELECT scope,event,team FROM rc22_cup_bindings WHERE game=?',(str(game),)).fetchone();native=legacy.native_row(c,game)
 if not bound or not native or native[0]!=bound[1]or native[1]is None:return False
 scope,event,own=bound
 if c.execute('SELECT 1 FROM rc24_cup_awards WHERE scope=?AND game=?',(scope,str(game))).fetchone():return False
 row=c.execute('SELECT data FROM rc24_cup_rosters WHERE game=?',(str(game),)).fetchone();rosters=json.loads(row[0])if row else dict(players={})
 goals=Counter(player_match_stats._event_ids(request,'goal_player_list'));assists=Counter(player_match_stats._event_ids(request,'assist_player_list'));totals={};unknown=Counter()
 motm=set()
 for field in ['myteam_player_list','opponent_player_list','away_player_list','home_player_list']:
  for player in detail.get(field,[]):
   if isinstance(player,dict)and player.get('is_man_of_the_match')in(True,'YES'):
    key=gid(player)
    if key:motm.add(key)
 for key in set(goals)|set(assists)|motm:
  p=rosters['players'].get(str(key[0])+':'+str(key[1]))
  if not p:unknown['goals']+=goals[key];unknown['assists']+=assists[key];continue
  target=totals.setdefault((p['team_id'],p['id']),dict(p,goals=0,assists=0,motm=0));target['goals']+=goals[key];target['assists']+=assists[key];target['motm']+=int(key in motm and len(motm)==1)
 # A missing opponent/scorer list is reported as incomplete coverage, not
 # silently filled with a guessed name. Shootout goals do not enter this total.
 score=request.get('score',[]);total_score=sum(int(r.get('score_1st',0))+int(r.get('score_2nd',0))+int(r.get('score_ex1st',0))+int(r.get('score_ex2nd',0))for r in score if isinstance(r,dict))
 unknown['goals']+=max(0,total_score-sum(goals.values()))
 doc=dict(players=list(totals.values()),source='engine',unattributed_goals=unknown['goals'],unattributed_assists=unknown['assists'],missing_assist_list=int(total_score>0 and 'assist_player_list'not in detail and 'assist_player_list'not in request))
 with c:c.execute('INSERT INTO rc24_cup_awards VALUES(?,?,?)',(scope,str(game),json.dumps(doc,ensure_ascii=False)))
 return True

def roster(c,state,index,modules):
 if not index:return []
 entry=state.get('opponents',[])[int(index)-1];source=entry.get('source','plan');number=entry.get('index')
 if number is None:return []
 # Same donor preset/Transfer override as the actual opponent construction.
 p=modules['opponent_squad'].preset(c,int(number),source)
 if not p:return []
 out=[];cards=list(p.get('owned_cards',{}).values());by_id={int(q.get('gameplayer_id',{}).get('id',0)):q for q in cards}
 for i,slot in enumerate(p.get('slots',[])[:11]):
  pid=int(slot['card_id']);params=by_id.get(pid,{}).get('parameters',[]);role=slot.get('position','CMF');finish=params[20]if len(params)>20 else 70;passing=params[17]if len(params)>17 else 70
  goal_weight=(.1 if role=='GK'else .5 if role in ['CB','LB','RB']else 1.4 if role in ['CF','SS','LWF','RWF']else 1)*max(1,finish)
  assist_weight=(.1 if role=='GK'else 1.4 if role in ['AMF','CMF','LMF','RMF','LWF','RWF']else .7)*max(1,passing)
  out.append(dict(id=pid,serial=0,name=names(pid),team_id=int(entry['team_id']),goal_weight=goal_weight,assist_weight=assist_weight))
 return out

def simulate_events(c,state,match,modules):
 seed=str(state['cup_id'])+':'+str(state['event_id'])+':'+str(match.get('index'))+':'+str(match.get('home_team_id'))+':'+str(match.get('away_team_id'))
 if 'rc25_probability'in match:seed+=':rc25-docx-v5'
 if match.get('rc24_player_events',{}).get('fixture_key')==seed:return
 rng=random.Random(int.from_bytes(hashlib.sha256(seed.encode()).digest(),'big'));events=[];missing=0
 for side in ['home','away']:
  count=int(match.get(side+'_score')or 0);players=roster(c,state,match[side],modules)
  if len(players)<11:missing+=count;continue
  if state.get('event_id')in (1120006,1120007):
   import rc25_probability
   players=rc25_probability.goal_shares(players,match[side+'_team_id'])
  for i in range(count):
   scorer=rng.choices(players,weights=[p['goal_weight']for p in players],k=1)[0];assist=None
   if rng.random()<.72:
    options=[p for p in players if p['id']!=scorer['id']];assist=rng.choices(options,weights=[p['assist_weight']for p in options],k=1)[0]
   events.append(dict(scorer={k:v for k,v in scorer.items()if k not in ['goal_weight','assist_weight']},assist={k:v for k,v in assist.items()if k not in ['goal_weight','assist_weight']}if assist else None))
 match['rc24_player_events']=dict(source='AI_SIMULATION',fixture_key=seed,events=events,unattributed_goals=missing)

def is_ai(match):return match.get('home')not in(None,0)and match.get('away')not in(None,0)

def all_matches(state):
 if not state:return []
 if isinstance(state.get('matches'),list):return state['matches']
 if isinstance(state.get('bracket'),list):return state['bracket']
 rounds=state.get('rounds',[])
 if isinstance(rounds,dict):rounds=list(rounds.values())
 return [m for r in rounds for m in(r.get('matches',[])if isinstance(r,dict)else r)]

def snapshot(c,spec,modules):
 setup(c);group,ko=states(c,spec,modules);scope=str(group['cup_id'])if group else str(ko.get('source_group_cup_id')or ko['cup_id'])if ko else None;totals={};engine_games=0;sim_games=0;unattributed=0;unknown_assists=0;missing_assists=0;legacy_games=0;teamnames=team_names(group,ko);covered=set()
 def add(p,field,amount=1):
  key=(int(p['team_id']),int(p['id']));target=totals.setdefault(key,dict(p,goals=0,assists=0,motm=0,team_name=teamnames.get(key[0],str(key[0]))));target[field]+=amount
 if scope:
  for game,data in c.execute('SELECT game,data FROM rc24_cup_awards WHERE scope=?',(scope,)):
   covered.add(game);engine_games+=1;doc=json.loads(data);unattributed+=doc.get('unattributed_goals',0);unknown_assists+=doc.get('unattributed_assists',0);missing_assists+=doc.get('missing_assist_list',0)
   for p in doc['players']:
    for field in ['goals','assists','motm']:add(p,field,p[field])
  if c.execute("SELECT 1 FROM sqlite_master WHERE type='table'AND name='rc22_cup_awards'").fetchone():
   for game,data in c.execute('SELECT game,data FROM rc22_cup_awards WHERE scope=?',(scope,)):
    if game in covered:continue
    engine_games+=1;legacy_games+=1;doc=json.loads(data)
    for p in doc['players']:
     for field in ['goals','assists','motm']:add(p,field,p[field])
  for state in [group,ko]:
   matches=all_matches(state);completed_rounds={m.get('round')for m in matches if not is_ai(m)and m.get('played')}
   for match in matches:
    if not is_ai(match):continue
    if not match.get('played')and not(match.get('projected')and match.get('round')in completed_rounds):continue
    doc=match.get('rc24_player_events');sim_games+=1
    if not doc:unattributed+=int(match.get('home_score')or 0)+int(match.get('away_score')or 0);continue
    unattributed+=doc.get('unattributed_goals',0)
    for event in doc['events']:
     add(event['scorer'],'goals')
     if event['assist']:add(event['assist'],'assists')
 boards={}
 for field in ['goals','assists','motm']:
  ordered=sorted((p for p in totals.values()if p[field]>0),key=lambda p:(-p[field],p['name'],p['team_id'],p['id']));board=[];last=None;rank=0
  for i,p in enumerate(ordered):
   if p[field]!=last:rank=i+1;last=p[field]
   board.append(dict(p,rank=rank))
  boards[field]=board
 notice='Trận đã chơi: dữ liệu engine. Trận AI: sự kiện mô phỏng theo đội hình giải.'
 notice+=' MOTM chỉ tính dữ liệu engine.'
 if unknown_assists or missing_assists or legacy_games:notice+=' Một phần lịch sử/kiến tạo chưa đủ dữ liệu để xác định cầu thủ.'
 if unattributed:notice+=' Có '+str(unattributed)+' bàn chưa xác định cầu thủ (lịch sử cũ hoặc kết quả thiếu).'
 text='\n\n'.join(label+'\n'+'\n'.join(str(p['rank'])+'. '+p['name']+' · '+p['team_name']+' · '+str(p[field])for p in boards[field][:20])for field,label in [('goals','VUA PHÁ LƯỚI'),('assists','VUA KIẾN TẠO'),('motm','MOTM')])+'\n\n'+notice
 return dict(boards=boards,games=engine_games,simulation_games=sim_games,unattributed_goals=unattributed,unattributed_assists=unknown_assists,matches_missing_assist_data=missing_assists,legacy_partial_games=legacy_games,coverage_complete=(unattributed==0 and unknown_assists==0 and missing_assists==0 and legacy_games==0),notice=notice),text
