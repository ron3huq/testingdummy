V19.1 FULL-2 startup trace + editor UI update
Apply only on the existing FULL-2 V19.1 APK.
Copy assets/ and classes5.dex to the APK root, replace duplicates, sign with the same key and install as an update. Keep all existing data and resource packs. Do not uninstall or clear storage.
Includes Back/Refresh and lazy editor tabs, unified full editor navigation and 10-second idle entry on Home.
This build adds a current-session HTTP startup trace to Runtime Diagnostics. It does not claim that the title-screen spinner is resolved. After reproducing it, return to the launcher and copy Runtime Diagnostics, including full3-gate-transport.json.
