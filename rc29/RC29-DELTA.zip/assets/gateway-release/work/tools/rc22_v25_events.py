"""Cup Event adapter for the V30 base.

RC22-RC26 back-ported V25's cup modules into V19.1 under a private import
graph. V30 already ships the same cup system natively (cup_spec, ucl_mode,
cup16_mode, ucl_service, wc_sim, cup_entry ...) together with its own cup UI
routing inside embedded_gateway. On V30 we therefore never replace cup_entry
or the gateway handle with donor code: the native V30 modules are exposed to
the RC24/RC25 layers (awards, Event Transfer squads, UCL simulation model) and
only the award capture/snapshot hooks are added.
"""
import functools,importlib,json
_installed=False
_modules={}
NAMES=('cup_spec','cup16_mode','cup16_service','ucl_mode','ucl_group_bridge','ucl_service','wc_field',
       'user_compe_service','cup_entry','opponent_squad','my_league_opponents','my_league_e112_candidate',
       'native_dv_formations','wc_sim')

def install(gateway=None):
    global _installed
    if _installed:return False
    for name in NAMES:_modules[name]=importlib.import_module(name)
    if gateway is not None:install_ui(gateway)
    _installed=True
    return True

def install_ui(gateway):
    """Native V30 cup UI stays authoritative; add RC22/RC24 award ledgers only."""
    ns=vars(gateway)
    cls=type(gateway._logic);old_handle=cls.handle
    @functools.wraps(old_handle)
    def handle(logic,command,request):
        response=old_handle(logic,command,request)
        if logic is not gateway._logic or not isinstance(response,dict)or response.get('result')!='NOERR':return response
        try:
            import rc22_cup_awards
            if command in ('CMD_GET_VSCOM_OPPONENT','CMD_GET_MYCLUB_VSCOM_OPPONENT'):rc22_cup_awards.bind(logic.conn,response,_modules)
            elif command=='CMD_GET_VSCOM_GAME_RESULT':rc22_cup_awards.record(logic.conn,request,_modules)
        except Exception as exc:
            try:
                import mod_startup
                mod_startup.record_error('cup-awards',exc)
            except Exception:pass
        return response
    old_manage=gateway.manage
    @functools.wraps(old_manage)
    def manage(action,payload=''):
        reply=old_manage(action,payload)
        if action!='ucl_ui_snapshot':return reply
        try:
            data=json.loads(reply)
            event=ns['_cup_snapshot_event'](payload)
            spec=ns['_cup_spec'](event)if event is not None else ns['_cup_specs']()[0]
            if spec is not None and isinstance(data,dict):
                import rc22_cup_awards
                data['awards'],data['awardsText']=rc22_cup_awards.snapshot(gateway._logic.conn,spec,_modules)
                return json.dumps(data,ensure_ascii=False)
        except Exception as exc:
            try:
                import mod_startup
                mod_startup.record_error('cup-awards-snapshot',exc)
            except Exception:pass
        return reply
    cls.handle=handle;gateway.manage=manage;gateway._rc22_cup_ui_namespace=ns
