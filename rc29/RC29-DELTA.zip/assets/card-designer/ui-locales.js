/* Generated display dictionaries; never apply to business payloads. */
window.UiLocaleData = {"locales":[{"code":"zh-CN","name":"简体中文","direction":"ltr"},{"code":"en","name":"English","direction":"ltr"}],"data":{}};
