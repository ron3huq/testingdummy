// 独立大师联赛界面 v2（我们自己的代码，不依赖 PC 版 app.js / pad.js）。
// 源码在 work/ml-league-ui/src/ml/*.js（按页面分文件，按文件名顺序拼成一个闭包）；app/ml.js 由 tools/build_ml_js.py 生成，不要直接改它。
// 数据：GET /api/state | /api/history | /api/fixture/<id> | /api/team/<id> | /api/season/options（work/tools/iml_ui.py，经 iml_host / 预览服务器）。
// 宿主：window.AndroidMlLeague.{closePanel, startMatch, newSeason(team)}；宿主回调 window.MlLeague.{matchReady, matchFailed(msg), refresh, postMatch(round)}。
// 结构：一级菜单 = 左侧图标栏（SECTIONS），二级菜单 = 内容区顶部标签；战报、他队阵容等是盖在内容区上的子页面层（layer）。
"use strict";
(() => {
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const host = () => window.AndroidMlLeague || null;
const REDUCED = matchMedia("(prefers-reduced-motion: reduce)").matches;

/* ================= 音效：游戏系统音（/sfx/*.wav）；只给页面级跳转与主要操作；文件不在（包里默认不带）就静音 ================= */
const SFX = { ok: ["SE_SYS_DECIDE", .55], back: ["SE_SYS_CANCEL", .55], page: ["SE_SYS_PAGE_CHANGE", .5], open: ["SE_SYS_DIALOG_OPEN", .5], close: ["SE_SYS_DIALOG_CLOSE", .5], cursor: ["SE_SYS_CURSOR", .3] };
let actx = null; const bufs = {};
function audio() {
  if (!actx) {
    const C = window.AudioContext || window.webkitAudioContext; if (!C) return null;
    actx = new C();
    for (const [id] of Object.values(SFX)) fetch(`/sfx/${id}.wav`).then((r) => { if (!r.ok) throw 0; return r.arrayBuffer(); })
      .then((b) => actx.decodeAudioData(b)).then((b) => { bufs[id] = b; }).catch(() => {});
  }
  if (actx.state === "suspended") actx.resume().catch(() => {});
  return actx;
}
function sound(name) {
  const s = SFX[name], a = audio(); if (!s || !a || !bufs[s[0]]) return;
  const src = a.createBufferSource(), g = a.createGain(); src.buffer = bufs[s[0]]; g.gain.value = s[1]; src.connect(g).connect(a.destination); src.start();
}
for (const ev of ["pointerdown", "keydown"]) addEventListener(ev, () => audio(), { capture: true, passive: true });
addEventListener("click", (e) => { const el = e.target.closest && e.target.closest("[data-sound]"); if (el && !el.disabled) sound(el.dataset.sound); }, true);

/* ================= 数据 ================= */
let S = null, H = null, lastJson = "";
let hostHidden = false;          // 宿主把面板藏起来了（MlLeague.setHidden）：不轮询、不跑动画
const teamCache = {}, fxCache = {};
// 性能（2026-11-14）：手机上每个 /api 读取都要排进宿主唯一的 Python 线程。同一路径正在读的，后来者共用同一次请求；
// 体能/状态这类一页里会被几处同时要的小接口，1.5 秒内复用结果（以前主页一次要读两遍 /api/health）。
const apiPending = new Map(), apiMemo = new Map(), API_MEMO_MS = { "/api/health": 1500, "/api/form": 1500 };
async function api(path) {
  const memo = apiMemo.get(path);
  if (memo && performance.now() - memo.t < (API_MEMO_MS[path] || 0)) return memo.j;
  if (apiPending.has(path)) return apiPending.get(path);
  const p = (async () => {
    const r = await fetch(path, { cache: "no-store" });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || `HTTP ${r.status}`);
    if (API_MEMO_MS[path]) apiMemo.set(path, { t: performance.now(), j });
    return j;
  })();
  apiPending.set(path, p);
  try { return await p; } finally { apiPending.delete(path); }
}
const me = () => S.career.user_team;
const T = (tid) => (S && S.teams[String(tid)]) || {};
const tname = (tid) => (EN ? T(tid).latin || T(tid).zh : T(tid).zh || T(tid).latin) || `#${tid}`;      // EN / tzh 在 01-i18n.js：英文模式用拉丁名
const tcode = (tid) => (T(tid).short || (T(tid).latin || "").replace(/[^A-Za-z]/g, "").slice(0, 3) || "?").toUpperCase().slice(0, 3);
const tcolor = (tid) => T(tid).c || "#3a3d45";
const row = (tid) => (S.table || []).find((r) => r.team === tid) || null;
const isMine = (f) => f && (f.home === me() || f.away === me());

/* ================= 小部件 ================= */
const crest = (tid, cls = "") => `<span class="cw ${cls}"><img src="/img/emblem/${tid}.png" alt="" onerror="this.parentNode.classList.add('fb')"><i style="--c:${tcolor(tid)};--k:${T(tid).ink || "#fff"}">${esc(tcode(tid))}</i></span>`;
/* 俱乐部现实资料与主帅（2026-11-14，iml_club_history 的静态底稿；只有五大联赛球队有）。读不到就是 null，页面不显示这一块。
   主帅头像不一定随包（社区头像包，分发条件未核，同步默认跳过 img/coach）：没有图时显示姓名首字母。 */
const clubCache = {};
const clubInfo = (tid) => clubCache[tid] || (clubCache[tid] = api(`/api/club/${tid}`).then((j) => (j && !j.error && j.team != null ? j : null)).catch(() => null));
const initials = (n) => String(n || "").split(/[\s-]+/).filter(Boolean).map((w) => w[0]).slice(-2).join("").toUpperCase();
const coachFace = (c, cls = "") => `<span class="cf${cls ? " " + cls : ""}" title="${esc(c.name)}"><i>${esc(initials(c.name))}</i>${c.face ? `<img src="/${esc(c.face)}" alt="" onerror="this.remove()">` : ""}</span>`;
const grp = (p) => !p ? "" : p === "GK" ? "GK" : /^(CB|LB|RB)$/.test(p) ? "DF" : /MF$/.test(p) ? "MF" : "FW";
const pos = (p, g) => `<span class="pos ${g || grp(p)}">${esc(p || g || "—")}</span>`;
const tier = (o) => o >= 85 ? "t1" : o >= 80 ? "t2" : o >= 75 ? "t3" : "";
const ovr = (o) => o ? `<span class="ovr ${tier(o)}">${o}</span>` : `<span class="ovr na">—</span>`;
const stars = (t) => { const n = Math.max(1, Math.min(5, (t | 0) + 1)); return `<span class="stars">${"★".repeat(n)}<i>${"★".repeat(5 - n)}</i></span>`; };
const RES = { W: "胜", D: "平", L: "负" };
const formDots = (f) => `<span class="fdots">${(f || []).map((c) => `<i class="${c}" title="${RES[c]}"></i>`).join("")}</span>`;
const form = (f) => `<span class="form">${(f || []).map((c) => `<b class="${c}">${RES[c]}</b>`).join("")}</span>`;
const bar = (w, c) => `<div class="bar"><i data-w="${Math.max(0, Math.min(100, w))}" style="--c:${c}"></i></div>`;
// 2026-11-15 用户：“侧边栏这几个图标……太简陋了 你重新画一下”。主页 / 转会 / 训练 / 财务 / 赛季 / 设置改成双色线面：线条描边 + 一层 .fi 淡色填充
// （ml.css 里 .fi = currentColor 低透明度，选中时加深），箭头等小部件用 .fh 实心。同一个键在别处（标题、按钮）也一起换新。
const ICON = {
  editor: '<path d="M4 20h4l10.5-10.5a2.1 2.1 0 0 0-3-3L5 17v3z"/><path d="M13.5 6.5l3 3"/>',
  cups: '<path class="fi" d="M12 3.5l2.4 4.9 5.4.8-3.9 3.8.9 5.4-4.8-2.5-4.8 2.5.9-5.4-3.9-3.8 5.4-.8z"/><path d="M12 3.5l2.4 4.9 5.4.8-3.9 3.8.9 5.4-4.8-2.5-4.8 2.5.9-5.4-3.9-3.8 5.4-.8z"/><path d="M8 21h8"/>',
  home: '<path class="fi" d="M5.5 10.2L12 5l6.5 5.2V20h-13z"/><path d="M2.8 11.3L12 4l9.2 7.3"/><path d="M5.5 9.6V20h13V9.6"/><path d="M9.8 20v-4.6a2.2 2.2 0 0 1 4.4 0V20"/><path d="M16 6.6V4.3h2.2v4"/>',
  squad: '<path d="M8 3l-5 3 2 5 2-1v11h10V10l2 1 2-5-5-3c0 2-2 3-4 3S8 5 8 3z"/>',
  // 转会（2026-11-15 第二版，用户“这个转会标志有点丑了”）：中间一件球衣，外面两段首尾相接的环形箭头 = 球员换东家
  transfer: '<path class="fi" d="M10.1 7.9L7.9 9.2l.9 2.1 1.1-.5V16.3h4.2v-5.5l1.1.5.9-2.1-2.2-1.3c-.3.8-1 1.3-1.9 1.3s-1.6-.5-1.9-1.3z"/><path d="M10.1 7.9L7.9 9.2l.9 2.1 1.1-.5V16.3h4.2v-5.5l1.1.5.9-2.1-2.2-1.3c-.3.8-1 1.3-1.9 1.3s-1.6-.5-1.9-1.3z"/><path d="M4.21 8.37A8.6 8.6 0 0 1 18.78 6.71"/><path class="fh" d="M20.22 8.81L17.36 7.60L20.18 5.70z"/><path d="M19.79 15.63A8.6 8.6 0 0 1 5.22 17.29"/><path class="fh" d="M3.78 15.19L6.64 16.40L3.82 18.30z"/>',
  training: '<path d="M8.4 12h7.2"/><rect class="fi" x="5" y="6.2" width="3.4" height="11.6" rx="1.2"/><rect x="5" y="6.2" width="3.4" height="11.6" rx="1.2"/><rect class="fi" x="15.6" y="6.2" width="3.4" height="11.6" rx="1.2"/><rect x="15.6" y="6.2" width="3.4" height="11.6" rx="1.2"/><rect x="2.2" y="8.8" width="2.8" height="6.4" rx="1"/><rect x="19" y="8.8" width="2.8" height="6.4" rx="1"/>',
  finance: '<rect class="fi" x="4" y="15" width="3.6" height="5.5" rx=".8"/><rect class="fi" x="10.2" y="12" width="3.6" height="8.5" rx=".8"/><rect class="fi" x="16.4" y="9" width="3.6" height="11.5" rx=".8"/><path d="M4 20.5v-4.7a.8.8 0 0 1 .8-.8h2a.8.8 0 0 1 .8.8v4.7M10.2 20.5v-7.7a.8.8 0 0 1 .8-.8h2a.8.8 0 0 1 .8.8v7.7M16.4 20.5V9.8a.8.8 0 0 1 .8-.8h2a.8.8 0 0 1 .8.8v10.7M2.5 20.5h19"/><path d="M4 10.5l5-4.2 3.6 2.4L19 3.6"/><path class="fh" d="M20.6 2.4l.2 4.3-3.7-2.1z"/>',
  season: '<path class="fi" d="M7 3.8h10v5.4a5 5 0 0 1-10 0z"/><path d="M7 3.8h10v5.4a5 5 0 0 1-10 0z"/><path d="M7 5.8H4.6v1.3a3.6 3.6 0 0 0 3.1 3.6M17 5.8h2.4v1.3a3.6 3.6 0 0 1-3.1 3.6"/><path d="M12 14.2v2.6"/><path class="fi" d="M8.6 20.5l.9-3.7h5l.9 3.7z"/><path d="M8.6 20.5l.9-3.7h5l.9 3.7zM7 20.5h10"/><path class="fh" d="M12 6.1l.8 1.6 1.7.2-1.3 1.2.4 1.7-1.6-.9-1.6.9.4-1.7-1.3-1.2 1.7-.2z"/>',
  exit: '<path d="M14 4h5v16h-5M10 8l-4 4 4 4M6 12h10"/>',
  cal: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  back: '<path d="M15 5l-7 7 7 7"/>',
  coin: '<circle cx="12" cy="12" r="9"/><path d="M15 9.5c-.5-1-1.6-1.5-3-1.5-1.7 0-3 .8-3 2s1.3 1.7 3 2 3 .8 3 2-1.3 2-3 2c-1.4 0-2.5-.5-3-1.5M12 6v2M12 16v2"/>',
  bell: '<path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10.3 21a1.9 1.9 0 0 0 3.4 0"/>',
  person: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
  me: '<rect class="fi" x="6.5" y="2.5" width="11" height="19" rx="2.4"/><rect x="6.5" y="2.5" width="11" height="19" rx="2.4"/><path d="M10.5 5h3"/><circle cx="12" cy="10.2" r="2.1"/><path d="M8.8 16.2c.4-1.9 1.7-2.8 3.2-2.8s2.8.9 3.2 2.8"/><path d="M11 19h2"/>',   // 侧栏“我的”：手机里一个人像
  med: '<path d="M12 5v14M5 12h14"/>',
  up: '<path d="M4 16l5-5 4 4 7-7M15 8h5v5"/>',
  down: '<path d="M4 8l5 5 4-4 7 7M15 16h5v-5"/>',      // E323 降级（up 的镜像）
  ball: '<circle cx="12" cy="12" r="9"/><path d="M12 8.6L15.23 10.95L14 14.75H10L8.77 10.95z"/><path d="M12 8.6V3.6M15.23 10.95L19.99 9.4M14 14.75L16.94 18.8M10 14.75L7.06 18.8M8.77 10.95L4.01 9.4"/>',
  doc: '<path d="M6 3h9l4 4v14H6zM14 3v5h5M9 13h7M9 17h5"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  readall: '<path d="M18 6L7 17l-5-5M22 10l-7.5 7.5L13 16"/>',
  smile: '<circle cx="12" cy="12" r="9"/><path d="M8.5 14c.8 1.2 2 1.8 3.5 1.8s2.7-.6 3.5-1.8M9 9.5h.01M15 9.5h.01"/>',
  bolt: '<path d="M13 2.5L5 13.5h6.5L10.5 21.5 19 10h-6.5z"/>',
  shield: '<path d="M12 3l7.5 2.8v6c0 4.6-3.2 7.6-7.5 9.2-4.3-1.6-7.5-4.6-7.5-9.2v-6z"/><path d="M8.8 12.2l2.3 2.3 4.2-4.5"/>',
  rank: '<path d="M3 21v-8h5.5v8M9.25 21V5h5.5v16M15.5 21V10H21v11M3 21h18"/>',
  play: '<path d="M8 5l11 7-11 7z"/>',
  plus: '<path d="M12 5v14M5 12h14"/><circle cx="12" cy="12" r="10"/>',
  gear: '<path class="fi" d="M19.13 10.03L21.86 10.31L21.86 13.69L19.13 13.97L18.44 15.65L20.17 17.77L17.77 20.17L15.65 18.44L13.97 19.13L13.69 21.86L10.31 21.86L10.03 19.13L8.35 18.44L6.23 20.17L3.83 17.77L5.56 15.65L4.87 13.97L2.14 13.69L2.14 10.31L4.87 10.03L5.56 8.35L3.83 6.23L6.23 3.83L8.35 5.56L10.03 4.87L10.31 2.14L13.69 2.14L13.97 4.87L15.65 5.56L17.77 3.83L20.17 6.23L18.44 8.35z"/><path d="M19.13 10.03L21.86 10.31L21.86 13.69L19.13 13.97L18.44 15.65L20.17 17.77L17.77 20.17L15.65 18.44L13.97 19.13L13.69 21.86L10.31 21.86L10.03 19.13L8.35 18.44L6.23 20.17L3.83 17.77L5.56 15.65L4.87 13.97L2.14 13.69L2.14 10.31L4.87 10.03L5.56 8.35L3.83 6.23L6.23 3.83L8.35 5.56L10.03 4.87L10.31 2.14L13.69 2.14L13.97 4.87L15.65 5.56L17.77 3.83L20.17 6.23L18.44 8.35z"/><circle cx="12" cy="12" r="3.2"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.6 4 5.6 4 9s-1.4 6.4-4 9c-2.6-2.6-4-5.6-4-9s1.4-6.4 4-9z"/>',
  grid: '<rect x="4" y="4" width="6.5" height="6.5" rx="1"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1"/>',
};
const svg = (k, w = 2) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round">${ICON[k]}</svg>`;
/* ---- 球员小头像加载队列（2026-11-14，用户：“新建档没有缓存的时候市场有超级多球员然后就卡”） ----
   手机上每张没缓存的头像都要宿主调一次 Python（editor_portrait），而 Python 只有网关一条业务线程：几百张头像排在前面，页面自己的数据请求
   （市场、俱乐部、财务）就全得等。所以：头像一律 <img data-face>，滚到屏幕附近才排队；同时最多 FACE_MAX 张在路上，最新进入屏幕的先加载，
   已经离开页面的跳过；加载过的直接出图。后台预取（只取自己阵容）排在最后，屏幕上的头像永远插队。 */
const FACE = { ok: new Set(), q: [], low: [], busy: 0 }, FACE_MAX = 2;
const faceUrl = (pid) => `/img/player/${encodeURIComponent(pid)}.png`;
function faceShow(img, queued) {
  const pid = img.dataset.face; img.removeAttribute("data-face");
  let done = false;
  const fin = (ok) => { if (done) return; done = true; if (queued) FACE.busy--; if (ok) FACE.ok.add(pid); else img.remove(); if (queued) facePump(); };
  img.addEventListener("load", () => fin(true), { once: true });
  img.addEventListener("error", () => fin(false), { once: true });
  if (queued) FACE.busy++;
  img.src = faceUrl(pid);
}
function facePump() {
  while (FACE.busy < FACE_MAX) {
    let img = FACE.q.pop();                                    // 最新进入屏幕的先来
    while (img && (!img.isConnected || !img.dataset.face)) img = FACE.q.pop();
    if (img) { faceShow(img, true); continue; }
    const pid = FACE.low.shift(); if (pid == null) return;
    if (FACE.ok.has(pid)) continue;
    FACE.busy++;
    const im = new Image(), fin = (ok) => { FACE.busy--; if (ok) FACE.ok.add(pid); facePump(); };
    im.onload = () => fin(true); im.onerror = () => fin(false); im.src = faceUrl(pid);
  }
}
function faceWant(img) {
  if (!img.dataset.face) return;
  if (FACE.ok.has(img.dataset.face)) return faceShow(img, false);          // 已经加载过：宿主内存里有，直接出图
  FACE.q.push(img); facePump();
}
const faceIO = "IntersectionObserver" in window
  ? new IntersectionObserver((es) => { for (const e of es) if (e.isIntersecting) { faceIO.unobserve(e.target); faceWant(e.target); } }, { rootMargin: "120px" }) : null;
function faceScan(node) {
  const list = node.matches && node.matches("img[data-face]") ? [node] : node.querySelectorAll ? [...node.querySelectorAll("img[data-face]")] : [];
  for (const img of list) faceIO ? faceIO.observe(img) : faceWant(img);
}
new MutationObserver((ms) => { for (const m of ms) for (const n of m.addedNodes) if (n.nodeType === 1) faceScan(n); }).observe(document.documentElement, { childList: true, subtree: true });
function toast(t) { const el = $("#toast"); el.textContent = t; el.classList.add("show"); clearTimeout(toast.h); toast.h = setTimeout(() => el.classList.remove("show"), 2600); }
// 数值一律直接显示真实值（2026-11-14 体验评审 U02：从 0 计数会瞬时出现“体能 5%”“排名 0”“预算跳动”）。
// 带 data-k 的数值和上次渲染不同时短暂高亮一次；没变就什么都不做，刷新/切页不重播。
const lastNum = new Map();
function countUp(el) {
  const k = el.dataset.k, v = el.dataset.to;
  if (!k) return;
  const prev = lastNum.get(k); lastNum.set(k, v);
  if (prev === undefined || prev === v || REDUCED) return;
  el.classList.remove("chg"); void el.offsetWidth; el.classList.add("chg");
}
function animate(root) {
  $$("[data-to]", root).forEach(countUp);
  const bars = $$(".bar > i[data-w]", root), cols = $$(".chart i[data-h]", root);
  requestAnimationFrame(() => requestAnimationFrame(() => {
    bars.forEach((b, i) => { b.style.transitionDelay = (i % 8) * 40 + "ms"; b.style.width = Math.max(0, Math.min(100, +b.dataset.w)) + "%"; });
    cols.forEach((c, i) => { c.style.transitionDelay = Math.floor(i / 2) * 60 + "ms"; c.style.height = c.dataset.h + "%"; });
  }));
}

/* ================= 多语言：英文模式（2026-11-15 用户：“把这个联赛做成英文模式，做一个 xml 方便别人翻译”） =================
   中文是源语言，所有页面照旧用中文生成；英文模式下这里在浏览器端把 DOM 里的中文文字按 /lang/en.json 换成英文，不改任何页面的写法。
   目录由 work/ml-league-ui/tools/i18n_tool.py 从源码（本目录 *.js 和 work/tools/iml_*.py）抽取成 i18n/ml-strings.xml 供翻译，build 后生成 app/lang/en.json：
     exact  整句对整句；tpl  带占位符的句型（{0}、{team}…，匹配后占位符里的中文再递归翻译）；names  俱乐部中→英名。
   没有译文的文字保持中文；球队名（tname）直接用接口里的拉丁名。切换语言＝写 localStorage 后重新载入（也可用 ?lang=en / ?lang=zh）。
   不想被翻译的元素加 translate="no"。 */
// 语言表（2026-11-16 用户：新增了好几种语言，做语言切换）：每种语言一个 /lang/<code>.json（由 i18n_tool.py build 从 i18n/translations/ 生成，缺的句子回落英文）。
// 新增语言：放一份 ml-strings-<code>.xml 到 i18n/translations/、在这里加一行、build。rtl＝从右往左书写。
// RC29.3: English only (user request) - every other language pack removed
const LANGS = [{ code: "en", name: "English" }];
const LANG = "en";
const EN = LANG !== "zh";                                                        // 历史名：“非中文模式”（用拉丁队名、加载语言包），不再只指英文
const langInfo = (c) => LANGS.find((l) => l.code === c) || LANGS[0];
const HAN = /[一-鿿]/;
const I18N = { exact: new Map(), tpl: [], names: new Map(), nameRe: null, cache: new Map(), ready: Promise.resolve(false), on: false };
function setLang(l) {
  return;
  try { localStorage.setItem("ml-lang", LANGS.some((x) => x.code === l) ? l : "zh"); } catch (e) { /* 存不了就保持当前语言 */ }
  const u = new URL(location.href); u.searchParams.delete("lang");                 // 网址里的 ?lang= 每次载入都会覆盖设置，切换时要先去掉
  location.replace(u.toString());
}
// 球队名：英文模式用拉丁名（接口给 zh 和 latin 两个）
const tzh = (x) => (EN ? x.latin || x.zh : x.zh || x.latin);
const esc1 = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
function i18nCompile(d) {
  for (const [k, v] of Object.entries(d.exact || {})) I18N.exact.set(k, v);
  for (const [k, v] of Object.entries(d.names || {})) I18N.names.set(k, v);
  I18N.runs = new Map(Object.entries(d.runs || {}));
  for (const [zh, en] of Object.entries(d.tpl || {})) {
    const groups = [], lits = [];                                                // 相邻的占位符（{0}{1}）合成一个捕获组，匹配后再按“能翻译的边界”切开
    let body = "", prevPh = false;
    for (const p of zh.split(/(\{\w+\})/)) {
      const m = /^\{(\w+)\}$/.exec(p);
      if (m) { if (prevPh) groups[groups.length - 1].push(m[1]); else { groups.push([m[1]]); body += "(.+?)"; } prevPh = true; }
      else if (p) { lits.push(p); body += esc1(p); prevPh = false; }
    }
    I18N.tpl.push({ re: new RegExp(`^${body}$`), key: lits.sort((a, b) => b.length - a.length)[0] || "", groups, en, weight: lits.join("").length });
  }
  I18N.tpl.sort((a, b) => b.weight - a.weight);                                  // 固定文字多的句型优先，避免被宽松句型抢先匹配
  const nm = [...I18N.names.keys()].sort((a, b) => b.length - a.length);
  I18N.nameRe = nm.length ? new RegExp(nm.map(esc1).join("|"), "g") : null;
}
// 把相邻占位符合并后的一段文字切成 k 份：优先让每份都“没有中文或能翻译”，同分取靠前的切法（只用于 {0}{1} 这类相邻占位符，文字很短）
function i18nSplit(chunk, k, depth) {
  if (k <= 1 || chunk.length < k || chunk.length > 40) return k <= 1 ? [chunk] : [chunk, ...Array(k - 1).fill("")];
  const good = (p) => (!HAN.test(p) || i18nCore(p.trim(), depth) != null ? 1 : 0);
  let best = null, bestScore = -1;
  const walk = (rest, left, acc, score) => {
    if (left === 1) { const s = score + good(rest); if (s > bestScore) { bestScore = s; best = [...acc, rest]; } return; }
    for (let i = 1; i <= rest.length - (left - 1); i++) { const p = rest.slice(0, i); walk(rest.slice(i), left - 1, [...acc, p], score + good(p)); }
  };
  walk(chunk, k, [], 0);
  return best;
}
// 一段规整过的文字（单空格、已 trim）→ 英文；没有译文返回 null
const I18N_SEG = { "欧冠": "UCL", "欧联": "UEL", "决赛": "Final", "半决赛": "Semi-final", "八强": "Quarter-final", "16强": "Round of 16", "首回合": "1st leg", "次回合": "2nd leg",
  "胜": "W", "平": "D", "负": "L", "主场": "Home", "客场": "Away", "中立场": "Neutral venue", "附加赛": "Play-off", "联赛阶段": "League phase", "状态": "form" };
function i18nRuns(core) {
  let r;
    r = core.replace(/第\s*(\d+)\s*轮/g, "Round $1").replace(/(\d+)\s*轮/g, "R$1").replace(/(\d+)\s*月\s*(\d+)\s*日/g, "$2/$1").replace(/[\u3400-\u9fff]+(?:[\u3000-\u303f\uff00-\uffef]*[\u3400-\u9fff]+)*/g, (m) => {
      const t = I18N.runs.get(m) ?? I18N.exact.get(m) ?? I18N.names.get(m);
      if (t != null) return ` ${t} `;
      // greedy longest-match segmentation of an unknown run ("欧冠决赛" -> "Champions League" + "Final")
      const look = (x) => I18N.runs.get(x) ?? I18N.exact.get(x) ?? I18N.names.get(x) ?? I18N_SEG[x];
      let out = [], i = 0, ok = true;
      while (i < m.length) {
        let hit = null, len = Math.min(10, m.length - i);
        for (; len > 0; len--) { const v = look(m.substr(i, len)); if (v != null) { hit = v; break; } }
        if (hit == null) { ok = false; break; }
        out.push(hit); i += len;
      }
      return ok ? ` ${out.join(" ")} ` : m;
    }).replace(/，/g, ", ").replace(/。/g, ". ").replace(/：/g, ": ").replace(/；/g, "; ").replace(/、/g, ", ").replace(/（/g, " (").replace(/）/g, ") ").replace(/！/g, "! ").replace(/？/g, "? ").replace(/\s+/g, " ").replace(/ ([,.:;!?)])/g, "$1").trim();
  return r;
}
function i18nCore(core, depth = 0) {
  if (!HAN.test(core)) return core;
  const hit = I18N.cache.get(core);
  if (hit !== undefined) return hit;
  const pm = /^([·•\s]*)(.*?)([·•\s]*)$/s.exec(core);                          // 首尾的“ · ”是排版分隔符：剥掉后翻译里面的句子再接回去
  if ((pm[1] || pm[3]) && pm[2]) { const inner = i18nCore(pm[2], depth + 1); const out = inner == null ? null : pm[1] + inner + pm[3]; I18N.cache.set(core, out); return out; }
  let r = I18N.exact.get(core);
  if (r == null) r = I18N.names.get(core);
  if (r == null && depth < 4) {
    for (const t of I18N.tpl) {
      if (t.key && core.indexOf(t.key) < 0) continue;
      const m = t.re.exec(core); if (!m) continue;
      const vals = {};
      t.groups.forEach((g, i) => {
        const chunk = m[i + 1].trim(), pieces = g.length > 1 ? i18nSplit(chunk, g.length, depth + 1) : [chunk];
        g.forEach((n, k) => { if (!(n in vals)) { const v = pieces[k]; const tv = i18nCore(v.trim(), depth + 1); vals[n] = tv == null ? v : tv; } });
      });
      r = t.en.replace(/\{(\w+)\}/g, (_, n) => (n in vals ? vals[n] : ""));
      break;
    }
  }
  if (r == null && depth < 4) {                                                  // “ · ”“，”等分隔的几段，各自再试一次
    const parts = core.split(/( · |，|、|；|：| \/ | → )/);
    if (parts.length > 1) {
      let any = false;
      const out = parts.map((p, i) => { if (i % 2) return p === "，" ? ", " : p === "、" ? ", " : p === "；" ? "; " : p === "：" ? ": " : p; const t = i18nCore(p.trim(), depth + 1); if (t != null && t !== p.trim()) any = true; return t == null ? p : t; }).join("");
      if (any) r = out;
    }
  }
  if (r == null && I18N.nameRe && I18N.nameRe.test(core)) { I18N.nameRe.lastIndex = 0; r = core.replace(I18N.nameRe, (m) => I18N.names.get(m)); }
  // RC29.3: phrase-level fallback - every Chinese run is replaced from the phrase table, Chinese punctuation becomes English
  if (depth === 0 && I18N.runs && (r == null || HAN.test(r))) r = i18nRuns(r == null ? core : r);
  if (I18N.nameRe) I18N.nameRe.lastIndex = 0;
  if (I18N.cache.size > 6000) I18N.cache.clear();
  I18N.cache.set(core, r == null ? null : r);
  return r == null ? null : r;
}
function i18nStr(v) {
  if (!v || !HAN.test(v)) return null;
  const core = v.replace(/\s+/g, " ").trim(), r = i18nCore(core);
  if (r == null || r === core) return null;
  return /^\s*/.exec(v)[0] + r + /\s*$/.exec(v)[0];
}
const I18N_ATTRS = ["title", "placeholder", "aria-label", "alt"];
function i18nEl(el) {
  for (const a of I18N_ATTRS) { const v = el.getAttribute && el.getAttribute(a); if (v) { const r = i18nStr(v); if (r != null) el.setAttribute(a, r); } }
}
const i18nSkip = (el) => /^(SCRIPT|STYLE|TEXTAREA|CODE)$/.test(el.tagName) || (el.getAttribute && el.getAttribute("translate") === "no");
function i18nTree(root) {
  if (!root) return;
  if (root.nodeType === 3) { if (!(root.parentNode && root.parentNode.closest && root.parentNode.closest("[translate=no]"))) { const r = i18nStr(root.nodeValue); if (r != null) root.nodeValue = r; } return; }
  if (root.nodeType !== 1 || (root.closest && root.closest("[translate=no]"))) return;
  const w = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, { acceptNode: (n) => (n.nodeType === 1 && i18nSkip(n) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT) });
  if (!i18nSkip(root)) i18nEl(root);
  for (let n = w.nextNode(); n; n = w.nextNode()) {
    if (n.nodeType === 1) i18nEl(n);
    else { const r = i18nStr(n.nodeValue); if (r != null) n.nodeValue = r; }
  }
}
function i18nStart() {
  I18N.on = true;
  const info = langInfo(LANG);
  document.documentElement.lang = LANG;
  if (info.rtl) document.documentElement.dir = "rtl";
  const t = i18nStr(document.title); if (t != null) document.title = t;
  i18nTree(document.body);
  const mo = new MutationObserver((muts) => {
    for (const m of muts) {
      if (m.type === "childList") m.addedNodes.forEach(i18nTree);
      else if (m.type === "characterData") i18nTree(m.target);
      else if (m.type === "attributes") i18nEl(m.target);
    }
    mo.takeRecords();                                                            // 丢掉我们自己改文字产生的记录，避免来回触发
  });
  mo.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: I18N_ATTRS });
}
if (EN) {
  I18N.ready = fetch(`/lang/${LANG}.json`).then((r) => { if (!r.ok) throw new Error(r.status); return r.json(); })
    .then((d) => { i18nCompile(d); i18nStart(); return true; })
    .catch((e) => { console.warn("语言包读取失败，保持中文：", LANG, e); return false; });
}
/* ================= 分区与二级菜单 ================= */
// tab: [名称, 渲染函数 | null(规划中)]
const SECTIONS = {
  home:     { t: "主页", tabs: [["概览", viewHome], ["通知", viewInbox], ["新闻", viewNews], ["董事会", viewBoard]] },
  // 2026-11-17 用户：“把青训放到训练里面，然后将训练改成成长”。青训从球队移走后荣誉/深度的下标各减 1——链接仍写旧编号，由 LINK_ALIAS 换算（见 navLink）
  // 2026-11-17 UI 评估第二档（用户“做第二档”）：低频页并进相关页当“子页”——标签第三项是 [[子页名, 渲染函数], …]，页签行右侧出一个分段开关切换。
  // 球队 7→5：深度并进阵容，伤病并进球员；赛季 6→4：日程、战报并进赛程。旧链接编号由 LINK_ALIAS 换算到 [分区, 标签, 子页]。
  season:   { t: "赛季", tabs: [["积分榜", viewTable], ["数据榜", viewStats], ["联赛", viewLeagues], ["欧战", viewEurope], ["Awards", viewAwards], ["赛程", viewHistory, [["赛果", viewHistory], ["日历", viewCalendar], ["战报", viewReports]]]] },     // 联赛放最后（四大联赛并排看）；E336 欧战再往后（旧编号 season:6）
  squad:    { t: "球队", tabs: [["概况", viewClub], ["阵容", viewLineup, [["阵容", viewLineup], ["深度", viewDepth]]], ["球员", viewPlayers, [["名单", viewPlayers], ["伤病", viewInjuries]]], ["合同", viewContracts], ["荣誉", viewHonors]] },
  transfer: { t: "转会", tabs: [["市场", viewMarket], ["球探", viewScout], ["报价", viewOffers], ["挂牌出售", viewListings], ["联赛球员", viewWorld], ["自由球员", viewFree]] },     // 联赛球员库放最后（M8-W0），不改已有下标
  training: { t: "成长", tabs: [["本周计划", viewWeek], ["个人训练", viewIndividual], ["成长记录", viewGrowth]] },     // RC29.3: no academy
  finance:  { t: "财务", tabs: [["概览", viewFinance], ["薪资", viewWages], ["赞助", viewSponsors]] },
  // 2026-11-17 用户：“把这个我的放在这个侧栏”——“我的教练”从主页标签移到侧栏独立分区，页面做成手机界面（53-coach.js）；旧链接 home:4 由 LINK_ALIAS 换到这里
  me:       { t: "我的", tabs: [["我的手机", viewCoach]] },
  editor:   { t: "Editor", tabs: [["Edit Transfer", viewEditor]] },     // RC29.6: Master League world editor     // RC29.4: stand-alone cups
};
// 经营层数据（/api/biz/*，M4 服务端未上线前手机上取不到 -> null，对应页面显示“上线后显示”的规划说明；预览服务器给 demo 数据并在标签栏标“示例数据”）
const BIZ = {};
let usedDemo = false;
let pageTools = "";       // 当前页想放到页签行右侧（#tools）的内容；每次 draw 前清空，由视图函数设置
const bizFailed = new Set();          // 本次重画里读取失败的经营数据键（不缓存，重试会重新请求）
// 服务端没有 /api/biz/*（手机现状）时用前端自带的示例数据（用户 2026-11-12：“现在是有什么就显示什么吧 反正我是自己测试”）；示例数据带 demo:true，标签栏标“示例数据”
// 同一个键正在读时，后来的调用等同一次读取（外壳在后台读市场时页面也要市场，只读一次）
const bizPending = new Map();
function biz(k) {
  if (k in BIZ) { if (BIZ[k] && BIZ[k].demo) usedDemo = true; return Promise.resolve(BIZ[k]); }
  if (!bizPending.has(k)) bizPending.set(k, bizLoad(k).finally(() => bizPending.delete(k)));
  return bizPending.get(k).then((v) => { if (v && v.demo) usedDemo = true; return v; });
}
async function bizLoad(k) {
  if (!(k in BIZ)) {
    // 手机上的宿主对未实现的 /api/* 回 200 + {}（不是 404）：空对象不是经营数据，按“服务端没有”处理（V28.1 实机：{} 让 renderShell 抛错，页面永远停在“正在载入”）
    // 服务端已接真数据的键（M4 批 1：training / inbox / stats）回真实 JSON；其余键回 {error: "not-built"}，同样走示例数据
    // 体验评审 U14：只有“服务端没有这一块”（not-built / 旧宿主的 {}）才用示例数据；真出错（网络失败、其他 error）不拿别的球员/金额顶替，
    // 记进 bizFailed 并且不缓存，页面显示“读取失败 + 重试”；没有赛季（no-season）回 null，显示“暂无数据”。
    let r = null, failed = false;
    try { r = await api(`/api/biz/${k}`); } catch (e) { failed = true; }
    const unbuilt = !failed && (!r || typeof r !== "object" || !Object.keys(r).length || r.error === "not-built");
    if (failed || (r && r.error && r.error !== "not-built" && r.error !== "no-season")) { bizFailed.add(k); return null; }
    if (r && r.error === "no-season") BIZ[k] = null;
    else if (unbuilt) { try { BIZ[k] = await demoBiz(k); } catch (e2) { BIZ[k] = null; } }
    else BIZ[k] = r;
    if (k === "inbox" && BIZ[k] && !BIZ[k].demo) { const rd = ibxRead(); BIZ[k].items.forEach((x) => { if (rd.has(x.id)) x.unread = false; }); }
  }
  if (BIZ[k] && BIZ[k].demo) usedDemo = true;
  return BIZ[k];
}
// 示例数据：形状即 M4 服务端契约（见 preview/mock_biz.py 文档串）；球员名取自 ML 存档真实阵容
const MARKET_PID = { "维尔茨": 105684381342404, "姆贝乌莫": 105665322409437, "伊萨克": 105553653252487, "西蒙斯": 105569222530856, "吉奥克雷斯": 105666127720390,
  "弗林蓬": 105649484728794, "苏比门迪": 105625862405274, "亚马尔": 105702903413058, "哈伊森": 105775380983650, "迪奥曼德": 105802761397591 };
const DEMO_MARKET = [["维尔茨", "AMF", 23, 89, 93, ["LEV", "勒沃库森", "#e32221", 128], 98], ["姆贝乌莫", "RWF", 26, 84, 85, ["BRE", "布伦特福德", "#e30613", 4180], 58],
  ["伊萨克", "CF", 26, 88, 90, ["NEW", "纽卡斯尔", "#241f20", 106], 110], ["奎罗斯", "CB", 22, 80, 87, ["TOT", "热刺", "#1e3871", 179], 34],
  ["西蒙斯", "AMF", 22, 85, 90, ["RBL", "莱比锡", "#dd0741", 5010], 72], ["吉奥克雷斯", "CF", 27, 86, 87, ["SCP", "葡萄牙体育", "#008057", 193], 80],
  ["弗林蓬", "RB", 24, 84, 87, ["LEV", "勒沃库森", "#e32221", 128], 45], ["苏比门迪", "DMF", 26, 86, 88, ["RSO", "皇家社会", "#0067b1", 0], 60],
  ["亚马尔", "RWF", 19, 90, 97, ["BAR", "巴塞罗那", "#a50044", 108], 180], ["巴克雷", "GK", 23, 78, 84, ["SEV", "塞维利亚", "#d4001f", 265], 15],
  ["哈伊森", "CB", 20, 80, 88, ["BOU", "伯恩茅斯", "#da291c", 4071], 40], ["迪奥曼德", "CB", 21, 81, 86, ["SCP", "葡萄牙体育", "#008057", 193], 52]];
async function demoBiz(k) {
  let sq = [];
  try { const t = await team(me()); sq = [...t.squad, ...t.reserve]; } catch (e) { /* 没阵容也能出页面 */ }
  const nm = (i, d) => (sq[Math.min(i, sq.length - 1)] || {}).name || d;
  const wageOf = (p, i) => Math.round((0.05 + ((p.overall || 80) - 70) * 0.012 + (i % 4) * 0.02) * 1000);      // 示例周薪：K / 周
  const r = row(me()) || {}, n = S.next, opp = n ? tname(n.home === me() ? n.away : n.home) : "对手";
  if (k === "club") return { demo: true, budget: 86.4, weekly_wages: sq.reduce((a, p, i) => a + wageOf(p, i), 0) || 3100, wage_room: 420, season_net: 12.8, morale: 74, fitness: 81,
    window: { kind: "winter", open: false, days: 3 },
    board: { trust: 68, target: "联赛前四", verdict: (r.position || 9) <= 4 ? "非常满意" : "满意", final: false, objectives: [
      { text: "联赛排名进入前四", state: (r.position || 9) <= 4 ? "met" : "chasing", note: `当前第 ${r.position || "—"} 名` },
      { text: "本季财务不亏损", state: "met", note: "目前盈余 €12.8M" },
      { text: "薪资占收入低于 60%", state: "met", note: "目前 58%" }] } };
  if (k === "inbox") return { demo: true, items: [
    { id: 1, kind: "transfer", title: `拜仁对 ${nm(0, "萨利巴")} 报价 €62M`, body: "对方希望 48 小时内答复，可以接受、拒绝或还价。", when: "2 小时前", unread: true },
    { id: 2, kind: "injury", title: `${nm(5, "厄德高")} 腿筋拉伤，预计缺阵 2 周`, body: "队医建议本周不参加高强度训练。", when: "上一轮后", unread: true },
    { id: 3, kind: "board", title: "董事会：本季目标 联赛前四", body: `董事会信任度 68%，目前第 ${r.position || "—"} 名。`, when: "赛季初", unread: true },
    { id: 4, kind: "growth", title: `${nm(2, "恩瓦内里")} 能力 +2`, body: "本月训练成长最快的球员。", when: "本周", unread: true },
    { id: 5, kind: "contract", title: "3 名球员合同将在本季结束后到期", body: "到“球队 · 合同”查看并续约。", when: "本周", unread: false },
    { id: 6, kind: "finance", title: "转播分成到账 €8.2M", body: "第二期转播分成。", when: "上周", unread: false },
    { id: 7, kind: "match", title: `下一场 vs ${opp}`, body: "赛前记得检查体能与阵容。", when: "本周", unread: false }] };
  if (k === "squad") {
    const players = {};
    sq.forEach((p, i) => { const o = p.overall || 80;
      players[String(p.pid)] = { age: 19 + (i * 7) % 15, wage: wageOf(p, i), until: 2027 + i % 4, value: +((o - 70) * 4.2 + (i % 5) * 2.5).toFixed(1), morale: 55 + (i * 17) % 45,
        fitness: 68 + (i * 13) % 32, potential: Math.min(97, o + (i * 5) % 8), injury: i === 5 ? { name: "腿筋拉伤", weeks: 2 } : i === 9 ? { name: "脚踝扭伤", weeks: 1 } : null }; });
    return { demo: true, players, youth: [["刘易斯-斯克利", "LB", 18, 68, 84, "左脚，助攻积极"], ["诺加德", "CMF", 17, 64, 86, "视野好，体能一般"], ["鲁特", "GK", 18, 61, 80, "反应快"],
      ["哈里森", "CF", 16, 58, 88, "最高潜力"], ["奥拉卢", "RWF", 17, 63, 82, "速度型"]].map(([name, position, age, overall, potential, note]) => ({ name, position, age, overall, potential, note })) };
  }
  if (k === "market") return { demo: true,
    market: DEMO_MARKET.map(([name, position, age, overall, potential, [code, cn, c, id], price], i) => ({ id: i + 1, pid: MARKET_PID[name], name, position, age, overall, potential, club: { id, code, name: cn, c }, price, wage: Math.round(price * 1000 / 300) })),
    shortlist: [1, 4, 9],
    offers: { incoming: [{ pid: (sq[0] || {}).pid, player: nm(0, "萨利巴"), position: (sq[0] || {}).position || "CB", club: "拜仁慕尼黑", clubId: 127, fee: 62, expires: "48 小时", state: "pending" },
      { pid: (sq[3] || {}).pid, player: nm(3, "若日尼奥"), position: (sq[3] || {}).position || "DMF", club: "那不勒斯", clubId: 327, fee: 18, expires: "3 天", state: "pending" }],
      outgoing: [{ player: "奎罗斯", position: "CB", club: "热刺", clubId: 179, fee: 30, expires: "2 天", state: "pending" }, { player: "巴克雷", position: "GK", club: "塞维利亚", clubId: 265, fee: 12, expires: "—", state: "rejected" }] },
    listings: [{ pid: (sq[6] || {}).pid, name: nm(6, "特罗萨德"), position: (sq[6] || {}).position || "RWF", overall: (sq[6] || {}).overall || 80, price: 25, interest: 3, days: 5 },
      { pid: (sq[8] || {}).pid, name: nm(8, "热苏斯"), position: (sq[8] || {}).position || "CF", overall: (sq[8] || {}).overall || 76, price: 9, interest: 1, days: 2 }] };
  if (k === "training") {
    const days = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"], kinds = ["normal", "intense", "normal", "intense", "recovery", "match", "rest"];
    return { demo: true, focus: "attack", risk: 38,
      focuses: [{ k: "attack", name: "进攻配合", desc: "传球 · 射门" }, { k: "defence", name: "防守组织", desc: "防守 · 对抗" }, { k: "fitness", name: "体能储备", desc: "体能 · 速度" }],
      week: days.map((day, i) => ({ day, kind: kinds[i], opp: kinds[i] === "match" ? opp : null })),
      players: sq.slice(0, 14).map((p, i) => ({ pid: p.pid, name: p.name, position: p.position || "", overall: p.overall, focus: ["射门", "传球", "防守", "体能", "速度"][i % 5], progress: (i * 23) % 100 })),
      growth: sq.slice(0, 6).map((p, i) => ({ pid: p.pid, name: p.name, position: p.position || "", from: (p.overall || 80) - 2, to: p.overall || 80, when: ["本周", "上周", "2 周前", "3 周前"][i % 4] })) };
  }
  if (k === "finance") {
    const wages = sq.map((p, i) => ({ pid: p.pid, name: p.name, position: p.position || "", wage: wageOf(p, i), until: 2027 + i % 4 })).sort((a, b) => b.wage - a.wage);
    return { demo: true, balance: 86.4,
      months: [["7月", 8, 41], ["8月", 22, 15], ["9月", 18, 14], ["10月", 20, 15], ["11月", 21, 14], ["12月", null, null], ["1月", null, null], ["2月", null, null]].map(([m, inc, exp]) => ({ m, inc, exp })),
      ledger: [["转播分成", 38.2], ["比赛日门票", 21.5], ["赞助与商业", 19.0], ["球员薪资", -53.6], ["转会支出", -32.0], ["训练与设施", -6.3]].map(([name, v]) => ({ name, v })),
      wages: { total: wages.reduce((a, w) => a + w.wage, 0), cap: 3500, players: wages },
      sponsors: [["主赞助（球衣胸前）", "球衣", 12.0, 2028, "进欧冠 +€3M"], ["球衣制造商", "装备", 6.5, 2029, "联赛冠军 +€2M"], ["球场冠名", "场馆", 4.0, 2027, "—"], ["训练基地合作", "设施", 1.2, 2027, "—"]]
        .map(([name, kind, amount, until, bonus]) => ({ name, kind, amount, until, bonus })) };
  }
  if (k === "stats") {
    // 我方：用真实卡上记录的进球/助攻；他队示例
    const goals = [...sq].filter((p) => p.goals).sort((a, b) => b.goals - a.goals).slice(0, 6).map((p) => ({ pid: p.pid, name: p.name, team: null, n: p.goals }));
    const asts = [...sq].filter((p) => p.assists).sort((a, b) => b.assists - a.assists).slice(0, 6).map((p) => ({ pid: p.pid, name: p.name, team: null, n: p.assists }));
    return { demo: true, scorers: goals.length ? goals : [{ name: nm(0, "—"), team: null, n: 0 }], assisters: asts.length ? asts : [{ name: nm(0, "—"), team: null, n: 0 }] };
  }
  if (k === "honors") return { demo: true, seasons: [{ season: S.career.season || 1, league: S.career.league_name, rank: S.career.finished ? r.position : null, points: r.points ?? null, trophy: null }],
    cabinet: [{ name: "联赛冠军", count: 0 }, { name: "国内杯赛", count: 0 }, { name: "欧冠", count: 0 }] };
  return null;
}
const money = (v, d = 1) => v == null ? "—" : `€${(+v).toFixed(d)}M`;
// 周薪一律用 K（2026-11-14 用户：“周薪还是用 K 为单位吧，不要用 M”）：服务端周薪是整数 K / 周，转会费、预算、收入仍是 M
const kfmt = (v) => v == null ? "—" : `€${Math.round(+v).toLocaleString("en-US")}K`;
const PLANS = {
  home: ["通知与董事会", "俱乐部的消息都汇到这里：转会报价、伤病、球员成长、董事会目标与信任度。", [["收件箱", "报价、伤病、合同到期等事件，未读计数显示在顶栏"], ["董事会", "赛季目标、信任度与评价"]]],
  squad: ["合同 · 伤病 · 荣誉", "球员的合同、周薪、伤病与体能，俱乐部的冠军与奖杯记录都在这里；开始赛季后才有数据。", [["合同", "到期提醒、续约与解约"], ["伤病", "伤情、预计缺阵轮次"], ["荣誉", "冠军、奖杯与赛季归档"]]],
  transfer: ["转会市场", "用转会预算从卡库签下新球员，挂牌出售多余球员；同一真人在大师联赛里只能有一张卡。", [["市场", "按位置、能力、年龄、预算筛选"], ["球探", "发现目标与能力报告"], ["报价", "收到与发出的报价，下一场比赛后答复"], ["挂牌出售", "设定价格，等待其他俱乐部出价"]]],
  training: ["成长", "每周安排训练强度与团队重点，球员在比赛与训练中成长，年龄增长后能力会下滑；青训营每个转会窗迎来一批新人。", [["本周计划", "七天日程，比赛日前建议恢复"], ["个人训练", "针对单个球员的能力方向"], ["成长记录", "能力变化与潜力"], ["青训", "青训日新人与学员成长"]]],
  finance: ["财务", "门票、转播、赞助与奖金是收入，薪资、转会与设施是支出；董事会按收支评价你的经营。", [["概览", "可用资金与月度收支"], ["薪资", "周薪总额与薪资占比"], ["赞助", "赞助合同与奖金条款"]]],
  season: ["数据榜", "射手榜、助攻榜与出场记录会放在这里。", [["数据榜", "射手、助攻、出场"], ["联赛", "四大联赛积分榜、赛果、射手榜与历届冠军"]]],
};
let cur = { sec: "home", tab: 0, sub: 0 };
// 字符串链接（data-tab、顶栏跳转、赛前简报、服务端通知/日历的 go、存档里的旧通知）一律沿用“旧编号”，由这里换算到现在的 [分区, 标签, 子页]：
//   球队（2026-11-17 前的编号）：0 概况 1 阵容 2 球员 3 合同 4 伤病 5 青训（已移到 成长·青训） 6 荣誉 7 深度
//   赛季：0 积分榜 1 赛程结果 2 日程 3 战报 4 数据榜 5 联赛 6 欧战（E336）
// 新写链接也照这套旧编号写（例如伤病写 squad:4、日程写 season:2），不要写现在的下标。
const LINK_ALIAS = { "squad:4": ["squad", 2, 1], "squad:5": ["training", 3], "squad:6": ["squad", 4], "squad:7": ["squad", 1, 1],
  "season:1": ["season", 5, 0], "season:2": ["season", 5, 1], "season:3": ["season", 5, 2], "season:4": ["season", 1], "season:5": ["season", 2], "season:6": ["season", 3],
  "home:4": ["me", 0] };
function navLink(to, opts) {
  const a = LINK_ALIAS[to]; if (a) return openSec(a[0], a[1], { ...(opts || {}), sub: a[2] || 0 });
  const [s, i] = String(to).split(":"); return openSec(s, +i || 0, opts);
}
const tabSubs = (sec, tab) => (SECTIONS[sec] && SECTIONS[sec].tabs[tab] && SECTIONS[sec].tabs[tab][2]) || null;
function openSec(sec, tab = 0, opts = {}) {
  if (!SECTIONS[sec]) sec = "home";
  if (!SECTIONS[sec].tabs[tab]) tab = 0;            // 旧版本记住的下标超出（例如球队少了一个标签）：回到第一个
  const changed = sec !== cur.sec;
  if (!opts.silent && changed) sound("page");
  if (!opts.keepLayer) closeLayer(true);
  const subs = tabSubs(sec, tab);
  let si = opts.sub != null ? +opts.sub : sec === cur.sec && tab === cur.tab ? cur.sub || 0 : 0;     // 同一标签重画时保留子页
  if (!subs || !subs[si]) si = 0;
  if (sec !== cur.sec || tab !== cur.tab || si !== (cur.sub || 0)) calMonth = null;      // 每次点开日程都定位到下一场所在的月份 (月份翻页用 draw()，不受影响)
  cur = { sec, tab, sub: si };
  const S2 = SECTIONS[sec], ri = $(`.ri[data-sec="${sec}"]`);
  $$(".ri[data-sec]").forEach((b) => b.classList.toggle("on", b === ri));
  // 2026-11-13：左栏没有“球队”项了，球队页从左上角队徽进入——此时左栏不亮任何项，队徽亮
  $("#rind").style.opacity = ri ? "" : "0"; if (ri) $("#rind").style.transform = `translateY(${ri.offsetTop}px)`;
  const bd = $(".brand"); if (bd) bd.classList.toggle("on", sec === "squad");
  const sub = $("#subnav");
  sub.style.display = sec === "me" ? "none" : "";      // 2026-11-17 用户：“你取消掉这个顶栏啊”——“我的”是整页手机，不要分区标题与标签行
  // E360：页签行在顶栏里，不再写分区大标题（左栏已经亮着所在分区）；分区名留给读屏
  if (changed || !sub.dataset.sec || opts.redraw) {
    sub.dataset.sec = sec;
    sub.setAttribute("aria-label", S2.t);
    // 工具区（#tools：子页开关、窗口状态等）在顶栏里独立一块、不随页签行横向滑动，永远看得见
    sub.innerHTML = S2.tabs.map(([n], i) => `<button class="st" data-i="${i}">${n}${tabBadge(sec, i)}</button>`).join("") + `<i class="uline"></i>`;
    $$(".st", sub).forEach((b) => b.onclick = () => { if (+b.dataset.i !== cur.tab) { sound("cursor"); openSec(sec, +b.dataset.i); } });
    const ul = $(".uline", sub); ul.style.transition = "none"; requestAnimationFrame(() => { ul.style.transition = ""; });
    if (typeof fitTop === "function") fitTop();
  }
  const tb = $$(".st", sub)[tab], ul = $(".uline", sub);
  $$(".st", sub).forEach((b) => b.classList.toggle("on", b === tb));
  if (tb && ul) { ul.style.left = tb.offsetLeft + 11 + "px"; ul.style.width = tb.offsetWidth - 22 + "px"; }
  if (tb && sub.scrollWidth > sub.clientWidth) {           // 页签行放不下时在横向滑动：把当前页签滑进视野
    const l = tb.offsetLeft, r = l + tb.offsetWidth;
    if (l < sub.scrollLeft) sub.scrollLeft = l - 8; else if (r > sub.scrollLeft + sub.clientWidth) sub.scrollLeft = r - sub.clientWidth + 8;
  }
  draw();
}
let drawSeq = 0, quietDraw = false;       // quietDraw：下一次重画不播入场动画、不闪“正在读取…”（战术板拖动换位后用）
async function draw() {
  const seq = ++drawSeq, page = $("#page"), subs = tabSubs(cur.sec, cur.tab), [name, fn] = subs ? subs[cur.sub || 0] || subs[0] : SECTIONS[cur.sec].tabs[cur.tab];
  let html;
  const quiet = quietDraw; quietDraw = false;
  const slow = quiet ? 0 : setTimeout(() => { if (seq === drawSeq) page.innerHTML = `<div class="view"><div class="empty-note">正在读取…</div></div>`; }, 120);
  usedDemo = false; bizFailed.clear(); pageTools = "";
  try { html = await fn(name); }
  catch (e) { html = viewBizError(name, e.message); }
  finally { clearTimeout(slow); }
  if (seq !== drawSeq) return;
  const tools = $("#tools");
  if (tools) {
    // 子页开关（UI 评估第二档）：并进来的低频页在这里切换；角标与标签同源（tabBadge 的子页版本）
    const seg = subs ? `<div class="subseg" role="tablist">${subs.map(([n], i) => `<button type="button" role="tab" data-sub="${i}" class="${i === (cur.sub || 0) ? "on" : ""}" aria-selected="${i === (cur.sub || 0)}">${n}${subBadge(cur.sec, cur.tab, i)}</button>`).join("")}</div>` : "";
    tools.innerHTML = (usedDemo ? `<span class="demo" title="经营层服务端未上线，这一页用的是预览示例数据">示例数据</span>` : "") + pageTools + seg;
    $$(".subseg button", tools).forEach((b) => b.onclick = () => { const i = +b.dataset.sub; if (i === (cur.sub || 0)) return; sound("cursor"); calMonth = null; cur = { ...cur, sub: i }; draw(); });
    if (typeof fitTop === "function") fitTop();            // E360：工具区在顶栏页签行里，内容变了要重新量
  }
  page.innerHTML = html;
  page.classList.toggle("still", quiet);
  bindPage(page);
  const rb = $("[data-bizretry]", page); if (rb) rb.onclick = () => { sound("cursor"); draw(); };
  animate(page);
  refreshBadges();
}
// 未读/待办计数：标签角标与顶栏铃铛（读过通知后即时减少）
function refreshBadges() {
  const ib = BIZ.inbox, n = ib ? ib.items.filter((m) => m.unread).length : 0, b = $("#bell");
  if (b) { const i = $("i", b); if (n) { if (i) i.textContent = n; else b.insertAdjacentHTML("beforeend", `<i>${n}</i>`); } else if (i) i.remove(); }
  $$("#subnav .st").forEach((t, i) => { const old = $(".b", t); if (old) old.remove(); t.insertAdjacentHTML("beforeend", tabBadge(cur.sec, i)); });
  const tb = $$("#subnav .st")[cur.tab], ul = $("#subnav .uline");
  if (tb && ul) { ul.style.left = tb.offsetLeft + 11 + "px"; ul.style.width = tb.offsetWidth - 22 + "px"; }
}

/* ================= 主页 · 概览 ================= */
function lastMine() {
  const lr = S.last_round; if (!lr) return null;
  return (lr.fixtures || []).find((f) => isMine(f) && f.result) || null;
}
function resultOf(f) { const mh = f.home === me(), a = f.result.home_goals, b = f.result.away_goals; const gf = mh ? a : b, ga = mh ? b : a; return gf > ga ? "W" : gf < ga ? "L" : "D"; }
// 主页概览（2026-11-13 重排，“俱乐部总览式”）：左列 = 下一场横幅（两队 + 主客/日期/倒计时 + 胜平负 + 按钮）和 6 格俱乐部指标，右列 = 通知。
// 指标：上一场、联赛排名、士气、体能、董事会信任、本季收支；经营数据取不到时换成进失球和之后三场。
let hmSide = "todo";
/* 经理待办（2026-11-14 体验评审批次 C / §5）：右列默认先给“现在该决定什么”，最多 3 条，每条直接通向处理的地方。
   只从真数据生成（示例数据不出待办，没有对应数据的提醒不编）：首发伤停 → 阵容；对方还价 → 报价页；收到出价 → 报价页；
   新援还在预备队 → 直接打开“换下谁”；合同季末到期（赛季最后 10 轮起）→ 合同页；赛季结束 → 总结。 */
// E355（2026-11-17 用户“点继续的时候卡顿”）：待办只用报价与自家阵容（offers / own），读轻量的 /api/biz/offers——不再每次“继续”后重建整个转会市场
// （约 0.5 s、700 KB 球员行）；旧宿主 / 预览没有这个键（示例数据或空）时照旧读整个市场。
const hmOffers = () => biz("offers").catch(() => null).then((o) => (o && !o.demo ? o : biz("market")));
async function hmTodos() {
  const [mk, sq, hl, tm, lu, club, yt] = await Promise.all([hmOffers(), biz("squad"), api("/api/health").catch(() => null), team(me()).catch(() => null), biz("lineup").catch(() => null),
    biz("club").catch(() => null), biz("youth").catch(() => null)]);
  const out = [], c = S.career;
  if (c.finished && !S.next) out.push({ ic: "season", col: "var(--gold)", t: "赛季已结束", s: "看看本季总结，再进入新赛季", btn: "赛季总结", attr: `data-act="review"` });
  // 2026-11-17 UI 评估第三档（待办中心）：转会窗快关（3 天内）、青训新人等揭晓 / 等签约决定也进待办，都直接通向处理的地方。
  // 只显示前 3 条，所以排在伤停与转会决定之后（later 在 return 前接上，合同到期仍在最后）
  const later = [];
  if (yt && !yt.demo) {
    const pend = yt.pending_reveal || [], wait = yt.waiting || [];
    if (pend.length) later.push({ ic: "person", col: "var(--gold)", t: `${pend.length} 名青训新人等你揭晓`, s: "青训日来了一批新人，看看都是谁", btn: "揭晓", attr: `data-ytplay="1"` });
    if (wait.length) later.push({ ic: "person", col: "var(--win)", t: `${wait.length} 名青训新人等你决定`, s: "签下或放弃，不签的会离开青训营", btn: "去青训", attr: `data-tab="training:3"` });
  }
  const win = club && club.window;
  if (win && win.open && win.days != null && win.days <= 3) {
    const live = mk && !mk.demo ? mk.offers.outgoing.filter((o) => ["pending", "countered", "agreed", "personal"].includes(o.state)).length : 0;
    later.unshift({ ic: "transfer", col: "var(--draw)", t: win.days ? `转会窗 ${win.days} 天后关闭` : "转会窗今天关闭", s: live ? `还有 ${live} 个报价在谈，关窗前没谈完就作废` : "关窗前最后的签人、卖人机会", btn: "去转会", attr: `data-tab="transfer:0"` });
  }
  if (luOk(lu) && lu.rotation.length) {          // M6-F2：首发伤停 / 疲劳 / 刚复出 → 直接打开阵容助手的轮换建议（比只说“去调整”多一个可接受的方案）
    const r = lu.rotation, hurt = r.filter((x) => x.kind === "injured").length, tired = r.filter((x) => x.kind === "tired").length;
    out.push({ ic: hurt ? "med" : "bolt", col: hurt ? "var(--loss)" : "var(--draw)", t: hurt ? `${hurt} 名首发伤停${tired ? `、${tired} 名疲劳` : ""}` : `${r.length} 名首发${tired ? "疲劳偏高" : "需要关注"}`,
      s: r[0].reason.split("；")[0], btn: "轮换建议", attr: `data-lu-assist="rot"` });
  } else if (hl && Array.isArray(hl.players) && tm) {
    const starters = new Set(tm.squad.filter((p) => p.starter).map((p) => String(p.pid)));
    const hurt = hl.players.filter((p) => p.injury && starters.has(String(p.pid)));
    if (hurt.length) { const nm = (tm.squad.find((p) => String(p.pid) === String(hurt[0].pid)) || {}).name || "首发球员";
      out.push({ ic: "med", col: "var(--loss)", t: hurt.length > 1 ? `${hurt.length} 名首发伤停` : `首发 ${nm} 伤停`, s: "伤员不能首发，开赛前换人", btn: "调整阵容", attr: `data-tab="squad:1"` }); }
  }
  if (mk && !mk.demo) {
    for (const o of mk.offers.outgoing.filter((x) => x.state === "agreed"))                 // M6-E1：俱乐部已同意，去和球员谈
      out.push({ ic: "transfer", col: "var(--gold)", t: `和 ${o.player} 谈个人条款`, s: `${o.club} 已同意 ${money(o.fee, 1)} · ${o.expires}`, btn: "谈条款", attr: `data-terms="${o.id}"` });
    for (const o of mk.offers.outgoing.filter((x) => x.state === "countered")) out.push({ ic: "transfer", col: "var(--gold)", t: `${o.club} 对 ${o.player} 还价 ${money(o.fee, 1)}`, s: `你的报价 ${money(o.bid, 1)} · 剩 ${o.expires}`, btn: "答复", attr: `data-tab="transfer:2"` });
    const inc = mk.offers.incoming.filter((x) => x.state === "pending");
    if (inc.length) { const top = [...inc].sort((a, b) => b.fee - a.fee)[0];
      out.push({ ic: "coin", col: "var(--gold)", t: inc.length > 1 ? `收到 ${inc.length} 份出价` : `${top.club} 出价 ${money(top.fee, 1)} 求购 ${top.player}`, s: inc.length > 1 ? `最高：${top.club} ${money(top.fee, 1)} 求购 ${top.player}` : `剩 ${top.expires} 答复`, btn: "答复", attr: `data-tab="transfer:2"` }); }
    const own = new Map((mk.own || []).map((p) => [String(p.pid), p]));
    const fresh = mk.offers.outgoing.filter((o) => o.state === "accepted" && own.has(String(o.pid)) && !own.get(String(o.pid)).in_squad);
    for (const o of fresh) out.push({ ic: "person", col: "var(--win)", t: `新援 ${o.player} 还在预备队`, s: "换进 23 人名单才能上场", btn: "安排上阵", attr: `data-sub="${esc(o.pid)}"` });
  }
  out.push(...later);
  if (sq && !sq.demo && sq.players && (c.finished || (c.rounds_total && c.current_round > c.rounds_total - 10))) {
    const end = 2026 + (c.season || 1), n = Object.values(sq.players).filter((p) => p.until && p.until <= end).length;
    if (n) out.push({ ic: "cal", col: "var(--draw)", t: `${n} 名球员合同季末到期`, s: "不续约的会在新赛季前离队", btn: "查看续约", attr: `data-tab="squad:3"` });
  }
  return out;
}
function hmTodoHtml(list) {
  if (!list.length) { const n = S.next, opp = n ? (n.home === me() ? n.away : n.home) : null;
    return `<div class="todo-empty">${svg("check", 2.2)}<b>本周暂无必须处理的事</b><small>${n ? "可以看看对手，或者直接推进到下一场" : "一切就绪"}</small>
      <div>${opp ? `<button class="btn" data-team="${opp}">对手阵容</button>` : ""}${n ? `<button class="btn pri" data-act="kickoff">${isMatchDay() ? "开始比赛" : "继续"}</button>` : ""}</div></div>`; }
  return list.slice(0, 3).map((x) => `<div class="todo" style="--k:${x.col}"><span class="ico">${svg(x.ic, 2)}</span><div><b>${esc(x.t)}</b><small>${esc(x.s)}</small></div><button class="btn sm pri" ${x.attr}>${esc(x.btn)}</button></div>`).join("")
    + (list.length > 3 ? `<div class="todo-more muted">另有 ${list.length - 3} 项，处理完上面的会依次出现</div>` : "");
}
// 主页右列面板（待办 / 通知 / 联赛排行 / 数据榜）。单独成函数：切标签时只替换这一块，不重画整个主页，也就不会重播主页动画。
async function hmSidePanel() {
  const [inbox, todos] = await Promise.all([biz("inbox"), hmTodos().catch(() => [])]);
  const hasIn = false;      // 2026-11-17 UI 评估第三档：右列不再放“通知”页签（顶栏铃铛与 主页·通知 已有，三处重复）；待办底部“全部通知 ›”直达
  if (hmSide === "inbox") hmSide = "todo";
  const un = hasIn ? inbox.items.filter((m) => m.unread).length : 0;
  let body, more;
  if (hmSide === "todo") {
    body = hmTodoHtml(todos); more = ["全部通知 ›", "home:1"];
  } else if (hmSide === "inbox") {
    body = inbox.items.slice(0, 6).map((m) => ibxRow(m, false, m.unread)).join(""); more = ["全部通知 ›", "home:1"];
  } else if (hmSide === "table") {
    const tb = S.table || [];
    body = `<table class="mini hm-rank"><thead><tr><th>#</th><th>球队</th><th class="n">赛</th><th class="n">净</th><th class="n">分</th></tr></thead><tbody>${tb.map((x) => `<tr class="go-row${x.team === me() ? " me" : ""}" data-team="${x.team}"><td class="muted">${x.position}</td><td class="name"><span class="tn">${crest(x.team, "sm")}<span>${esc(tname(x.team))}</span></span></td><td class="n muted">${x.played}</td><td class="n muted">${x.gd > 0 ? "+" : ""}${x.gd}</td><td class="n"><span class="num">${x.points}</span></td></tr>`).join("")}</tbody></table>`; more = ["完整积分榜 ›", "season:0"];
  } else {
    const d = await biz("stats");
    const part = (title, rows, unit) => `<div class="ibg">${title}</div><table class="mini"><tbody>${(rows || []).slice(0, 5).map((r, i) => { const tid = r.team == null ? me() : r.team;
      return `<tr class="${tid === me() ? "me" : ""}"><td class="muted" style="width:20px">${i + 1}</td><td class="name"><span class="tn">${crest(tid, "sm")}${pface(r)}<b>${esc(r.name)}</b></span></td><td class="n"><span class="num">${r.n}</span> <span class="muted fs-s">${unit}</span></td></tr>`; }).join("")}</tbody></table>`;
    body = d ? part("射手榜", d.scorers, "球") + part("助攻榜", d.assisters, "次") : `<div class="empty-note">赛季数据榜上线后显示</div>`; more = ["完整数据榜 ›", "season:4"];
  }
  const tabBtn = (k, label, icon, extra = "") => `<button class="hm-tab${hmSide === k ? " on" : ""}" data-hms="${k}" title="${label}" aria-label="${label}">${svg(icon, 1.8)}${extra}</button>`;
  const side = `<div class="card hm-in${hmSide === "inbox" ? " inbox" : ""}" style="--i:1"><div class="hm-tabs">${tabBtn("todo", "经理待办", "check", todos.length ? `<b class="hm-n">${Math.min(todos.length, 9)}</b>` : "")}${hasIn ? tabBtn("inbox", "通知", "bell", un ? `<b class="hm-n">${un}</b>` : "") : ""}${tabBtn("table", "联赛排行", "rank")}${tabBtn("stats", "赛季数据榜", "ball")}</div>
    <div class="cb scroll">${body}</div><div class="hm-bot">${hmSide === "inbox" ? `<button class="hm-read" data-ibread title="全部已读" aria-label="全部已读"${un ? "" : " disabled"}>${svg("readall", 1.9)}</button>` : ""}<button class="hm-more" data-tab="${more[1]}">${more[0]}</button></div></div>`;
  return side;
}
async function hmSwap() {
  const old = $(".hm-in"); if (!old) { quietDraw = true; return draw(); }
  const tmp = document.createElement("div"); tmp.innerHTML = (await hmSidePanel()).trim();
  const n = tmp.firstElementChild; n.style.animation = "none";
  old.replaceWith(n); bindPage(n); refreshBadges();
}
async function viewHome() {
  const c = S.career, n = S.next, r = row(me()) || {};
  const [club, inbox, hl, tm, st, sq] = await Promise.all([biz("club"), biz("inbox"), api("/api/health").catch(() => null), team(me()).catch(() => null), biz("stats").catch(() => null), biz("squad").catch(() => null)]);
  const di = dayInfo();
  // 赛程条：下一场之后的 3 场（队徽 + 主/客 + 日期）
  const dOf = (f) => { const x = (S.schedule || []).find((y) => y.id === f.id || y.round === f.round); return x && x.date ? parseD(x.date) : null; };
  const sch = (S.upcoming || []).slice(euroFirst() ? 0 : 1, euroFirst() ? 3 : 4).map((f) => { const opp = f.home === me() ? f.away : f.home, d = dOf(f);
    return `<span class="sc" data-team="${opp}" title="第 ${f.round} 轮 · ${esc(tname(opp))}">${crest(opp, "sm")}<i>${f.home === me() ? "主" : "客"}</i>${d ? `<em>${d.getMonth() + 1}/${d.getDate()}</em>` : ""}</span>`; }).join("");
  // 伤停 / 疲劳条：优先用宿主 /api/health；没有就用经营层示例数据里的伤情
  const squadAll = tm ? [...tm.squad, ...tm.reserve] : [], nameOf = (pid) => (squadAll.find((p) => String(p.pid) === String(pid)) || {}).name || "球员";
  let hurt = [];
  if (hl && Array.isArray(hl.players)) hurt = hl.players.filter((p) => p.injury || (p.fatigue || 0) >= 60).map((p) => ({ pid: p.pid, inj: !!p.injury, fat: p.fatigue || 0 }));
  else if (sq && sq.players) hurt = Object.entries(sq.players).filter(([, v]) => v.injury).map(([pid]) => ({ pid, inj: true, fat: 0 }));
  hurt.sort((a, b) => (b.inj - a.inj) || (b.fat - a.fat));
  const injN = hurt.filter((h) => h.inj).length, fatN = hurt.length - injN;
  const hurtHtml = hurt.length ? `${injN ? `<span class="hb inj" title="伤停 ${injN} 人">${svg("med", 2.6)}<b>${injN}</b></span>` : ""}${fatN ? `<span class="hb fat" title="疲劳 ${fatN} 人">${svg("bolt", 2.2)}<b>${fatN}</b></span>` : ""}<span class="hps">${hurt.slice(0, 3).map((h) => `<span class="hp${h.inj ? " inj" : ""}" data-player="${h.pid}" title="${esc(nameOf(h.pid))} · ${h.inj ? "伤停" : `疲劳 ${h.fat}`}">${pface(squadAll.find((p) => String(p.pid) === String(h.pid)) || { pid: h.pid })}</span>`).join("")}${hurt.length > 3 ? `<b class="hmore">+${hurt.length - 3}</b>` : ""}</span>` : `<span class="hb ok" title="全员健康">${svg("check", 2.6)}<b>健康</b></span>`;
  const schBox = `<div class="hm-t sch"><div class="hm-sch" title="之后的赛程">${svg("cal", 1.8)}${sch || `<span class="muted fs-s">之后没有比赛</span>`}</div></div>`, injBox = `<button class="hm-t inj" data-tab="squad:4" title="伤停 / 疲劳"><div class="hm-inj">${hurtHtml}</div></button>`;
  let banner;
  if (euroFirst()) {                                  // E341：下一场是欧战：同一块横幅，赛事名 + 主/客/中立场 + 日期；没有联赛的排名和胜平负
    const e = CAL.europe, today = euroToday(), isHome = !e.neutral && e.home, hm = e.neutral || e.home;
    await euTeamsAll();
    const side = (tid, away) => `<div class="hm-side${away ? " a" : ""}${tid === me() ? " me" : ""}" data-team="${tid}">${crest(tid, "lg")}<div><b>${esc(tname(tid))}</b><small>实力 ${T(tid).strength || "—"}</small></div></div>`;
    const goTxt = today ? "开始比赛" : "继续", goAct = today || n ? "kickoff" : "offgo";
    banner = `<div class="card hm-next eu ${euCls(e)}" style="--i:0;--hc:${tcolor(hm ? me() : e.opponent)};--ac:${tcolor(hm ? e.opponent : me())}">
      <div class="hm-hd">${euLogo(e) ? `<i class="eulg">${euLogo(e)}</i>` : svg("season", 1.8)}<b>${esc(e.label)}</b></div>
      <div class="hm-vs">${side(hm ? me() : e.opponent, false)}<div class="hm-mid"><b>${dateTxt(parseD(e.date))}</b><small>${e.neutral ? "中立场" : isHome ? "主场" : "客场"}</small><em class="${today ? "now" : ""}">${today ? "今天比赛" : `还有 ${e.days} 天`}</em></div>${side(hm ? e.opponent : me(), true)}</div>
      <div class="hm-foot"><div class="odds"></div><button class="btn" data-team="${e.opponent}">对手阵容</button><button class="btn pri" data-act="${goAct}">${goTxt}</button></div></div>`;
  } else if (n) {
    const opp = n.home === me() ? n.away : n.home, home = n.home === me(), o = n.odds || [0, 0, 0], fav = o.indexOf(Math.max(...o));
    const side = (tid, away) => { const rr = row(tid) || {}; return `<div class="hm-side${away ? " a" : ""}${tid === me() ? " me" : ""}" data-team="${tid}">${crest(tid, "lg")}<div><b>${esc(tname(tid))}</b><small>实力 ${T(tid).strength || "—"}</small><span class="hm-rk"><em class="rkc" title="联赛排名">${rr.position || "—"}</em>${formDots(rr.form)}</span></div></div>`; };
    banner = `<div class="card hm-next" style="--i:0;--hc:${tcolor(n.home)};--ac:${tcolor(n.away)}">
      <div class="hm-hd">${lgLogo() || svg("cal")}<b>第 ${n.round} 轮</b>${CAL && CAL.phase === "preseason" ? `<span class="hm-pre" title="7 月 1 日到首轮前：转会、续约、登记">季前期</span>` : ""}</div>
      <div class="hm-vs">${side(n.home, false)}<div class="hm-mid">${di ? `<b>${dateTxt(di.nd)}</b>` : ""}<small>${home ? "主场" : "客场"}</small>${di ? `<em class="${di.matchDay ? "now" : ""}">${di.matchDay ? "今天比赛" : `还有 ${di.left} 天`}</em>` : ""}</div>${side(n.away, true)}</div>
      <div class="hm-foot"><div class="odds">${["主胜", "平", "客胜"].map((l, i) => `<div class="${i === fav ? "fav" : ""}">${l}<span class="num">${Math.round(o[i] * 100)}%</span>${bar(100, i === fav ? "#fff" : "#ffffff40")}</div>`).join("")}</div>
        <button class="btn" data-brief title="对手、我方风险、一项建议（对手阵容在简报里）">赛前简报</button><button class="btn pri" data-act="kickoff">${isMatchDay() ? "开始比赛" : "继续"}</button></div></div>`;
  } else {
    // M5-D-c：休赛期写今天与到 6/30 还有几天，可“过一天/继续”；到了 6/30 主按钮变“进入新赛季”（同样先打开赛季总结确认）
    const off = c.finished && offWalk(), end = c.finished && seasonEnd();
    const left = CAL ? Math.max(0, Math.round((new Date(+CAL.date.slice(0, 4), 5, 30) - parseD(CAL.date)) / 864e5)) : 0;
    const when = c.finished && CAL ? `<em class="hm-off">${dateTxt(parseD(CAL.date))} · ${end ? "赛季最后一天，明天 7 月 1 日新赛季开始" : `休赛期 · 还有 ${left} 天到 6 月 30 日`}</em>` : "";
    banner = `<div class="card hm-next done" style="--i:0;--hc:${tcolor(me())};--ac:${tcolor(me())}">
      <div class="ch">${c.finished ? "赛季已结束" : "暂无比赛"}</div>
      <div class="hm-vs one"><div class="hm-side me" data-team="${me()}">${crest(me(), "xl")}<div><b>${esc(tname(me()))}</b><small>${lgLogo()}${esc(c.league_name)} · 最终第 ${r.position || "—"} 名 · ${r.points ?? 0} 分</small>${form(r.form)}${when}</div></div></div>
      <div class="hm-foot">${c.finished ? `<button class="btn${off ? "" : " pri"}" data-act="review">${svg("season", 2)} ${end ? "进入新赛季" : "赛季总结"}</button>${off ? `<button class="btn pri" data-act="offgo">继续</button>` : ""}` : ""}</div></div>`;
  }
  // 6 个指标：无边框，每格 = 圆环（环内是图标）+ 数值；状态用环的填充表示，不再用条形和文字标签（名称放在 title 里）
  const lm = lastMine(), tiles = [], pl = r.played || 0, nTeams = (S.table || []).length || 20;
  const ringT = (cls, label, icon, pct, color, big, small, attrs = "", inner = "") => `<${attrs ? "button" : "div"} class="hm-t ${cls}" title="${esc(label)}" aria-label="${esc(label)}" ${attrs}><span class="ring" style="--v:${Math.max(0, Math.min(100, pct))};--c:${color}">${inner || svg(icon, 1.8)}</span><span class="hm-v">${big}${small ? `<small>${small}</small>` : ""}</span></${attrs ? "button" : "div"}>`;
  if (lm) { const rs = resultOf(lm), opp = lm.home === me() ? lm.away : lm.home, col = `var(--${rs === "W" ? "win" : rs === "L" ? "loss" : "draw"})`;
    tiles.push(ringT("last", `上一场 · 第 ${lm.round} 轮 · 点开看战报`, "", 100, col, `<span class="num">${lm.result.home_goals} : ${lm.result.away_goals}</span>`, `<i class="res ${rs}">${RES[rs]}</i>`, `data-fx="${lm.id}" data-sound="page"`, crest(opp, "sm")));
  } else tiles.push(ringT("last", "上一场", "ball", 0, "var(--ink3)", `<span class="num muted">—</span>`, "", ""));
  // 队内最佳射手（数据榜里我队的第一名）
  const top = st && st.scorers ? st.scorers.find((x) => (x.team == null ? me() : x.team) === me()) : null;
  const scorerTile = top ? `<button class="hm-t" data-player="${esc(top.pid || "")}" title="队内最佳射手 · ${esc(top.name)}"><span class="ring" style="--v:100;--c:var(--gold)">${pface(top)}</span><span class="hm-v"><span class="num">${top.n}</span><small>${esc(short(top.name))}</small></span></button>` : null;
  if (club) {
    const b = club.board || {}, net = club.season_net;
    // 短标签（体验评审 U05）：触摸没有悬停，圆环下补两个字的名称；完整名称仍在 title / aria-label
    const fitTxt = club.fitness >= 80 ? "体能" : club.fitness >= 65 ? "体能·留意" : "体能·轮换";
    tiles.push(ringT("", "平均体能", "bolt", club.fitness, "var(--blue)", `<span class="num" data-k="hm-fit" data-to="${club.fitness}">${club.fitness}%</span>`, fitTxt, `data-tab="squad:4" data-lbl`),
      ...(scorerTile ? [scorerTile] : [ringT("", "进球 / 失球", "ball", pl ? (r.gf || 0) / Math.max(1, (r.gf || 0) + (r.ga || 0)) * 100 : 0, "var(--win)", `<span class="num">${r.gf || 0} : ${r.ga || 0}</span>`, "进失球", "")]),
      ringT("", "球队士气", "smile", club.morale, "var(--win)", `<span class="num" data-k="hm-mor" data-to="${club.morale}">${club.morale}</span>`, "士气", `data-tab="squad:2" data-lbl`),
      ringT("", "董事会信任", "shield", b.trust, "var(--draw)", `<span class="num" data-k="hm-trust" data-to="${b.trust}">${b.trust}</span>`, "信任", `data-tab="home:3" data-lbl`),
      ringT("net", "本季收支", "coin", 100, net >= 0 ? "var(--win)" : "var(--loss)", `<span class="num ${net >= 0 ? "up" : "dn"}" data-k="hm-net" data-to="${net}">${net >= 0 ? "+" : "-"}${money(Math.abs(net))}</span>`, "收支", `data-tab="finance:0" data-lbl`));
  } else {
    tiles.push(ringT("", "进球 / 失球", "ball", pl ? (r.gf || 0) / Math.max(1, (r.gf || 0) + (r.ga || 0)) * 100 : 0, "var(--win)", `<span class="num">${r.gf || 0} : ${r.ga || 0}</span>`, "", ""));
    for (const f of (S.upcoming || []).slice(1, 4)) { const opp = f.home === me() ? f.away : f.home;
      tiles.push(ringT("", `第 ${f.round} 轮 · ${tname(opp)}`, "", 100, "var(--ink3)", `<span class="num">${f.home === me() ? "主" : "客"}</span>`, `第 ${f.round} 轮`, `data-team="${opp}"`, crest(opp, "sm"))); }
    while (tiles.length < 6) tiles.push(`<div class="hm-t"><span class="ring" style="--v:0"></span><span class="hm-v"><span class="num muted">—</span></span></div>`);
  }  if (club && tiles.length === 6) { const c0 = tiles.slice(); tiles.length = 0; [0, 3, 5, 1, 4, 2].forEach((i) => tiles.push(c0[i])); }   // 排成：上一场 士气 收支 / 体能 信任 射手
  const side = await hmSidePanel();
  return `<div class="view v-home2"><div class="hm-left">${banner}<div class="hm-tiles" style="--i:2">${tiles.join("")}${schBox}${injBox}</div></div>${side}</div>`;
}
/* ================= 球队 ================= */
// 同一队的并发请求共用一个 promise（主页一次会有多份示例数据同时要阵容）；失败不缓存
function team(tid, force) {
  if (!teamCache[tid] || force) teamCache[tid] = api(`/api/team/${tid}`).catch((e) => { delete teamCache[tid]; throw e; });
  return teamCache[tid];
}
// 阵型站位：按登记位置分线（门将/后卫/后腰/中场/前腰/前锋），同一线内左→右（屏幕上→下）均分。只表示球员的登记位置，不是比赛里的阵型。
const LINE = { GK: [0, 7], CB: [1, 23], LB: [1, 23], RB: [1, 23], DMF: [2, 39], CMF: [3, 53], LMF: [3, 53], RMF: [3, 53], AMF: [4, 68], LWF: [5, 86], RWF: [5, 86], SS: [5, 80], CF: [5, 86] };
const short = (n) => { const s = String(n || "").trim().split(/\s+/); return s.length > 1 && /^[\x00-ɏ]+$/.test(n) ? s[s.length - 1] : n; };
const SIDE = (p) => p[0] === "L" ? 0 : p[0] === "R" ? 2 : 1;
function layout(starters) {
  const lines = {};
  starters.forEach((p) => { const k = (LINE[p.position] || [3, 50])[0]; (lines[k] = lines[k] || []).push(p); });
  const out = [];
  for (const k of Object.keys(lines)) {
    const ps = lines[k].sort((a, b) => SIDE(a.position) - SIDE(b.position)), n = ps.length;
    ps.forEach((p, i) => out.push({ p, x: (LINE[p.position] || [3, 50])[1], y: n === 1 ? 50 : 16 + (68 * i) / (n - 1) }));
  }
  return out;
}
// 阵容页 = 战术板（2026-11-13）。阵型和谁踢哪个位置来自存档（GET /api/formation：站位坐标 + 槽位 → 球员），不再只按登记位置猜。
// 直接按住球员拖到另一名（首发或替补）身上松手互换位置（轻点仍是看详情），右上角下拉可换 23 个原生阵型；写存档，下一场比赛开始前宿主会把新阵容刷给游戏。
// 读不到 /api/formation（预览没有存档、旧宿主）就退回按登记位置排布、只读。
let simSequence = 0;
const simRequests = new Map();
function simDone(id, raw) {
  const resolve = simRequests.get(id); if (!resolve) return;
  simRequests.delete(id);
  try {
    const result = JSON.parse(raw);
    if (!result || (!result.ok && !result.reason) || result.reason === "exception") {
      resolve({ error: "数据暂时不可用", reason: "result-unknown" });
    } else resolve(result);
  } catch (e) { resolve({ error: "数据暂时不可用", reason: "result-unknown" }); }
}
async function post(path, body) {
  const h = host();
  if (path === "/api/sim" && h && h.simulateAsync) {
    const id = `sim-${Date.now()}-${++simSequence}`;
    return new Promise((resolve) => {
      simRequests.set(id, resolve);
      try {
        if (!h.simulateAsync(id)) { simRequests.delete(id); resolve({ error: "正在模拟比赛", reason: "busy" }); }
      } catch (e) {
        simRequests.delete(id); resolve({ error: "数据暂时不可用", reason: "result-unknown" });
      }
    }); // no timeout/retry: a delayed result must never simulate the next fixture
  }
  if (h && h.act) { try { return JSON.parse(h.act(path, JSON.stringify(body || {}))); } catch (e) { return { error: "数据暂时不可用", reason: "exception" }; } }
  const r = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
  return r.json().catch(() => ({}));
}
const FM_ERR = { busy: "正在进入比赛，稍后再调整", formation: "这个调整不行", "no-ml-profile": "还没有大师联赛存档" };
async function fmApply(path, body, done) {
  const r = await post(path, body);
  // 2026-11-18（用户：“现在这个自由摆位是用不了吗”）：宿主不认识这个操作时回 200 + {}（旧版本宿主 / 没重启的预览服务器），
  // 以前当成功、静悄悄弹回原位；成功一定带新的站位（spots），空回复按“这个版本不支持”提示。
  if (r && !r.error && !Array.isArray(r.spots) && !Object.keys(r).length) { toast("当前版本还不支持这个操作，请更新到最新版本后再试"); quietDraw = true; return draw(); }
  if (!r || r.error) { toast(r && /[一-龥]/.test(r.error || "") ? r.error : FM_ERR[r && r.reason] || (r && r.error) || "调整失败"); quietDraw = true; return draw(); }
  luDrop(); try { await team(me(), true); } catch (e) { /* 下次进页面会重取 */ }
  sound("ok"); quietDraw = true; draw();
}
// 拖动换位：按住球场上的球员（替补列表按住头像）拖到另一名球员上松手 = 互换位置。拖动中只动一个跟手的影子，不重画页面。
// 2026-11-15 用户：“做成拖动头像就可以拖动，而不是那个竖着的点”——替补行去掉 ⠿ 把手列，头像就是抓手；行的其它地方照常滑动列表 / 点开详情。
// 2026-11-18：预备队行（data-fmr = 卡 id）也能拖——拖到场上 / 替补球员身上 = 用这名预备队员换下他（/api/formation/substitute）；
// 反过来把场上 / 替补拖到预备队员身上也是同一个换人。预备队员之间不能互拖。
function fmDragBind(root) {
  $$("[data-fm], [data-fmr]", root).forEach((el) => {
    const grip = el.tagName === "TR" ? $(".pf", el) : el;          // 替补行只抓头像：列表本身还要能用手指滑动
    if (!grip) return;
    grip.addEventListener("dragstart", (e) => e.preventDefault());
    grip.addEventListener("pointerdown", (e) => {
      if (e.button) return;
      e.preventDefault();                                   // 不让浏览器开始拖图片 / 选文字
      if (fmFree && el.dataset.spot != null) return fmFreeDrag(e, el);   // 自由摆位模式：球场上的球员拖动 = 改站位坐标，不是互换
      const res = el.dataset.fmr != null, slot = res ? null : +el.dataset.fm, x0 = e.clientX, y0 = e.clientY; let ghost = null, over = null;
      const okTarget = (tg) => tg && tg !== el && (tg.dataset.fmr != null ? !res : !(slot != null && +tg.dataset.fm === slot));
      const move = (ev) => {
        if (!ghost) {
          if (Math.hypot(ev.clientX - x0, ev.clientY - y0) < 7) return;
          if (el.tagName === "TR") { ghost = document.createElement("div"); ghost.className = "fm-ghost"; ghost.innerHTML = ($(".pf", el) || el).outerHTML; }
          else { ghost = el.cloneNode(true); ghost.classList.remove("drag", "drop"); ghost.classList.add("fm-ghost"); ghost.style.left = "0"; ghost.style.top = "0"; }
          document.body.appendChild(ghost); el.classList.add("drag"); sound("cursor");
        }
        ghost.style.transform = `translate(${ev.clientX}px, ${ev.clientY}px) translate(-50%, -50%)`;
        const t = document.elementFromPoint(ev.clientX, ev.clientY), tg = t && t.closest ? t.closest("[data-fm], [data-fmr]") : null, ns = okTarget(tg) ? tg : null;
        if (over !== ns) { if (over) over.classList.remove("drop"); if (ns) ns.classList.add("drop"); over = ns; }
      };
      const end = () => {
        window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", end); window.removeEventListener("pointercancel", end);
        const moved = !!ghost, target = over;
        if (ghost) ghost.remove(); el.classList.remove("drag"); if (over) over.classList.remove("drop");
        if (moved) {                                          // 拖动结束后浏览器还会补一个 click：吞掉，免得弹出球员详情
          const stop = (ev) => { ev.stopPropagation(); ev.preventDefault(); };
          window.addEventListener("click", stop, { capture: true, once: true }); setTimeout(() => window.removeEventListener("click", stop, true), 120);
        }
        if (!moved || !target) return;
        if (res) fmApply("/api/formation/substitute", { slot: +target.dataset.fm, card: el.dataset.fmr }, "已换入");
        else if (target.dataset.fmr != null) fmApply("/api/formation/substitute", { slot, card: target.dataset.fmr }, "已换入");
        else fmSwap(slot, +target.dataset.fm);
      };
      window.addEventListener("pointermove", move); window.addEventListener("pointerup", end); window.addEventListener("pointercancel", end);
    });
  });
}
// 自由摆位（2026-11-17）：球场左上角“自由摆位”打开后，拖球场上的球员就是改他的站位坐标（角色不变），松手保存；关掉后拖动仍是互换。
// 屏幕 % → 游戏坐标是 fmPct 的反函数，并限制在原生阵型用到的范围内（纵深 3..43、横向 12..92），球员拖不出球场。
let fmFree = false;
const FM_X = [8, 43], FM_Y = [12, 92];                    // 场上球员不进小禁区（原生后卫最深 11）；门将不能动
const FM_BACK = 17, FM_MID = 36;                           // 纵深分区：≤17 后卫线、18..36 中场、更前为锋线（原生后卫 11..15、中场 19..34、锋线 39 起）
function fmZones(xs) { return [xs.filter((x) => x <= FM_BACK).length, xs.filter((x) => x > FM_BACK && x <= FM_MID).length]; }
// 后卫线、中场各至少两人；已经不足的只要不更糟就允许（便于修回来）。与服务端 iml_formation.set_spot 一致。
function fmLineErr(spot, nx) {
  const sp = ((lastFm && lastFm.spots) || []).filter((s) => s.role !== "GK");
  const b = fmZones(sp.map((s) => s.x)), a = fmZones(sp.map((s) => s.spot === spot ? nx : s.x));
  if (a[0] < 2 && a[0] < b[0]) return "后卫线最少要有两个人";
  if (a[1] < 2 && a[1] < b[1]) return "中场最少要有两个人";
  return "";
}
const fmGame = (px, py) => ({
  x: Math.max(FM_X[0], Math.min(FM_X[1], Math.round(52 - py / 100 * 54))),
  y: Math.max(FM_Y[0], Math.min(FM_Y[1], Math.round((px / 100 - .5) * 107.4 + 52))),
});
function fmFreeDrag(e, el) {
  const field = el.closest(".pf-field"); if (!field) return;
  const x0 = e.clientX, y0 = e.clientY, spot = +el.dataset.spot; let moved = false, g = null;
  const me0 = ((lastFm && lastFm.spots) || []).find((s) => s.spot === spot);
  if (me0 && me0.role === "GK") {                                // 门将的位置不能动：拖一下只提示，不改任何东西
    const tip = () => { window.removeEventListener("pointerup", tip); toast("门将的位置不能移动"); };
    window.addEventListener("pointerup", tip); return;
  }
  const move = (ev) => {
    if (!moved) { if (Math.hypot(ev.clientX - x0, ev.clientY - y0) < 7) return; moved = true; el.classList.add("mv"); sound("cursor"); }
    const r = field.getBoundingClientRect();
    g = fmGame((ev.clientX - r.left) / r.width * 100, (ev.clientY - r.top) / r.height * 100);
    const q = fmPct({ x: g.x, y: g.y });                          // 吸回合法范围内再显示，所见即所存
    el.style.left = q.x + "%"; el.style.top = q.y + "%";
  };
  const end = () => {
    window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", end); window.removeEventListener("pointercancel", end);
    el.classList.remove("mv");
    if (!moved) return;
    const stop = (ev) => { ev.stopPropagation(); ev.preventDefault(); };
    window.addEventListener("click", stop, { capture: true, once: true }); setTimeout(() => window.removeEventListener("click", stop, true), 120);
    const err = g ? fmLineErr(spot, g.x) : "";
    if (err) { toast(err); sound("ng"); quietDraw = true; return draw(); }     // 不合规：弹回原位
    if (g) fmApply("/api/formation/spot", { spot, x: g.x, y: g.y }, "站位已改，下一场比赛起生效");
  };
  window.addEventListener("pointermove", move); window.addEventListener("pointerup", end); window.addEventListener("pointercancel", end);
}
// 还原预设：摆位会连带改位置（角色），所以回到“自定义之前的原生阵型”——宿主在 base 里记着；当前正是某个原生阵型就还原它自己。
function fmRestore() {
  const fm = lastFm; if (!fm) return;
  const idx = fm.preset != null ? fm.preset : fm.base;
  if (idx == null) return toast("找不到之前的预设阵型，请点阵型按钮重新选择");
  fmApply("/api/formation/preset", { index: idx }, "已还原预设站位，下一场比赛起生效");
}
function fmSwap(a, b) {
  const bench = (s) => { const r = document.querySelector(`tr[data-fm="${s}"]`); return !!r; };
  if (bench(a) && bench(b)) return toast("两名替补互换不会改变场上");
  fmApply("/api/formation/swap", { a, b }, "已互换，下一场比赛起生效");
}
// 阵型选择（2026-11-13）：点阵容页右上角的阵型按钮弹出窗口，每个阵型一张带站位示意图的卡片，点一张就换。
// 示意图优先用宿主给的原生站位（presets[i].spots：{role,x,y}，x 3..43 纵深、y 12..92 横向）；旧宿主没给就按名字里的数字（4-2-3-1）分线画。
let lastFm = null;
const FM_GRP = { GK: "g", CB: "d", LB: "d", RB: "d", DMF: "m", CMF: "m", LMF: "m", RMF: "m", AMF: "m", LWF: "f", RWF: "f", SS: "f", CF: "f" };
// 游戏站位坐标 → 屏幕（2026-11-15 真机校准，outputs/runs/20261115-ML-formation-calib/CALIB.md）：
// 原生战术页把阵型画在“竖着的本方半场”里——底边本方球门线、顶边中线（中圈圆心在顶边），横竖等比约 22px/米。
// 用主存档一套手调阵容的 11 个原始坐标对照卡片中心：横向 52 = 中线、两条边线 ≈ −1.7 / 105.7（每单位 0.63 米）；
// 纵深本方球门线 ≈ −2、中线 ≈ 52（每单位 1.08 米）。所以中锋 43 站在中圈下方、门将 3 贴着小禁区——与游戏一致。
// 返回 x = 距左边线 %，y = 距顶边（中线）%；阵容页大球场和阵型缩略图共用。
const PW = 68, PH = 58;                                    // 画出来的半场：宽 68 米 × 长 58 米（游戏图的实测长宽比）
const fmPct = (s) => ({ x: Math.max(0, Math.min(100, ((s.y - 52) / 107.4 + .5) * 100)), y: Math.max(0, Math.min(100, (52 - s.x) / 54 * 100)) });
// 半场球场线（单位：米）：禁区 40.32×16.5、小禁区 18.32×5.5、点球点 11、中圈/罚球弧半径 9.15、球门 7.32
function pitchLines(cls) {
  const c = PW / 2, g = PH, box = (w, d) => `<path d="M${c - w / 2} ${g}V${g - d}H${c + w / 2}V${g}"/>`;
  const dx = Math.sqrt(9.15 ** 2 - 5.5 ** 2);
  return `<g class="${cls}"><rect x="0" y="0" width="${PW}" height="${PH}"/>`
    + `<path d="M${c - 9.15} 0A9.15 9.15 0 0 0 ${c + 9.15} 0"/><circle cx="${c}" cy="0" r=".5" class="dot"/>`
    + box(40.32, 16.5) + box(18.32, 5.5) + `<circle cx="${c}" cy="${g - 11}" r=".5" class="dot"/>`
    + `<path d="M${(c - dx).toFixed(2)} ${g - 16.5}A9.15 9.15 0 0 1 ${(c + dx).toFixed(2)} ${g - 16.5}"/>`
    + `<path d="M${c - 3.66} ${g}V${g + 1.8}H${c + 3.66}V${g}" class="goal"/></g>`;
}
function fmDots(p) {
  if (Array.isArray(p.spots) && p.spots.length) return p.spots.map((s) => { const q = fmPct(s); return { x: q.x / 100, y: q.y / 100, g: FM_GRP[s.role] || "m" }; });
  const ln = String(p.name || "").replace(/（.*?）/g, "").split("-").map(Number).filter((n) => n > 0), out = [{ x: .5, y: .9, g: "g" }];
  ln.forEach((n, i) => { for (let k = 0; k < n; k++) out.push({ y: .72 - i / Math.max(1, ln.length - 1) * .56, x: n === 1 ? .5 : .14 + .72 * k / (n - 1), g: i === 0 ? "d" : i === ln.length - 1 ? "f" : "m" }); });
  return out;
}
function fmDiagram(p, cls = "") {
  const dots = fmDots(p).map((d) => `<circle cx="${(d.x * PW).toFixed(1)}" cy="${(d.y * PH).toFixed(1)}" r="3" class="fd-${d.g}"/>`).join("");
  return `<svg class="fm-dia ${cls}" viewBox="-3 -3 ${PW + 6} ${PH + 6}" aria-hidden="true">${pitchLines("fd-line")}${dots}</svg>`;
}
function fmPicker() {
  const fm = lastFm; if (!fm || !$(".main")) return;
  $$(".fm-pop").forEach((e) => e.remove());
  const pop = document.createElement("div"); pop.className = "fm-pop";
  pop.innerHTML = `<div class="fm-box" role="dialog" aria-label="选择阵型"><div class="fm-head"><b>选择阵型</b><span>当前：${esc(fm.name)} · 下一场比赛起生效</span><button class="fm-x" aria-label="关闭">×</button></div>
    <div class="fm-grid scroll">${fm.presets.map((x) => `<button class="fm-card${x.index === fm.preset ? " on" : ""}" data-pidx="${x.index}">${fmDiagram(x)}<b>${esc(x.name)}</b>${x.index === fm.preset ? "<i>当前</i>" : ""}</button>`).join("")}</div>
    <div class="fm-key"><u class="fd-g"></u>门将<u class="fd-d"></u>后卫<u class="fd-m"></u>中场<u class="fd-f"></u>前锋</div></div>`;
  const esc2 = (e) => { if (e.key === "Escape") close(); }, close = () => { document.removeEventListener("keydown", esc2); pop.remove(); };
  pop.addEventListener("click", (e) => { if (e.target === pop || e.target.closest(".fm-x")) return close();
    const c = e.target.closest(".fm-card"); if (!c) return; close();
    if (+c.dataset.pidx === fm.preset) return; fmApply("/api/formation/preset", { index: +c.dataset.pidx }, "已换阵型，下一场比赛起生效"); });
  document.addEventListener("keydown", esc2); $(".main").appendChild(pop);
}
// 对手难度（2026-11-13 用户：“对手难度是实时下发的吗？可以在菜单里面加一个难度选项”）：放在左下角“设置”页里（见 openSettings），不放阵容页。
// 每次开赛游戏都会向服务端要一次对手，回包里的 cpu_level 就是这场的难度；默认（自动）跟随游戏里“AI 对战”的段位（新存档是最低档），
// 手选后固定用选的档，下一场开赛起生效；已经开球的比赛不变。7 档为游戏原生档位（引擎怎么用它不在我们控制内）。
// 档位名按游戏原生（eFootball 的 CPU 难度七档）：VERYEASY 新手 / EASY 业余 / NORMAL 普通 / HARD 职业 / VERYHARD 顶尖球员 / HARDEST 超级巨星 / LEGEND 传奇。
// “顶尖球员 / 超级巨星 / 传奇 / 职业”来自项目 E103/E120 对游戏界面的记录；最低三档按用户确认：新手 / 业余 / 普通。
const DF = { VERYEASY: ["新手"], EASY: ["业余"], NORMAL: ["普通"], HARD: ["职业"], VERYHARD: ["顶尖球员"], HARDEST: ["超级巨星"], LEGEND: ["传奇"] };
const dfName = (k) => (DF[k] || [k])[0];
const dfBars = (k) => { const n = Math.max(0, Object.keys(DF).indexOf(k)) + 1; return `<svg class="df-bars" viewBox="0 0 28 16" aria-hidden="true">${[0, 1, 2, 3, 4, 5, 6].map((i) => `<rect x="${i * 4}" y="${15 - 2 - i * 2}" width="3" height="${2 + i * 2}" class="${i < n ? "on" : ""}"/>`).join("")}</svg>`; };
const dfLabel = (df) => df.level === "AUTO" ? `自动（${dfName(df.auto)}）` : dfName(df.level);
function dfRows(df) {
  const opts = [["AUTO", df.level === "AUTO" ? `自动（${dfName(df.auto)}）` : "自动"], ...df.levels.map((k) => [k, dfName(k)])];
  return opts.map(([k, n]) => `<button class="df-row${k === df.level ? " on" : ""}" data-df="${k}">${k === "AUTO" ? `<i class="df-auto">A</i>` : dfBars(k)}<b>${esc(n)}</b>${k === df.level ? `<span class="df-ck">${svg("check", 2.4)}</span>` : ""}</button>`).join("");
}
// 存档里的站位坐标坏了（全挤在同一点 / 缺失 / 不是数字）时，球员会全叠在球场中心。检测到就按“角色”从原生阵型里借坐标仅用于显示
// （选了阵型或换位后会写回正常坐标）：优先角色组成相同的阵型，其次 4-2-3-1。
function fmRepairSpots(fm) {
  const good = (a) => a.length >= 11 && a.every((s) => Number.isFinite(+s.x) && Number.isFinite(+s.y) && s.x !== null && s.y !== null)
    && new Set(a.map((s) => (+s.x) + "," + (+s.y))).size >= 8;
  if (good(fm.spots)) return fm;
  const sig = (a) => a.map((s) => s.role).sort().join(",");
  const ps = Array.isArray(fm.presets) ? fm.presets.filter((p) => p.spots && p.spots.length === fm.spots.length) : [];
  if (!ps.length) return fm;
  const pr = ps.find((p) => sig(p.spots) === sig(fm.spots)) || ps.find((p) => p.name === "4-2-3-1") || ps[0];
  const pool = pr.spots.map((s) => ({ ...s, used: false }));
  const spots = fm.spots.map((s) => {
    const hit = pool.find((q) => !q.used && q.role === s.role) || pool.find((q) => !q.used);
    hit.used = true;
    return { ...s, x: hit.x, y: hit.y };
  });
  return { ...fm, spots, repaired: true };
}
let lnSort = "ovr";                                       // 阵容页右侧替补 / 预备队表的排序：ovr 能力 / pos 位置
async function viewLineup() {
  const t = await team(me());
  let fm = null; try { fm = await api("/api/formation"); if (!fm || fm.error || !Array.isArray(fm.spots)) fm = null; } catch (e) { fm = null; }
  if (fm) fm = fmRepairSpots(fm);
  const lu = fm ? await biz("lineup").catch(() => null) : null;       // M6-F2 阵容助手（推荐 / 上一场 / 轮换）；取不到就不显示按钮
  const bySlot = new Map(t.squad.map((p) => [p.slot, p]));
  const starters = t.squad.filter((p) => p.starter), bench = t.squad.filter((p) => !p.starter);
  const avg = starters.length ? Math.round(starters.reduce((a, p) => a + (p.overall || 0), 0) / starters.length) : 0;
  // 站位坐标：和游戏战术页一样竖着画本方半场（球门在下、中线在上，左路在左），换算见 fmPct。
  // 读不到存档阵型时按登记位置分线：layout 的 x 7..86 / y 16..84 先折回游戏坐标（纵深 3..43、横向 12..92）再换算。
  const spots = fm ? fm.spots.map((s) => ({ p: bySlot.get(s.slot), ...fmPct(s), role: s.role, slot: s.slot, spot: s.spot })).filter((o) => o.p)
    : layout(starters).map((o) => ({ p: o.p, ...fmPct({ x: 3 + (o.x - 7) / 79 * 40, y: 12 + (o.y - 16) / 68 * 80 }), role: "", slot: o.p.slot }));
  const edit = !!fm;                       // 有存档阵型就一直可拖（轻点仍是看详情，拖动超过 7px 才算换位）
  const att = (p, slot, spot) => edit ? `data-player="${p.pid}" data-fm="${slot}"${spot != null ? ` data-spot="${spot}"` : ""}` : `data-player="${p.pid}"`;
  // 2026-11-13：球员小头像（游戏自带缩略图，宿主 /img/player/<pid>.png）；能力值缩成头像右下角小角标。读不到头像就退回原来的能力值方块。
  const toks = spots.map((o, i) => `<div class="tok face tg-${grp(o.role || o.p.position)}${edit ? " edit" : ""}"style="left:${o.x}%;top:${o.y}%;--d:${i}" title="${esc(o.p.name)}" ${att(o.p, o.slot, o.spot)}><i class="fc"><img src="/img/player/${encodeURIComponent(o.p.pid)}.png" alt="" draggable="false" onerror="this.closest('.tok').classList.remove('face')">${edit && o.role ? `<em class="rl${o.role !== o.p.position ? " off" : ""}">${esc(o.role)}</em>` : ""}${ovr(o.p.overall)}</i><span>${esc(short(o.p.name))}</span></div>`).join("");
  // 2026-11-18 用户：“右边可以放一些预备队的球员，能直接选择预备队球员放进来…不要显示出场和进球，改为能力值排序和位置排序，显示士气和状态”：
  // 右侧一张表两段（替补 / 预备队），列＝位置 · 球员 · 能力 · 状态（本场 A~E，开赛前定）· 士气；点“位置”“能力”表头排序。
  // 预备队行：“换入”按钮（先给建议换下谁，同 58-lineup mkSubstitute），或按住头像拖到场上 / 替补球员身上直接换入；场上 / 替补拖到预备队员身上也一样。
  const [sqx, frm] = await Promise.all([biz("squad").catch(() => null), api("/api/form").catch(() => null)]);
  const moraleOf = (p) => { const b = sqx && !sqx.demo && sqx.players ? sqx.players[String(p.pid)] : null; return b && b.morale != null ? b.morale : null; };
  const gradeOf = new Map(((frm && Array.isArray(frm.players)) ? frm.players : []).map((r) => [String(r.pid), r.grade]));
  const POS_ORDER = ["GK", "CB", "LB", "RB", "DMF", "CMF", "LMF", "RMF", "AMF", "LWF", "RWF", "SS", "CF"];
  const posIdx = (p) => { const i = POS_ORDER.indexOf(p.position); return i < 0 ? 99 : i; };
  // 用户追加：“状态和士气也可以排序吧”——状态 A→E（还没定的排后面），士气 高→低（没有数据的排后面）；同值再按能力
  const byOvr = (a, b) => (b.overall || 0) - (a.overall || 0) || posIdx(a) - posIdx(b);
  const gIdx = (p) => { const i = "ABCDE".indexOf(gradeOf.get(String(p.pid)) || "?"); return i < 0 ? 9 : i; };
  const mVal = (p) => { const m = moraleOf(p); return m == null ? -1 : m; };
  const lnCmp = { pos: (a, b) => posIdx(a) - posIdx(b) || byOvr(a, b), form: (a, b) => gIdx(a) - gIdx(b) || byOvr(a, b),
    mor: (a, b) => mVal(b) - mVal(a) || byOvr(a, b) }[lnSort] || byOvr;
  const cells = (p) => { const g = gradeOf.get(String(p.pid)), m = moraleOf(p);
    return `<td class="n">${ovr(p.overall)}</td><td class="n">${g ? `<b class="ln-grade num" style="color:${GRADE_C[g] || "var(--ink)"}">${esc(g)}</b>` : `<span class="muted">—</span>`}</td>
      <td class="n">${m == null ? `<span class="muted">—</span>` : `<b class="ln-mor num" style="color:${gaugeColor(m)}">${Math.round(m)}</b>`}</td>`; };
  const rows = [...bench].sort(lnCmp).map((p) => `<tr class="go-row${edit ? " fmb-row" : ""}" ${att(p, p.slot)}><td>${pos(p.position, p.group)}</td><td class="name">${pface(p, edit ? "fm-h" : "")}<b>${esc(p.name)}</b></td>${cells(p)}</tr>`).join("");
  const rsv = [...t.reserve].sort(lnCmp).map((p) => `<tr class="go-row fmr-row" data-player="${p.pid}"${edit ? ` data-fmr="${p.pid}"` : ""}><td>${pos(p.position, p.group)}</td>
    <td class="name">${pface(p, edit ? "fm-h" : "")}<b>${esc(p.name)}</b>${edit ? `<button class="btn sm ln-in" data-ln-in="${p.pid}" title="换入 23 人名单（先选换下谁）">换入</button>` : ""}</td>${cells(p)}</tr>`).join("");
  const sortTh = (k, label, cls = "") => `<th class="${cls}${cls ? " " : ""}ln-sort${lnSort === k ? " on" : ""}" data-ln-sort="${k}" role="button" title="按${label}排序">${label}${lnSort === k ? " ↓" : ""}</th>`;
  const sec = (label, n, hint) => `<tr class="ln-sec"><td colspan="5"><b>${label}</b><i>${n}</i>${hint ? `<small>${hint}</small>` : ""}</td></tr>`;
  lastFm = fm;
  const curP = fm && fm.presets.find((x) => x.index === fm.preset);
  // 2026-11-18 用户：“把阵型、自由摆位、阵容助手都放到阵容的右上角吧，用一些小的图案去表示就好了，不要用文字了。这样右边就可以空出更多的空间”——
  // 球场右上角一排小图标按钮（名字只在悬停提示 / 读屏里）：阵型＝当前阵型的小示意图，自由摆位＝四向箭头（开着时变 ✓ 完成），还原预设＝撤回箭头（只在摆位时），阵容助手＝魔杖（带轮换建议数）。右侧表不再有卡头。
  const PT = (d) => `<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
  const IC_MOVE = PT(`<path d="M10 2.5v15M2.5 10h15M10 2.5 7.6 4.9M10 2.5l2.4 2.4M10 17.5l-2.4-2.4M10 17.5l2.4-2.4M2.5 10l2.4-2.4M2.5 10l2.4 2.4M17.5 10l-2.4-2.4M17.5 10l-2.4 2.4"/>`);
  const IC_DONE = PT(`<path d="M4 10.5l4 4 8-9"/>`);
  const IC_UNDO = PT(`<path d="M5.5 7.5H12a4.5 4.5 0 0 1 0 9H8"/><path d="M8.5 4.5l-3 3 3 3"/>`);
  const IC_WAND = PT(`<path d="M4 16 13.5 6.5"/><path d="M12 5l3 3"/><path d="M15.5 2.5v2.5M14.25 3.75h2.5M5.5 3v2M4.5 4h2M16.5 11v2M15.5 12h2"/>`);
  const fmName = fm ? `阵型 ${fm.name} · 点击更换` : "";
  // 还原预设放在摆位键左边：这一排靠右对齐，放右边会把摆位键挤走，再点一下就误点成“还原预设”
  const ptools = !fm ? "" : `<button class="pt-btn pt-fm" data-fm-open title="${esc(fmName)}" aria-label="${esc(fmName)}">${fmDiagram(curP || { name: fm.name })}</button>`
    + (fmFree ? `<button class="pt-btn" data-fm-restore title="还原预设" aria-label="还原预设">${IC_UNDO}</button>` : "")
    + `<button class="pt-btn${fmFree ? " on" : ""}" data-fm-free aria-pressed="${fmFree}" title="${fmFree ? "完成摆位" : "自由摆位"}" aria-label="${fmFree ? "完成摆位" : "自由摆位"}">${fmFree ? IC_DONE : IC_MOVE}</button>`
    + (luOk(lu) ? `<button class="pt-btn" data-lu-assist title="阵容助手：推荐阵容 / 上一场阵容 / 轮换建议" aria-label="阵容助手">${IC_WAND}${lu.rotation.length ? `<b class="pt-n">${lu.rotation.length}</b>` : ""}</button>` : "");
  // 2026-11-13 重构：球场占满左侧整张卡（去掉原来占一行高度的卡头），阵型下拉移到右侧替补卡的卡头、平均能力做成球场左上角小标。
  // 2026-11-15：照游戏战术页画竖着的本方半场（.pf-field 68:58，容器查询定尺寸、四周留出半个标记的余量），球员与球场线共用同一坐标。
  return `<div class="view v-lineup">
    <div class="card pitch-card" style="--i:0"><div class="pitch pv">
      <div class="pitch-avg">平均能力 <b class="num">${avg || "—"}</b></div>
      ${edit ? `<div class="pitch-tools">${ptools}</div>${fmFree ? `<div class="pitch-hint">拖动球员到想要的位置</div>` : ""}` : ""}
      <div class="pf-field"><svg class="pf-lines" viewBox="0 0 ${PW} ${PH}" preserveAspectRatio="none" aria-hidden="true">${pitchLines("pl")}</svg>${toks}</div>
      <div class="pitch-dir" aria-hidden="true">进攻方向 ↑</div></div></div>
    <div class="card bench-card" style="--i:1">
      <div class="cb scroll">${rows || rsv ? `<table class="ln-table"><thead><tr>${sortTh("pos", "位置")}<th>球员</th>${sortTh("ovr", "能力", "n")}${sortTh("form", "状态", "n")}${sortTh("mor", "士气", "n")}</tr></thead>
        <tbody>${sec("替补", bench.length)}${rows || `<tr><td colspan="5" class="muted">没有替补</td></tr>`}${t.reserve.length ? sec("预备队", t.reserve.length, edit ? "点“换入”或拖头像到场上 / 替补身上" : "") + rsv : ""}</tbody></table>` : `<div class="empty-note">没有替补</div>`}</div></div></div>`;
}
// 列表里的球员小头像（2026-11-13）：宿主 /img/player/<pid>.png；读不到就只留一个灰圆，名字照样对齐
// 没有 pid（示例/外部球员：市场、青训）或读不到头像时，.pf 的底图是一个人形剪影，所以每个有球员的地方都有统一的圆头像位。
// 2026-11-14：不再直接写 src——交给 00-core 的头像队列（滚到屏幕附近才加载、同时最多 2 张、读不到就移除）
// p.face（战报里电脑队球员）＝他所在俱乐部真正出场的那张卡的 id：头像用它，而不是 pid（原生球员 id，会显示成原生头像）
const pface = (p, cls = "") => { const id = p && (p.face || p.pid); return `<i class="pf${cls ? " " + cls : ""}">${id ? `<img data-face="${esc(id)}" alt="">` : ""}</i>`; };
// 可点的头像 / 整行（2026-11-15 用户：“榜单、转会市场、联赛球员的头像点不进去”）：pgo 给元素加上 data-player，bindPage 点开球员页。
// tid＝球员所在队（我队→球员详情，他队→球探报告，"free"→自由球员）；kind "g"/"a" + n＝榜单里已有的本季进球 / 助攻
const pgo = (p, tid, kind, n) => p && p.pid ? ` data-player="${esc(p.pid)}"${tid === "free" ? ` data-pfree="1"` : tid != null ? ` data-pteam="${esc(tid)}"` : ""}${kind === "g" ? ` data-pg="${+n || 0}"` : kind === "a" ? ` data-pa="${+n || 0}"` : ""}` : "";
const pfaceGo = (p, tid, cls = "", kind, n) => `<i class="pf pf-go${cls ? " " + cls : ""}"${pgo(p, tid, kind, n)}>${p && p.pid ? `<img data-face="${esc(p.pid)}" alt="">` : ""}</i>`;
let pgroup = "全部";
async function viewPlayers() {
  const t = await team(me());
  const all = [...t.squad.map((p) => ({ ...p, st: p.starter ? "首发" : "替补" })), ...t.reserve.map((p) => ({ ...p, st: "预备" }))];
  const list = all.filter((p) => pgroup === "全部" || p.group === pgroup);
  const mkd = await biz("market"), canTrade = !!(mkd && !mkd.demo);        // 转会市场是真数据：预备队球员可以上阵 / 出售
  const rows = list.map((p) => `<tr class="go-row${p.st === "预备" ? " dim" : ""}" data-player="${p.pid}"><td>${pos(p.position, p.group)}</td><td class="name">${pface(p)}<b>${esc(p.name)}</b>${p.kind ? ` <span class="muted fs-s">${esc(p.kind)}</span>` : ""}</td><td class="n">${ovr(p.overall)}</td><td class="n muted">${p.level != null ? `${p.level}/${p.level_limit ?? "—"}` : "—"}</td><td class="n">${p.apps}</td><td class="n">${p.goals}</td><td class="n">${p.assists}</td><td class="c" style="font-size:11px;color:${p.st === "首发" ? "#fff" : "var(--ink3)"}">${p.st}</td>${canTrade ? `<td class="c">${p.st === "预备" ? `<button class="btn sm pri" data-sub="${p.pid}">上阵</button> <button class="btn sm" data-sellp="${p.pid}">出售</button>` : `<button class="btn sm" data-sellp="${p.pid}">出售</button>`}</td>` : ""}</tr>`).join("");
  return `<div class="view" style="grid-template-columns:minmax(0,1fr)"><div class="card">
    <div class="ch">全部球员<span class="r">${all.length} 人</span></div>
    <div style="display:flex;gap:5px;padding:0 10px 6px">${["全部", "GK", "DF", "MF", "FW"].map((g) => `<button class="chip${pgroup === g ? " on" : ""}" data-pgroup="${g}">${g}</button>`).join("")}</div>
    <div class="cb scroll"><table><thead><tr><th>位置</th><th>球员</th><th class="n">能力</th><th class="n">等级</th><th class="n">出场</th><th class="n">进球</th><th class="n">助攻</th><th class="c">状态</th>${canTrade ? `<th class="c"></th>` : ""}</tr></thead><tbody>${rows}</tbody></table></div></div></div>`;
}

/* ================= 赛季 ================= */
async function history(force) { if (!H || force) H = await api("/api/history"); return H; }
// E323 升降级：积分榜行带 zone（up / down），表下一行图例（服务端 iml_promotion.zones；德甲没有次级联赛，不显示）
// 2026-11-17：另有 ucl / uel（前 N 名进下赛季欧冠 / 前 N+M 名进欧联，iml_europe.SLOTS）；第 1 赛季没有上赛季排名，欧战名单按实力定（欧战页写明）。
const zoneKey = (z) => z && (z.up || z.down || z.ucl || z.uel) ? `<div class="zone-key">${z.ucl ? `<span class="zk-ucl"><i></i>前 ${z.ucl} 名进欧冠</span>` : ""}${z.uel ? `<span class="zk-uel"><i></i>接下来 ${z.uel} 名进欧联</span>` : ""}${z.up ?`<span class="zk-up"><i></i>前 ${z.up} 名升入${esc(z.up_name || "顶级联赛")}</span>` : ""}${z.down ? `<span class="zk-down"><i></i>后 ${z.down} 名降入${esc(z.down_name || "次级联赛")}</span>` : ""}</div>` : "";
async function viewTable() {
  const h = await history();
  const rows = (S.table || []).map((x, i, a) => `<tr class="go-row${x.team === me() ? " me" : ""}${x.zone ? ` z-${x.zone}` : ""}" data-team="${x.team}"><td class="muted">${x.position}</td><td class="name"><span class="tn">${crest(x.team, "sm")}<span style="font-weight:${x.team === me() ? 800 : 500}">${esc(tname(x.team))}</span></span></td><td class="n">${x.played}</td><td class="n">${x.won}</td><td class="n">${x.drawn}</td><td class="n">${x.lost}</td><td class="n">${x.gf}:${x.ga}</td><td class="n">${x.gd > 0 ? "+" : ""}${x.gd}</td><td class="n"><span class="num">${x.points}</span></td><td>${form(x.form)}</td></tr>`).join("");
  const mine = [];
  for (const r of [...h.rounds].reverse()) for (const f of r.fixtures) if (isMine(f) && f.result) mine.push(f);
  const played = mine.slice(-4).map((f) => { const opp = f.home === me() ? f.away : f.home, rs = resultOf(f);
    return `<div class="fxl" data-fx="${f.id}" data-sound="page"><span class="fs-s">第${f.round}轮</span>${crest(opp, "sm")}<span>${esc(tname(opp))}</span><span class="num" style="color:var(--${rs === "W" ? "win" : rs === "L" ? "loss" : "draw"})">${f.result.home_goals}:${f.result.away_goals}</span></div>`; });
  const next = (S.upcoming || []).map((f, i) => { const opp = f.home === me() ? f.away : f.home;
    return `<div class="fxl ${i === 0 ? "next" : "later"}" data-team="${opp}"><span class="fs-s">第${f.round}轮</span>${crest(opp, "sm")}<span>${esc(tname(opp))}</span><span class="ha${f.home === me() ? " h" : ""}">${f.home === me() ? "主" : "客"}</span></div>`; });
  return `<div class="view v-table">
    <div class="card" style="--i:0"><div class="cb scroll" style="padding-top:0" id="tablebox"><table><thead><tr><th>#</th><th>球队</th><th class="n">赛</th><th class="n">胜</th><th class="n">平</th><th class="n">负</th><th class="n">进:失</th><th class="n">净</th><th class="n">分</th><th>近况</th></tr></thead><tbody>${rows}</tbody></table>${zoneKey((S.career || {}).zones)}</div></div>
    <div class="card" style="--i:1"><div class="ch">我的赛程<span class="r">第 ${S.career.current_round} / ${S.career.rounds_total} 轮</span></div><div class="cb scroll">${played.join("") + next.join("") || `<div class="empty-note">没有赛程</div>`}</div></div></div>`;
}
let histRound = null;
function matchRows(fixtures) {
  return fixtures.map((f) => `<div class="mrow${isMine(f) ? " mine" : ""}" data-fx="${f.id}" data-sound="page"><span>${esc(tname(f.home))}</span>${crest(f.home, "sm")}<span class="sc">${f.result ? `${f.result.home_goals} - ${f.result.away_goals}` : "vs"}</span>${crest(f.away, "sm")}<span>${esc(tname(f.away))}</span></div>`).join("");
}
async function viewHistory() {
  const h = await history();
  if (!h.rounds.length) return `<div class="view"><div class="card"><div class="empty-note">还没有赛果</div></div></div>`;
  if (histRound == null || !h.rounds.some((r) => r.round === histRound)) histRound = h.rounds[0].round;
  const r = h.rounds.find((x) => x.round === histRound);
  const list = h.rounds.map((x) => { const m = x.fixtures.find(isMine); const rs = m && m.result ? resultOf(m) : null;
    return `<button class="rnd${x.round === histRound ? " on" : ""}" data-round="${x.round}">第 ${x.round} 轮${rs ? `<i class="res ${rs}">${RES[rs]}</i>` : ""}</button>`; }).join("");
  return `<div class="view v-hist"><div class="card scroll" style="--i:0;padding:4px 0">${list}</div>
    <div class="card" style="--i:1"><div class="ch">第 ${r.round} 轮 · 全部比赛<span class="r">点比赛看战报</span></div><div class="cb scroll">${matchRows(r.fixtures)}</div></div></div>`;
}
let repSel = null;
async function viewReports() {
  const h = await history(), mine = [];
  for (const r of h.rounds) for (const f of r.fixtures) if (isMine(f) && f.result) mine.push(f);
  if (!mine.length) return `<div class="view"><div class="card"><div class="empty-note">踢完第一场后这里会有战报</div></div></div>`;
  if (!repSel || !mine.some((f) => f.id === repSel)) repSel = mine[0].id;
  // 2026-11-15 战报改版（用户图例）：最左一列只有对手队徽 + 比分，没有文字
  const list = mine.map((f) => { const opp = f.home === me() ? f.away : f.home, rs = resultOf(f);
    return `<button class="rp-mini${f.id === repSel ? " on" : ""}" data-rep="${f.id}" title="第${f.round}轮 ${esc(tname(opp))}" aria-label="第${f.round}轮 ${esc(tname(opp))} ${f.result.home_goals}:${f.result.away_goals}">${crest(opp, "sm")}<i class="res ${rs}">${f.result.home_goals}:${f.result.away_goals}</i></button>`; }).join("");
  const f = await fixture(repSel);
  // M7-G4：本轮变化（新伤 / 月度成长 / 半季评估 / 转会 / 收支，只列真实发生的）；宽度 ≤ 800 时左侧轮次列表收成顶部下拉（CSS 切换，见 .rep-pick）
  const chg = await biz("changes").catch(() => null), cr = chg && chg.rounds ? chg.rounds[String(f.round)] : null;
  const CHG = { injury: ["新伤", "med"], growth: ["成长", "up"], form: ["半季评估", "star"], deal: ["转会", "transfer"], money: ["收支", "coin"] };
  const strip = cr ? (cr.empty ? ""                                             // 没有变化就不占一行（2026-11-15 战报改版）
    : `<div class="rp-chg${repChgOpen ? " open" : ""}"><button class="rp-chg-h" data-chg aria-expanded="${repChgOpen}"><b>本轮变化</b>${cr.groups.map((g) => `<span class="k-${g.kind}">${CHG[g.kind][0]}${g.kind === "money" ? "" : ` ${g.n}`}</span>`).join("")}<i>${repChgOpen ? "收起" : "展开"}</i></button>
      ${repChgOpen ? `<div class="rp-chg-b">${cr.groups.map((g) => `<div class="k-${g.kind}">${esc(g.text)}</div>`).join("")}</div>` : ""}</div>`) : "";
  const sel = mine.find((x) => x.id === repSel), selOpp = sel ? (sel.home === me() ? sel.away : sel.home) : 0;
  const pick = `<button class="rep-pick" data-rep-menu>${sel ? `<span class="tn">${crest(selOpp, "sm")}<span>第${sel.round}轮 ${esc(tname(selOpp))}</span></span><i class="res ${resultOf(sel)}">${sel.result.home_goals}:${sel.result.away_goals}</i>` : "选择比赛"}<em>▾</em></button>`;
  void pick;                                                                   // 窄屏下拉已不需要：小列表在任何宽度都放得下
  return `<div class="view v-reports v-rp-new"><div class="card scroll rep-list rp-minis" style="--i:0">${list}</div>
    <div class="rep-main" style="--i:1;min-height:0;display:flex;flex-direction:column">${strip}${reportBody(f)}</div></div>`;
}
let repChgOpen = false;
// 窄屏的战报下拉：菜单里每个我方已赛的轮次，选了就切战报
async function repMenu(anchor) {
  const h = await history(), mine = [];
  for (const r of h.rounds) for (const f of r.fixtures) if (isMine(f) && f.result) mine.push(f);
  trMenu(anchor, mine.map((f) => { const opp = f.home === me() ? f.away : f.home; return { k: f.id, label: `第${f.round}轮 ${tname(opp)}  ${f.result.home_goals}:${f.result.away_goals}`, on: f.id === repSel }; }), (it) => { repSel = it.k; sound("cursor"); draw(); });
}
async function fixture(id) { if (!fxCache[id]) fxCache[id] = await api(`/api/fixture/${encodeURIComponent(id)}`); return fxCache[id]; }
// 战报（2026-11-13 重做）：只用宿主真有的数据——比分、进球者、我方出场/进球/助攻（原生赛果没有分钟数、评分、技术统计，不编）。
// 头部计分牌带结果标签（胜/平/负）、轮次/日期/主客场和几个一眼能看懂的小标签（零封、大胜…）；进球按主队在左、客队在右排；
// 我方出场按首发 / 替补登场分组，有进球助攻的行高亮并把贡献写成图标。
function rpPossession(r, home, away) {
  const s = r.sim_stats;
  if (!s || s.source !== "simulated" || (r.native && r.native.status === "ok")) return "";
  const p = s.possession || {}, h = p[String(home)], a = p[String(away)];
  if (!Number.isFinite(h) || !Number.isFinite(a) || h < 0 || a < 0 || h > 100 || a > 100 || Math.abs(h + a - 100) > .11) return "";
  // 2026-11-18 用户：战报里只有控球率。模拟比赛的射门／射正／xG／关键传球／扑救（宿主 iml_ui._sim_possession 汇总自模拟的逐次射门）也列出来，同一块里一行一项
  const num = (k, d) => { const o = s[k] || {}, x = o[String(home)], y = o[String(away)]; return Number.isFinite(x) && Number.isFinite(y) ? [x, y, d] : null; };
  const more = [["射门", num("shots", 0)], ["射正", num("on_target", 0)], ["xG（预期进球）", num("xg", 2)], ["关键传球", num("key_passes", 0)], ["扑救", num("saves", 0)]].filter(([, v]) => v)
    .map(([name, [x, y, d]]) => { const t = x + y, pa = t > 0 ? Math.round(x / t * 100) : 50;
      return `<div class="rp-pr"><b>${x.toFixed(d)}</b><span>${name}</span><b>${y.toFixed(d)}</b></div>
        <div class="rp-pb" aria-hidden="true"><span style="width:${pa}%;background:var(--hc,#66aaff)"></span><span style="width:${100 - pa}%;background:var(--ac,#ffbb66)"></span></div>`; }).join("");
  return `<div class="rp-blk rp-possession"><div class="rp-bt">${more ? "技术统计" : "控球率"} · 模拟</div>
    <div class="rp-pr"><b>${h}%</b><span>控球率</span><b>${a}%</b></div>
    <div class="rp-pb" aria-label="${h}% : ${a}%"><span style="width:${h}%;background:var(--hc,#66aaff)"></span><span style="width:${a}%;background:var(--ac,#ffbb66)"></span></div>${more}</div>`;
}
function reportBody(f) {
  const r = f.result;
  if (!r) return `<div class="empty-note">比赛还没进行</div>`;
  const mine = isMine(f), mh = f.home === me(), rs = mine ? resultOf(f) : null;
  const gf = mh ? r.home_goals : r.away_goals, ga = mh ? r.away_goals : r.home_goals, tot = r.home_goals + r.away_goals, diff = Math.abs(r.home_goals - r.away_goals);
  const cup = f.cup || null;                                  // E341：欧战比赛用同一张战报页（宿主 /api/fixture/eu:<场次>），cup = 赛事名、两回合总比分/加时/点球
  const sc = (S.schedule || []).find((x) => x.id === f.id), dt = cup ? (f.date ? parseD(f.date) : null) : sc && sc.date ? parseD(sc.date) : null;
  const meta = [cup ? cup.label : `第 ${f.round} 轮`, dt ? `${dt.getMonth() + 1} 月 ${dt.getDate()} 日` : "", mine ? (cup && cup.neutral ? "中立场" : mh ? "主场" : "客场") : "", r.source === "played" ? "实际比赛" : "模拟"].filter(Boolean).join(" · ");
  const tieNote = cup && cup.tie && cup.tie.text ? `<div class="rp-note" style="text-align:center">${esc(cup.tie.text)}</div>` : cup && cup.tie ? `<div class="rp-note" style="text-align:center">两回合，次回合见分晓</div>` : "";
  const tags = [];
  if (tot === 0) tags.push(["互交白卷", ""]);
  else if (mine) { if (ga === 0) tags.push(["零封", "W"]); if (gf === 0) tags.push(["未能进球", "L"]); if (rs === "W" && diff >= 3) tags.push(["大胜", "W"]); if (rs === "L" && diff >= 3) tags.push(["惨败", "L"]); }
  if (tot >= 5) tags.push(["进球大战", ""]);
  // 2026-11-15 战报改版（用户图例）：中间框＝两队队徽夹比分（不写队名），下面只列进球者和助攻者，主队在左、客队在右
  const nat = r.native, natOk = nat && nat.status === "ok";
  const simTeam = (tid) => (!natOk && r.ratings && r.ratings.teams && r.ratings.teams[String(tid)]) || null;
  const assists = (tid) => natOk
    ? nat.players.filter((p) => p.team === tid && p.stats.assists).map((p) => ({ pid: p.pid, name: p.name, n: p.stats.assists }))
    : simTeam(tid) ? simTeam(tid).filter((p) => p.assists).map((p) => ({ pid: p.pid, name: p.name, n: p.assists }))
    : cup && !(r.players || []).length ? (cup.assists || []).filter((a) => a.team === tid)
    : (r.players || []).filter((p) => p.team === tid && p.assists).map((p) => ({ pid: p.pid, name: p.name, n: p.assists }));
  // 进球者 / 助攻者的头像：电脑队球员用他们真正出场的那张卡（模拟评分里的 face），不是原生球员头像
  const faceOf = (x) => { if (x.face || !simR) return x; const hit = [...(simR.teams[String(f.home)] || []), ...(simR.teams[String(f.away)] || [])].find((p) => p.pid && String(p.pid) === String(x.pid)); return hit && hit.face ? { ...x, face: hit.face } : x; };
  const who = (x, n, icon) => `<div class="rp-who">${icon}${x.pid ? pface(faceOf(x)) : ""}<b>${esc(x.name)}</b>${n > 1 ? `<i>×${n}</i>` : ""}</div>`;
  const col = (tid, kind) => kind === "g"
    ? (r.scorers || []).filter((g) => g.team === tid).map((g) => who(g, g.goals, gIcon())).join("")     // 含“进球者未记录”行
    : assists(tid).map((a) => who(a, a.n, aIcon())).join("");
  const block = (kind, title) => { const h = col(f.home, kind), a = col(f.away, kind);
    return h || a ? `<div class="rp-blk"><div class="rp-bt">${title}</div>${h}<div class="a">${a}</div></div>` : ""; };     // 单列：主队靠左、客队靠右，名字用满整宽
  const ps = r.players || [], starters = ps.filter((p) => p.sub !== "on"), subs = ps.filter((p) => p.sub === "on");
  const prow = (p) => { const hl = p.goals || p.assists;
    return `<tr${hl ? ' class="hl"' : ""}><td>${pos(p.position, p.position)}</td><td class="name">${pface(p)}${hl ? `<b>${esc(p.name)}</b>` : esc(p.name)}</td><td class="ct">${p.goals ? `<span class="cg">${gIcon()}${p.goals > 1 ? `×${p.goals}` : ""}</span>` : ""}${p.assists ? `<span class="ca">${aIcon()}${p.assists > 1 ? `×${p.assists}` : ""}</span>` : ""}</td></tr>`; };
  const sumG = ps.reduce((a, p) => a + (p.goals || 0), 0), sumA = ps.reduce((a, p) => a + (p.assists || 0), 0);
  const natNote = nat && !natOk ? `<div class="rp-note">球员技术统计：${esc(nat.reason || "没有采集到")}</div>` : "";
  const right = natOk ? rpStatsCard(f)
    : ps.length
    ? `<div class="card"><div class="ch">我方出场<span class="r">${ps.length} 人${sumG || sumA ? ` · 进球 ${sumG} · 助攻 ${sumA}` : ""}</span></div><div class="cb scroll"><table class="rp-tab"><tbody>${starters.map(prow).join("")}${subs.length ? `<tr class="sep"><td colspan="3">替补登场</td></tr>${subs.map(prow).join("")}` : ""}</tbody></table>${natNote}</div></div>`
    : `<div class="card"><div class="ch">比赛信息</div><div class="cb"><div class="empty-note">${r.source === "sim" ? "电脑模拟赛果，没有球员数据" : "这场没有记录球员数据"}</div>${natNote}</div></div>`;
  const simR = !natOk && r.ratings && r.ratings.teams ? r.ratings : null;                  // C2：电脑赛 / 模拟赛的模拟评分
  const simAll = simR ? [...(simR.teams[String(f.home)] || []).map((p) => ({ ...p, team: f.home })), ...(simR.teams[String(f.away)] || []).map((p) => ({ ...p, team: f.away }))] : [];
  const best = natOk ? nat.players.find((p) => p.best && p.rating != null) : simAll.find((p) => p.best) || null;   // 批次C：全场最佳（评分最高、出场够长）
  const events = (best ? `<div class="rp-blk rp-mvp"><div class="rp-bt">全场最佳</div><div class="rp-who${best.team === f.away ? " a" : ""}">${crest(best.team, "sm")}${pface(best)}<b>${esc(best.name)}</b>${rpRt(best.rating)}</div></div>` : "")
    + block("g", "进球") + block("a", "助攻");
  const simCard = () => { const colR = (tid) => (simR.teams[String(tid)] || []).map((p) => `<div class="rp-sr${p.best ? " best" : ""}${p.started ? "" : " sub"}"${p.mine && p.pid ? ` data-player="${esc(p.pid)}"` : ""}>${pface(p)}<span>${esc(p.name)}</span>${p.goals ? `${gIcon()}${p.goals > 1 ? `<small>×${p.goals}</small>` : ""}` : ""}${p.assists ? `${aIcon()}${p.assists > 1 ? `<small>×${p.assists}</small>` : ""}` : ""}${p.started ? "" : `<i class="rp-sub">替补</i>`}${p.best ? `<i class="rp-best">★</i>` : ""}${rpRt(p.rating)}</div>`).join("");
    return `<div class="card"><div class="ch">球员评分<span class="r">模拟评分</span></div><div class="cb scroll"><div class="rp-sim"><div><div class="rp-st-h">${crest(f.home, "sm")}</div>${colR(f.home)}</div><div><div class="rp-st-h">${crest(f.away, "sm")}</div>${colR(f.away)}</div></div><div class="rp-note">${esc(simR.note || "")}</div></div></div>`; };
  const solo = !natOk && !ps.length && !simR;                                // 没有任何球员数据：只留中间卡，居中，不放空的大框
  return `<div class="view v-report v-rp3${solo ? " solo" : ""}">
    <div class="card rp-mid ${rs || ""}" style="--hc:${tcolor(f.home)};--ac:${tcolor(f.away)}"><div class="cb scroll">
      <div class="rp-sb"><span data-team="${f.home}" title="${esc(tname(f.home))}">${crest(f.home, "lg")}</span><div class="rp-sc"><b class="num">${r.home_goals} : ${r.away_goals}</b>${rs ? `<i class="res ${rs}">${RES[rs]}</i>` : ""}</div><span data-team="${f.away}" title="${esc(tname(f.away))}">${crest(f.away, "lg")}</span></div>
      <div class="rp-meta">${meta}</div>${tieNote}${tags.length ? `<div class="rp-tags">${tags.map(([x, c]) => `<u class="${c}">${x}</u>`).join("")}</div>` : ""}
      ${rpPossession(r, f.home, f.away)}${events || `<div class="empty-note">${tot ? "进球者未记录" : "双方都没有进球"}</div>`}${solo ? `<div class="rp-note" style="text-align:center">${r.source === "sim" ? "电脑模拟赛果，没有球员数据" : "这场没有记录球员数据"}</div>${natNote}` : ""}
    </div></div>
    ${solo ? "" : simR ? simCard() : right}</div>`;
}
// E307 批次B（2026-11-15）：结算时从游戏里读到的逐人技术统计＋14×10 活动热区（宿主 iml_match_stats）。只显示真采到的数字；
// 没采到时上面的旧卡片写原因。评分是批次 C，这里不出分。点“我方/对方”切队，点一行看这名球员的热区（只重画本卡，不整页重绘）。
const rpState = {};
// 进球＝小足球、助攻＝球鞋（2026-11-15 用户：“进球的标志用一个小足球；助攻不要用‘助’，用一个鞋子”）。行内小图标，尺寸由 .ic-g / .ic-a 控制
const gIcon = () => `<span class="ic-g" title="进球"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10.6" fill="#101010" stroke="#fff" stroke-width="1.4"/><g fill="#fff" stroke="#fff" stroke-width=".8" stroke-linejoin="round"><polygon points="12,8.25 9.38,6.35 10.38,3.28 13.62,3.28 14.62,6.35"/><polygon points="15.57,10.84 16.57,7.77 19.8,7.77 20.8,10.84 18.18,12.74"/><polygon points="14.2,15.03 17.44,15.03 18.44,18.11 15.82,20.01 13.21,18.11"/><polygon points="9.8,15.03 10.79,18.11 8.18,20.01 5.56,18.11 6.56,15.03"/><polygon points="8.43,10.84 5.82,12.74 3.2,10.84 4.2,7.77 7.43,7.77"/></g></svg></span>`;
const aIcon = () => `<span class="ic-a" title="助攻"><svg viewBox="0 0 24 24"><path d="M2.8 16.6c0-.9.6-1.6 1.5-2l5.6-2.6 2.3-5.3 3 1.3 2.2-3 3.9 2c.6.3.8 1 .5 1.6l-2.7 5.4c-.6 1.1-1.5 1.9-2.7 2.3L5.7 19.2c-1.6.5-2.9-.4-2.9-2.6z" fill="currentColor"/><path d="M8.2 12.4l2.2 4M11.2 10.8l2.2 4" stroke="#1c1c1e" stroke-width="1.4" stroke-linecap="round"/></svg></span>`;
const RP_COLS = [[gIcon(), (s) => s.goals], [aIcon(), (s) => s.assists], ["射门", (s) => `${s.shots}/${s.shots_on_target}`], ["传球", (s) => `${s.passes}/${s.passes_completed}`],
  ["抢断", (s) => `${s.tackles}/${s.tackles_won}`], ["拦截", (s) => s.interceptions], ["触球", (s) => s.touches]];   // 射门=射门/射正，传球/抢断=次数/成功（表下注明）
const rpMore = (s) => [`盘带 ${s.dribbles}/${s.dribbles_completed}`, `直塞 ${s.through_balls}/${s.through_completed}`, `夺回 ${s.recoveries}`, `丢失 ${s.possession_lost}`,
  s.crosses ? `传中 ${s.crosses}/${s.crosses_completed}` : "", s.clearances ? `解围 ${s.clearances}` : "", s.fouls ? `犯规 ${s.fouls}` : "",
  s.yellow_cards ? `黄牌 ${s.yellow_cards}` : "", s.red_cards ? `红牌 ${s.red_cards}` : "", s.gk_on_target_faced ? `扑救 ${s.gk_saves}/${s.gk_on_target_faced}` : ""].filter(Boolean).join(" · ");
function rpStatsCard(f) { return `<div class="card rp-stats" data-rpfx="${esc(f.id)}">${rpInner(f)}</div>`; }
// E307 批次C：自有评分（宿主 iml_match_rating）。没分时说明原因，不显示 0
const RP_Q = { not_played: "未出场", too_short: "出场不足 15 分钟", no_time: "缺出场时间" };
const rpRt = (v, lg) => v == null ? `<em class="rt rt-n${lg ? " lg" : ""}">—</em>` : `<em class="rt ${v >= 8 ? "rt-a" : v >= 7 ? "rt-b" : v >= 6 ? "rt-c" : "rt-d"}${lg ? " lg" : ""}">${v.toFixed(1)}</em>`;
function rpInner(f) {
  const n = f.result.native, st = rpState[f.id] || (rpState[f.id] = { mine: true, pick: null });
  const rows = n.players.filter((p) => p.mine === st.mine).sort((a, b) => (a.sub === "on") - (b.sub === "on"));
  if (!rows.some((p) => p.player_key === st.pick)) st.pick = ([...rows].sort((a, b) => (b.rating ?? -1) - (a.rating ?? -1))[0] || {}).player_key || null;   // 默认选本队评分最高的人
  const pick = rows.find((p) => p.player_key === st.pick), opp = f.home === me() ? f.away : f.home, tid = st.mine ? me() : opp, pi = pick && pick.rating_info;
  const ts = (n.team_stats || {})[String(tid)] || {};
  const cell = (v) => (v === 0 || v === "0/0" ? `<span class="muted">${v}</span>` : esc(String(v)));
  const tr = (p) => `<tr class="${p.player_key === st.pick ? "on" : ""}${p.sub === "on" ? " sub" : ""}" data-rpp="${esc(p.player_key)}"><td class="name"><div class="rp-nm">${pface(p)}<span>${esc(p.name)}</span>${p.best ? `<i class="rp-best" title="全场最佳">★</i>` : ""}${p.sub === "on" ? `<i class="rp-sub">替补</i>` : ""}</div></td><td class="rtc">${rpRt(p.rating)}</td>${RP_COLS.map(([, fn]) => `<td>${cell(fn(p.stats))}</td>`).join("")}</tr>`;
  const sw = `<span class="rp-sw"><button class="chip${st.mine ? " on" : ""}" data-rpside="1" title="${esc(tname(me()))}">${crest(me(), "sm")}我方</button><button class="chip${st.mine ? "" : " on"}" data-rpside="0" title="${esc(tname(opp))}">${crest(opp, "sm")}对方</button></span>`;
  const top = pick ? `<div class="rp-top"><div class="rp-heat"><canvas data-rpheat="${pick.heat.join(",")}"></canvas><div class="rp-hl"><span>本方球门</span><span class="rp-lg"><i>低</i><u></u><i>高</i></span><span>进攻方向</span></div></div>
      <div class="rp-pi"><div class="rp-pn">${pface(pick, "lg")}<div><b>${esc(pick.name)}</b><small>${pick.sub === "on" ? "替补登场 · " : ""}${pi && pi.minutes_est != null ? `约 ${Math.round(pi.minutes_est)} 分钟` : `热区采样 ${pick.heat_total} 次`}${pi && pi.group ? ` · ${pi.group}` : ""}</small></div>${rpRt(pick.rating, true)}</div>
      ${pick.rating == null ? `<div class="rp-why muted">${esc((pi && RP_Q[pi.quality]) || "没有评分")}</div>` : (pi && pi.reasons && pi.reasons.length ? `<div class="rp-why">${pi.reasons.map((x) => `<span class="${x.delta >= 0 ? "up" : "dn"}">${esc(x.label)} ${x.delta >= 0 ? "+" : ""}${x.delta.toFixed(1)}</span>`).join("")}</div>` : "")}
      <div class="rp-more">${rpMore(pick.stats).split(" · ").map((x) => `<span>${esc(x)}</span>`).join("")}</div></div></div>` : "";
  return `<div class="ch">球员数据${sw}<span class="r">${ts.pass_accuracy != null ? `传球成功率 ${ts.pass_accuracy}% · ` : ""}射门 ${ts.shots || 0}/${ts.shots_on_target || 0}</span></div>
    <div class="cb scroll">${top}
    <table class="rp-tab rp-st"><thead><tr><th class="name">球员</th><th class="rtc">评分</th>${RP_COLS.map(([h]) => `<th>${h}</th>`).join("")}</tr></thead><tbody>${rows.map(tr).join("")}</tbody></table>
    <div class="rp-note">射门＝射门/射正，传球、抢断＝次数/成功。${esc(n.heat_note || "")}${n.rating_note ? `<br>${esc(n.rating_note)}` : ""}</div></div>`;
}
// 热成像风格（2026-11-15 用户）：每格按强度画一个柔和光斑叠加成强度场，再按热成像色带上色（深蓝→青→绿→黄→橙→红）。
// 只是显示方式：原始分辨率仍是 14×10 格，颜色按本人最大值归一化，不同球员之间不可比。
let RP_PAL = null;
function rpPalette() {
  if (RP_PAL) return RP_PAL;
  const c = document.createElement("canvas"); c.width = 256; c.height = 1;
  const g = c.getContext("2d"), gr = g.createLinearGradient(0, 0, 256, 0);
  [[0, "#1a1a8c"], [.2, "#0050ff"], [.4, "#00c8e6"], [.56, "#52e04a"], [.7, "#ffe600"], [.85, "#ff7800"], [1, "#ff1e28"]].forEach(([o, k]) => gr.addColorStop(o, k));
  g.fillStyle = gr; g.fillRect(0, 0, 256, 1);
  return (RP_PAL = g.getImageData(0, 0, 256, 1).data);
}
function rpPaint(cv) {
  const v = cv.dataset.rpheat.split(",").map(Number), w = cv.clientWidth || 300, h = Math.round(w * 10 / 14 * 0.68), dpr = window.devicePixelRatio || 1;
  const W = Math.round(w * dpr), H = Math.round(h * dpr);
  cv.width = W; cv.height = H; cv.style.height = h + "px";
  const x = cv.getContext("2d");
  x.fillStyle = "#0b1f16"; x.fillRect(0, 0, W, H);
  for (let i = 0; i < 7; i++) if (i % 2) { x.fillStyle = "rgba(255,255,255,.025)"; x.fillRect(i * W / 7, 0, W / 7, H); }   // 草皮条纹
  const off = document.createElement("canvas"); off.width = W; off.height = H;
  const o = off.getContext("2d"), cw = W / 14, ch = H / 10, rad = Math.max(cw, ch) * 1.45, max = Math.max(1, ...v);
  for (let a = 0; a < 14; a++) for (let b = 0; b < 10; b++) {
    const c = v[a * 10 + b]; if (!c) continue;
    const px = (a + .5) * cw, py = (b + .5) * ch, g = o.createRadialGradient(px, py, 0, px, py, rad);
    g.addColorStop(0, `rgba(0,0,0,${(.5 * c / max).toFixed(3)})`); g.addColorStop(1, "rgba(0,0,0,0)");
    o.fillStyle = g; o.fillRect(px - rad, py - rad, rad * 2, rad * 2);
  }
  const img = o.getImageData(0, 0, W, H), d = img.data, pal = rpPalette();
  let peak = 0; for (let i = 3; i < d.length; i += 4) if (d[i] > peak) peak = d[i];
  if (peak) for (let i = 0; i < d.length; i += 4) {
    const t = Math.round(d[i + 3] / peak * 255); if (t < 10) { d[i + 3] = 0; continue; }
    const k = t * 4; d[i] = pal[k]; d[i + 1] = pal[k + 1]; d[i + 2] = pal[k + 2]; d[i + 3] = Math.min(230, 50 + t * .8);
  }
  o.putImageData(img, 0, 0); x.drawImage(off, 0, 0);
  x.strokeStyle = "rgba(255,255,255,.45)"; x.lineWidth = Math.max(1, dpr);
  const L = (fn) => { x.beginPath(); fn(); x.stroke(); };
  L(() => x.rect(.5, .5, W - 1, H - 1)); L(() => { x.moveTo(W / 2, 0); x.lineTo(W / 2, H); }); L(() => x.arc(W / 2, H / 2, H * .15, 0, Math.PI * 2));
  L(() => x.rect(.5, H * .21, W * .14, H * .58)); L(() => x.rect(W - W * .14 - .5, H * .21, W * .14, H * .58));
  L(() => x.rect(.5, H * .36, W * .05, H * .28)); L(() => x.rect(W - W * .05 - .5, H * .36, W * .05, H * .28));
}
function rpBind(el) {
  const f = fxCache[el.dataset.rpfx]; if (!f || !f.result || !f.result.native) return;
  const st = rpState[f.id];
  $$("[data-rpside]", el).forEach((b) => b.onclick = (e) => { e.stopPropagation(); st.mine = b.dataset.rpside === "1"; st.pick = null; sound("cursor"); el.innerHTML = rpInner(f); rpBind(el); });
  $$("[data-rpp]", el).forEach((row) => row.onclick = (e) => { e.stopPropagation(); st.pick = row.dataset.rpp; sound("cursor"); el.innerHTML = rpInner(f); rpBind(el); });
  $$("canvas[data-rpheat]", el).forEach(rpPaint);
}
/* ================= 规划中的分区 ================= */
function viewPlan(sec, tabName) {
  if (bizFailed.size) return viewBizError(tabName);
  const [title, desc, items] = PLANS[sec];
  return `<div class="view v-plan">
    <div class="card plan-hero" style="--i:0"><span class="big">${svg(sec === "home" ? "home" : sec, 1.2)}</span>
      <small>暂无数据</small><b>${esc(tabName || title)}</b><p>${esc(desc)}</p></div>
    <div class="card" style="--i:1"><div class="ch">这里会显示</div><div class="cb scroll"><ul class="plist">${items.map(([a, b]) => `<li><i></i><div>${esc(a)}<span>${esc(b)}</span></div></li>`).join("")}</ul></div></div></div>`;
}

// 读取失败（不是“没有数据”，更不是 0）：说清楚并给重试
function viewBizError(tabName, msg = "") {
  return `<div class="view v-plan" style="grid-template-columns:minmax(0,1fr)"><div class="card plan-hero" style="--i:0"><span class="big">${svg("bell", 1.2)}</span>
    <small>读取失败</small><b>${esc(tabName || "经营数据")}</b><p>这一页的数据暂时取不到${msg ? `（${esc(msg)}）` : ""}。金额、球员和报价都没有变化，稍后重试即可。</p>
    <button class="btn pri" data-bizretry>重试</button></div></div>`;
}
/* ================= FM 式谈判单（2026-11-14）=================
   用户：“这个UI做好一点吧”“这种UI”（续约 / 发起报价弹窗截图）“做成类FM的那种感觉吧 现在太简陋了”。
   转会与合同弹窗统一成一张“谈判单”：左栏球员卡（所属俱乐部色渐变、大头像、能力/潜力、关键事实），右栏分节条款
   （步进输入、快捷按钮、分段选择）、图形条（预算占用、薪资结构、对比要价）、对方说的话（体育总监 / 经纪人 / 球员的反馈气泡）。
   外壳仍是 mkDialog（第 4 个参数 "fm"）；这里只有拼装与绑定的小部件，各弹窗的业务在 50-/55- 文件里。 */
/* 星级（2026-11-14 用户：“不应该显示能力和潜力具体数值 应该显示个星级就好了 … 参照下FM”）：别队球员的能力 / 潜力按星级显示，½～5 星。潜力是球探的区间：实心到下限、空心到上限。
   2026-11-15 用户：“身价是正常，但是他这个星星、能力跟潜力就有点怪怪的”——以前 3 星＝我队最强 11 人的平均 CA、一星 9 CA，传奇卡阵容（平均 CA 167.8）让市场 68% 的人只有半星。
   现在是全联赛统一的绝对刻度：ref＝服务端 star_ref（3 星的 CA，iml_ability.STAR_MID＝148），一星＝star_step（14）CA；和我队比强弱另看 squad_ca（mkVsUs）。 */
const starStep = () => (typeof BIZ !== "undefined" && BIZ.market && BIZ.market.star_step) || 3;   // W6-c2：服务端给“一星＝多少 CA”（旧服务端没有：3 点总评）
const starVal = (ov, ref) => (ref == null || ov == null ? null : Math.max(0.5, Math.min(5, Math.round((3 + (ov - ref) / starStep()) * 2) / 2)));
function starsHtml(v, hi = null, cls = "") {
  if (v == null) return `<span class="muted">—</span>`;
  const top = hi != null ? Math.max(v, hi) : v; let h = "";
  for (let i = 1; i <= 5; i++) h += `<i class="${v >= i ? "f" : v >= i - 0.5 ? (top >= i ? "hp" : "h") : top >= i ? "p" : top >= i - 0.5 ? "ph" : "e"}"></i>`;
  return `<span class="rstars ${cls}" title="${top > v ? `${v}～${top} 星` : `${v} 星`}">${h}</span>`;
}
function fmWho(p, { color, crest = "", tag = "", facts = [] } = {}) {
  return `<aside class="fm-who" style="--pc:${color || "var(--club)"}">
    <div class="fm-top">${crest}${tag ? `<span class="fm-tag">${tag}</span>` : ""}</div>
    <div class="fm-face">${pface(p, "lg")}</div>
    <b class="fm-name">${esc(p.name || p.player || "")}</b><small class="fm-sub">${esc(p.position || "")}</small>
    <div class="fm-ab">${p.stars ? `<span><i>能力</i>${starsHtml(p.stars.ab)}</span><span><i>潜力</i>${starsHtml(p.stars.lo, p.stars.hi, "pot")}</span>`
      : `${p.overall != null ? `<span><i>能力</i>${ovr(p.overall)}</span>` : ""}${p.potential != null ? `<span><i>潜力</i>${ovr(p.potential)}</span>` : ""}`}</div>
    <dl class="fm-facts">${facts.filter(([, v]) => v != null && v !== "" && v !== "—").map(([k, v]) => `<div><dt>${k}</dt><dd>${v}</dd></div>`).join("")}</dl></aside>`;
}
const fmSheet = (who, main, cls = "") => `<div class="fm-sheet${cls ? ` ${cls}` : ""}">${who}<div class="fm-main">${main}</div></div>`;
const fmSec = (title, inner, side = "") => `<section class="fm-sec">${title ? `<h4><span>${title}</span>${side ? `<em>${side}</em>` : ""}</h4>` : ""}${inner}</section>`;
const fmInl = (label, inner) => `<div class="fm-inl"><span>${label}</span>${inner}</div>`;       // 一行：小标签＋控件（省一行段标题，一屏放得下）
// 对方说的话：tone = "" 中性 / "bad" 拒绝或警告 / "good" 好消息
const fmQuote = (who, text, tone = "") => `<div class="fm-q ${tone}"><i>${svg("person", 1.8)}</i><div><small>${who}</small><p>${text}</p></div></div>`;
// 步进输入：− [数字] 单位 +；min/max 由 input 自己约束
function fmStep(id, val, { step = 1, min = 0, max = null, dec = 0, unit = "" } = {}) {
  return `<div class="fm-step" data-st="${step}" data-dec="${dec}"><button type="button" data-d="-1" aria-label="减少">−</button><input id="${id}" type="number" inputmode="decimal" step="${step}" min="${min}"${max != null ? ` max="${max}"` : ""} value="${val}"><em>${unit}</em><button type="button" data-d="1" aria-label="增加">+</button></div>`;
}
const fmSeg = (name, opts, cur) => `<div class="fm-seg" data-seg="${name}">${opts.map(([v, l]) => `<button type="button" data-v="${v}" class="${String(v) === String(cur) ? "on" : ""}">${l}</button>`).join("")}</div>`;
const fmTiles = (tiles) => `<div class="fm-tiles">${tiles.map(([k, v, c]) => `<div class="fm-tile"><small>${k}</small><b class="num"${c ? ` style="color:${c}"` : ""}>${v}</b></div>`).join("")}</div>`;
// 进度条：base（已有，灰）＋ add（这一笔，彩色）＋ cap 竖线（上限 / 要价 / 身价）；fmMeterSet 每次输入变化时重画
// drive＝对应步进输入框的 id：这根条可以拖动（2026-11-14 用户：“报价条能不能做成那种可以拖动的”），拖到哪里输入框就是多少（对齐步长、受 min/max 约束）
const fmMeter = (id, drive = null) => `<div class="fm-meter${drive ? " drag" : ""}" id="${id}"${drive ? ` data-drive="${drive}"` : ""}><div class="tr"${drive ? ` role="slider" aria-label="拖动调整"` : ""}><i class="b"></i><i class="a"></i><s></s></div><div class="lb"><span></span><b></b></div></div>`;
function fmMeterSet(el, { base = 0, add = 0, cap = null, max = null, label = "", value = "", tone = "", limit = true }) {   // limit=false：cap 只是参考线（如身价），越过不算超限
  if (!el) return;
  const m = Math.max(max || cap || 0, base + add, 1e-9), pb = Math.min(100, base / m * 100);
  const tr = $(".tr", el), a = $(".a", tr), s = $("s", tr);
  $(".b", tr).style.width = `${pb}%`; a.style.left = `${pb}%`; a.style.width = `${Math.max(0, Math.min(100 - pb, add / m * 100))}%`;
  if (cap != null) { s.style.display = ""; s.style.left = `${Math.min(100, cap / m * 100)}%`; } else s.style.display = "none";
  el.classList.toggle("over", limit && cap != null && tone !== "ok" && base + add > cap + 1e-9);
  el.dataset.tone = tone; $(".lb span", el).innerHTML = label; $(".lb b", el).innerHTML = value;
  el.dataset.span = Math.max(max || cap || 0, 1e-9); el.dataset.base = base;        // 拖动的刻度：固定用 max（不随这一笔变），拖动时条不会跳
}
// 绑定一张谈判单里的步进、分段与快捷按钮（[data-fill="id:value"]）；任一变化调 onChange
function fmBind(el, onChange) {
  const ch = () => onChange && onChange();
  $$(".fm-step", el).forEach((w) => { const inp = $("input", w), st = +w.dataset.st, dec = +w.dataset.dec;
    $$("button", w).forEach((b) => b.onclick = () => { const d = +b.dataset.d, cur = +inp.value || 0;          // 对齐到步长：240.8 → +0.5 = 241.0
      let v = (d > 0 ? Math.floor(cur / st + 1e-9) + 1 : Math.ceil(cur / st - 1e-9) - 1) * st;
      if (inp.min !== "") v = Math.max(+inp.min, v); if (inp.max !== "") v = Math.min(+inp.max, v); inp.value = v.toFixed(dec); sound("cursor"); ch(); });
    inp.addEventListener("input", ch); });
  $$(".fm-seg", el).forEach((g) => $$("button", g).forEach((b) => b.onclick = () => { $$("button", g).forEach((x) => x.classList.toggle("on", x === b)); sound("cursor"); ch(); }));
  $$("[data-fill]", el).forEach((b) => b.onclick = () => { const [id, v] = b.dataset.fill.split(":"); const inp = $(`#${id}`, el); if (inp) { inp.value = v; sound("cursor"); ch(); } });
  // 可拖动的条：按下即跳到该位置，按住拖动连续调整；鼠标与触屏都用 pointer 事件（手机 WebView 支持），松手时一声
  $$(".fm-meter[data-drive]", el).forEach((mt) => { const inp = $(`#${mt.dataset.drive}`, el), tr = $(".tr", mt); if (!inp || !tr) return;
    const w = inp.closest(".fm-step"), st = w ? +w.dataset.st || 1 : 1, dec = w ? +w.dataset.dec || 0 : 0;
    const set = (e) => { const r = tr.getBoundingClientRect(), f = Math.max(0, Math.min(1, (e.clientX - r.left) / Math.max(1, r.width)));
      let v = Math.round((f * (+mt.dataset.span || 0) - (+mt.dataset.base || 0)) / st) * st;
      if (inp.min !== "") v = Math.max(+inp.min, v); if (inp.max !== "") v = Math.min(+inp.max, v);
      const t = Math.max(0, v).toFixed(dec); if (inp.value !== t) { inp.value = t; ch(); } };
    tr.addEventListener("pointerdown", (e) => { e.preventDefault(); try { tr.setPointerCapture(e.pointerId); } catch (_) {} mt.classList.add("dragging"); set(e); });
    tr.addEventListener("pointermove", (e) => { if (mt.classList.contains("dragging")) set(e); });
    const end = () => { if (mt.classList.contains("dragging")) { mt.classList.remove("dragging"); sound("cursor"); } };
    tr.addEventListener("pointerup", end); tr.addEventListener("pointercancel", end); tr.addEventListener("lostpointercapture", end); });
}
// 报价对比要价的文字（2026-11-14 用户：“给一个拒绝的概率吧 不要低于要价就拒绝 而且这个概率不明着写出来 … 续约和转会都是这样”）：
// 只描述差距，不写会不会被拒、不写概率——低于要价对方也可能接受（服务端 iml_terms.accept_chance / 俱乐部的隐藏底线）
const gapTxt = (r, what) => (r >= 1 ? `达到${what}` : r >= 0.95 ? `接近${what}` : r >= 0.88 ? `比${what}低一些` : r >= 0.8 ? `和${what}差距明显` : `远低于${what}`);
const fmTone = (r) => (r >= 1 ? "ok" : r >= 0.9 ? "mid" : "low");
/* “他的看法”（E334，2026-11-16 用户：“改成类FM的这种”）：FM 的谈判单是边改条款边看到每一项对方满不满意——✓ 满意 / … 还可以谈 / ✕ 不行，
   每项带一句原因和加成百分比，最后一句结论，再给对方的还价（点一下填进去）。数据来自服务端的只读预览（市场 /api/market/terms/preview、
   续约 /api/contract/preview）；只给状态与结论，不写接受概率（用户 2026-11-14 规定隐藏）。预览失败（旧宿主）就整块不显示。 */
const FEED_ICON = { ok: "✓", talk: "…", no: "✕" };
const ADJ_ZH = { role: "定位", club: "俱乐部", years: "年限", expiry: "到期年", gap: "未兑现", relationship: "留队关系", competition: "竞争合同" };
// 2026-11-16 用户：“信息太挤了 看法都在下面谁看得到”——紧凑成两行、放在周薪条正下方：①结论＋每项一个小标签（✓/…/✕ ＋几个字 ＋ +x%，点一下看原因）②还价按钮
// 2026-11-16 用户：“他的看法要放在主要位置 放最下面怎么看 而且有点简陋了”——改成右栏的一整张“看法”卡：大结论（图标＋颜色）＋逐项（标签、百分比、原因）＋还价按钮
const fmFeed = (id) => `<div class="fm-feed" id="${id}" hidden><div class="fd-v"></div><ul class="fd-i"></ul><div class="fd-c"></div></div>`;
const FEED_LABEL = { wage: "周薪", role: "队内定位", club: "俱乐部", years: "合同年限", cap: "周薪上限", expiry: "到期年", gap: "未兑现", relationship: "留队关系", competition: "竞争合同" };
// 2026-11-16 用户：结论用表情——笑脸 / 思考 / 尴尬；“emoji 太丑了”→ 自绘扁平 SVG 脸（和界面的红黄绿同色，不依赖系统 emoji 字体）
const faceSvg = (fill, feat) => `<svg class="fm-face-ic" viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="14.5" fill="${fill}"/><g fill="none" stroke="#15171b" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">${feat}</g></svg>`;
const FEED_FACE = {
  yes: faceSvg("var(--win)", `<circle cx="11" cy="13" r=".9" fill="#15171b"/><circle cx="21" cy="13" r=".9" fill="#15171b"/><path d="M9.5 18.5c1.6 3.6 11.4 3.6 13 0"/>`),
  maybe: faceSvg("var(--draw)", `<circle cx="11.5" cy="14" r=".9" fill="#15171b"/><circle cx="21.5" cy="14" r=".9" fill="#15171b"/><path d="M9 9.5l4-1.4M19.5 8.6l4 1.2" stroke-width="1.8"/><path d="M12 21.5h8"/>`),
  no: faceSvg("var(--loss)", `<circle cx="10.5" cy="14" r=".9" fill="#15171b"/><circle cx="19.5" cy="14" r=".9" fill="#15171b"/><path d="M9.5 21c1.4-1.5 2.4-1.5 3.8 0s2.4 1.5 3.8 0 2.4-1.5 3.4 0"/><path d="M25 7.5c1.8 2.2 2.6 3.6 2.6 4.8a2.6 2.6 0 0 1-5.2 0c0-1.2.8-2.6 2.6-4.8z" fill="#bfe6ff" stroke="none"/>`),
};
const FEED_HEAD = { yes: [FEED_FACE.yes, "他愿意签"], maybe: [FEED_FACE.maybe, "还可以谈"], no: [FEED_FACE.no, "差距较大"] };
const fmAdj = (parts) => (parts || []).map((p) => `${ADJ_ZH[p.kind] || p.kind} ${p.sign || "+"}${p.pct}%`).join(" · ");
// 定位卡（2026-11-16 用户：“太拥挤了 没有美感”）：只留四样——名字＋状态标签、一个大价格、一行小字（基础价与加成）、首发占比；其余写进悬停说明
const fmRoleCard = (o) => `<button type="button" class="fm-role${o.on ? " on" : ""}" data-role="${o.r}" title="${esc(`${o.share}${o.tip ? ` · ${o.tip}` : ""}`)}"><span class="rh"><b>${o.name}</b>${o.tags || ""}</span><strong class="rp">${o.price}</strong><small class="rs">${o.sub}</small><small class="rm">${o.share}</small></button>`;
const fmCounterTxt =(c, roleZh) => `${roleZh[c.role] ? roleZh[c.role] + " " : ""}€${c.wage}K${c.years ? ` · ${c.years}年` : ""}`;
function fmFeedSet(el, d, roleZh, pick) {
  if (!el) return; if (!d || d.error || !d.items) { el.hidden = true; return; }
  el.hidden = false; el.dataset.verdict = d.verdict || "";
  const items = d.items.slice(); if (d.over_cap && !items.some(x => x.key === "cap")) items.push({ key: "cap", state: "no", short: "超出周薪上限", text: d.over_cap });
  const head = FEED_HEAD[d.verdict] || ["", d.verdict_text || ""];
  $(".fd-v", el).innerHTML = `<i>${head[0]}</i><b>${esc(d.verdict_text || head[1])}</b>`;
  $(".fd-i", el).innerHTML = items.map((i) => `<li class="${i.state}"><i>${FEED_ICON[i.state] || "·"}</i><div><b>${esc(FEED_LABEL[i.key] || i.short || "")}${i.pct && i.state !== "ok" ? `<em>+${i.pct}%</em>` : ""}</b><span>${esc(i.text || "")}</span></div></li>`).join("");
  const box = $(".fd-c", el), cs = d.verdict === "yes" ? [] : [["还价", d.counter], ["或", d.alt]].filter(([, c]) => c && c.wage);
  box.innerHTML = cs.map(([k, c], n) => `<button type="button" class="chip" data-cn="${n}"><small>${k}</small>${esc(fmCounterTxt(c, roleZh || {}))}</button>`).join("");
  $$("[data-cn]", box).forEach((b) => b.onclick = () => { sound("cursor"); pick && pick(cs[+b.dataset.cn][1]); });
}
// 条款一变就向服务端要一次预览（防抖 250ms；只认最新一次的回复）
// onData（可选，2026-11-17 转会签约界面）：拿到预览后再交给调用方一份（竞争合同对比板读其中 competition 一项的领先 / 落后）
function fmFeedLoader(el, url, payload, roleZh, pick, onData) {
  let timer = 0, seq = 0;
  return () => { clearTimeout(timer); timer = setTimeout(async () => { const mine = ++seq; let r = null;
    try { r = await post(url, payload()); } catch (e) { r = null; }
    if (mine === seq && document.body.contains(el)) { fmFeedSet($(".fm-feed", el), r, roleZh, pick); if (onData) onData(r); } }, 250); };
}
const fmSegVal = (el, name) => { const b = $(`[data-seg="${name}"] button.on`, el); return b ? b.dataset.v : null; };
/* ================= 经营层页面（数据：/api/biz/*；服务端没有这一块时显示规划说明，读取失败时显示重试） ================= */
const KIND = {
  transfer: ["转会", "var(--gold)", "transfer"], injury: ["伤病", "var(--loss)", "med"], board: ["董事会", "var(--blue)", "person"],
  growth: ["成长", "var(--win)", "up"], form: ["状态", "var(--gold)", "up"], finance: ["财务", "var(--gold)", "coin"], match: ["比赛", "var(--ink2)", "ball"], contract: ["合同", "var(--draw)", "doc"],
};
const kindOf = (k) => KIND[k] || ["消息", "var(--ink2)", "bell"];
// E365（2026-11-18 用户：“球员相关的新闻可以显示他的小头像”）：消息带 pid＝单人头像（右下角类别小徽标）；带 people＝最多 3 张叠放头像；都没有才用类别图标。
// people = [{pid, name, note, tone: up/dn/warn, team?}]（iml_biz 只读字段，旧宿主没有就退回原样）
const ibxPeople = (m) => (m.people || []).filter((p) => p && p.pid);
function ibxAv(m, big) {
  const [, col, ic] = kindOf(m.kind), ppl = ibxPeople(m), badge = `<em class="ibk" style="--k:${col}">${svg(ic, 2.2)}</em>`;
  if (m.pid) return `<span class="ibav${big ? " big" : ""}" style="--k:${col}">${pface({ pid: m.pid })}${badge}</span>`;
  if (ppl.length) { const show = ppl.slice(0, ppl.length > 3 ? 2 : 3), more = ppl.length - show.length;
    return `<span class="ibav stack n${show.length + (more ? 1 : 0)}${big ? " big" : ""}" style="--k:${col}">${show.map((p) => pface(p)).join("")}${more ? `<i class="pf ibmore">+${more}</i>` : ""}${badge}</span>`; }
  return `<span class="ico${big ? " big" : ""}" style="color:${col}">${svg(ic)}</span>`;
}
function msgHtml(m, attrs = "") {
  return `<div class="msg${m.unread ? " unread" : ""}" ${attrs}>${ibxAv(m)}<div><p>${esc(m.title)}</p><small>${esc(kindOf(m.kind)[0])} · ${esc(m.when || "")}</small></div></div>`;
}
const later = (txt = "示例数据，暂不能操作") => `data-todo="${esc(txt)}" data-sound="ok"`;
const gaugeColor = (v) => v >= 70 ? "var(--win)" : v >= 45 ? "var(--draw)" : "var(--loss)";

// ---- 主页 · 通知
let ibxKind = "all", ibxSel = null;
// 消息 id 多数是数字，留队关系事件是 "relationship:…" 字符串（iml_finance）——以前一律 +id 变成 NaN，那类消息点不开（E365 修）
const ibxId = (v) => (/^\d+$/.test(String(v)) ? +v : String(v));
// 已读记在本机 localStorage（服务端只按“最近一轮”给 unread；消息 id 稳定，见 iml_biz.inbox）；示例数据不记
const IBX_KEY = "iml-inbox-read";
function ibxRead() { try { return new Set(JSON.parse(localStorage.getItem(IBX_KEY) || "[]")); } catch (e) { return new Set(); } }
function ibxMark(ids) {
  if (!BIZ.inbox || BIZ.inbox.demo || !ids.length) return;
  try { const s = ibxRead(); ids.forEach((i) => s.add(i)); localStorage.setItem(IBX_KEY, JSON.stringify([...s].slice(-400))); } catch (e) { /* 存不了就只在本次会话里已读 */ }
}
// 通知页（2026-11-13 重做）：左侧按未读/更早分组，每条带类别色条、标题、正文摘要；右侧是详情卡（类别色头部、正文、相关页面按钮、上一条/下一条）。
// 数据只有 kind/title/body/when/unread，所以详情里不编造额外字段；按钮只跳到已有页面（转会的拒绝/还价/接受仍是“经营层上线后可用”）。
function ibxRow(x, sel, isNew) {
  const [kn, col] = kindOf(x.kind);
  return `<div class="ibr${sel ? " sel" : ""}${isNew ? " new" : ""}" data-ibx="${x.id}" style="--k:${col}">${ibxAv(x)}<div class="ibt"><b>${esc(x.title)}</b>${x.body ? `<span class="ibp">${esc(x.body)}</span>` : ""}<small><u>${esc(kn)}</u>${esc(x.when || "")}</small></div>${isNew ? `<i class="ibd"></i>` : ""}</div>`;
}
const IBX_LINK = { transfer: [["查看报价", "transfer:2"]], injury: [["球队 · 伤病", "squad:4"]], contract: [["球队 · 合同", "squad:3"]], board: [["董事会", "home:3"]],
  growth: [["成长记录", "training:2"]], form: [["查看阵容", "squad:1"], ["个人训练", "training:1"]], finance: [["财务概览", "finance:0"]], match: [["查看阵容", "squad:1"], ["赛季日程", "season:2"]] };
async function viewInbox(name) {
  const d = await biz("inbox"); if (!d) return viewPlan("home", name);
  const kinds = ["all", ...new Set(d.items.map((m) => m.kind))];
  const list = d.items.filter((m) => ibxKind === "all" || m.kind === ibxKind);
  if (!list.some((m) => m.id === ibxSel)) ibxSel = list.length ? list[0].id : null;
  const m = d.items.find((x) => x.id === ibxSel), fresh = new Set(list.filter((x) => x.unread).map((x) => x.id));   // 进页面时的未读，用于分组（点开后才标已读）
  if (m && m.unread) { m.unread = false; ibxMark([m.id]); }
  const unreadN = d.items.filter((x) => x.unread).length, cnt = (k) => d.items.filter((x) => k === "all" || x.kind === k).length;
  const row = (x) => ibxRow(x, x.id === ibxSel, fresh.has(x.id));
  const newer = list.filter((x) => fresh.has(x.id)), older = list.filter((x) => !fresh.has(x.id));
  const rows = (newer.length ? `<div class="ibg">未读 ${newer.length}</div>${newer.map(row).join("")}` : "") + (older.length ? `<div class="ibg">${newer.length ? "更早" : "全部消息"}</div>${older.map(row).join("")}` : "");
  const idx = m ? list.findIndex((x) => x.id === m.id) : -1, prev = idx > 0 ? list[idx - 1] : null, next = idx >= 0 && idx < list.length - 1 ? list[idx + 1] : null;
  let detail = `<div class="empty-note">选一条消息</div>`;
  if (m) {
    const [kn, col, ic] = kindOf(m.kind), links = IBX_LINK[m.kind] || [];
    const acts = (m.kind === "transfer" ? `<button class="btn" ${later()}>拒绝</button><button class="btn" ${later()}>还价</button><button class="btn" ${later()}>接受</button>` : "")
      + links.map(([txt, go], i) => `<button class="btn${i === 0 && m.kind !== "transfer" ? " pri" : ""}" data-tab="${go}">${esc(txt)} ›</button>`).join("");
    // 详情：单人消息的大头像可点开球员页；多人消息在正文下列“相关球员”（头像＋名字＋这条消息里他的变化），点一行打开球员页
    const ppl = ibxPeople(m), mine = me(), TONE = { up: "tag-up", dn: "tag-dn", warn: "tag-warn" };
    const head = m.pid ? `<span class="ibav big pf-go" style="--k:${col}"${pgo({ pid: m.pid }, mine)}>${pface({ pid: m.pid })}<em class="ibk" style="--k:${col}">${svg(ic, 2.2)}</em></span>` : ibxAv(m, true);
    const who = ppl.length ? `<div class="ibpl"><div class="ibg">相关球员 ${ppl.length}</div>${ppl.map((p) => `<div class="ibpr"${pgo(p, p.team ?? mine)}>${pface(p)}<b>${esc(p.name)}</b>${p.note ? `<span class="${TONE[p.tone] || "tag-up"}">${esc(p.note)}</span>` : ""}<i>›</i></div>`).join("")}</div>` : "";
    detail = `<div class="ibh" style="--k:${col}">${head}<div><small>${esc(kn)} · ${esc(m.when || "")}</small><b>${esc(m.title)}</b></div></div>
      <div class="cb scroll ibb"><p>${esc(m.body || "这条消息没有更多说明。")}</p>${who}</div>
      <div class="iba">${acts}<span class="ibn"><button class="btn" data-ibx="${prev ? prev.id : ""}" ${prev ? "" : "disabled"} aria-label="上一条">‹</button><em>${idx + 1} / ${list.length}</em><button class="btn" data-ibx="${next ? next.id : ""}" ${next ? "" : "disabled"} aria-label="下一条">›</button></span></div>`;
  }
  return `<div class="view v-inbox">
    <div class="card inbox" style="--i:0"><div class="filters">${kinds.map((k) => `<button class="chip${k === ibxKind ? " on" : ""}" data-ibk="${k}">${k === "all" ? "全部" : kindOf(k)[0]}<b>${cnt(k)}</b></button>`).join("")}${unreadN ? `<button class="chip ibread" data-ibread>全部已读</button>` : ""}</div>
      <div class="cb scroll">${rows || `<div class="empty-note">没有消息</div>`}</div></div>
    <div class="card ibd-card" style="--i:1">${detail}</div></div>`;
}// ---- 主页 · 董事会
async function viewBoard(name) {
  const d = await biz("club"); if (!d || !d.board) return viewPlan("home", name);
  // 目标状态（2026-11-14 体验评审 U04）：赛季中只报进度（目前达标 / 仍在竞争 / 落后目标），赛季结束才有“达成 / 未达成”；
  // 早季宽容＝仍在竞争，不是达成。旧服务端的 ok/risk 按进度口径显示，避免把宽容翻成“达成”。
  const b = d.board, ST = { met: ["目前达标", "var(--win)"], chasing: ["仍在竞争", "var(--draw)"], behind: ["落后目标", "var(--loss)"],
    done: ["达成", "var(--win)"], fail: ["未达成", "var(--loss)"], ok: ["目前达标", "var(--win)"], risk: ["仍在竞争", "var(--draw)"] };
  const st = (o) => ST[o.state] || ["—", "var(--ink3)"];
  return `<div class="view" style="grid-template-columns:240px minmax(0,1fr)">
    <div class="card plan-hero" style="--i:0;justify-content:flex-start"><small>董事会信任</small><b class="num" style="font-size:64px;color:${gaugeColor(b.trust)}">${b.trust}</b>
      <div class="bar" style="height:6px">${`<i data-w="${b.trust}" style="--c:${gaugeColor(b.trust)}"></i>`}</div>
      <p>本季目标：<b style="color:#fff">${esc(b.target)}</b><br>${b.final ? "最终评价" : "目前评价"}：<b style="color:#fff">${esc(b.verdict)}</b></p></div>
    <div class="card" style="--i:1"><div class="ch">赛季目标<span class="r">${b.final ? "本季最终结果" : "赛季中为进度，赛季结束才定结果"} · 信任度反映董事会评价</span></div><div class="cb scroll">
      ${b.objectives.map((o) => `<div class="obj"><i style="background:${st(o)[1]}"></i><div><b>${esc(o.text)}</b><span>${esc(o.note || "")}</span></div><em style="color:${st(o)[1]}">${st(o)[0]}</em></div>`).join("")}</div></div></div>`;
}
// ---- 球队 · 合同 / 伤病 / 青训
async function squadRows() {
  const [t, x] = await Promise.all([team(me()), biz("squad")]);
  if (!x) return null;
  return [...t.squad, ...t.reserve].map((p) => ({ ...p, ...(x.players[String(p.pid)] || {}) }));
}
async function viewContracts(name) {
  const ps = await squadRows(); if (!ps) return viewPlan("squad", name);
  const sq = await biz("squad"), real = !sq.demo, cur = 2026 + (S.career.season || 1);       // 合同“到期”＝赛季年份：第 n 季的合同到 2026+n 年 6 月
  const first = real ? cur : Math.min(...ps.map((p) => p.until || 9999));
  const rows = [...ps].sort((a, b) => (a.until || 9999) - (b.until || 9999) || (b.wage || 0) - (a.wage || 0));
  const exp = rows.filter((p) => p.until === first).length, total = ps.reduce((a, p) => a + (p.wage || 0), 0);
  const act = (p) => !real ? `<button class="btn sm" ${later()}>${p.until === first ? "续约" : "调整"}</button>`
    : `<button class="btn sm${p.until <= first ? " pri" : ""}" data-ct="${p.pid}">${p.until <= first ? "续约" : "调整"}</button>${p.release_fee != null ? ` <button class="btn sm" data-rel="${p.pid}">解约</button>` : ""}`;
  return `<div class="view" style="grid-template-columns:minmax(0,1fr)"><div class="card">
    <div class="ch">合同<span class="r">本季到期 <b class="dn">${exp}</b> 人 · 周薪合计 <b style="color:var(--gold)">${kfmt(total)}</b>${real && sq.cap ? ` / 上限 ${kfmt(sq.cap)}` : ""}</span></div>
    <div class="cb scroll"><table><thead><tr><th>位置</th><th>球员</th><th class="n">年龄</th><th class="n">能力</th><th class="n">周薪</th><th class="n">身价</th><th>定位</th><th class="n">到期</th><th class="c">操作</th></tr></thead><tbody>
    ${rows.map((p) => `<tr class="go-row" data-player="${p.pid}"><td>${pos(p.position, p.group)}</td><td class="name">${pface(p)}<b>${esc(p.name)}</b></td><td class="n">${p.age ?? "—"}</td><td class="n">${ovr(p.overall)}</td><td class="n"><span class="num" style="color:var(--gold)">${kfmt(p.wage)}</span></td><td class="n"><span class="num">${money(p.value)}</span></td><td class="ct-role ${roleCls(p.role)}">${p.role ? esc(roleTag(p.role)) : `<span class="muted">—</span>`}${p.relationship?.state === "seeking" ? `<small class="dn" title="${esc(p.relationship.reason)}"> · 希望转会</small>` : p.relationship?.state === "concerned" ? `<small class="warn" title="${esc(p.relationship.reason)}"> · 留队存疑</small>` : ""}</td><td class="n ${p.until <= first ? "dn" : ""}">${p.until ? p.until + ".06" : "—"}</td><td class="c">${act(p)}</td></tr>`).join("")}</tbody></table></div></div></div>`;
}
/* ---- 合同操作（2026-11-14，M4 批 7）：续约（球员要价、年限、周薪上限）/ 解约（赔偿剩余周薪的一半）。服务端 iml_finance；周薪一律 K / 周。 ---- */
// M6-E2：定位兑现——“主力 · 首发 6/10 ✓”；不足 4 场写“还在观察”。r＝服务端 iml_terms.role_table 的一行（没有许诺的球员为 null）
const roleTag = (r) => !r ? "" : `${ROLE_ZH[r.role]} · ${r.judged ? `参与 ${r.participation ?? r.starts}/${r.games} ${r.met ? "✓" : "✗"}` : `参与 ${r.participation ?? r.starts}/${r.games} · 还在观察`}`;
const roleCls = (r) => !r || !r.judged ? "" : r.met ? "up" : r.gap >= 2 ? "dn" : "warn";
async function ctRenew(pid) {
  const ps = await squadRows(), p = ps && ps.find((x) => String(x.pid) === String(pid)); if (!p) return;
  const sq = await biz("squad"), cur = 2026 + (S.career.season || 1); let years = 3;
  const q = await post("/api/contract/quote", { card: p.pid });                 // M6-E2：每个定位的要价、本季兑现情况
  const quoted = q && !q.error && q.want, roles = quoted ? q.roles : [];
  if (quoted && q.talk && !q.talk.can_offer) {
    const t = q.talk;
    return mkDialog("续约进度", fmSheet(fmWho(p, { facts: [["现周薪", kfmt(p.wage)]] }),
      fmQuote("经纪人", esc(t.text || "等待答复")) + fmSec("", `<p>${t.state === "pending" ? `预计 ${esc(t.reply_on)} 答复，推进日期后查看。` : `本轮谈判已结束${t.cooldown_until ? `，${esc(t.cooldown_until)} 后可再谈` : ""}。`}</p>`)), [{ label: "关闭" }], "fm");
  }
  let role = quoted ? (q.role || "starter") : null;
  const ask = (r = role) => (quoted ? Math.ceil(q.want[r] * (q.duration_by_year?.[String(years)]?.factor || 1) - 1e-9) : p.demand);
  const wageIn = () => Math.max(0, Math.round(+$("#ct-wage").value || 0)), ending = p.until <= cur;
  // FM 式谈判单（2026-11-14 用户：“做成类FM的那种感觉吧”）：经纪人开价、周薪对比要价、年限分段与续到年份、薪资结构条；E2 加定位与兑现
  const who = fmWho(p, { color: tcolor(me()), crest: `<span class="fm-cl">${crest(me(), "sm")}${esc(tname(me()))}</span>`, tag: ending ? "本季到期" : "",
    facts: [["现周薪", kfmt(p.wage)], ["合同到", `${p.until}.06`], ["定位", quoted && q.kept ? roleTag(q.kept) : quoted && q.role ? ROLE_ZH[q.role] : "未定"]] });
  const kept = quoted && q.kept, short = kept && kept.judged && kept.gap > 0;
  const voice = short
    ? fmQuote("经纪人", `你许诺他是<b>${ROLE_ZH[kept.role]}</b>，本季参与折算为 ${kept.participation ?? kept.starts}/${kept.games} 场（替补按⅓计，已知伤缺不计机会）。${kept.gap >= 2 ? "按原来的定位，他不会再降价续约了——要么给更低的定位，要么给足周薪。" : "想按原定位续约，周薪得再高一些（未兑现每差一档 +10%）。"}`, "bad")
    : fmQuote("经纪人", `${ending ? "合同这个赛季就到期了。" : ""}想留下他，${quoted ? `按“${ROLE_ZH[role]}”定位他希望周薪 <b class="gold">${kfmt(ask())}</b> 左右` : `他希望周薪 <b class="gold">${kfmt(p.demand)}</b> 左右`}。`, ending ? "bad" : "");
  const SHARE = { core: "参与 70%+（替补按⅓计）", starter: "参与 50%+（替补按⅓计）", rotation: "参与 20%+（替补按⅓计）", prospect: "参与 10%+（替补按⅓计）" };
  // E334：要价本来就是真实价（到期年 +10%、定位系数、未兑现 +10%/档），这里把它拆开写：基础 = 市场周薪，加成逐项列出
  const card = (r) => { const d = q.detail && q.detail[r];
    const adj = d && d.parts.length ? fmAdj(d.parts) : "";
    return fmRoleCard({ r, on: r === role, name: ROLE_ZH[r], price: kfmt(q.want[r]), share: SHARE[r], tip: adj ? `基础 ${kfmt(d.base)} · ${adj}` : "",
      tags: (q.firm || []).includes(r) ? `<u class="warn">要价不降</u>` : r === q.role ? `<u class="now">现在</u>` : "",
      sub: adj ? `基础 ${kfmt(d.base)} · ${esc(adj.split(" · ")[0])}` : "要价" }); };
  // 2026-11-16 用户：“要在一个屏幕内把所有信息展示出来，不要上下滑动”——两栏：左＝定位＋薪资结构，右＝周薪＋年限＋他的看法
  const main = `<div class="fm-cols three${quoted ? "" : " no-roles"}"><div class="fm-c">${quoted ? fmSec("队内定位", `<div class="fm-roles">${roles.map(card).join("")}</div>`) : ""}${voice}</div>
      <div class="fm-c">${fmSec("新周薪", `<div class="fm-row">${fmStep("ct-wage", ask(), { step: 1, min: 1, unit: "K € / 周" })}
        <span class="fm-quick" id="ct-wq"></span></div>${fmMeter("ct-ask", "ct-wage")}`)}${fmInl("合同年限", `${fmSeg("years", [1, 2, 3, 4, 5].map((y) => [y, `${y}年`]), years)}<small class="fm-note" id="ct-until"></small>`)}${fmSec("", fmMeter("ct-pay"))}</div>
      <div class="fm-c fm-opin">${fmSec("他的看法", fmFeed("ct-feed"))}</div></div>`;
  const el = mkDialog("续约", fmSheet(who, main + fmSec("谈判安排", `<p>${esc(q?.attitude?.text || "愿意商谈续约")}${q?.relationship?.observed ? ` · ${esc(q.relationship.reason)}` : ""} ${q?.talk?.text ? ` · 上次答复：${esc(q.talk.text)}` : ""} · 隔天答复 · 本轮剩余 ${q?.talk?.offers_left ?? 3} 次报价</p>`), "wide"),
    [{ label: "取消" }, { label: "送出报价", pri: true, fn: async () => { const r = await post("/api/contract/renew", { card: p.pid, years, wage: wageIn(), role }); if (mkFail(r)) return false; sound("ok"); await mkAfter(`${p.name} 的续约报价已送出，预计 ${r.reply_on} 答复`); } }], "fm");
  const quick = () => { const w = ask(); $("#ct-wq", el).innerHTML = `<button class="chip sm" data-fill="ct-wage:${w}">按要价</button><button class="chip sm" data-fill="ct-wage:${Math.round(w * 1.1)}">+10%</button>`; };
  const paint = () => { years = +fmSegVal(el, "years") || years; const w = wageIn(), want = ask(), r = w / Math.max(1, want);
    $$(`[data-role]`, el).forEach((b) => { $(".rp", b).textContent = kfmt(ask(b.dataset.role)); });
    const d = w - p.wage;
    $("#ct-until", el).textContent = `续到 ${cur + years - 1}.06 · ${d >= 0 ? "涨薪" : "降薪"} ${kfmt(Math.abs(d))}/周 · 每季${d >= 0 ? "新增" : "节省"} ${money(Math.abs(d) * 52 / 1000, 1)}`;
    fmMeterSet($("#ct-ask", el), { add: w, cap: want, max: want * 1.5, tone: fmTone(r), label: gapTxt(r, quoted ? `${ROLE_ZH[role]}要价` : "他的期望"), value: `${Math.round(r * 100)}%` });
    fmMeterSet($("#ct-pay", el), { base: sq.payroll - p.wage, add: w, cap: sq.cap, max: sq.cap * 1.05, tone: "mid", label: "周薪合计 / 上限", value: `${kfmt(sq.payroll - p.wage + w)} / ${kfmt(sq.cap)}` });
    quick(); fmBind($("#ct-wq", el), paint); feed(); };
  const feed = fmFeedLoader(el, "/api/contract/preview", () => ({ card: p.pid, years: +fmSegVal(el, "years") || years, wage: wageIn(), role }), ROLE_ZH, (c) => applyCounter(c));
  const setRole = (r) => { role = r; $$("[data-role]", el).forEach((x) => x.classList.toggle("on", x.dataset.role === role)); };
  const applyCounter = (c) => { if (c.role && roles.includes(c.role)) setRole(c.role); $("#ct-wage", el).value = c.wage;
    if (c.years) $$('[data-seg="years"] button', el).forEach((x) => x.classList.toggle("on", x.dataset.v === String(c.years))); paint(); };
  fmBind(el, paint);
  $$("[data-role]", el).forEach((b) => b.onclick = () => { setRole(b.dataset.role); sound("cursor"); $("#ct-wage", el).value = ask(); paint(); });
  paint();
}
async function ctRelease(pid) {
  const ps = await squadRows(), p = ps && ps.find((x) => String(x.pid) === String(pid)); if (!p || p.release_fee == null) return;
  const who = fmWho(p, { color: tcolor(me()), crest: `<span class="fm-cl">${crest(me(), "sm")}${esc(tname(me()))}</span>`, facts: [["周薪", kfmt(p.wage)], ["合同到", `${p.until}.06`], ["身价", money(p.value, 1)]] });
  const main = fmQuote("董事会", `解约要付合同剩余周薪的一半作为赔偿，从转会预算里出。<b>他会立即离队，不能撤销。</b>`, "bad")
    + fmSec("这笔账", fmTiles([["解约赔偿", money(p.release_fee, 1), "var(--loss)"], ["每周省下", kfmt(p.wage), "var(--win)"], ["一季省下", money(p.wage * 52 / 1000, 1), "var(--win)"]]));
  mkDialog("解约", fmSheet(who, main),
    [{ label: "取消" }, { label: `解约 · 付 ${money(p.release_fee, 1)}`, pri: true, warn: true, fn: async () => { const r = await post("/api/contract/release", { card: p.pid }); if (mkFail(r)) return false; sound("ok"); await mkAfter(`已解约 ${r.name}，赔偿 ${money(r.fee, 1)}`); } }], "fm");
}
async function viewInjuries(name) {
  const ps = await squadRows(); if (!ps) return viewPlan("squad", name);
  const hurt = ps.filter((p) => p.injury), fit = [...ps].sort((a, b) => (a.fitness ?? 100) - (b.fitness ?? 100));
  return `<div class="view" style="grid-template-columns:minmax(0,1fr) minmax(0,1.2fr)">
    <div class="card" style="--i:0"><div class="ch">伤病名单<span class="r">${hurt.length} 人</span></div><div class="cb scroll">
      ${hurt.map((p) => `<div class="inj" data-player="${p.pid}" style="cursor:pointer">${pos(p.position, p.group)}<div><b>${pface(p)}${esc(p.name)}</b><span>${esc(p.injury.name)}</span></div><div class="wk"><span class="num">${p.injury.weeks}</span> 周</div></div>`).join("") || `<div class="empty-note">全员健康</div>`}</div></div>
    <div class="card" style="--i:1"><div class="ch">体能<span class="r">低于 70% 建议轮换</span></div><div class="cb scroll"><table><tbody>
      ${fit.map((p) => `<tr class="go-row" data-player="${p.pid}"><td>${pos(p.position, p.group)}</td><td class="name">${pface(p)}<b>${esc(p.name)}</b></td><td style="width:45%">${bar(p.fitness ?? 0, (p.fitness ?? 0) < 70 ? "var(--loss)" : "var(--blue)")}</td><td class="n"><span class="num">${p.fitness ?? "—"}%</span></td></tr>`).join("")}</tbody></table></div></div></div>`;
}
// E321 青训（2026-11-16 用户定规则）：每季 3 月 15 日青训日，全库真人抽成 16～17 岁新人（服务端 iml_youth）。
// 页面：待揭晓的新人按顺序连播 ytReveal，播完告诉服务端；学员卡片可回放；队伍满时的新人在“等待签约”里签。
function ytArg(r) {      // 服务端给 id / 名称，队色和简称由前端补（同其它页面的 tcode / tcolor）
  // 卡上没有俱乐部（传奇卡、国家队卡）：立牌写我们自己的俱乐部——他进的是我们的青训营（用户不要问号）
  const own = me(), c = r.club && r.club.id ? { ...r.club, code: r.club.code || tcode(r.club.id), c: tcolor(r.club.id) } : { id: own, name: tname(own), code: tcode(own), c: tcolor(own) };
  return { ...r, club: c, nation: r.nation || {} };
}
async function ytPlayPending() {
  const d = await biz("youth"); if (!d || !d.pending_reveal || !d.pending_reveal.length) return;
  for (const r of d.pending_reveal) await ytReveal(ytArg(r));
  await post("/api/youth/revealed", { cards: d.pending_reveal.map((r) => r.pid) }).catch(() => null);
  delete BIZ.youth; quietDraw = true; draw();
}
async function viewYouth(name) {
  const d = await biz("youth");
  if (!d || d.error) return `<div class="view v-plan" style="grid-template-columns:minmax(0,1fr)">
    <div class="card plan-hero" style="--i:0"><span class="big">${svg("squad", 1.2)}</span><small>暂未开放</small><b>青训</b>
      <p>青训营还没有开放，目前不会产出新人。</p>
      <div><button class="btn" data-ytdemo title="青训出人时的揭晓演出（样例球员，不会进队）">预览出人演出</button></div></div></div>`;
  // 2026-11-16 用户“青训营的 UI 太简陋”：左侧青训营面板（队徽、学员数、下一次青训日倒计时、待揭晓时的卡背堆＋揭晓按钮），
  // 右侧学员卡用真卡面缩略图＋能力→潜力成长条，卡边一抹档位色（同揭晓演出的六档颜色，不写档位名）
  const pend = d.pending_reveal || [], wait = d.waiting || [], ac = d.academy || [], own = me();
  const [nm, nd] = (d.next_day || d.youth_day).slice(5).split("-").map(Number);
  const days = d.days_to == null ? "—" : Math.max(0, d.days_to);
  const side = `<aside class="card yt-side" style="--i:0;--yt-crest:url('/img/emblem/${own}.png')">
      <div class="yt-crest"><img src="/img/emblem/${own}.png" alt="" onerror="this.style.visibility='hidden'"><div><small>ACADEMY</small><b>青训营</b><span>${esc(tname(own))}</span></div></div>
      <div class="yt-stats"><div><span class="num">${ac.length}</span><small>学员</small></div><div><span class="num">${d.new_this_season || 0}</span><small>本季新人</small></div><div><span class="num">${days}</span><small>天后青训日</small></div></div>
      <div class="yt-next">${svg("cal", 1)}<span>下一次青训日</span><b>${nm} 月 ${nd} 日</b><em>${d.intake[0]}～${d.intake[1]} 人</em></div>
      ${wait.length ? `<button class="yt-waitbtn" data-ytwait title="队伍满员时进不了队的新人：签约或放弃"><span class="num">${wait.length}</span><span class="yt-wb-t"><b>等待签约</b><small>队伍满员时进不了队的新人</small></span><i>›</i></button>` : ""}
      ${pend.length
        ? `<button class="yt-cta" data-ytplay><span class="yt-stack">${pend.slice(0, 4).map((_, i) => `<i style="--k:${i};background-image:url('/img/emblem/${own}.png')"></i>`).join("")}</span>
            <span class="yt-cta-t"><b>揭晓新人</b><small>${pend.length} 名新人等待揭晓</small></span></button>`
        : `<p class="yt-note">每个赛季迎来一批 16～17 岁的新人，从球员库里抽出真实球员。按潜力成长，上场越多长得越快。</p>
           <button class="btn sm yt-demo" data-ytdemo title="样例球员，不会进队">预览出人演出</button>`}
    </aside>`;
  const card = (y, i) => {
    // 还没揭晓的新人：只显示卡背（用户要的是开包的惊喜，揭晓前名单上不能先露出名字和卡面）
    if (y.revealed === false) return `<div class="ytc ytc-hid" style="--i:${i}" data-ytplay title="点击揭晓"><div class="ytc-art ytc-back" style="background-image:url('/img/emblem/${own}.png')"></div>
      <div class="ytc-body"><div class="ytc-top"><span class="muted">第 ${y.season} 季新人</span></div><b class="ytc-name">待揭晓</b><small class="muted">点击揭晓这名新人</small></div></div>`;
    const hi = y.potential_range ? y.potential_range[1] : y.potential || y.overall, lo = y.potential_range ? y.potential_range[0] : hi, base = 40;
    const pct = (v) => Math.max(0, Math.min(100, (v - base) / Math.max(1, hi - base) * 100));
    return `<div class="ytc" style="--i:${i};--tc:${YT_TIER_C[y.tier] || "var(--line2)"}">
      <div class="ytc-art"><img src="/img/card/${y.pid}.png" alt="" loading="lazy" onerror="this.style.visibility='hidden'"></div>
      <div class="ytc-body">
        <div class="ytc-top">${pos(y.position)}<span title="第 ${y.season} 季入营">${y.age} 岁</span>
          <div class="ytc-acts">${y.reveal ? `<button class="ytc-replay ytc-play" data-yt="${y.pid}" title="揭晓回放" aria-label="揭晓回放">${svg("play", 0.9)}</button>` : ""}<button class="ytc-replay ytc-rel" data-ytrelease="${y.pid}" title="放走这名学员（按合同解约，付剩余周薪的一半）">放走</button></div></div>
        <b class="ytc-name" data-player="${y.pid}">${esc(y.name)}</b>
        <div class="ytc-num"><span><small>能力</small>${ovr(y.overall)}</span><span class="ytc-to">→</span><span><small>潜力</small><span class="num">${lo === hi ? hi : `${lo}–${hi}`}</span></span>${y.up ? `<em class="up">本季 +${y.up}</em>` : ""}</div>
        <div class="ytc-bar"><s style="left:${pct(lo)}%"></s><i style="width:${pct(y.overall)}%"></i></div>
        ${talentChips(y.talent)}      </div></div>`;
  };
  const list = ac.length ? `<div class="ytgrid">${ac.map(card).join("")}</div>`
    : `<div class="yt-empty"><span>${svg("squad", 1.4)}</span><b>还没有青训出身的球员</b><small>青训日到来时，新人会出现在这里</small></div>`;
  return `<div class="view yt-view">${side}<section class="yt-main">
    <div class="card yt-list" style="--i:2"><div class="ch">学员<span class="r">潜力为球探预估，观察越久越准</span></div><div class="cb scroll">${list}</div></div></section></div>`;
}
// 2026-11-17 用户：“等待签约做成二级菜单吧 要按钮进入 不然太占空间了”——左栏按钮打开这个弹窗；签约 / 放弃都在弹窗里，做完原地刷新，没人了自动关。
// 放弃＝点一下变“确认放弃”，3 秒内再点才执行（不再叠第二个弹窗）。成功不弹提示（2026-11-14 用户）。
async function ytWaitOpen() {
  delete BIZ.youth;
  const d = await biz("youth"), wait = (d && d.waiting) || [];
  quietDraw = true; draw();
  if (!wait.length) { $$("#mkdlg").forEach((e) => e.remove()); return; }
  // 2026-11-17 用户“等待签约希望可以点进去看到球员的数据吧”：点一行展开他的卡面、能力→潜力、年龄、天赋方向、各能力组（服务端 iml_youth.waiting_facts）。
  // 还没揭晓的新人不露名字和数据（同学员卡），只给“去揭晓”。
  const tal = (w) => Object.fromEntries((w.talent || []).map((t) => [t.group, t.kind]));
  const det = (w) => { const pr = w.potential_range, t = tal(w);
    return `<div class="yw-det"><div class="yw-art"><img src="/img/card/${w.pid}.png" alt="" loading="lazy" onerror="this.style.visibility='hidden'"></div><div class="yw-info">
      <div class="yw-kv"><span><small>能力</small>${ovr(w.overall)}</span><span class="ytc-to">→</span><span><small>潜力</small><b class="num">${pr ? (pr[0] === pr[1] ? pr[1] : `${pr[0]}–${pr[1]}`) : "—"}</b></span><span><small>年龄</small><b class="num">${w.age ?? "—"}</b></span></div>
      ${talentChips(w.talent)}
      <div class="yw-groups">${(w.groups || []).map((g) => `<div class="yw-g ${t[g.group] || ""}"><span>${esc(g.name)}</span><i><s style="width:${Math.max(0, Math.min(100, (g.value - 30) / 69 * 100))}%"></s></i><b class="num">${g.value}</b></div>`).join("")}</div>
    </div></div>`; };
  const row = (w) => w.revealed === false
    ? `<div class="yw-item"><div class="ywait"><span class="muted">第 ${w.season} 季新人</span><b>待揭晓</b><button class="btn sm" data-wplay>去揭晓</button></div></div>`
    : `<div class="yw-item" data-wopen="${w.pid}"><div class="ywait" style="--tc:${YT_TIER_C[w.tier] || "var(--line2)"}">${pos(w.position)}<b title="点开看数据">${esc(w.name)}</b>
      <span class="yw-ovr">${ovr(w.overall)}</span><i class="yw-chev">›</i><button class="btn sm pri" data-wsign="${w.pid}">签约</button><button class="ywait-x" data-wdecl="${w.pid}" title="不花钱，放弃后不能再签">放弃</button></div>${det(w)}</div>`;
  const el = mkDialog(`等待签约 · ${wait.length} 人`, `<p class="dlg-p">点新人看数据。队伍满员先放走一人再签；放弃不花钱，但不能再签。</p>
      <div class="ytw-list">${wait.map(row).join("")}</div>`, [{ label: "关闭" }]);
  $$("[data-wopen] .ywait", el).forEach((r) => r.onclick = (e) => { if (e.target.closest("button")) return; const it = r.parentElement; sound("cursor");
    const open = !it.classList.contains("open"); $$(".yw-item.open", el).forEach((x) => x.classList.remove("open")); it.classList.toggle("open", open); });
  $$("[data-wplay]", el).forEach((b) => b.onclick = () => { $$("#mkdlg").forEach((e) => e.remove()); sound("page"); ytPlayPending(); });
  $$("[data-wsign]", el).forEach((b) => b.onclick = async () => { b.disabled = true; const r = await post("/api/youth/sign", { card: +b.dataset.wsign });
    if (mkFail(r)) { b.disabled = false; return; } sound("ok"); ytWaitOpen(); });
  $$("[data-wdecl]", el).forEach((b) => b.onclick = async () => {
    if (!b.classList.contains("arm")) { sound("cursor"); b.classList.add("arm"); b.textContent = "确认放弃"; setTimeout(() => { if (b.isConnected) { b.classList.remove("arm"); b.textContent = "放弃"; } }, 3000); return; }
    b.disabled = true; const r = await post("/api/youth/decline", { card: +b.dataset.wdecl }); if (mkFail(r)) { b.disabled = false; return; } sound("ok"); ytWaitOpen(); });
}
const YT_TIER_C = ["#9fb2c6", "#3fd68c", "#4ea8ff", "#c86bff", "#f2c14e", "#ffe6a8"];      // signing3d.js TIERS 的颜色（T2～T7）
// 2026-11-17 用户“显示出来”：青训新人的天赋方向（服务端 iml_growth.talent_view，档案 v2 才有）——强项／次强项／弱项三个小标签，名称放 title
// 圆点里用符号不用“强/次/弱”：页面多语言是按文本节点整段替换，单字“次”在词库里已是计数单位（times），会被误译
const TALENT_T = { strong: ["▲", "天赋强项：这组能力扣得少、长得最快"], second: ["△", "次强项：长得比一般快"], weak: ["▼", "弱项：这组能力起点低、长得慢"] };
function talentChips(t, cls = "") {
  if (!Array.isArray(t) || !t.length) return "";
  return `<div class="tal ${cls}">${t.map((x) => `<span class="tal-c ${x.kind}" title="${esc((TALENT_T[x.kind] || ["", ""])[1])}"><i>${(TALENT_T[x.kind] || ["·"])[0]}</i>${esc(x.name)}</span>`).join("")}</div>`;
}
// 全球新闻：本联赛已结算记录 + 其他联赛按生涯日期存储的模拟赛果。
// 2026-11-15 改版成足球媒体站样式；2026-11-18 E360 重构（用户：“现在的新闻板块太乱了 信息也点不开 有些新闻看不全 而且重点不明了”，选样稿方案 A）：
//   左边频道（要闻 / 我的俱乐部 / 转会 / 各联赛）→ 中间一行一条的标题列表（要闻频道顶上固定“本周要闻”3 条）→ 右边阅读区显示全文与“查看”跳转。
//   窄屏（≤800px 宽）阅读区改为点开后覆盖整块、带返回。转会频道（用户：“把自由球员里的转会新闻放到新闻里”）是一张转会表（样稿方案 B）。
//   不用容器单位（旧 WebView，见 E359）。
let newsCh = "top", newsShown = 18, newsSel = -1, newsXf = "all";
let newsItems = [];                       // 当前这次渲染的新闻（带 _i 下标），阅读区就地换内容时用
const NEWS_PAGE = 18;
document.addEventListener("click", (event) => {
  // 自由球员页的“转会新闻 ›”：直接打开新闻中心的转会频道
  if (event.target.closest("[data-news-xfer]")) { newsCh = "xfer"; newsXf = "all"; sound("page"); openSec("home", 2); return; }
  if (cur.sec !== "home" || cur.tab !== 2) return;
  const ch = event.target.closest("[data-news-ch]");
  if (ch) {
    const v = ch.dataset.newsCh, next = /^\d+$/.test(v) ? Number(v) : v;
    if (next === newsCh) return;
    newsCh = next; newsShown = NEWS_PAGE; newsSel = -1; sound("cursor"); draw(); return;
  }
  if (event.target.closest("[data-news-more]")) { newsShown += NEWS_PAGE; quietDraw = true; draw(); return; }
  const xf = event.target.closest("[data-nxf]");
  if (xf) { if (xf.dataset.nxf !== newsXf) { newsXf = xf.dataset.nxf; sound("cursor"); quietDraw = true; draw(); } return; }
  if (event.target.closest("[data-news-back]")) { const w = $(".nw"); if (w) w.classList.remove("reading"); sound("cursor"); return; }
  const it = event.target.closest("[data-nid]");
  if (it) { newsOpen(+it.dataset.nid); sound("cursor"); }
});
// 选中一条：只换阅读区与高亮，不重读、不重画整页
function newsOpen(i) {
  newsSel = i;
  const n = newsItems.find((x) => x._i === i), rd = $("#nwRead"), w = $(".nw");
  if (rd) { rd.innerHTML = newsReader(n); rd.scrollTop = 0; bindPage(rd); }
  $$(".nw [data-nid]").forEach((b) => b.classList.toggle("on", +b.dataset.nid === i));
  if (w) w.classList.add("reading");
}
// "2026-08-15" -> "8月15日"；非日期格式（旧存档/预览）原样显示
function newsDay(when) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(when || ""));
  return m ? `${Number(m[2])}月${Number(m[3])}日` : String(when || "");
}
function newsGoLabel(go) {
  return go === "review" ? "赛季总结" : go === "season:0" ? "积分榜" : go.startsWith("squad:4") ? "伤病" : go === "squad:5" || go === "training:3" ? "青训" : go.startsWith("training") ? "成长记录"
    : go.startsWith("transfer") ? "转会" : go.startsWith("squad:3") ? "合同" : go.startsWith("squad:") ? "球员" : "赛程";
}
// 栏目标签：[文字, 颜色类]
const NEWS_TAG = {
  champion: ["夺冠", "gold"], title_secured: ["夺冠", "gold"], leader_change: ["榜首", "gold"], leader_gap: ["榜首", "gold"], title_race: ["争冠", "gold"],
  season_review: ["赛季总结", "gold"], standings: ["积分榜", "gold"], rank_up: ["排名", "green"], rank_down: ["排名", "red"],
  upset: ["爆冷", "amber"], top_clash: ["强强对话", "blue"], round_summary: ["本轮综述", "blue"], round_shutouts: ["本轮综述", "blue"],
  big_win: ["大胜", "green"], heavy_loss: ["惨败", "red"], shootout: ["进球大战", "amber"], goals_draw: ["进球大战", "amber"], goalless: ["战报", "blue"],
  win_run: ["连胜", "green"], home_wins: ["连胜", "green"], away_wins: ["连胜", "green"], unbeaten: ["不败", "green"], home_unbeaten: ["不败", "green"],
  clean_run: ["零封", "green"], scoring: ["火力", "green"], attack_form: ["火力", "green"], first_win: ["首胜", "green"], end_winless: ["走出低谷", "green"],
  end_losses: ["止败", "green"], end_drought: ["破荒", "green"], loss_run: ["连败", "red"], winless: ["不胜", "red"], away_winless: ["不胜", "red"],
  conceding: ["防线", "red"], defense_alarm: ["防线", "red"], goal_drought: ["进球荒", "red"], end_unbeaten: ["不败终结", "red"],
  xfer_free: ["自由身", "purple"], xfer_buy: ["转会", "purple"], xfer_big: ["大额转会", "gold"], xfer_xl: ["跨联赛转会", "purple"],
  signing: ["转会", "purple"], sale: ["转会", "purple"], bid_rejected: ["转会", "purple"], talks_failed: ["转会", "purple"],
  injury: ["伤病", "red"], growth: ["成长", "green"], decline: ["成长", "red"], contract: ["合同", "blue"],
};
const NEWS_WEIGHT = {
  champion: 10, title_secured: 9, season_review: 8, leader_change: 8, upset: 7, top_clash: 7, signing: 7, title_race: 6, big_win: 6, heavy_loss: 6, sale: 6,
  injury: 5, shootout: 5, goals_draw: 4, first_win: 5, end_losses: 5, end_unbeaten: 5, win_run: 5, loss_run: 5, rank_up: 4, rank_down: 4, leader_gap: 4,
  xfer_big: 7, xfer_xl: 6, xfer_buy: 3, xfer_free: 2,
  unbeaten: 4, end_winless: 4, end_drought: 4, growth: 3, contract: 3, standings: 1, bid_rejected: 3, talks_failed: 3,
};
const newsScore = (n) => (NEWS_WEIGHT[n.topic] || (n.topic === "result" ? 1 : 2)) + (n.mine ? 3 : 0);
function newsTag(n) {
  const t = NEWS_TAG[n.topic] || ["战报", "blue"];
  return `<b class="nt nt-${t[1]}">${t[0]}</b>`;
}
function newsGoBtn(n) {
  return n.go ? `<button class="btn" ${n.go === "review" ? 'data-act="review"' : `data-tab="${esc(n.go)}"`}>查看${newsGoLabel(n.go)} ›</button>` : "";
}
function newsDate(n) { return `${esc(newsDay(n.when))}${n.fixture ? ` · 第 ${esc(n.fixture)} 轮` : ""}`; }
// 图片区：关联球队的队徽（最多两支，对阵类并排），球队主色渐变；没有关联球队（本轮综述等）用联赛标志
function newsArt(n, size) {
  const ids = (n.teams || []).slice(0, 2);
  const c1 = ids.length ? tcolor(ids[0]) : "#3a3d45", c2 = ids.length > 1 ? tcolor(ids[1]) : c1;
  const marks = ids.length ? ids.map(t => crest(t, size)).join("") : `<span class="cw ${size}"><img src="/img/comp/L${esc(n.league_id)}.png" alt="" onerror="this.remove()"></span>`;
  return `<div class="np-art${ids.length > 1 ? " duo" : ""}" style="--tc:${esc(c1)};--tc2:${esc(c2)}">${marks}</div>`;
}
const newsMeta = (n) => `${esc(n.league || "")}${n.league ? " · " : ""}${newsDate(n)}`;
// 阅读区 / 文章页：全文（正文不截断）＋“查看…”跳转＋相关新闻（同队的其他几条）；窄屏和要闻头版里带“返回”
function newsArticle(n) {
  const a = n.article, [hq, ...rest] = String(n.body || "").split("\n");
  const quote = rest.join(" ").trim();
  const tl = (a.timeline || []).map((g) => `<li class="${g.team === a.home ? "h" : "a"}"><b>${g.min}'</b>${crest(g.team, "sm")}<span><strong translate="no">${esc(g.name)}</strong>${g.assist ? `<small>assist ${esc(g.assist)}</small>` : ""}</span></li>`).join("");
  const st = (a.stats || []).map(([k, x, y]) => { const nx = parseFloat(x) || 0, ny = parseFloat(y) || 0, t = nx + ny || 1; return `<div class="na-st"><b>${esc(String(x))}</b><span><i style="width:${Math.round(nx / t * 100)}%"></i></span><em>${esc(k)}</em><span class="r"><i style="width:${Math.round(ny / t * 100)}%"></i></span><b>${esc(String(y))}</b></div>`; }).join("");
  const rt = (k) => (a.ratings[k] || []).map((p) => `<div class="na-rt">${pface(p, "mr-pf")}<span translate="no">${esc(shortName(p.name))}${p.g ? ` <i class="mr-g">${"●".repeat(Math.min(p.g, 4))}</i>` : ""}${p.a ? ` <i class="mr-a">A${p.a > 1 ? p.a : ""}</i>` : ""}</span><b class="mr-pill ${p.r >= 7.5 ? "hi" : p.r >= 6.5 ? "mid" : "lo"}">${p.r.toFixed(1)}</b></div>`).join("");
  return `<div class="na">
    <div class="na-board">${crest(a.home, "lg")}<b>${a.score[0]}</b><i>–</i><b>${a.score[1]}</b>${crest(a.away, "lg")}</div>
    ${(a.paras || []).map((p, i) => /^\d+' - /.test(p) ? `<p class="na-cm"><b>${esc(p.split(" - ")[0])}</b>${esc(p.slice(p.indexOf(" - ") + 3))}</p>` : `<p class="${i === 0 ? "na-lead" : ""}">${esc(p)}</p>`).join("")}
    ${(a.voices || []).map((v) => `<blockquote class="na-q na-v">${crest(v.team, "sm")}<span>“${esc(v.text)}”<small translate="no">${esc(v.who)} · ${esc(v.role || "")}</small></span></blockquote>`).join("")}
    ${tl ? `<h4>Goals</h4><ul class="na-tl">${tl}</ul>` : ""}
    ${a.motm ? `<div class="na-motm">${pface(a.motm, "mr-pf big")}<span><small>Player of the match</small><b translate="no">${esc(a.motm.name)}</b></span><b class="mr-pill hi">${a.motm.r.toFixed(1)}</b></div>` : ""}
    ${quote ? `<blockquote class="na-q">${esc(quote)}</blockquote>` : ""}
    ${a.player_quote ? `<blockquote class="na-q pl">“${esc(a.player_quote.q)}” — ${esc(a.player_quote.by)}</blockquote>` : ""}
    <h4>Match stats</h4><div class="na-stats">${st}</div>
    <h4>Top performers</h4><div class="na-rts"><div>${rt("home")}</div><div>${rt("away")}</div></div></div>`;
}
function newsReader(n) {
  if (!n) return `<div class="empty-note">点左边任意一条新闻查看全文</div>`;
  const ids = new Set((n.teams || []).map(Number));
  const rel = ids.size ? newsItems.filter((x) => x !== n && x._i !== n._i && (x.teams || []).some((t) => ids.has(Number(t)))).slice(0, 3) : [];
  // 返回键（用户：“这个返回键做得直观一点，然后放在左上角吧”）：放在文章大图左上角，箭头＋文字的按钮
  return `<div class="nw-rd-art"><button class="nw-back" data-news-back aria-label="${newsCh === "top" ? "返回头版" : "返回列表"}"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M10 3 5 8l5 5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>${newsCh === "top" ? "返回头版" : "返回列表"}</button>${newsArt(n, "xl")}</div>
    <div class="nw-rd-b">
      <div class="nw-kick">${newsTag(n)}${n.mine ? `<u>我的俱乐部</u>` : ""}</div>
      <h3>${esc(n.title)}</h3><small class="nw-meta">全球足球讯 · ${newsMeta(n)}</small>
      ${n.article ? newsArticle(n) : n.body ? `<p>${esc(n.body)}</p>` : ""}<div class="nw-rd-go">${newsGoBtn(n)}</div>
      ${rel.length ? `<div class="nw-rel"><b>相关新闻</b>${rel.map((x) => `<button class="nw-rel-i" data-nid="${x._i}"><span class="nf-k nk-${newsColor(x)}">${newsKicker(x)}</span>${esc(x.title)}<small>${esc(newsDay(x.when))}</small></button>`).join("")}</div>` : ""}</div>`;
}
// 栏目字（新闻站式彩色眉题，不用色块）
const newsKicker = (n) => (NEWS_TAG[n.topic] || ["战报"])[0];
const newsColor = (n) => (NEWS_TAG[n.topic] || [0, "blue"])[1];
// 要闻头版（2026-11-18 用户：“搞点头条啥的 让他像真的新闻网站的UI”）：报头 → 头条大图 + 右侧三条次头条 → “最新消息”带缩略图的两栏信息流；
// 点任何一条打开文章页（盖住头版，带“返回头版”）。其他频道仍是 列表 + 右侧阅读区。
function newsFront(d, rows, latest) {
  const t0 = Date.parse(latest);
  const recent = rows.filter((n) => !(t0 >= 0) || Date.parse(n.when) >= t0 - 7 * 864e5);
  const ranked = (recent.length ? recent : rows).slice().sort((a, b) => newsScore(b) - newsScore(a) || (a.when < b.when ? 1 : -1));
  const hero = ranked[0], side = ranked.slice(1, 4), topSet = new Set([hero, ...side]);
  const rest = rows.filter((n) => !topSet.has(n)), shown = rest.slice(0, newsShown);
  const kick = (n) => `<span class="nf-k nk-${newsColor(n)}">${newsKicker(n)}</span>${n.mine ? `<u class="nf-mine">我的俱乐部</u>` : ""}`;
  const heroHtml = hero ? `<button class="nf-hero${hero.mine ? " mine" : ""}" data-nid="${hero._i}">${newsArt(hero, "xl")}
      <span class="nf-hero-txt"><span class="nf-kicks"><b class="nf-badge">头条</b>${kick(hero)}</span><b class="nf-h1">${esc(hero.title)}</b>
      ${hero.body ? `<span class="nf-lede">${esc(hero.body)}</span>` : ""}<small>${newsMeta(hero)}</small></span></button>` : "";
  const sideHtml = side.map((n) => `<button class="nf-side-i" data-nid="${n._i}"><span class="nf-kicks">${kick(n)}</span><b>${esc(n.title)}</b><small>${newsMeta(n)}</small></button>`).join("");
  const feed = shown.map((n) => `<button class="nf-li${n.mine ? " mine" : ""}" data-nid="${n._i}"><span class="nf-thumb">${newsArt(n, "sm")}</span>
      <span class="nf-t"><span class="nf-kicks">${kick(n)}</span><b>${esc(n.title)}</b><small>${esc(n.league || "")} · ${esc(newsDay(n.when))}</small></span></button>`).join("");
  const more = rest.length > shown.length ? `<button class="btn nw-more" data-news-more="1">显示更多（还有 ${rest.length - shown.length} 条）</button>` : "";
  return `<div class="nw-front scroll"><header class="nf-mast"><b>全球足球</b><span>新闻中心</span><i>第 ${esc(d.season || 1)} 赛季${latest ? ` · ${esc(newsDay(latest))}` : ""}</i></header>
    <section class="nf-top">${heroHtml}<div class="nf-side">${sideHtml}</div></section>
    ${shown.length ? `<h4 class="nf-sec"><span>最新消息</span></h4><div class="nf-feed">${feed}</div>${more}` : ""}
    <footer class="nw-end">${esc(d.note || "仅展示本生涯已结算的比赛及经营记录。")}</footer></div>`;
}
function newsRow(n) {
  return `<button class="nw-li${n.mine ? " mine" : ""}${n._i === newsSel ? " on" : ""}" data-nid="${n._i}">${newsTag(n)}
    <span class="nw-t"><b>${esc(n.title)}</b><small>${esc(n.league || "")}${n.fixture ? ` · 第 ${esc(n.fixture)} 轮` : ""}${n.mine ? ` · <u>我的俱乐部</u>` : ""}</small></span>
    <span class="nw-when">${esc(newsDay(n.when))}</span></button>`;
}
async function viewNews(name) {
  delete BIZ.news; // 每次进入重读，比赛/转会/逐日推进后不显示旧缓存。
  const d = await biz("news");
  if (!d) return viewPlan("home", name);
  const all = (Array.isArray(d.items) ? d.items : []).map((n, i) => ({ ...n, _i: i }));
  newsItems = all;
  const leagues = d.leagues || [];
  const mineCount = all.filter(n => n.mine).length;
  if (newsCh === "mine" && !mineCount) newsCh = "top";
  if (typeof newsCh === "number" && !leagues.some((l) => l.id === newsCh)) newsCh = "top";
  const latest = all.reduce((m, n) => (n.when > m ? n.when : m), "");
  // 频道栏
  const ch = (key, ico, label, count, cls = "") => `<button class="nw-ch${cls ? " " + cls : ""}${newsCh === key ? " on" : ""}" data-news-ch="${key}" aria-pressed="${newsCh === key}">${ico ? `<span class="nw-ico">${ico}</span>` : ""}<span class="nw-nm">${label}</span>${count == null ? "" : `<i>${count}</i>`}</button>`;
  const lgIco = (id) => `<img src="/img/comp/L${esc(id)}.png" alt="" onerror="this.replaceWith(document.createTextNode('◎'))">`;
  const nav = `<div class="nw-brand"><b>新闻中心</b><small>第 ${esc(d.season || 1)} 赛季${latest ? ` · ${esc(newsDay(latest))}` : ""}</small></div>`
    + ch("top", "", "要闻", all.length)
    + (mineCount ? ch("mine", crest(me(), "sm"), "我的俱乐部", mineCount, "mine") : "")
    + ch("xfer", svg("transfer", 1.7), "转会", null)
    + (leagues.length ? `<b class="nw-sec">联赛</b>` : "")
    + leagues.map((l) => ch(l.id, lgIco(l.id), esc(l.name), l.count || 0)).join("");
  let body;
  if (newsCh === "xfer") body = await newsXferView();
  else if (newsCh === "top") {
    const sel = all.find((n) => n._i === newsSel);
    body = all.length ? `${newsFront(d, all, latest)}<aside class="nw-read scroll" id="nwRead">${newsReader(sel)}</aside>`
      : `<div class="nw-front"><div class="empty-note">暂无新闻<br><small>点击继续推进生涯后更新。</small></div></div>`;
  } else {
    const rows = newsCh === "mine" ? all.filter(n => n.mine) : typeof newsCh === "number" ? all.filter(n => Number(n.league_id) === newsCh) : all;
    // 我的俱乐部 / 各联赛：列表（新的在前）＋右侧阅读区；“要闻”走上面的头版
    const rest = rows, shown = rest.slice(0, newsShown);
    if (!rows.some((n) => n._i === newsSel)) newsSel = (shown[0] || {})._i ?? -1;
    const sel = rows.find((n) => n._i === newsSel);
    const more = rest.length > shown.length ? `<button class="btn nw-more" data-news-more="1">显示更多（还有 ${rest.length - shown.length} 条）</button>` : "";
    const list = rows.length
      ? `${shown.map(newsRow).join("")}${more}
         <footer class="nw-end">${esc(d.note || "仅展示本生涯已结算的比赛及经营记录。")}</footer>`
      : `<div class="empty-note">暂无新闻<br><small>${newsCh === "mine" ? "我的俱乐部暂无简讯。" : "该频道尚无已结算简讯。"}点击继续推进生涯后更新。</small></div>`;
    body = `<div class="nw-list scroll">${list}</div><aside class="nw-read scroll" id="nwRead">${newsReader(sel)}</aside>`;
  }
  return `<div class="view" style="grid-template-columns:minmax(0,1fr)"><div class="card nw${newsCh === "xfer" ? " xf" : newsCh === "top" ? " front" : ""}">
    <nav class="nw-nav scroll">${nav}</nav>${body}</div></div>`;
}
// 转会频道（样稿方案 B）：数据 = /api/biz/world 的 news（本联赛本季的转会与自由签约，含我们和跨联赛；服务端只给最近 30 笔）
async function newsXferView() {
  const [w, club] = await Promise.all([biz("world").catch(() => null), biz("club").catch(() => null)]);
  if (!w || w.demo || !Array.isArray(w.news)) return `<div class="nw-xf scroll"><div class="empty-note">转会新闻需要真实赛季数据（新建游戏后可用）</div></div>`;
  for (const [k, v] of Object.entries(w.teams || {})) if (!S.teams[k]) S.teams[k] = v;      // 跨联赛转会的对方球队名
  const cardOf = new Map();                                                                  // 世界球员 id -> 游戏卡（点一行看球员资料）
  for (const c of w.clubs || []) for (const p of c.players || []) if (p.card) cardOf.set(String(p.id), p.card);
  for (const p of w.free || []) if (p.card) cardOf.set(String(p.id), p.card);
  const mine = me(), all = w.news;
  const us = (e) => e.club === mine || e.from === mine;
  const pick = { all: () => true, mine: us, free: (e) => !e.from, xl: (e) => !!e.xl };
  if (!pick[newsXf] || (newsXf === "xl" && !all.some(pick.xl))) newsXf = "all";
  const rows = all.filter(pick[newsXf]);
  const total = all.reduce((a, e) => a + (+e.fee || 0), 0);
  const win = club && !club.demo && club.window;
  const winTxt = win ? ` · ${win.kind === "winter" ? "冬窗" : "夏窗"}${win.open ? `开放中（剩 ${win.days} 天）` : `${win.days} 天后开启`}` : "";
  const big = all.filter((e) => e.fee).sort((a, b) => b.fee - a.fee).slice(0, 3);
  const bigHtml = big.length ? `<div class="nw-big">${big.map((e, i) => `<div class="nw-big-i"><small>${i ? "#" + (i + 1) : "本季最贵"}</small><b>${esc(e.name)}</b>
      <span>${e.from ? esc(tname(e.from) || "") : "自由身"} → ${esc(tname(e.club) || "")}</span><em>${money(e.fee, 1)}</em></div>`).join("")}</div>` : "";
  const chips = [["all", "全部"], ["mine", "我们"], ["free", "自由身"], ...(all.some(pick.xl) ? [["xl", "跨联赛"]] : [])]
    .map(([k, l]) => `<button class="chip${newsXf === k ? " on" : ""}" data-nxf="${k}">${l}</button>`).join("");
  const side = (id) => id ? `${crest(id, "sm")} ${esc(tname(id) || "")}` : `<span class="muted">自由身</span>`;
  const trs = rows.map((e) => { const pid = cardOf.get(String(e.id));
    return `<tr class="${us(e) ? "us" : ""}${pid ? " go-row" : ""}"${pid ? pgo({ pid }, e.club) : ""}><td class="muted">${esc((e.date || "").slice(5).replace("-", "/"))}</td>
      <td class="name">${pid ? pface({ pid }) : ""}<b>${esc(e.name)}</b></td><td>${side(e.from)}</td><td class="c muted">→</td><td>${side(e.club)}</td>
      <td class="n">${e.fee ? `<b class="nw-fee">${money(e.fee, 1)}</b>` : `<span class="muted">免费</span>`}</td></tr>`; }).join("");
  return `<div class="nw-xf scroll"><div class="nw-xf-h"><b>转会</b><span>本季 ${all.length} 笔${all.length >= 30 ? "（最近 30 笔）" : ""} · 总额 ${money(total, 1)}${winTxt}</span></div>
    ${bigHtml}<div class="filters">${chips}</div>
    ${trs ? `<table class="nw-xf-t"><thead><tr><th>日期</th><th>球员</th><th>从</th><th></th><th>到</th><th class="n">转会费</th></tr></thead><tbody>${trs}</tbody></table>`
      : `<div class="empty-note">${all.length ? "这个筛选下没有转会" : "本季还没有转会（转会窗开着时各队每天可能成交）"}</div>`}</div>`;
}
/* 玩家本人 · 教练档案与独立个人钱包。余额及工资只读服务端数据。
   E352 第2批（2026-11-17）：本轮其他场次胜平负竞猜（不含我队比赛，赔率下注时锁定，我队比赛开始即封盘）＋进修课程（一次一门，期满加能力）。
   第3a/3b批：执教能力（成长、开赛熟练度）、转会谈判（要价、工资要求）、青训培养（青训日高档概率）、球队管理（疲劳、连败士气）均已生效，数值由服务端 effects 给出。所有钱数都是服务端算好的整数欧元。
   2026-11-17 用户界面要求（依次）：手机界面＋“我的”放侧栏（10-nav.js，分区不显示标签行）→ 横屏 → 去掉前置摄像头 → 填满、能力只写数字、iOS 风格
   → 折叠屏（参考展开的折叠 iPhone）→“只是做一个外形 … 整个屏幕中间不要分屏，就一个界面 … 首页就是个人信息，右边可以切换竞猜啥的”。
   现在：折叠屏外形（薄边框、钛金属边、上下折痕、顶边按键）里一整块 iOS 深色界面（用户“然后用暗色UI吧”）；右侧竖栏切换 首页（个人信息）/ 钱包 / 竞猜 / 进修。
   样式全在本文件的 <style>（ml.css 另有会话在改，不动）；类名一律 cph- 前缀（fd- 已被 ml.css 赛程详情占用，.ovr / .app 等短名也有全局样式）。 */
const COACH_LEDGER = { salary: "教练周薪", "bet-stake": "竞猜下注", "bet-payout": "竞猜派彩", "bet-refund": "竞猜退款", course: "进修学费" };
const COACH_BET_STATUS = { open: "待开奖", won: "猜中", lost: "未中", void: "已退款" };
const COACH_CLOSED = { "match-started": "本轮比赛已开始，竞猜已封盘", "round-played": "本轮已结束，下一轮开放后可竞猜", "season-over": "赛季已结束", "no-round": "本轮暂无可竞猜场次" };
const COACH_APPS = [["profile", "首页", "home", "#0a84ff"], ["wallet", "钱包", "finance", "#30d158"], ["bet", "竞猜", "season", "#ff9f0a"], ["course", "进修", "training", "#bf5af2"]];
const coachLive = (a) => (a.effects || []).length > 0 && !String(a.effects[0]).startsWith("暂无");      // 服务端对 ≤70 的能力回“暂无加成…”，灰色显示
const coachEuro = (n) => `€${Number(n || 0).toLocaleString("zh-CN")}`;
let coachApp = "profile";
let coachLeague = null, coachMatch = null, coachBetTab = "round";      // 竞猜：选中的联赛 / 比赛 / 本轮或记录（2026-11-17 用户三栏设计）
const CPH_CSS = `<style>
.cph-wrap{display:flex;justify-content:center;align-items:center;min-height:calc(100vh - 60px);padding:6px 0;font-family:-apple-system,"SF Pro Text","PingFang SC","Helvetica Neue","Microsoft YaHei",system-ui,sans-serif;-webkit-font-smoothing:antialiased}
.cph{position:relative;width:min(1020px,100%);height:clamp(250px,calc(100vh - 84px),560px);border-radius:38px;padding:7px;background:#121214;box-shadow:0 0 0 1.5px #a7a7ad,0 0 0 3px #3b3b40,0 24px 54px rgba(0,0,0,.55)}
.cph::before,.cph::after{content:"";position:absolute;left:50%;width:30px;height:4px;margin-left:-15px;background:#2a2a2e;border-radius:2px}.cph::before{top:-3px}.cph::after{bottom:-3px}
.cph-key{position:absolute;top:-4px;height:3px;border-radius:2px;background:#a7a7ad}
.cph-scr{height:100%;border-radius:31px;overflow:hidden;display:grid;grid-template-columns:minmax(0,1fr) 56px;background:#000;color:#fff}
.cph-pg{min-height:0;overflow-y:auto;padding:14px 10px 12px 20px;scrollbar-width:none}.cph-pg::-webkit-scrollbar{display:none}
.cph-hd{display:flex;align-items:baseline;justify-content:space-between;gap:10px;margin:0 2px 9px}
.cph-ttl{font-size:clamp(20px,5.4vh,28px);font-weight:700;letter-spacing:-.015em}.cph-hd small{font-size:11.5px;color:#8e8e93;font-weight:500}
.cph-cols{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.15fr);gap:14px;align-items:start}
.cph-mgrid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:11px}.cph-mgrid .cph-grp{margin-bottom:0}
.cph-rail{display:flex;flex-direction:column;align-items:center;gap:10px;padding:12px 0 10px}
.cph-time{font-size:12px;font-weight:700;text-align:center;line-height:1.15}.cph-time small{display:block;font-size:9px;font-weight:600;color:#8e8e93}
.cph-pill{display:flex;flex-direction:column;gap:6px;padding:5px;border-radius:24px;background:#1c1c1e;border:1px solid #2c2c2e;margin:auto 0}
.cph-rb{position:relative;width:38px;height:38px;border-radius:50%;border:0;display:grid;place-items:center;background:#2c2c2e;box-shadow:none;cursor:pointer;padding:0}
.cph-rb svg{width:20px;height:20px}.cph-rb.cph-on{box-shadow:none}.cph-rb.cph-on svg{color:#fff}
.cph-rb em{position:absolute;right:-4px;top:-4px;min-width:16px;height:16px;padding:0 4px;border-radius:8px;background:#ff453a;color:#fff;font-style:normal;font-size:10px;font-weight:700;display:grid;place-items:center}
.cph-rl{font-size:8.5px;color:#8e8e93;text-align:center;margin-top:1px}
.cph-grp{background:#1c1c1e;border-radius:12px;overflow:hidden;margin-bottom:11px}.cph-cap{font-size:11px;color:#8e8e93;margin:0 4px 5px}
.cph-row{position:relative;display:flex;align-items:center;justify-content:space-between;gap:10px;padding:9px 12px;font-size:13.5px}
.cph-row+.cph-row::before{content:"";position:absolute;top:0;left:12px;right:0;height:1px;background:#38383a}
.cph-row small{display:block;font-size:11px;color:#8e8e93;margin-top:1px}.cph-val{font-weight:600;font-variant-numeric:tabular-nums}
.cph-go{cursor:pointer}.cph-go:active{background:#2c2c2e}.cph-chev{color:#5a5a5e;font-size:16px;margin-left:4px}
.cph-av{width:44px;height:44px;flex:none;border-radius:50%;display:grid;place-items:center;background:linear-gradient(145deg,#ffd60a,#ff9f0a);color:#3a2300}.cph-av svg{width:24px;height:24px}
.cph-num{font-size:26px;font-weight:700;font-variant-numeric:tabular-nums}.cph-big{font-size:clamp(24px,6.4vh,34px);font-weight:700;letter-spacing:-.02em}
.cph-eff{font-size:11px;line-height:1.5;margin-top:1px}.cph-eff.cph-on{color:#30d158}.cph-eff.cph-off{color:#8e8e93}
.cph-tag{display:inline-block;padding:3px 10px;border-radius:12px;font-size:11px;font-weight:600;background:#2c2c2e;color:#8e8e93}.cph-tag.cph-ok{background:rgba(48,209,88,.18);color:#30d158}
.cph-dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:7px;vertical-align:1px}
.cph-m{padding:10px 12px}
.cph-vs{display:flex;align-items:center;gap:6px;font-size:13px;font-weight:500;margin-bottom:7px}.cph-vs span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.cph-vs span:last-child{text-align:right}
.cph-odds{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}
.cph-odd{background:#2c2c2e;border:1px solid #3a3a3c;border-radius:9px;padding:4px 0;color:#fff;font:inherit;font-size:10.5px;cursor:pointer}.cph-odd b{display:block;font-size:15px;font-variant-numeric:tabular-nums}
.cph-odd.cph-on{background:#0a84ff;border-color:#0a84ff;color:#fff}.cph-odd:disabled{cursor:default;color:#5a5a5e}.cph-odd.cph-on:disabled{color:#fff}
.cph-btn{background:#0a84ff;color:#fff;border:0;border-radius:14px;padding:5px 12px;font:inherit;font-weight:600;font-size:12px;cursor:pointer;white-space:nowrap}.cph-btn:disabled{background:#2c2c2e;color:#5a5a5e;cursor:default}
.cph-prog{height:4px;border-radius:2px;background:#3a3a3c;overflow:hidden;margin:7px 0 4px}.cph-prog i{display:block;height:100%;background:#0a84ff;border-radius:2px}
.cph-note{font-size:11px;color:#8e8e93;line-height:1.55;margin:0 4px 10px}
.cph-fill{display:flex;flex-direction:column;overflow:hidden;padding-bottom:10px}
.cph-bh{display:flex;align-items:center;gap:8px;margin:0 2px 8px;flex:none;min-width:0}
.cph-st{display:flex;align-items:center;gap:0;background:#1c1c1e;border-radius:10px;padding:4px 4px 4px 2px;min-width:0;overflow:hidden;cursor:pointer}
.cph-st span{display:flex;flex-direction:column;align-items:center;padding:0 8px;line-height:1.15;white-space:nowrap}.cph-st span+span{border-left:1px solid #38383a}
.cph-st small{font-size:9.5px;color:#8e8e93}.cph-st b{font-size:12.5px;font-variant-numeric:tabular-nums}
.cph-seg{display:flex;background:#1c1c1e;border-radius:9px;padding:2px;flex:none}.cph-seg button{border:0;background:none;color:#8e8e93;font:inherit;font-size:11.5px;font-weight:600;padding:4px 10px;border-radius:7px;cursor:pointer}.cph-seg button.cph-on{background:#3a3a3c;color:#fff}
.cph-3{flex:1;min-height:0;display:grid;grid-template-columns:62px minmax(0,1fr) minmax(170px,.62fr);gap:8px}
.cph-lg{display:flex!important;align-items:center;justify-content:center;min-height:52px;padding:6px!important}.cph-lg img{width:34px;height:34px;object-fit:contain;filter:drop-shadow(0 1px 2px rgba(0,0,0,.5))}
.cph-lg em{min-width:15px;height:15px;padding:0 4px;border-radius:8px;background:#0a84ff;color:#fff!important;display:grid;place-items:center;font-size:9.5px!important;right:4px!important;bottom:4px!important}.cph-lg i{right:5px!important;top:5px!important;width:6px!important;height:6px!important}
.cph-col{min-height:0;overflow-y:auto;background:#1c1c1e;border-radius:12px;scrollbar-width:none}.cph-col::-webkit-scrollbar{display:none}
.cph-lg{position:relative;display:block;width:100%;text-align:left;border:0;background:none;color:#fff;font:inherit;padding:8px 10px;cursor:pointer;border-bottom:1px solid #2c2c2e}
.cph-lg b{display:block;font-size:13px}.cph-lg small{font-size:10px;color:#8e8e93}.cph-lg.cph-on{background:#2c2c2e}.cph-lg.cph-on::before{content:"";position:absolute;left:0;top:8px;bottom:8px;width:3px;border-radius:2px;background:#0a84ff}
.cph-lg i{position:absolute;right:8px;top:9px;width:7px;height:7px;border-radius:50%}.cph-lg em{position:absolute;right:6px;bottom:7px;font-style:normal;font-size:9.5px;font-weight:700;color:#0a84ff}
.cph-rh{position:sticky;top:0;z-index:1;background:#1c1c1e;padding:7px 11px 6px;font-size:11px;color:#8e8e93;border-bottom:1px solid #2c2c2e}
.cph-fx{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1fr);align-items:center;gap:6px;padding:7px 10px;cursor:pointer;border-bottom:1px solid #2c2c2e;font-size:12.5px}
.cph-fx:last-child{border-bottom:0}.cph-fx.cph-on{background:#2c2c2e}.cph-fx > span{display:flex;align-items:center;gap:6px;min-width:0}.cph-fx > span:last-child{justify-content:flex-end}
.cph-fx b{font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.cph-fx small{font-size:10px;color:#636366;text-align:center;line-height:1.2}.cph-fx small.cph-mine{color:#0a84ff;font-weight:700}
.cph-cr{display:inline-flex;flex:none}.cph-cr .cw{width:20px;height:20px;font-size:7px}.cph-cr .cw img{width:100%;height:100%;object-fit:contain}
.cph-cr.big .cw{width:44px;height:44px;font-size:12px}
.cph-dt{padding:12px 11px;display:flex;flex-direction:column;gap:10px}
.cph-dt .tm{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;text-align:center;gap:4px}.cph-dt .tm div{display:flex;flex-direction:column;align-items:center;gap:4px;font-size:12px;font-weight:600;min-width:0}
.cph-dt .tm div span:last-child{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.cph-pk{display:flex;flex-direction:column;gap:6px}.cph-pk .cph-odd{display:flex;justify-content:space-between;align-items:center;padding:8px 12px;font-size:12.5px;font-weight:600}.cph-pk .cph-odd b{display:inline;font-size:16px}
.cph-hs{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:10px;flex:none}.cph-hs div{background:#1c1c1e;border-radius:12px;padding:8px 11px}.cph-hs small{display:block;font-size:10.5px;color:#8e8e93}.cph-hs b{font-size:18px;font-variant-numeric:tabular-nums}
@media (max-height:460px){.cph{border-radius:32px;padding:6px}.cph-scr{border-radius:26px;grid-template-columns:minmax(0,1fr) 50px}.cph-rl{display:none}
.cph-rb{width:32px;height:32px}.cph-rb svg{width:17px;height:17px}.cph-pill{gap:5px;padding:4px}.cph-rail{padding:9px 0 7px;gap:6px}
.cph-pg{padding:10px 6px 10px 16px}.cph-row{padding:7px 11px;font-size:12.5px}.cph-hd{margin-bottom:6px}.cph-num{font-size:22px}.cph-av{width:38px;height:38px}}
</style>`;
async function viewCoach() {
  const d = await biz("coach");
  if (!d || d.demo) return `<div class="view"><div class="card"><div class="ch">我的</div><div class="cb empty-note">教练档案暂不可用，请稍后重试。</div></div></div>`;
  const app = COACH_APPS.some((a) => a[0] === coachApp) ? coachApp : "profile";
  const today = d.today ? new Date(d.today + "T00:00:00") : null;
  return `${CPH_CSS}<div class="view cph-wrap"><div class="cph"><span class="cph-key" style="right:86px;width:44px"></span><span class="cph-key" style="right:150px;width:30px"></span>
    <div class="cph-scr"><div class="cph-pg${app === "bet" ? " cph-fill" : ""}">${coachAppScreen(d, app, today)}</div>${coachRail(d, today, app)}</div></div></div>`;
}
function coachRail(d, today, app) {
  const bet = d.betting || {}, open = (bet.bets || []).filter((b) => b.status === "open").length;
  const badge = { bet: open ? open : bet.open ? "!" : "", course: d.course ? "1" : "" };
  return `<div class="cph-rail"><div class="cph-time">${today ? `${today.getMonth() + 1}/${today.getDate()}` : ""}<small>5G</small></div>
    <div class="cph-pill">${COACH_APPS.map(([k, n, ic, c]) => `<div><button class="cph-rb${k === app ? " cph-on" : ""}" data-capp="${k}" title="${n}" style="${k === app ? `background:${c}` : `color:${c}`}">${svg(ic, 1.9)}${badge[k] ? `<em>${badge[k]}</em>` : ""}</button><div class="cph-rl">${n}</div></div>`).join("")}</div></div>`;
}
const coachLabel = (d, k) => (d.attributes.find((a) => a.key === k) || {}).label || k;
function coachAppScreen(d, app, today) {
  if (app === "wallet") return coachWalletApp(d);
  if (app === "bet") return coachBetApp(d);
  if (app === "course") return coachCourseApp(d);
  return coachProfileApp(d, today);
}
const coachHead = (title, sub) => `<div class="cph-hd"><span class="cph-ttl">${title}</span>${sub ? `<small>${sub}</small>` : ""}</div>`;
function coachProfileApp(d, today) {
  const bet = d.betting || {}, open = (bet.bets || []).filter((b) => b.status === "open").length;
  const wd = today ? `星期${"日一二三四五六"[today.getDay()]} · ${today.getFullYear()}年${today.getMonth() + 1}月${today.getDate()}日` : "";
  const go = (k, dot, text, val) => `<div class="cph-row cph-go" data-capp="${k}"><span><i class="cph-dot" style="background:${dot}"></i>${text}</span><span class="cph-val" style="color:#8e8e93;font-weight:500">${val || ""}<span class="cph-chev">›</span></span></div>`;
  const news = [d.course ? go("course", "#bf5af2", `进修 ${esc(coachLabel(d, d.course.attribute))}`, `${esc(d.course.ends_on.slice(5))} 结业`) : "",
    open ? go("bet", "#ff9f0a", "竞猜待开奖", `${open} 场`) : bet.open ? go("bet", "#ff9f0a", `第${bet.fixture}轮竞猜开放`, `${bet.matches.length} 场`) : ""].join("");
  const row = (a) => `<div class="cph-row"><div style="min-width:0"><div>${esc(a.label)}</div><div class="cph-eff ${coachLive(a) ? "cph-on" : "cph-off"}">${(a.effects || []).map(esc).join("　") || "—"}</div></div><span class="cph-num">${a.value}</span></div>`;
  return `${coachHead("首页", esc(wd) + " · 游戏日期")}<div class="cph-cols"><div>
      <div class="cph-grp"><div class="cph-row"><div style="display:flex;align-items:center;gap:11px;min-width:0"><span class="cph-av">${svg("person")}</span><div style="min-width:0"><div style="font-weight:600;font-size:15px">${esc(d.name)}</div><small>${esc(tname(d.club))} 主帅 · ${esc(d.hired_on)} 起</small></div></div><div style="text-align:right"><small>综合</small><span class="cph-num" style="color:#ff9f0a">${d.overall}</span></div></div></div>
      <div class="cph-grp"><div class="cph-row cph-go" data-capp="wallet"><div><small style="margin:0">个人钱包</small><span class="cph-big">${coachEuro(d.wallet.balance_eur)}</span></div><span class="cph-chev">›</span></div>
        <div class="cph-row"><span>合同周薪</span><span class="cph-val">${coachEuro(d.weekly_wage_eur)}</span></div><div class="cph-row"><span>下次发薪</span><span class="cph-val">${esc(d.next_pay)}</span></div></div>
      ${news ? `<div class="cph-grp">${news}</div>` : ""}
    </div><div>
      <div class="cph-cap">能力与当前加成</div><div class="cph-grp">${d.attributes.map(row).join("")}</div>
      <p class="cph-note">高于 ${d.effect_base || 70} 的部分才计加成，低于不扣，只作用于我队。想提高能力去“进修”。</p>
    </div></div>`;
}
function coachWalletApp(d) {
  const w = d.wallet;
  const row = (r) => `<div class="cph-row"><div>${esc(COACH_LEDGER[r.kind] || "个人收支")}<small>${esc(r.date)}</small></div><div style="text-align:right"><span class="cph-val" style="color:${r.amount_eur >= 0 ? "#30d158" : "#ff453a"}">${r.amount_eur >= 0 ? "+" : ""}${coachEuro(r.amount_eur)}</span><small>余额 ${coachEuro(r.balance_eur)}</small></div></div>`;
  return `${coachHead("钱包", "游戏内虚拟资金")}<div class="cph-cols"><div>
      <div class="cph-grp" style="padding:11px 12px"><small style="color:#8e8e93;font-size:11px">可用余额</small><div class="cph-big">${coachEuro(w.balance_eur)}</div></div>
      <div class="cph-grp"><div class="cph-row"><span>合同周薪</span><span class="cph-val">${coachEuro(d.weekly_wage_eur)}</span></div><div class="cph-row"><span>下次发薪</span><span class="cph-val">${esc(d.next_pay)}</span></div><div class="cph-row"><span>累计工资</span><span class="cph-val">${coachEuro(w.salary_total_eur)}</span></div><div class="cph-row"><span>结算至</span><span class="cph-val">${esc(d.paid_through)}</span></div></div>
      <p class="cph-note">每 7 个游戏日发薪，俱乐部同步记支出。个人钱包与转会资金分开。</p>
    </div><div>
      <div class="cph-cap">交易记录</div><div class="cph-grp">${w.ledger.map(row).join("") || `<div class="cph-row"><span style="color:#8e8e93">尚未发薪，首笔工资 ${esc(d.next_pay)} 到账</span></div>`}</div>
    </div></div>`;
}
function coachBetApp(d) {
  // 2026-11-17 用户：“左边联赛列表（5 大联赛）· 中间本轮赛程（带队徽，可选比赛）· 右边点中比赛后出现胜负平 · 左上角历史记录（投入、赚了多少、胜率、历史胜负和场次）”
  const bet = d.betting || { matches: [], bets: [], leagues: [] }, picks = bet.picks || { H: "主胜", D: "平局", A: "客胜" };
  const lgs = bet.leagues && bet.leagues.length ? bet.leagues : [{ comp: 0, name: "联赛", own: true, open: bet.open, reason: bet.reason, fixture: bet.fixture, date: null, matches: bet.matches || [] }];
  const st = bet.stats || {}, bal = d.wallet.balance_eur;
  for (const x of lgs) for (const [k, v] of Object.entries(x.teams || {})) if (!S.teams[k]) S.teams[k] = v;      // 其他联赛的队名与颜色（同 67-leagues.js，不覆盖本联赛已有的）
  const openBy = {};
  (bet.bets || []).forEach((b) => { if (b.status === "open") openBy[b.comp || lgs[0].comp] = (openBy[b.comp || lgs[0].comp] || 0) + 1; });
  let lg = lgs.find((x) => x.comp === coachLeague);
  if (!lg) { lg = lgs.find((x) => x.open && x.matches.length) || lgs[0]; coachLeague = lg.comp; }
  let m = lg.matches.find((x) => x.key === coachMatch);
  if (!m) { m = lg.matches.find((x) => !x.my_bet) || lg.matches[0] || null; coachMatch = m ? m.key : null; }
  const signed = (n) => `${n > 0 ? "+" : n < 0 ? "−" : ""}${coachEuro(Math.abs(n || 0))}`;
  const pct = st.win_rate == null ? "—" : `${Math.round(st.win_rate * 100)}%`;
  const strip = `<div class="cph-st" data-cbt="${coachBetTab === "history" ? "round" : "history"}" title="历史记录">
      <span><small>投入</small><b>${coachEuro(st.staked)}</b></span><span><small>盈亏</small><b style="color:${(st.profit || 0) >= 0 ? "#30d158" : "#ff453a"}">${signed(st.profit)}</b></span>
      <span><small>胜率</small><b>${pct}</b></span><span><small>战绩</small><b>${st.won || 0}胜${st.lost || 0}负</b></span></div>`;
  const head = `<div class="cph-bh"><span class="cph-ttl" style="flex:none">竞猜</span>${strip}
      <div class="cph-seg" style="margin-left:auto"><button class="${coachBetTab !== "history" ? "cph-on" : ""}" data-cbt="round">本轮</button><button class="${coachBetTab === "history" ? "cph-on" : ""}" data-cbt="history">记录</button></div>
      <small style="color:#8e8e93;font-size:11px;white-space:nowrap">余额 ${coachEuro(bal)}</small></div>`;
  if (coachBetTab === "history") return head + coachBetHistory(bet, st, picks, signed, pct);
  const md = (iso) => iso ? `${+iso.slice(5, 7)}月${+iso.slice(8, 10)}日` : "";
  // 2026-11-17 用户：“这个不要文字了改成我们赛季里面的标志”——联赛只显示赛季页同款标志（/img/comp/L<编号>.png），名称放 title；图片读不到时退回文字
  const leagueBtn = (x) => `<button class="cph-lg${x.comp === lg.comp ? " cph-on" : ""}" data-clg="${x.comp}" title="${esc(x.name)}${x.fixture ? ` · 第${x.fixture}轮` : ""}${x.own ? " · 本队联赛" : ""}">
      ${(x.logo || x.comp) ? `<img src="/img/comp/L${x.logo || x.comp}.png" alt="${esc(x.name)}" onerror="this.replaceWith(Object.assign(document.createElement('b'),{textContent:this.alt}))">` : `<b>${esc(x.name)}</b>`}
      <i style="background:${x.open ? "#30d158" : "#48484a"}"></i>${openBy[x.comp] ? `<em>${openBy[x.comp]}</em>` : ""}</button>`;
  const side = (tid, right) => right ? `<b>${esc(tname(tid))}</b><span class="cph-cr">${crest(tid)}</span>` : `<span class="cph-cr">${crest(tid)}</span><b>${esc(tname(tid))}</b>`;
  const fx = (x) => `<div class="cph-fx${m && x.key === m.key ? " cph-on" : ""}" data-cmt="${esc(x.key)}"><span>${side(x.home)}</span>
      ${x.my_bet ? `<small class="cph-mine">${esc(picks[x.my_bet.pick])}</small>` : `<small>vs</small>`}<span>${side(x.away, true)}</span></div>`;
  const state = lg.open ? `<span style="color:#30d158">开放中</span>` : esc(COACH_CLOSED[lg.reason] || (lg.reason === "round-due" ? "今日开赛，已封盘" : "暂未开放"));
  const mid = `<div class="cph-col"><div class="cph-rh">${esc(lg.name)}${lg.fixture ? ` · 第${lg.fixture}轮` : ""}${lg.date ? ` · ${md(lg.date)}` : ""} · ${state}</div>
      ${lg.matches.map(fx).join("") || `<div class="cph-fx" style="cursor:default"><small style="grid-column:1/-1">${lg.own ? "本轮没有可竞猜的场次（不含我队比赛）" : "这个联赛本季已没有比赛"}</small></div>`}</div>`;
  let right = `<div class="cph-col"><div class="cph-dt"><small style="color:#8e8e93">在中间选一场比赛</small></div></div>`;
  if (m) {
    const pick = (k) => `<button class="cph-odd${m.my_bet && m.my_bet.pick === k ? " cph-on" : ""}" data-cbet="${esc(m.key)}" data-cpick="${k}" data-codds="${m.odds[k]}" ${!lg.open || m.my_bet ? "disabled" : ""}><span>${esc(picks[k])}</span><b>${Number(m.odds[k]).toFixed(2)}</b></button>`;
    right = `<div class="cph-col"><div class="cph-dt">
        <div class="tm"><div><span class="cph-cr big">${crest(m.home)}</span><span>${esc(tname(m.home))}</span></div><small style="color:#636366">vs</small><div><span class="cph-cr big">${crest(m.away)}</span><span>${esc(tname(m.away))}</span></div></div>
        <small style="text-align:center;color:#8e8e93;font-size:10.5px">${esc(lg.name)} 第${lg.fixture}轮${lg.date ? ` · ${md(lg.date)}` : ""}</small>
        <div class="cph-pk">${["H", "D", "A"].map(pick).join("")}</div>
        ${m.my_bet ? `<small style="text-align:center;color:#0a84ff;font-size:11px">已下注 ${coachEuro(m.my_bet.stake_eur)} · 猜中得 ${coachEuro(Math.floor(m.my_bet.stake_eur * m.my_bet.odds))}</small>`
          : !lg.open ? `<small style="text-align:center;color:#8e8e93;font-size:11px">${state}</small>` : `<small style="text-align:center;color:#8e8e93;font-size:10.5px">单注 ${coachEuro(bet.min_eur)}～${coachEuro(bet.max_eur)} · 赔率下注时锁定</small>`}
      </div></div>`;
  }
  return `${head}<div class="cph-3"><div class="cph-col">${lgs.map(leagueBtn).join("")}</div>${mid}${right}</div>`;
}
function coachBetHistory(bet, st, picks, signed, pct) {
  const row = (b) => {
    const col = b.status === "won" ? "#30d158" : b.status === "lost" ? "#ff453a" : "#ff9f0a";
    return `<div class="cph-row"><div style="min-width:0;display:flex;align-items:center;gap:8px"><span class="cph-cr">${crest(b.home)}</span><div style="min-width:0">${esc(tname(b.home))} vs ${esc(tname(b.away))}${b.score ? ` <b class="cph-val">${b.score[0]}-${b.score[1]}</b>` : ""}
        <small>${esc(b.league || "")} 第${b.fixture}轮 · ${esc(picks[b.pick])} @ ${Number(b.odds).toFixed(2)} · 本金 ${coachEuro(b.stake_eur)}</small></div></div>
      <div style="text-align:right"><span class="cph-val" style="color:${col}">${esc(COACH_BET_STATUS[b.status] || b.status)}</span><small>${b.status === "open" ? `猜中得 ${coachEuro(Math.floor(b.stake_eur * b.odds))}` : b.return_eur ? `+${coachEuro(b.return_eur)}` : coachEuro(0)}</small></div></div>`;
  };
  return `<div class="cph-hs"><div><small>累计投入</small><b>${coachEuro(st.staked)}</b></div><div><small>累计回报</small><b>${coachEuro(st.returned)}</b></div>
      <div><small>净盈亏</small><b style="color:${(st.profit || 0) >= 0 ? "#30d158" : "#ff453a"}">${signed(st.profit)}</b></div>
      <div><small>胜率</small><b>${pct}</b></div><div><small>历史胜负</small><b>${st.won || 0} 胜 ${st.lost || 0} 负${st.void ? ` ${st.void} 退` : ""}</b></div><div><small>历史场次</small><b>${st.count || 0} 场${st.open ? ` · ${st.open} 待开奖` : ""}</b></div></div>
    <div class="cph-col" style="flex:1">${(bet.bets || []).map(row).join("") || `<div class="cph-row"><span style="color:#8e8e93">还没有竞猜记录</span></div>`}</div>`;
}
function coachCourseApp(d) {
  const c = d.course, rule = d.course_rule || {}, bal = d.wallet.balance_eur;
  let cur = `<div class="cph-grp" style="padding:10px 12px"><b>当前没有课程</b><small style="display:block;color:#8e8e93;font-size:11px;margin-top:3px">选一项能力报名，${rule.days} 个游戏日后 +${rule.gain}</small></div>`;
  if (c) {
    const a = new Date(c.started_on + "T00:00:00"), b = new Date(c.ends_on + "T00:00:00"), t = d.today ? new Date(d.today + "T00:00:00") : a;
    const pct = Math.max(0, Math.min(100, (t - a) / Math.max(1, b - a) * 100));
    cur = `<div class="cph-grp" style="padding:10px 12px"><div style="display:flex;justify-content:space-between"><b>${esc(coachLabel(d, c.attribute))}</b><span class="cph-val" style="color:#ff9f0a">${c.from} → ${c.from + c.gain}</span></div><div class="cph-prog"><i style="width:${pct}%"></i></div><small style="color:#8e8e93;font-size:11px">${esc(c.started_on)} 开课 · ${esc(c.ends_on)} 结业</small></div>`;
  }
  const row = (a) => {
    const off = !!c || a.course_capped || bal < a.course_cost_eur;
    const why = c ? "已有进修在进行" : a.course_capped ? `已达上限 ${rule.cap}` : bal < a.course_cost_eur ? "余额不足" : `${rule.days}天后 +${rule.gain}`;
    return `<div class="cph-row"><div>${esc(a.label)} <span class="cph-val" style="color:#ff9f0a">${a.value}</span><small>${esc(why)}</small></div><button class="cph-btn" data-ccourse="${esc(a.key)}" ${off ? "disabled" : ""}>${coachEuro(a.course_cost_eur)}</button></div>`;
  };
  const last = (d.courses_done || [])[0];
  return `${coachHead("进修", `余额 ${coachEuro(bal)}`)}<div class="cph-cols"><div>
      <div class="cph-cap">${c ? "进修中" : "当前课程"}</div>${cur}
      ${last ? `<p class="cph-note">上次进修：${esc(coachLabel(d, last.attribute))} ${last.from} → ${last.to}（${esc(last.done_on)} 结业）</p>` : ""}
      <p class="cph-note">学费从个人钱包支付，不退。一次一门，${rule.days} 个游戏日后 +${rule.gain}，进修上限 ${rule.cap}。</p>
    </div><div>
      <div class="cph-cap">课程</div><div class="cph-grp">${d.attributes.map(row).join("")}</div>
    </div></div>`;
}
function coachRefresh() { $$("#mkdlg").forEach((e) => e.remove()); delete BIZ.coach; quietDraw = true; draw(); }
function coachBind(root) {
  $$("[data-capp]", root).forEach((el) => el.addEventListener("click", (e) => {
    e.stopPropagation(); if (coachApp === el.dataset.capp) return;
    sound("cursor"); coachApp = el.dataset.capp; quietDraw = true; draw();
  }));
  const pick = (sel, fn) => $$(sel, root).forEach((el) => el.addEventListener("click", (e) => { e.stopPropagation(); if (fn(el) === false) return; sound("cursor"); quietDraw = true; draw(); }));
  pick("[data-clg]", (el) => { if (coachLeague === +el.dataset.clg) return false; coachLeague = +el.dataset.clg; coachMatch = null; });
  pick("[data-cmt]", (el) => { if (coachMatch === el.dataset.cmt) return false; coachMatch = el.dataset.cmt; });
  pick("[data-cbt]", (el) => { if (coachBetTab === el.dataset.cbt) return false; coachBetTab = el.dataset.cbt; });
  $$("[data-cbet]", root).forEach((el) => el.addEventListener("click", (e) => {
    e.stopPropagation(); sound("cursor");
    // 比赛可能在本联赛（bet.matches）也可能在别的联赛（bet.leagues[].matches）：2026-11-17 只查前者，点其他联赛的赔率没有任何反应。
    const d = BIZ.coach || {}, bet = d.betting || {};
    const m = [{ matches: bet.matches || [] }, ...(bet.leagues || [])].reduce((hit, lg) => hit || (lg.matches || []).find((x) => x.key === el.dataset.cbet), null);
    if (!m) return toast("这场比赛暂时不能下注，请刷新后再试");
    const k = el.dataset.cpick, odds = +el.dataset.codds, bal = (d.wallet || {}).balance_eur || 0, max = Math.min(bet.max_eur, bal);
    const start = Math.max(bet.min_eur, Math.min(1000, max));
    const box = mkDialog(`竞猜 · ${esc(tname(m.home))} vs ${esc(tname(m.away))}`, `<p class="dlg-p">选择：<b>${esc(bet.picks[k])}</b>　赔率 <b class="num">${odds.toFixed(2)}</b>　可用余额 <b class="num">${coachEuro(bal)}</b></p>
      <label class="dlg-p" style="display:flex;align-items:center;gap:10px">本金 €<input id="cb-stake" type="number" min="${bet.min_eur}" max="${max}" step="100" value="${start}" style="flex:1;font-size:18px;padding:6px 8px"></label>
      <div style="display:flex;gap:6px;margin:6px 0">${[1000, 5000, 10000].filter((v) => v <= max).map((v) => `<button class="chip sm" data-cbq="${v}">${coachEuro(v)}</button>`).join("")}${max >= bet.min_eur ? `<button class="chip sm" data-cbq="${max}">全部 ${coachEuro(max)}</button>` : ""}</div>
      <p class="dlg-p muted" id="cb-ret"></p>`,
      [{ label: "取消" }, { label: "确认下注", pri: true, off: max < bet.min_eur, fn: async (b, close) => {
        const stake = Math.floor(+$("#cb-stake", b).value || 0);
        const r = await post("/api/coach/bet", { match: m.key, pick: k, stake });
        if (mkFail(r)) return false; sound("ok"); close(); coachRefresh(); } }]);
    const inp = $("#cb-stake", box), ret = $("#cb-ret", box), upd = () => { ret.textContent = `猜中可得 ${coachEuro(Math.floor((+inp.value || 0) * odds))}（含本金）`; };
    inp.addEventListener("input", upd); upd();
    $$("[data-cbq]", box).forEach((q) => q.onclick = () => { inp.value = q.dataset.cbq; upd(); });
  }));
  $$("[data-ccourse]", root).forEach((el) => el.addEventListener("click", (e) => {
    e.stopPropagation(); sound("cursor");
    const d = BIZ.coach || {}, a = (d.attributes || []).find((x) => x.key === el.dataset.ccourse), rule = d.course_rule || {};
    if (!a) return;
    mkDialog(`进修 · ${esc(a.label)}`, `<p class="dlg-p">学费 <b class="num">${coachEuro(a.course_cost_eur)}</b>（从个人钱包支付，不退）。为期 ${rule.days} 个游戏日，结业后 ${esc(a.label)} ${a.value} → ${Math.min(rule.cap, a.value + rule.gain)}。进修期间不能再报其他课程。</p>`,
      [{ label: "取消" }, { label: "报名", pri: true, fn: async (b, close) => {
        const r = await post("/api/coach/course", { attribute: a.key });
        if (mkFail(r)) return false; sound("ok"); close(); coachRefresh(); } }]);
  }));
}
// ---- 转会
let mkPos = "全部", mkSel = null, mkLimit = 0; const mkOpt = { budget: false, young: false, top: false };
/* 性能（2026-11-14，用户：“优化一下大师联赛的性能，减少卡顿”）：手机上市场最多 400 人。以前点一行就整页重画（几百行 + 入场动画 + 每个元素重新绑事件）；
   现在点行只换右侧详情卡、切换选中样式（mkSelect）；表格一次只画 MK_CHUNK 行，底部“显示更多”再追加（筛选一变就回到第一段）。 */
const MK_CHUNK = 60;
const mkPot = (x) => x.potential_range && x.potential_range[0] !== x.potential_range[1] ? `${x.potential_range[0]}–${x.potential_range[1]}` : x.potential;
// 别队球员一律星级（不露具体数值）；ref＝d.star_ref（2026-11-15 起是全联赛统一刻度里 3 星的 CA，不再随我队变）
const mkStars = (x, ref) => { const r = Array.isArray(x.ca_pot) ? x.ca_pot : [x.ca, x.ca];      // W6-c2：星级读 CA 与球探的 PA 区间
  return { ab: starVal(x.ca, ref), lo: starVal(r[0], ref), hi: starVal(r[1], ref) }; };
// 和我队比（2026-11-15）：星级改成绝对刻度后，“他能不能进我的首发”另用一句话说——d.squad_ca＝我队最强 11 人的平均 CA（旧服务端没有就不显示）
const mkVsUs = (ca, d) => { if (ca == null || !d || d.squad_ca == null) return null; const g = ca - d.squad_ca;
  return g >= 6 ? ["up", "强于你的首发"] : g >= -6 ? ["eq", "和你的首发相当"] : g >= -18 ? ["dn", "略弱于你的首发"] : ["dn2", "明显弱于你的首发"]; };
const mkVsTag = (ca, d) => { const v = mkVsUs(ca, d); return v ? `<span class="mk-vs ${v[0]}">${v[1]}</span>` : ""; };
const mkPrice = (x, budget, real) => x.status === "nfs" ? `<span class="mk-nfs" title="俱乐部不打算出售；只有高到无法拒绝的报价才可能打动他们">非卖品</span>`
  : `${x.status === "listed" ? `<span class="mk-lst" title="俱乐部挂牌出售：更便宜，也更好谈">挂牌</span> ` : ""}<span class="num" style="color:${x.price > budget ? "var(--loss)" : "var(--gold)"}">${money(x.price, real ? 1 : 0)}</span>`;
const mkClubCrest = (c) => c.id ? crestId(c.id, c.code, c.c, "sm") : crestId(0, c.code, c.c, "sm");
/* 其他联赛（2026-11-15 用户：“其他联赛球员的身价/要价”“我们能向其他联赛买人”）：市场里也有西甲/意甲/法甲各队有卡的球员（club.lg / lg_name），
   报价、还价、谈条款和本联赛一样；联赛筛选 mkLg：0＝全部，-1＝本联赛，其他＝联赛 id。 */
let mkLg = 0;
const mkLgTag = (c) => c && c.lg ? `<span class="mk-lg" title="${esc(c.lg_name)}的球队">${esc(c.lg_name)}</span>` : "";
const mkLeagues = (d) => { const m = new Map(); for (const p of d.market) if (p.club && p.club.lg && !m.has(p.club.lg)) m.set(p.club.lg, p.club.lg_name); return [...m]; };
function mkRow(x, d, budget, real) {
  // M6-F1：从阵容深度来时，比我队这个位置最好的人强的标“提升”；主位置不在所选位置、只是能踢的标“能踢”
  const st = mkStars(x, d.star_ref);
  const tags = (mkF.pos && mkF.beat && x.overall > mkF.beat ? ` <span class="mk-up">提升</span>` : "") + (mkF.pos && !mkF.pos.includes(x.position) ? ` <span class="mk-can-t">能踢</span>` : "");
  return `<tr class="go-row${x.id === mkSel ? " sel" : ""}" data-mk="${x.id}"><td>${pos(x.position)}</td><td class="name mk-who" title="${esc(x.name)}"><span class="mk-nm">${pfaceGo(x, x.club && x.club.id)}<b translate="no">${esc(shortName(x.name))}</b></span>${tags}${d.shortlist.includes(x.id) ? ' <span style="color:var(--gold)">★</span>' : ""}${x.bid && (x.bid.state === "pending" || x.bid.state === "countered") ? ` <span class="mk-bd${x.bid.state === "countered" ? " ctr" : ""}">${x.bid.state === "pending" ? "已报价" : "还价"}</span>` : ""}</td><td class="mk-club" title="${esc(x.club.name)}"><span class="tn">${mkClubCrest(x.club)}</span></td><td class="n">${starsHtml(st.ab)}</td><td class="n">${starsHtml(st.lo, st.hi, "pot")}</td><td class="n">${mkPrice(x, budget, real)}</td></tr>`;
}
const mkMoreRow = (left) => left > 0 ? `<tr class="mk-more"><td colspan="6"><button class="btn sm" data-mkmore>显示更多 · 还有 ${left} 人</button></td></tr>` : "";
async function mkSelect(id) {
  const [d, club] = await Promise.all([biz("market"), biz("club")]); if (!d) return;
  mkSel = id;
  $$("#page tr[data-mk]").forEach((tr) => tr.classList.toggle("sel", +tr.dataset.mk === id));
  const old = $("#page .card.detail"); if (!old) return draw();
  const tmp = document.createElement("div"); tmp.innerHTML = mkDetail(d, club).trim();
  const n = tmp.firstElementChild; n.style.animation = "none"; old.replaceWith(n); bindPage(n);
}
async function mkMore() {
  const [d, club] = await Promise.all([biz("market"), biz("club")]); if (!d) return;
  const { list, budget, real } = mkList(d, club), from = mkLimit; mkLimit += MK_CHUNK;
  const body = $("#page .mk-table tbody"); if (!body) return draw();
  const more = body.querySelector(".mk-more"); if (more) more.remove();
  const tmp = document.createElement("tbody");                  // 只给新追加的行绑事件（已有的行不重复绑）
  tmp.innerHTML = list.slice(from, mkLimit).map((x) => mkRow(x, d, budget, real)).join("") + mkMoreRow(list.length - mkLimit);
  bindPage(tmp);
  body.append(...tmp.children);
}
// M6-F1 常用筛选（评审 §8.1：精确位置、最高转会费、最高周薪、年龄区间、关注、名字搜索、清空；为空时给原因与一键放宽）。
// pos：精确位置数组（阵容深度“去市场找”带来，can=true 时“能踢”也算）；beat：我队这个位置最好的人的能力，市场行标“提升”。
const mkF = { pos: null, posName: "", can: true, q: "", fee: "", wage: "", amin: "", amax: "", watch: false, beat: 0 };
let mkMoreOpen = false;
function mkResetFilters() { mkPos = "全部"; mkLg = 0; Object.keys(mkOpt).forEach((k) => { mkOpt[k] = false; }); Object.assign(mkF, { pos: null, posName: "", can: true, q: "", fee: "", wage: "", amin: "", amax: "", watch: false, beat: 0 }); }
function mkRules(d, budget) {
  const rules = [];
  if (mkLg) { const lg = mkLeagues(d).find(([id]) => id === mkLg); rules.push(["lg", mkLg < 0 ? "本联赛" : lg ? lg[1] : "其他联赛", (p) => mkLg < 0 ? !(p.club && p.club.lg) : p.club && p.club.lg === mkLg]); }
  if (mkPos !== "全部") rules.push(["pos-g", mkPos, (p) => grp(p.position) === mkPos]);
  if (mkF.pos) rules.push(["pos", mkF.posName || mkF.pos.join("/"), (p) => mkF.pos.includes(p.position) || (mkF.can && p.apt && mkF.pos.some((x) => p.apt[x]))]);
  if (mkOpt.top) rules.push(["top", "能力 4 星以上", (p) => (starVal(p.ca, d.star_ref) ?? 0) >= 4]);
  if (mkOpt.budget) rules.push(["budget", "≤ 预算", (p) => p.price <= budget]);
  if (mkOpt.young) rules.push(["young", "≤ 23 岁", (p) => p.age <= 23]);
  if (mkF.fee !== "") rules.push(["fee", `转会费 ≤ €${mkF.fee}M`, (p) => p.price <= +mkF.fee]);
  if (mkF.wage !== "") rules.push(["wage", `周薪 ≤ €${mkF.wage}K`, (p) => p.wage <= +mkF.wage]);
  if (mkF.amin !== "") rules.push(["amin", `${mkF.amin} 岁以上`, (p) => p.age >= +mkF.amin]);
  if (mkF.amax !== "") rules.push(["amax", `${mkF.amax} 岁以下`, (p) => p.age <= +mkF.amax]);
  if (mkF.watch) rules.push(["watch", "只看关注", (p) => d.shortlist.includes(p.id)]);
  if (mkF.q.trim()) { const q = mkF.q.trim().toLowerCase(); rules.push(["q", `名字含“${mkF.q.trim()}”`, (p) => String(p.name).toLowerCase().includes(q) || String(p.club.name).toLowerCase().includes(q)]); }
  return rules;
}
/* 升降序（2026-11-15 用户：“顺便做个升降序功能吧”，截图圈了表头 俱乐部 / 年龄 / 能力 / 潜力）：点表头排序，再点同一列反向；换一列从该列的默认方向开始
   （能力 / 潜力 / 要价默认从高到低，位置 / 俱乐部 / 年龄默认从低到高）。能力按 CA、潜力按球探区间上限再下限——和星级同一来源，不额外泄露数值；
   要价排序时非卖品不论方向都排在最后。同值按能力从高到低。k=null＝服务端原顺序。 */
const mkSort = { k: null, dir: 1 };
const MK_SORT_DESC = { ab: true, pot: true, price: true };
const MK_POS_ORD = ["GK", "CB", "LB", "RB", "DMF", "CMF", "LMF", "RMF", "AMF", "LWF", "RWF", "SS", "CF"];
function mkSortBy(k) {
  if (mkSort.k === k) mkSort.dir = -mkSort.dir; else { mkSort.k = k; mkSort.dir = MK_SORT_DESC[k] ? -1 : 1; }
}
function mkSortList(list) {
  const k = mkSort.k, dir = mkSort.dir; if (!k) return list;
  const num = (v) => (v == null || Number.isNaN(+v) ? null : +v);
  const key = {
    pos: (p) => { const i = MK_POS_ORD.indexOf(p.position); return i < 0 ? 99 : i; },
    club: (p) => `${p.club && p.club.lg_name || ""}\u0001${p.club && p.club.name || ""}`,
    age: (p) => num(p.age),
    ab: (p) => num(p.ca),
    pot: (p) => (Array.isArray(p.ca_pot) ? p.ca_pot[1] * 1000 + p.ca_pot[0] : num(p.ca) != null ? p.ca * 1001 : null),
    price: (p) => (p.status === "nfs" ? null : num(p.price)),
  }[k];
  if (!key) return list;
  const tie = (a, b) => (num(b.ca) ?? -1) - (num(a.ca) ?? -1);
  return list.sort((a, b) => {
    const x = key(a), y = key(b);
    if (x == null || y == null) return x == null && y == null ? tie(a, b) : x == null ? 1 : -1;     // 没有值的（非卖品要价等）永远垫底
    const c = typeof x === "string" ? x.localeCompare(y, "zh") : x - y;
    return c ? c * dir : tie(a, b);
  });
}
const mkTh = (k, label, cls = "") => { const on = mkSort.k === k;
  return `<th class="${cls}${cls ? " " : ""}mk-sh${on ? " on" : ""}" data-mksort="${k}" title="点击排序${on ? "，再点反向" : ""}">${label}<i class="mk-ar">${on ? (mkSort.dir > 0 ? "▲" : "▼") : "⇅"}</i></th>`; };
function mkList(d, club) {
  const real = !d.demo, budget = d.available != null ? d.available : d.budget != null ? d.budget : club ? club.budget : Infinity;
  const rules = mkRules(d, budget), list = d.market.filter((p) => rules.every((r) => r[2](p)));
  if (mkSort.k) mkSortList(list);
  else if (mkF.pos && mkF.beat) list.sort((a, b) => (b.overall > mkF.beat) - (a.overall > mkF.beat) || b.overall - a.overall);
  return { list, budget, real, rules };
}
// 结果为空：逐条去掉筛选，告诉玩家去掉哪一条会有多少人，一键放宽
function mkWhyEmpty(d, rules) {
  if (!rules.length) return `<div class="empty-note">${!d.demo && !d.market.length ? "市场暂时没有球员（新生涯开局时才会生成各俱乐部名单）" : "没有符合条件的球员"}</div>`;
  const tries = rules.map((r) => [r, d.market.filter((p) => rules.every((x) => x === r || x[2](p))).length]).filter(([, n]) => n > 0).sort((a, b) => b[1] - a[1]).slice(0, 3);
  return `<div class="mk-empty"><b>没有同时满足这些条件的球员</b>${tries.length ? `<span>去掉一条试试：</span>${tries.map(([r, n]) => `<button class="chip sm" data-mkdrop="${r[0]}">去掉“${esc(r[1])}” · ${n} 人</button>`).join("")}` : ""}<button class="chip sm" data-mkclear>清空筛选</button></div>`;
}
function mkDrop(key) {
  if (key === "lg") mkLg = 0; else if (key === "pos-g") mkPos = "全部"; else if (key === "pos") Object.assign(mkF, { pos: null, posName: "", beat: 0 }); else if (key in mkOpt) mkOpt[key] = false;
  else if (key === "watch") mkF.watch = false; else if (key === "q") mkF.q = ""; else mkF[key] = "";
}
// 搜索框边打边筛：只重画表格行与右侧详情，不整页重画（否则输入框失焦）
async function mkRefilter() {
  const [d, club] = await Promise.all([biz("market"), biz("club")]); if (!d) return;
  const { list, budget, real, rules } = mkList(d, club);
  if (!list.some((p) => p.id === mkSel)) mkSel = list.length ? list[0].id : null;
  mkLimit = MK_CHUNK;
  const body = $("#page .mk-table tbody"); if (!body) return draw();
  body.innerHTML = list.slice(0, mkLimit).map((x) => mkRow(x, d, budget, real)).join("") + mkMoreRow(list.length - mkLimit) || `<tr><td colspan="6">${mkWhyEmpty(d, rules)}</td></tr>`;
  bindPage(body);
  const old = $("#page .card.detail"); if (old) { const tmp = document.createElement("div"); tmp.innerHTML = mkDetail(d, club).trim(); const n = tmp.firstElementChild; n.style.animation = "none"; old.replaceWith(n); bindPage(n); }
}
async function viewMarket(name) {
  const [d, club] = await Promise.all([biz("market"), biz("club")]); if (!d) return viewPlan("transfer", name);
  const { list, budget, real, rules } = mkList(d, club), win = d.window || null;
  if (!list.some((p) => p.id === mkSel)) mkSel = list.length ? list[0].id : null;
  const at = list.findIndex((p) => p.id === mkSel);
  mkLimit = Math.max(MK_CHUNK, Math.min(list.length, (Math.floor(Math.max(0, at) / MK_CHUNK) + 1) * MK_CHUNK));     // 选中的那一行一定画出来
  const adv = rules.filter((r) => !["lg", "pos-g", "pos", "top", "budget", "young", "q"].includes(r[0])).length;
  const lgs = mkLeagues(d);
  // 2026-11-16 布局：联赛筛选从两行按钮改成一个下拉（十来个联赛的按钮在手机上要占两行）
  const lgChips = lgs.length ? `<select class="chip mk-lgsel${mkLg ? " on" : ""}" data-mklgsel title="按联赛筛选">${[[0, "全部联赛"], [-1, "本联赛"], ...lgs].map(([id, n]) => `<option value="${id}"${mkLg === id ? " selected" : ""}>${esc(n)}</option>`).join("")}</select>` : "";
  // E360（2026-11-18 用户：“这个夏窗能不能做到下面这里…简化一下…太占空间了”）：从顶栏挪到筛选栏最右，短写“夏窗 1天后 / 夏窗剩 7 天”，全句在悬停提示
  const winName = win ? (win.kind === "winter" ? "冬窗" : "夏窗") : "";
  const winTag = win ? `<span class="mk-win${win.open ? " open" : ""}" title="转会窗口：${winName}${win.open ? `${win.days} 天后关闭` : `${win.days} 天后开启`}">${winName}${win.open ? `剩 ${win.days} 天` : ` ${win.days}天后`}</span>` : "";
  return `<div class="view mk-view" style="grid-template-columns:minmax(0,1fr) 250px">
    <div class="card mk-card" style="--i:0"><div class="filters"><span class="mk-seg">${["全部", "GK", "DF", "MF", "FW"].map((g) => `<button class="chip${mkPos === g ? " on" : ""}" data-mkp="${g}">${g}</button>`).join("")}</span>
      ${mkF.pos ? `<button class="chip on mk-posf" data-mkdrop="pos" title="去掉位置筛选">${esc(mkF.posName)} ×</button>` : ""}
      <button class="chip${mkOpt.top ? " on" : ""}" data-mko="top">★4+</button><button class="chip${mkOpt.budget ? " on" : ""}" data-mko="budget">≤ 预算</button>
      <button class="chip${adv || mkMoreOpen ? " on" : ""}" data-mkadv>筛选${adv ? ` ${adv}` : ""} ▾</button>
      <input class="mk-q" id="mk-q" type="search" placeholder="搜索球员 / 俱乐部" title="搜索球员 / 俱乐部" value="${esc(mkF.q)}">${lgChips}${winTag}</div>
      ${mkMoreOpen ? mkAdvPanel() : ""}
      <div class="cb scroll"><table class="mk-table"><thead><tr>${mkTh("pos", "位置")}<th>Player</th>${mkTh("club", "俱乐部")}${mkTh("ab", "能力", "n")}${mkTh("pot", "潜力", "n")}${mkTh("price", "要价", "n")}</tr></thead><tbody>
      ${list.slice(0, mkLimit).map((x) => mkRow(x, d, budget, real)).join("") + mkMoreRow(list.length - mkLimit) || `<tr><td colspan="7">${mkWhyEmpty(d, rules)}</td></tr>`}</tbody></table></div></div>
    ${mkDetail(d, club)}</div>`;
}
// 更多筛选：一块浮在表格上方的面板（不占表格高度）——精确位置、最高转会费、最高周薪、年龄区间、只看关注、清空
function mkAdvPanel() {
  const POS = ["GK", "CB", "LB", "RB", "DMF", "CMF", "LMF", "RMF", "AMF", "LWF", "RWF", "SS", "CF"];
  const on = (x) => mkF.pos && mkF.pos.length === 1 && mkF.pos[0] === x;
  return `<div class="mk-adv"><div class="mk-adv-r"><span>精确位置</span><span class="mk-posgrid">${POS.map((x) => `<button class="chip sm${on(x) ? " on" : ""}" data-mkpos="${x}" title="${POS_ZH[x]}">${x}</button>`).join("")}</span></div>
    <div class="mk-adv-r"><span>上限</span><label>转会费 ≤ €<input data-mkf="fee" type="number" inputmode="decimal" value="${esc(mkF.fee)}" placeholder="不限">M</label><label>周薪 ≤ €<input data-mkf="wage" type="number" inputmode="numeric" value="${esc(mkF.wage)}" placeholder="不限">K</label>
      <label>年龄 <input data-mkf="amin" type="number" inputmode="numeric" value="${esc(mkF.amin)}" placeholder="16"> ～ <input data-mkf="amax" type="number" inputmode="numeric" value="${esc(mkF.amax)}" placeholder="40"></label></div>
    <div class="mk-adv-r"><span>其他</span><button class="chip sm${mkF.watch ? " on" : ""}" data-mkwatchf>★ 只看关注</button><label class="mk-can"><input type="checkbox" data-mkcan ${mkF.can ? "checked" : ""}>能踢该位置的也算</label><button class="chip sm" data-mkclear>清空</button><button class="chip sm on" data-mkadv>完成</button></div></div>`;
}
function mkDetail(d, club) {
  const real = !d.demo, budget = d.available != null ? d.available : d.budget != null ? d.budget : club ? club.budget : Infinity, win = d.window || null;
  const p = d.market.find((x) => x.id === mkSel), over = p && p.price > budget, star = p && d.shortlist.includes(p.id);
  const live = p && p.bid && ["pending", "countered", "agreed", "personal"].includes(p.bid.state) ? p.bid : null;   // 正在谈的报价（等待答复 / 对方还价 / M6-E1 和球员谈条款）
  const clubCrest = mkClubCrest, st = p ? mkStars(p, d.star_ref) : null, nfs = p && p.status === "nfs", ref = p ? (nfs ? p.value : p.price) : 0;
  return `<div class="card detail" style="--i:1">${p ? `<div class="ch">球员详情<button class="r" ${real ? `data-mkwatch="${p.id}"` : later()}>${star ? "★ 已关注" : "☆ 关注"}</button></div>
      <div class="who">${pfaceGo(p, p.club && p.club.id, "lg")}<div><b>${esc(p.name)}</b><small>${esc(p.position)} · ${clubCrest(p.club)} ${esc(p.club.name)}${p.club.lg ? `（${esc(p.club.lg_name)}）` : ""}</small>${p.version ? `<small class="ver" title="${esc(p.version)}">${esc(p.version)}</small>` : ""}</div></div>
      <div class="cb" title="星级是全联赛统一的刻度：3 星＝联赛中游主力，5 星＝世界级；具体能力签下后才知道"><div class="meter mk-st"><span>能力</span>${starsHtml(st.ab)}</div><div class="meter mk-st"><span>潜力</span>${starsHtml(st.lo, st.hi, "pot")}</div>${mkVsTag(p.ca, d)}
      </div>
      <div class="price"><div><small>俱乐部要价${p.status === "listed" ? ` <span class="mk-lst">挂牌</span>` : ""}${club && !nfs ? ` · <span class="${ref > budget ? "dn" : ""}" title="占转会预算">预算 ${Math.round(ref / budget * 100)}%</span>` : ""}</small>${nfs ? `<span class="mk-nfs big" title="一般报价不会考虑，只有高到无法拒绝的报价才可能成交">非卖品</span>` : `<span class="num" data-to="${p.price}" data-pre="€" data-suf="M">${money(p.price, 0)}</span>`}</div><div style="text-align:right"><small>期望周薪</small><span class="num" style="font-size:19px;color:var(--ink)">${kfmt(p.wage)}</span></div></div>
      <div class="acts"><button class="btn" ${real ? `data-mkcmp="${p.id}"` : `data-tab="transfer:1"`}>${real ? "对比" : "球探报告"}</button>${real
        ? (live ? (live.state === "agreed" ? `<button class="btn gold" data-terms="${live.id}">谈个人条款</button>`
            : `<button class="btn" data-tab="transfer:2">${live.state === "pending" ? "已报价 · 等待答复" : live.state === "personal" ? "已开条件 · 等球员答复" : `对方还价 ${money(live.fee, 1)}`}</button>`)
          : !win || !win.open ? `<button class="btn" disabled>窗口关闭</button>` : `<button class="btn gold" data-mkbid="${p.id}">发起报价</button>`)
        : `<button class="btn ${over ? "" : "gold"}" ${over ? "disabled" : later("报价功能在经营层上线后开放")}>${over ? "超出预算" : "发起报价"}</button>`}</div>` : `<div class="empty-note">选一名球员</div>`}</div>`;
}
// 真实联赛的标志 (服务端 career.comp_logo = 竞赛 ID, 游戏里有才给; 图在 /img/comp/L<id>.png)
const lgLogo = () => (S && S.career && S.career.comp_logo ? `<img class="lg-logo" src="/img/comp/L${S.career.comp_logo}.png" alt="">` : "");
const crestId = (id, code, c, cls = "") => `<span class="cw ${cls}${id ? "" : " fb"}">${id ? `<img src="/img/emblem/${id}.png" alt="" onerror="this.parentNode.classList.add('fb')">` : ""}<i style="--c:${c || "#555"}">${esc(code)}</i></span>`;
async function viewScout(name) {
  const d = await biz("market"); if (!d) return viewPlan("transfer", name);
  const sl = d.market.filter((p) => d.shortlist.includes(p.id));
  const note = (p) => (p.ca_pot ? p.ca_pot[1] : 0) - (p.ca || 0) >= 12 ? "年轻、成长空间大，建议尽早签下" : ["up", "eq"].includes((mkVsUs(p.ca, d) || [])[0]) ? "即战力，能直接进首发" : "稳定的轮换人选";
  return `<div class="view" style="grid-template-columns:minmax(0,1fr)"><div class="card"><div class="ch">关注名单<span class="r">${sl.length} 人 · 在“市场”里点 ☆ 加入</span></div>
    <div class="cb scroll"><div class="ycards">${sl.map((p, i) => `<div class="ycard" style="--i:${i}"><div class="yt">${pos(p.position)}<span class="muted">${p.age} 岁</span></div><b>${pfaceGo(p, p.club && p.club.id, "lg")}${esc(p.name)}</b>
      <div class="ypot"><span>能力</span>${starsHtml(mkStars(p, d.star_ref).ab)}<span>潜力</span>${starsHtml(mkStars(p, d.star_ref).lo, mkStars(p, d.star_ref).hi, "pot")}</div><small>${crestId(p.club.id, p.club.code, p.club.c, "sm")} ${esc(p.club.name)} · ${p.status === "nfs" ? '<b class="mk-nfs">非卖品</b>' : `要价 <b style="color:var(--gold)">${money(p.price, 0)}</b>`}</small>
      <small style="color:var(--ink2)">球探：${note(p)}</small><button class="btn sm" data-mkgo="${p.id}">在市场中查看</button></div>`).join("") || `<div class="empty-note">还没有关注的球员</div>`}</div></div></div></div>`;
}
async function viewOffers(name) {
  const [d] = await Promise.all([biz("market"), biz("squad").catch(() => null)]); if (!d) return viewPlan("transfer", name);
  const ST = { pending: ["待答复", "var(--draw)"], accepted: ["已成交", "var(--win)"], rejected: ["已拒绝", "var(--loss)"], expired: ["已过期", "var(--ink3)"] }, real = !d.demo;
  const col = (title, rows, mine) => `<div class="card"><div class="ch">${title}<span class="r">${rows.length} 条</span></div><div class="cb scroll">
    ${rows.map((o) => `<div class="offer">${pos(o.position)}<div><b>${pface(o)}${esc(o.player)}</b><span>${mine ? (real ? "签自" : "向") : "来自"} ${o.clubId ? crestId(o.clubId, String(o.club).slice(0, 3), "#555", "sm") + " " : ""}${esc(o.club)} · ${o.state === "pending" ? `剩 ${esc(o.expires)}` : ""}</span></div><span class="num" style="color:var(--gold);font-size:20px">${money(o.fee, real ? 1 : 0)}</span>
      <em style="color:${(ST[o.state] || ST.expired)[1]}">${(ST[o.state] || ST.expired)[0]}</em>${o.state === "pending" ? (mine ? `<button class="btn sm" ${later()}>撤回</button>` : real ? `<button class="btn sm" data-oact="reject" data-oid="${o.id}">拒绝</button><button class="btn sm pri" data-oact="accept" data-oid="${o.id}">接受</button>` : `<button class="btn sm" ${later()}>拒绝</button><button class="btn sm pri" ${later()}>接受</button>`) : ""}</div>`).join("") || `<div class="empty-note">没有报价</div>`}</div></div>`;
  // 真数据的“我的报价”：每个向别的俱乐部发出的报价，从等待答复到成交 / 还价 / 拒绝
  // M6-E1：俱乐部同意转会费后进入球员段——agreed（去谈个人条款）/ personal（等球员隔天答复）/ collapsed（谈判破裂）
  const OUT = { pending: ["等待答复", "var(--draw)"], countered: ["对方还价", "var(--gold)"], agreed: ["谈个人条款", "var(--gold)"], personal: ["等球员答复", "var(--draw)"], accepted: ["已成交", "var(--win)"], rejected: ["已拒绝", "var(--loss)"], expired: ["已过期", "var(--ink3)"], withdrawn: ["已撤回", "var(--ink3)"], failed: ["没能办成", "var(--loss)"], collapsed: ["谈判破裂", "var(--loss)"] };
  const lastAns = (o) => { const t = o.terms && o.terms.offers.length ? o.terms.offers[o.terms.offers.length - 1] : null; const race = o.terms && o.terms.competition, winner = race && race.offers.find((x) => x.team === race.winner); return winner ? `球员选择加盟 ${winner.club}` : t && t.answer && !t.answer.ok ? t.answer.text : ""; };
  const outRow = (o) => { const st = OUT[o.state] || ["", "var(--ink3)"], talk = o.state === "agreed" || o.state === "personal" || o.state === "collapsed";
    const lostTo = o.state === "collapsed" && o.race && o.race.winner != null;
    const stl = lostTo ? "竞争落败" : st[0];          // 不改共用的 OUT 表，只换这一行的标签
    const sub = talk ?`${o.clubId === 0 ? "自由身 · 不需要转会费" : `${esc(o.club)} 同意 ${money(o.fee, 1)}`}${o.state === "agreed" ? ` · ${esc(o.expires)} · 还能谈 ${o.terms.offers_left} 次` : o.state === "personal" ? ` · ${esc(o.expires)}` : ""}`
      : `向 ${o.clubId ? crestId(o.clubId, String(o.club).slice(0, 3), "#555", "sm") + " " : ""}${esc(o.club)} · 报价 ${money(o.bid, 1)} · 要价 ${money(o.ask, 1)}${o.state === "countered" ? ` · 剩 ${esc(o.expires)}` : o.state === "pending" ? ` · ${esc(o.expires)}` : ""}`;
    const why = talk && lastAns(o) && !lostTo ? `<small class="of-why">${o.state === "collapsed" ? "" : "上次答复："}${esc(lastAns(o))}</small>` : "";
    return `<div class="offer${o.race ? " raced" : ""}">${pos(o.position)}<div><b>${pface(o)}${esc(o.player)}</b><span>${sub}</span>${why}${mkRaceLine(o)}</div><span class="num" style="color:var(--gold);font-size:20px">${money(o.fee, 1)}</span>
      <em style="color:${st[1]}">${stl}</em>${o.state === "pending" || o.state === "personal" ? `<button class="btn sm" data-wd="${o.id}">撤回</button>` : o.state === "countered" ? `<button class="btn sm" data-wd="${o.id}">撤回</button><button class="btn sm pri" data-ctr="${o.id}">接受还价</button>` : o.state === "agreed" ? `<button class="btn sm" data-wd="${o.id}">放弃</button><button class="btn sm pri" data-terms="${o.id}">谈条款</button>` : ""}</div>`; };
  if (!real) return `<div class="view" style="grid-template-columns:minmax(0,1fr) minmax(0,1fr)">${col("收到的报价", d.offers.incoming, false)}${col("发出的报价", d.offers.outgoing, true)}</div>`;
  // 体验评审 U07/U08（批次 C）：一张单列清单——“需要你处理”（对方还价、收到的出价）→“等待答复”→“刚成交”（带查看新援 / 安排上阵）→ 历史折叠。
  // 标题按待办计数，不再对已成交的报价写“答复在下一场比赛后”；矮屏不再出现半边空栏。
  const own = new Map((d.own || []).map((p) => [String(p.pid), p]));
  const out = d.offers.outgoing, inc = d.offers.incoming;
  const reply = [...out.filter((o) => o.state === "agreed" || o.state === "countered"), ...inc.filter((o) => o.state === "pending")];
  const wait = out.filter((o) => o.state === "pending" || o.state === "personal");
  const done = out.filter((o) => o.state === "accepted");
  const lost = out.filter((o) => o.state === "collapsed" && o.race && o.race.winner != null);      // 竞争落败单独一节，不沉到历史里
  const hist = [...out.filter((o) => !["countered", "pending", "accepted", "agreed", "personal"].includes(o.state) && !lost.includes(o)), ...inc.filter((o) => o.state !== "pending")];
  const incRow = (o) => `<div class="offer">${pos(o.position)}<div><b>${pface(o)}${esc(o.player)}</b><span>${o.clubId ? crestId(o.clubId, String(o.club).slice(0, 3), "#555", "sm") + " " : ""}${esc(o.club)} 求购 · ${o.state === "pending" ? `剩 ${esc(o.expires)}` : ""}</span></div><span class="num" style="color:var(--gold);font-size:20px">${money(o.fee, 1)}</span>
    <em style="color:${(ST[o.state] || ST.expired)[1]}">${o.state === "pending" ? "收到出价" : (ST[o.state] || ST.expired)[0]}</em>${o.state === "pending" ? `<button class="btn sm" data-oact="reject" data-oid="${o.id}">拒绝</button><button class="btn sm pri" data-oact="accept" data-oid="${o.id}">接受</button>` : ""}</div>`;
  const doneRow = (o) => { const p = own.get(String(o.pid)), w = BIZ.squad && BIZ.squad.players && BIZ.squad.players[String(o.pid)];
    const where = !p ? "已不在队中" : p.in_squad ? "已在 23 人名单" : "在预备队";
    const role = o.signed ? ROLE_ZH[o.signed.role] : "";
    return `<div class="offer done">${pos(o.position)}<div><b>${pface(o)}${esc(o.player)}</b><span>签自 ${esc(o.club)} · 转会费 ${money(o.fee, 1)}${o.signed ? ` · 周薪 ${kfmt(o.signed.wage)} · ${o.signed.years} 年 · ${role}` : w && w.wage != null ? ` · 周薪 ${kfmt(w.wage)}` : ""} · ${where}</span>${mkRaceLine(o)}</div>
      <em style="color:var(--win)">已成交</em>${p ? `<button class="btn sm" data-player="${esc(o.pid)}">查看新援</button>${p.in_squad ? "" : `<button class="btn sm pri" data-sub="${esc(o.pid)}">安排上阵</button>`}` : ""}</div>`; };
  const sec = (title, rows) => rows ? `<div class="ibg">${title}</div>${rows}` : "";
  const head = [reply.length ? `需回复 <b class="up">${reply.length}</b>` : "", wait.length ? `等待 <b>${wait.length}</b>` : "", done.length ? `已成交 <b>${done.length}</b>` : ""].filter(Boolean).join(" · ") || "没有进行中的报价";
  const body = sec("需要你处理", reply.map((o) => (o.bid !== undefined ? outRow(o) : incRow(o))).join(""))
    + sec("等待答复", wait.map(outRow).join(""))
    + sec("刚成交", done.map(doneRow).join(""))
    + sec("竞争落败", lost.map(outRow).join(""))
    + (hist.length ? `<details class="of-hist"><summary class="ibg">历史 · ${hist.length} 条 ›</summary>${hist.map((o) => (o.bid !== undefined ? outRow(o) : incRow(o))).join("")}</details>` : "");
  return `<div class="view" style="grid-template-columns:minmax(0,1fr)"><div class="card"><div class="ch">报价<span class="r">${head}</span></div>
    <div class="cb scroll">${reply.length + wait.length + done.length + lost.length ? body : `<div class="empty-note">还没有报价。在“市场”里选一名球员点“发起报价”；挂牌出售的球员收到出价也会出现在这里</div>${body}`}</div></div></div>`;
}
async function viewListings(name) {
  const d = await biz("market"); if (!d) return viewPlan("transfer", name);
  const real = !d.demo;
  return `<div class="view" style="grid-template-columns:minmax(0,1fr)"><div class="card"><div class="ch">挂牌出售<span class="r"><button class="btn sm" ${real ? `data-lst="new"` : later()}>挂牌新球员</button></span></div>
    <div class="cb scroll"><table><thead><tr><th>位置</th><th>球员</th><th class="n">能力</th><th class="n">${real ? "身价" : "挂牌价"}</th>${real ? `<th class="n">挂牌价</th>` : ""}<th class="n">感兴趣的俱乐部</th><th class="n">已挂牌</th><th class="c">操作</th></tr></thead><tbody>
    ${d.listings.map((l) => `<tr><td>${pos(l.position)}</td><td class="name">${pface(l)}<b>${esc(l.name)}</b></td><td class="n">${ovr(l.overall)}</td>${real ? `<td class="n"><span class="num muted">${money(l.value, 1)}</span></td>` : ""}<td class="n"><span class="num" style="color:var(--gold)">${money(l.price, real ? 1 : 0)}</span></td><td class="n">${l.interest} 家</td><td class="n muted">${l.days} 天</td><td class="c">${real ? `<button class="btn sm" data-lst="${l.pid}">改价</button> <button class="btn sm" data-unlist="${l.pid}">撤牌</button>` : `<button class="btn sm" ${later()}>改价</button> <button class="btn sm" ${later()}>撤牌</button>`}</td></tr>`).join("") || `<tr><td colspan="${real ? 8 : 7}"><div class="empty-note">没有挂牌球员${real ? "。挂牌后转会窗开着的每一天都有俱乐部可能出价，也可以直接“立即出售”" : ""}</div></td></tr>`}</tbody></table></div></div></div>`;
}
/* ---- 转会操作（2026-11-14，M4 批 6）：签下 / 关注 / 挂牌 / 出售 / 接受或拒绝报价 / 预备队球员上阵。服务端 iml_market；下面只有弹窗和调用。 ---- */
function mkDialog(title, body, actions, cls = "") {          // cls "fm"：FM 式谈判单外观（45-fm-sheet.js）
  $$("#mkdlg").forEach((e) => e.remove());
  const el = document.createElement("div"); el.id = "mkdlg"; el.className = "dlg-back";
  el.innerHTML = `<div class="dlg wide ${cls}" role="dialog" aria-modal="true"><b class="dlg-t">${title}</b>${body}<div class="dlg-b">${actions.map((a, i) => `<button data-i="${i}" class="${a.pri ? "pri" : ""}${a.warn ? " warn" : ""}" ${a.off ? "disabled" : ""}>${a.label}</button>`).join("")}</div></div>`;
  document.body.appendChild(el);
  const close = () => { document.removeEventListener("keydown", onKey); el.remove(); };
  const onKey = (e) => { if (e.key === "Escape") { sound("back"); close(); } };
  document.addEventListener("keydown", onKey);
  el.addEventListener("click", (e) => { if (e.target === el) { sound("back"); close(); } });
  $$(".dlg-b button", el).forEach((b) => b.onclick = async () => { const a = actions[+b.dataset.i]; if (!a.fn) { sound("back"); return close(); } b.disabled = true; const keep = await a.fn(el, close); if (keep === false) b.disabled = false; });
  return el;
}
const mkFail = (r) => { if (!r || r.error || !r.ok) { toast((r && r.error) || "操作失败，请重试"); return true; } return false; };       // 宿主动作成功一律回 {ok:true,…}：空回包（宿主不认识这个动作）也算失败
// 2026-11-14 用户：“这种弹窗能不能全部取消掉”——操作成功不再弹底部提示，结果直接体现在刷新后的页面（报价状态、预算、名单）里；
// msg 参数保留给调用处当说明，不显示。失败提示（mkFail 等）仍然保留，否则按钮没反应时玩家不知道为什么。
async function mkAfter(msg) { $$("#mkdlg").forEach((e) => e.remove()); await refresh(true); }
// 发起报价（FM 式，2026-11-14 用户：“转会不要直接签下，要俱乐部发起报价”）：向球员所在俱乐部报一个转会费，俱乐部两天后答复（M5-D-b）——
// 达到他们的底线就接受并完成转会；略低于底线会还价（在“报价”页接受还价或撤回）；太低直接拒绝并冷却几轮。已承诺给报价的钱不能再用于别的报价。
async function mkBid(card) {
  const d = await biz("market"), p = d && d.market.find((x) => x.id === card); if (!p) return;
  const min = d.limits ? d.limits.min_bid : 0.3, avail = d.available, bal = d.budget, com = Math.max(0, +(bal - avail).toFixed(1));
  const nfs = p.status === "nfs", ref = nfs ? p.value : p.price, what = nfs ? "身价" : "要价";       // 非卖品：没有公开要价，拿身价作参照
  const who = fmWho({ ...p, stars: mkStars(p, d.star_ref) }, { color: p.club.c, crest: `<span class="fm-cl">${crestId(p.club.id, p.club.code, p.club.c, "sm")}${esc(p.club.name)}</span>`,
    tag: nfs ? "非卖品" : p.status === "listed" ? "挂牌出售" : "", facts: [["身价", money(p.value, 1)], ["期望周薪", kfmt(p.wage)], ["版本", esc(p.version || "—")]] });
  const pct = (f) => (ref * f).toFixed(1);
  // 2026-11-17 用户：“发起报价 弹窗 你优化一下吧”——顶部流程条（让人知道俱乐部同意后还有个人条款与可能的竞争合同）；
  // 左＝体育总监的话＋转会费；右＝总投入（转会费＋按期望周薪 3 年估的工资）与预算、竞争风险（/api/market/interest：同一世界里有位置需求、
  // 资金与薪资空间、可能开出竞争合同的球队；只读估算，不抽签，真正开价最多 2 家）。
  const steps = [["报价", "现在"], ["俱乐部答复", "2 天"], ["个人条款", "周薪 · 年限 · 定位"], ["竞争合同", "可能出现"], ["成交", ""]];
  const flow = `<ol class="bd-flow">${steps.map(([t, s], i) => `<li class="${i === 0 ? "on" : ""}${i === 3 ? " race" : ""}"><b>${t}</b>${s ? `<small>${s}</small>` : ""}</li>`).join("")}</ol>`;
  const voice = nfs ? fmQuote(`${esc(p.club.name)} · 体育总监`, `${esc(p.name)} 不在我们的出售名单上——<b>他是非卖品</b>。一般的报价我们不会考虑，也不会还价。`, "bad")
      : fmQuote(`${esc(p.club.name)} · 体育总监`, `${p.status === "listed" ? "我们愿意放他走。" : ""}要价 <b class="gold">${money(p.price, 1)}</b>。${p.seller?.text ? `要价考虑了：${esc(p.seller.text)}。` : ""}低一些我们也会认真考虑，两天内答复。`);
  const feeSec = fmSec("转会费", `<div class="fm-row">${fmStep("mk-fee", Math.min(nfs ? ref * 1.5 : ref, avail).toFixed(1), { step: 0.5, min: (p.price * min).toFixed(1), dec: 1, unit: "M €" })}</div>
        <div class="fm-quick bd-quick">${nfs ? `<button class="chip sm" data-fill="mk-fee:${pct(1)}">身价</button><button class="chip sm" data-fill="mk-fee:${pct(1.5)}">×1.5</button><button class="chip sm" data-fill="mk-fee:${pct(2.5)}">×2.5</button>`
          : `<button class="chip sm" data-fill="mk-fee:${pct(0.85)}">要价 85%</button><button class="chip sm" data-fill="mk-fee:${pct(0.95)}">95%</button><button class="chip sm" data-fill="mk-fee:${pct(1)}">要价</button>`}</div>${fmMeter("mk-vs", "mk-fee")}`);
  const costSec = fmSec("总投入", `<div class="bd-cost"><div><small>转会费</small><b class="num" id="bd-fee"></b></div><i>＋</i><div><small>工资 · 3 年</small><b class="num">${money(p.wage * 52 * 3 / 1000, 1)}</b></div><i>＝</i><div class="t"><small>合计</small><b class="num" id="bd-total"></b></div></div>
      ${fmMeter("mk-bud")}`, `周薪按期望 ${kfmt(p.wage)} 估`);
  const riskSec = fmSec("竞争风险", `<div class="bd-risk" id="bd-risk"><small class="muted">正在估算…</small></div>`);
  const main = `${flow}<div class="fm-cols bd-cols"><div class="fm-c">${voice}${feeSec}</div><div class="fm-c">${costSec}${riskSec}</div></div>`;
  const el = mkDialog("发起报价", fmSheet(who, main, "bd"),
    [{ label: "取消" }, { label: "发出报价", pri: true, fn: async (box) => { const r = await post("/api/market/bid", { card, fee: +$("#mk-fee", box).value }); if (mkFail(r)) return false; sound("ok"); await mkAfter(`已向${p.club.name}报价 ${money(r.fee, 1)}`); } }], "fm");
  // 竞争风险：转会费变了重新估（对手也要付同样的转会费，钱不够的就不来抢）；防抖，只认最新一次
  let rt = 0, rseq = 0;
  const risk = () => { clearTimeout(rt); rt = setTimeout(async () => { const mine = ++rseq; let r = null;
    try { r = await post("/api/market/interest", { card, fee: +$("#mk-fee", el).value || 0 }); } catch (e) { r = null; }
    const box = $("#bd-risk", el); if (mine !== rseq || !box || !document.body.contains(el)) return;
    if (!r || r.error || !Array.isArray(r.clubs)) { box.innerHTML = `<small class="muted">暂时估算不了</small>`; return; }
    const n = r.clubs.length, lv = n === 0 ? "low" : n <= 2 ? "mid" : "high";
    box.dataset.lv = lv;
    box.innerHTML = n === 0 ? `<div class="bd-rh"><em>低</em><span>没有别的俱乐部有能力争夺他</span></div>`
      : `<div class="bd-rh"><em>${lv === "high" ? "高" : "中"}</em><span>另有 <b>${n}</b> 家俱乐部有需要、也付得起</span></div>`
        + `<div class="bd-rc">${r.clubs.slice(0, 6).map((c) => `<span title="${esc(c.club)} · 实力 #${c.rank} · 会给${ROLE_ZH[c.role] || ""}">${crest(c.team, "sm")}<small>${ROLE_ZH[c.role] || ""}</small></span>`).join("")}${n > 6 ? `<small class="muted">+${n - 6}</small>` : ""}</div>`
        + `<small class="bd-rn">俱乐部同意后，其中最多 ${r.max || 2} 家可能开出合同，2～4 天内球员比较后决定去向</small>`; }, 300); };
  const paint = () => { const f = +$("#mk-fee", el).value || 0, r = f / ref;
    fmMeterSet($("#mk-vs", el), nfs ? { add: f, cap: ref, max: ref * 3, limit: false, tone: "mid", label: `身价的 ${Math.round(r * 100)}%（非卖品，没有公开要价）`, value: money(f, 1) }
      : { add: f, cap: ref, max: ref * 1.25, tone: r >= 1 ? "ok" : r >= 0.85 ? "mid" : "low", label: gapTxt(r, what), value: `${Math.round(r * 100)}%` });
    fmMeterSet($("#mk-bud", el), { base: com, add: f, cap: bal, max: bal, tone: f > avail ? "" : "mid", label: f > avail ? "超出可用转会预算" : `报价后可用 · 已承诺 ${money(com, 1)}`, value: money(Math.max(0, avail - f), 1) });
    $("#bd-fee", el).textContent = money(f, 1); $("#bd-total", el).textContent = money(f + p.wage * 52 * 3 / 1000, 1); risk(); };
  fmBind(el, paint); paint();
}
// M6-E1 两段谈判（契约 INDEPENDENT_MASTER_LEAGUE_M6_NEGOTIATION.md；用户定：球员隔天答复）：俱乐部同意转会费后，和球员谈周薪 / 年限 / 队内定位。
// 每个定位旁写他的要价（服务端 iml_terms.hints），并说明他现在的角色与在我队“可信”的最高定位；上次被拒的原因放在顶上。提交后他第二天答复，“继续”会停下。
const ROLE_ZH = { core: "核心", starter: "主力", rotation: "轮换", prospect: "培养" };
/* 竞争合同（E343/E344 的 CPU 竞价，2026-11-17 用户：“优化一下转会签约的UI吧 我们不是做了CPU竞价吗”）：
   谈条款弹窗里一块对比板——第一行我方（随周薪 / 定位 / 年限实时变），下面每家对手：队徽、周薪、定位、年限、实力排名；
   逐项和我方比，对手更好标红、我方更好标绿；右上角倒计时与“领先 / 落后”（服务端预览 competition 一项，不涉及隐藏的接受概率）。
   报价页：竞争中的报价带“竞争 · N 家”与对手队徽；失利写“被 ×× 抢走”并并排两份合同；赢了写“击败 N 家”。 */
const ROLE_LV = { core: 3, starter: 2, rotation: 1, prospect: 0 };
function mkRaceRow(team, label, t, rank, ours, me) {
  const cmp = (a, b, hi = true) => (me || a == null || b == null || a === b ? "" : (hi ? a > b : a < b) ? " up" : " dn");    // up＝对手这一项更好（对我们不利）
  return `<div class="rc-r${me ? " me" : ""}"><span class="rc-t">${crest(team, "sm")}<b>${esc(label)}</b></span>`
    + `<span class="rc-v${cmp(t.wage, ours.wage)}">${kfmt(t.wage)}</span><span class="rc-v${cmp(ROLE_LV[t.role], ROLE_LV[ours.role])}">${ROLE_ZH[t.role] || "—"}</span>`
    + `<span class="rc-v">${t.years}年</span><span class="rc-v${cmp(rank, ours.rank, false)}" title="俱乐部实力排名">${rank ? `#${rank}` : "—"}</span></div>`;
}
// 报价页一行：竞争中＝“竞争 · N 家”＋对手队徽；失利＝被谁抢走＋两份合同并排；成交＝击败 N 家
function mkRaceLine(o) {
  const r = o.race; if (!r || !r.rivals || !r.rivals.length) return "";
  const crests = (list) => list.map((x) => `<i title="${esc(x.club)} · ${kfmt(x.wage)} · ${ROLE_ZH[x.role] || ""} · ${x.years}年">${crest(x.team, "sm")}</i>`).join("");
  const live = r.rivals.filter((x) => x.state === "active");
  if (o.state === "agreed" || o.state === "personal")
    return live.length ? `<div class="of-race live"><em>竞争 · ${live.length} 家</em>${crests(live)}<small>${live.map((x) => esc(x.club)).join("、")}</small></div>` : "";
  if (o.state === "collapsed" && r.winner != null) {
    const w = r.rivals.find((x) => x.team === r.winner), ours = o.terms && o.terms.offers.length ? o.terms.offers[o.terms.offers.length - 1] : null;
    // 对方合同里胜过我方的那几项标红（周薪更高 / 定位更高），一眼看出输在哪
    const beat = (k) => ours && w && (k === "wage" ? w.wage > ours.wage : ROLE_LV[w.role] > ROLE_LV[ours.role]);
    // 两份合同上下对齐成一个小表（对方一行、我方一行），旁边一句“输在 周薪 · 定位”；原来挤在一行、我方是灰色小字看不清
    const cells = (x, mark) => `<span class="${mark && beat("wage") ? "up" : ""}">${kfmt(x.wage)}</span><span class="${mark && beat("role") ? "up" : ""}">${ROLE_ZH[x.role] || "—"}</span><span>${x.years}年</span>`;
    const why = [beat("wage") && "周薪", beat("role") && "定位"].filter(Boolean);
    const cmp = w && ours ? `<div class="of-cmp"><span class="k">${crest(w.team, "sm")}对方</span>${cells(w, true)}<span class="k me">${crest(me(), "sm")}我方</span>${cells(ours, false)}</div>`
      + (why.length ? `<small class="why">输在 ${why.join(" · ")}</small>` : "") : "";
    return `<div class="of-race lost"><em>被抢走</em>${w ? `<i>${crest(w.team, "sm")}</i><b>${esc(w.club)}</b>${w.rank ? `<small>实力第 ${w.rank}</small>` : ""}` : ""}</div>`
      + (cmp ? `<div class="of-lost">${cmp}</div>` : "");
  }
  if (o.state === "accepted") return `<div class="of-race won"><em>击败 ${r.rivals.length} 家</em>${crests(r.rivals)}</div>`;
  return "";
}
function mkRaceBoard(rivals, ours, { when = "", state = "" } = {}) {
  const pill = state ? `<em class="rc-st ${state === "ok" ? "lead" : "trail"}">${state === "ok" ? "领先" : "落后"}</em>` : "";
  return `<div class="rc-head"><span>${pill}${when ? `<small>${esc(when)}</small>` : ""}</span></div>`
    + `<div class="rc-grid"><div class="rc-r h"><span>球队</span><span>周薪</span><span>定位</span><span>年限</span><span>实力</span></div>`
    + mkRaceRow(me(), "我方", ours, ours.rank, ours, true) + rivals.map((o) => mkRaceRow(o.team, o.club, o, o.rank, ours, false)).join("") + `</div>`;
}
async function mkTerms(id) {
  const [d, club] = await Promise.all([biz("market"), biz("club").catch(() => null)]);
  const o = d && d.offers.outgoing.find((x) => x.id === id); if (!o || !o.terms || !o.terms.hints) return toast("这个报价现在不能谈条款");
  const h = o.terms.hints, roles = Object.keys(h.want), last = o.terms.offers.length ? o.terms.offers[o.terms.offers.length - 1] : null;
  let role = roles.includes(h.expects) ? h.expects : roles[0], years = 3;
  const LV = { core: 3, starter: 2, rotation: 1, prospect: 1 }, SHARE = { core: "参与 70%+（替补按⅓计）", starter: "参与 50%+（替补按⅓计）", rotation: "参与 20%+（替补按⅓计）", prospect: "参与 10%+（替补按⅓计）" };
  const race = o.terms.competition, rivals = race && race.offers ? race.offers : [];
  const ourRank = o.race ? o.race.our_rank : null;
  let raceState = "";                                                    // 预览里 competition 一项：ok＝领先 / talk＝落后
  const raceNote = rivals.length ? fmSec(`竞争合同 · ${rivals.length} 家`, `<div class="mk-race" id="mk-race"></div>`, "") : "";
  const replyNote = rivals.length ? `${esc(race.decision_on)} 决定去向` : "他明天答复";
  const used = o.terms.offers.length, total = used + o.terms.offers_left;
  const pips = `<span class="fm-pips" title="还能谈 ${o.terms.offers_left} 次">${Array.from({ length: total }, (_, i) => `<i class="${i < used ? "used" : ""}"></i>`).join("")}</span>${esc(o.expires)}`;
  const who = fmWho({ name: o.player, pid: o.pid, position: o.position, age: o.terms.age, stars: { ab: starVal(o.terms.ca, d.star_ref), lo: null, hi: null } },
    { color: o.clubId ? tcolor(o.clubId) : null, crest: `<span class="fm-cl">${o.clubId ? crestId(o.clubId, String(o.club).slice(0, 3), "#555", "sm") : ""}${esc(o.club)}</span>`,
      tag: o.clubId === 0 ? "自由身" : `已同意 ${money(o.fee, 1)}`, facts: [["现在的角色", ROLE_ZH[h.expects]], ["市场周薪", kfmt(o.terms.market_wage)], ["你队同位置更强", `${h.better} 人`]] });
  const voice = last && last.answer && !last.answer.ok
    ? fmQuote(`经纪人 · 第 ${last.n} 次（${ROLE_ZH[last.role]} · ${kfmt(last.wage)} · ${last.years} 年）`, esc(last.answer.text), "bad")
    : fmQuote("经纪人", o.clubId === 0 ? `我的球员现在是自由身，不需要转会费，想找一个能让他踢上球的地方。给他<b>${ROLE_ZH[h.expects]}</b>左右的角色和合适的待遇，他会认真考虑。` : `我的球员在${esc(o.club)}是<b>${ROLE_ZH[h.expects]}</b>。给他合适的角色和待遇，他会认真考虑。`);
  // E334：定位卡写“基础价”（市场周薪×定位系数）、加成（定位 / 俱乐部…的 +x%）与“稳妥价”（他一定答应的周薪）；周薪框默认填稳妥价
  const ask = (r) => (h.year_wages?.[r]?.[String(years)] ?? (h.roles && h.roles[r] ? h.roles[r].safe : h.want[r]));
  const card = (r) => { const rd = h.roles && h.roles[r], tags = [r === h.expects ? `<u class="now">现在</u>` : ""].join("");     // 2026-11-16 用户：像 FM，定位越高越好——不再有“难以置信”标签与加价
    const adj = rd && rd.parts.length ? fmAdj(rd.parts) : "";
    return fmRoleCard({ r, on: r === role, name: ROLE_ZH[r], tags, price: kfmt(ask(r)), share: SHARE[r], tip: adj ? `基础 ${kfmt(h.want[r])} · ${adj}` : "",
      sub: rd && rd.safe !== rd.base ? `基础 ${kfmt(h.want[r])}${adj ? ` · ${esc(adj.split(" · ")[0])}` : ""}` : "基础价，无加成" }); };
  const lc = last && last.answer && !last.answer.ok ? last.answer : null, counters = lc ? [["他的还价", lc.counter], ["或者", lc.alt]].filter(([, c]) => c && c.wage) : [];
  // 2026-11-16 用户：“要在一个屏幕内把所有信息展示出来，不要上下滑动”——两栏：左＝定位＋薪资结构，右＝（上次还价）＋周薪＋年限＋他的看法
  // 三栏一屏：左＝定位，中＝周薪＋年限＋薪资结构，右＝“他的看法”（经纪人的话＋逐项＋结论＋还价）
  // 有竞争合同时左栏换成对比板（经纪人那句只在上次被拒时保留，一屏放得下）
  const main = `<div class="fm-cols three"><div class="fm-c">${fmSec("队内定位", `<div class="fm-roles${rivals.length ? " row" : ""}">${roles.map(card).join("")}</div>`)}${rivals.length ? (last && last.answer && !last.answer.ok ? voice : "") + raceNote : voice}</div>
      <div class="fm-c">${fmSec("周薪", `<div class="fm-row">${fmStep("mk-wage", ask(role), { step: 1, min: 1, unit: "K € / 周" })}<span class="fm-quick" id="mk-wq"></span></div>${fmMeter("mk-ask", "mk-wage")}`)}${fmInl("合同年限", fmSeg("years", [1, 2, 3, 4, 5].map((y) => [y, `${y}年`]), 3))}${club ? fmSec("", fmMeter("mk-pay")) : ""}</div>
      <div class="fm-c fm-opin">${fmSec("他的看法", `${counters.length ? `<div class="fd-c" id="mk-last">${counters.map(([k, c], n) => `<button type="button" class="chip" data-lc="${n}"><small>上次${k}</small> ${esc(fmCounterTxt(c, ROLE_ZH))}</button>`).join("")}</div>` : ""}${fmFeed("mk-feed")}`)}</div></div>`;
  const el = mkDialog("与球员谈个人条款", fmSheet(who, main, "wide") +`<div class="fm-foot">${pips} · ${replyNote}</div>`,
    [{ label: "取消" }, { label: "开出条件", pri: true, fn: async (box) => {
      const r = await post("/api/market/terms", { bid: id, wage: +$("#mk-wage", box).value, years: +fmSegVal(box, "years"), role });
      if (mkFail(r)) return false; sound("ok"); await mkAfter(""); } }], "fm");
  const quick = () => { const base = h.want[role], w = ask(role); $("#mk-wq", el).innerHTML = [["基础价", base], ...(w !== base ? [["稳妥价", w]] : []), ["110%", Math.round(w * 1.1)]].map(([l, v]) => `<button class="chip sm" data-fill="mk-wage:${v}">${l}</button>`).join(""); };
  const raceBox = $("#mk-race", el);
  const raceDraw = () => { if (!raceBox) return; raceBox.innerHTML = mkRaceBoard(rivals, { wage: +$("#mk-wage", el).value || 0, role, years: +fmSegVal(el, "years") || 3, rank: ourRank }, { when: o.expires, state: raceState }); };
  const feed = fmFeedLoader(el, "/api/market/terms/preview", () => ({ bid: id, wage: +$("#mk-wage", el).value || 0, years: +fmSegVal(el, "years") || 3, role }), ROLE_ZH, (c) => applyCounter(c),
    (r) => { const it = r && r.items ? r.items.find((x) => x.key === "competition") : null; raceState = it ? it.state : ""; raceDraw(); });
  const paint = () => { years = +fmSegVal(el, "years") || 3; const w = +$("#mk-wage", el).value || 0, want = ask(role), r = w / want; raceDraw();
    $$(`[data-role]`, el).forEach((b) => { $(".rp", b).textContent = kfmt(ask(b.dataset.role)); });
    fmMeterSet($("#mk-ask", el), { add: w, cap: want, max: want * 1.5, tone: fmTone(r),
      label: `${gapTxt(r, `${ROLE_ZH[role]}稳妥价`)} · ${kfmt(want)}`, value: `${Math.round(r * 100)}%` });
    if (club) fmMeterSet($("#mk-pay", el), { base: club.weekly_wages, add: w, cap: club.wage_cap, max: club.wage_cap * 1.05, tone: "mid",
      label: "周薪合计 / 上限", value: `${kfmt(club.weekly_wages + w)} / ${kfmt(club.wage_cap)}` });
    quick(); fmBind($("#mk-wq", el), paint); feed(); };
  const setRole = (r) => { role = r; $$("[data-role]", el).forEach((x) => x.classList.toggle("on", x.dataset.role === role)); };
  const applyCounter = (c) => { if (c.role && roles.includes(c.role)) setRole(c.role); $("#mk-wage", el).value = c.wage;
    if (c.years) $$('[data-seg="years"] button', el).forEach((x) => x.classList.toggle("on", x.dataset.v === String(c.years))); paint(); };
  fmBind(el, paint);
  $$("[data-role]", el).forEach((b) => b.onclick = () => { setRole(b.dataset.role); sound("cursor"); $("#mk-wage", el).value = ask(role); paint(); });
  $$("[data-lc]", el).forEach((b) => b.onclick = () => { sound("cursor"); applyCounter(counters[+b.dataset.lc][1]); });
  paint();
}
// 两人比较（M6-F1，评审 §8.1）：市场球员 vs 我队同位置组的人（默认能上场的最好那个，可切换）。只比能力 / 潜力 / 年龄 / 位置 / 周薪 / 身价——
// 不给对方的细项能力值（2026-11-14 用户定的规则：别队球员不展示能力值、技巧和技能），FM 式谈判单外观。
const DP_UNIT = { GK: "GK", CB: "CB", LB: "LB", RB: "RB", DMF: "CM", CMF: "CM", LMF: "LW", LWF: "LW", RMF: "RW", RWF: "RW", AMF: "AM", SS: "ST", CF: "ST" };
async function mkCompare(card) {
  const [d, dp, sq] = await Promise.all([biz("market"), biz("depth").catch(() => null), biz("squad").catch(() => null)]);
  const p = d && d.market.find((x) => x.id === card); if (!p) return;
  const u = dp && dp.units ? dp.units.find((x) => x.unit === DP_UNIT[p.position]) : null;
  const ours = u ? [...u.players, ...u.reserve] : [];
  let pick = ours.find((x) => !x.injured) || ours[0] || null;
  const pot = Array.isArray(p.ca_pot) ? p.ca_pot[1] : null;
  const who = fmWho({ ...p, stars: mkStars(p, d.star_ref) }, { color: p.club.c, crest: `<span class="fm-cl">${crestId(p.club.id, p.club.code, p.club.c, "sm")}${esc(p.club.name)}</span>`,
    facts: [["要价", p.status === "nfs" ? "非卖品" : money(p.price, 1)], ["身价", money(p.value, 1)], ["期望周薪", kfmt(p.wage)]] });
  const sv = (v) => starVal(v, d.star_ref), sfmt = (v) => starsHtml(v);
  const body = () => { const o = pick, oRec = o && sq && sq.players ? sq.players[String(o.pid)] : null, oPot = oRec && oRec.ca_pot ? oRec.ca_pot[1] : null, oCa = oRec ? oRec.ca : null;
    const nat = (apt, x) => (apt && apt[x] === 2 ? "天然" : apt && apt[x] ? "能踢" : "—");
    const line = (k, a, b, { hi = true, fmt = (v) => v } = {}) => { const ok = a != null && b != null, w = ok ? (hi ? a > b : a < b) : null, l = ok ? (hi ? a < b : a > b) : null, m = ok ? Math.max(Math.abs(a), Math.abs(b), 1) : 1;
      return `<div class="cmp-r"><span class="cmp-a${w ? " win" : l ? " lose" : ""}"><b class="num">${a == null ? "—" : fmt(a)}</b><i style="width:${ok ? Math.abs(a) / m * 100 : 0}%"></i></span><em>${k}</em><span class="cmp-b${l ? " win" : w ? " lose" : ""}"><i style="width:${ok ? Math.abs(b) / m * 100 : 0}%"></i><b class="num">${b == null ? "—" : fmt(b)}</b></span></div>`; };
    const chips = ours.length ? `<div class="cmp-pick">${ours.map((x) => `<button type="button" class="chip sm${o && x.pid === o.pid ? " on" : ""}" data-cmp="${x.pid}">${esc(x.name)}${x.injured ? " · 伤" : ""}</button>`).join("")}</div>` : "";
    return fmSec(`对比我队${u ? esc(u.name) : ""}`, `${chips}${o ? `<div class="cmp-head"><b>${esc(p.name)}</b><span>vs</span><b>${esc(o.name)}</b></div>
        ${line("能力", sv(p.ca), sv(oCa), { fmt: sfmt })}${line("潜力", sv(pot), sv(oPot), { fmt: sfmt })}${line("年龄", p.age, o.age, { hi: false })}
        ${line("周薪", p.wage, o.wage, { hi: false, fmt: (v) => kfmt(v) })}${line("身价", p.value, o.value, { fmt: (v) => money(v, 1) })}
        <div class="cmp-r txt"><span class="cmp-a">${p.position} · ${nat(p.apt, p.position)}</span><em>位置</em><span class="cmp-b">${esc(o.position)} · ${o.natural ? "天然" : "能踢"}</span></div>` : `<div class="empty-note">我队没有能踢这个位置的人</div>`}`,
      u ? esc(u.rating_zh) : "") + `<small class="fm-note">能力与潜力都按星级比较（全联赛统一刻度）；对方的具体能力要签下后才知道。</small>`; };
  const el = mkDialog("球员对比", fmSheet(who, `<div id="cmp-main">${body()}</div>`), [{ label: "关闭" }, { label: "发起报价", pri: true, off: !(d.window && d.window.open), fn: async () => { $$("#mkdlg").forEach((e) => e.remove()); mkBid(card); return false; } }], "fm");
  const bind = () => $$("[data-cmp]", el).forEach((b) => b.onclick = () => { pick = ours.find((x) => String(x.pid) === b.dataset.cmp); sound("cursor"); $("#cmp-main", el).innerHTML = body(); bind(); });
  bind();
}
function mkListing(own, d) {
  const lo = d.limits ? d.limits.price[0] : 0.5, hi = d.limits ? d.limits.price[1] : 2.5, start = own.listed != null ? own.listed : +(own.value * 1.1).toFixed(1);
  const v = own.value, at = (f) => (v * f).toFixed(1);
  const who = fmWho(own, { color: tcolor(me()), crest: `<span class="fm-cl">${crest(me(), "sm")}${esc(tname(me()))}</span>`, tag: own.listed != null ? `挂牌中 ${money(own.listed, 1)}` : "",
    facts: [["身价", money(v, 1)], ["名单", own.in_squad ? "23 人名单内" : "预备队"], ["立即出售", money(own.quick, 1)]] });
  const main = fmQuote("体育总监", `挂得越接近身价，越快有人出价；转会窗开着时每天都可能有俱乐部报价。${own.in_squad ? "他在 23 人名单里，<b>成交前要先换下来</b>。" : ""}`, own.in_squad ? "bad" : "")
    + fmSec("挂牌价", `<div class="fm-row">${fmStep("mk-price", start, { step: 0.5, min: at(lo), max: at(hi), dec: 1, unit: "M €" })}
        <span class="fm-quick"><button class="chip sm" data-fill="mk-price:${at(0.9)}">身价 90%</button><button class="chip sm" data-fill="mk-price:${at(1)}">身价</button><button class="chip sm" data-fill="mk-price:${at(1.3)}">130%</button></span></div>${fmMeter("mk-pv", "mk-price")}`, `身价的 ${lo}～${hi} 倍`)
    + fmSec("市场反应", `<div class="fm-heat" id="mk-heat"></div>`);
  const el = mkDialog(own.listed != null ? "改价" : "挂牌出售", fmSheet(who, main),
    [{ label: "取消" }, { label: "培养外租", off: own.in_squad || !(d.window && d.window.open), fn: async () => { await mkLoan(own); } }, { label: `立即出售 ${money(own.quick, 1)}`, off: own.in_squad, warn: true, fn: async () => { const r = await post("/api/market/sell", { card: own.pid }); if (mkFail(r)) return false; sound("ok"); await mkAfter(`已卖出 ${own.name}，${money(r.fee, 1)}`); } },
      { label: "挂牌", pri: true, fn: async (box) => { const r = await post("/api/market/list", { card: own.pid, price: +$("#mk-price", box).value }); if (mkFail(r)) return false; sound("ok"); await mkAfter(`${own.name} 已挂牌 ${money(r.price, 1)}`); } }], "fm");
  // 关注度与服务端 iml_market.interest_chance 同一分档（每周有俱乐部出价的概率）
  const HEAT = [[0.8, 5, "抢手", "几乎每周都有人出价"], [1.0, 4, "热门", "大概两周内会有报价"], [1.2, 3, "一般", "要等几周"], [1.5, 2, "冷门", "很少有人问"], [Infinity, 1, "难卖", "基本没人出价"]];
  const paint = () => { const pr = +$("#mk-price", el).value || 0, r = pr / v, h = HEAT.find(([m]) => r <= m);
    fmMeterSet($("#mk-pv", el), { add: pr, cap: v, max: v * hi, limit: false, tone: r <= 1 ? "ok" : r <= 1.5 ? "mid" : "low", label: "对比身价", value: `${Math.round(r * 100)}%` });
    $("#mk-heat", el).innerHTML = `<span class="fm-bars">${[1, 2, 3, 4, 5].map((i) => `<i class="${i <= h[1] ? "on" : ""}"></i>`).join("")}</span><b>${h[2]}</b><small>${h[3]}</small>`; };
  fmBind(el, paint); paint();
}
async function mkListPicker() {
  const d = await biz("market"); if (!d || d.demo) return;
  const own = [...d.own].sort((a, b) => (a.in_squad - b.in_squad) || (b.value - a.value));
  mkDialog("选择要挂牌的球员", `<div class="mk-pick scroll">${own.map((p) => `<button class="mk-pk" data-pk="${p.pid}">${pos(p.position)}${pface(p)}<b>${esc(p.name)}</b>${ovr(p.overall)}<em>${p.listed != null ? "已挂牌" : p.in_squad ? "名单内" : "预备"}</em><span class="num">${money(p.value, 1)}</span></button>`).join("")}</div>`,
    [{ label: "关闭" }, { label: "外租名单", fn: async () => { await mkLoans(d); } }]);
  $$(".mk-pk").forEach((b) => b.onclick = () => { const p = own.find((x) => String(x.pid) === b.dataset.pk); $$("#mkdlg").forEach((e) => e.remove()); sound("cursor"); mkListing(p, d); });
}
async function mkSellFromPlayers(pid) { const d = await biz("market"); const own = d && !d.demo && d.own.find((x) => String(x.pid) === String(pid)); if (own) mkListing(own, d); }
async function mkLoan(own) {
  const r = await post("/api/loan/options", { card: own.pid }); if (mkFail(r)) return;
  const teams = r.destinations || [];
  mkDialog("培养外租", `<div class="cb"><p>${esc(own.name)} · 根据接收队的位置竞争评估出场机会，后续可能变化。</p><p>我方承担全部工资，6月30日归队；转会窗内可召回。出场为独立培养估算，不计入CPU比赛统计。</p>${teams.length ? `<select id="loan-team">${teams.map((t) => `<option value="${t.team}">${esc(tname(t.team) || t.name)} · ${t.role === "start" ? "预计首发" : "预计替补"}</option>`).join("")}</select>` : `<div class="empty-note">暂无有合适培养位置的球队</div>`}</div>`,
    [{ label: "取消" }, { label: "确认外租", pri: true, off: !teams.length, fn: async (box) => { const out = await post("/api/loan/send", { card: own.pid, team: +$("#loan-team", box).value }); if (mkFail(out)) return false; await mkAfter(`${own.name} 已外租培养`); } }]);
}
async function mkLoans(d) {
  const loan = d.loans || { active: [] };
  const el = mkDialog("外租培养名单", `<div class="cb scroll"><p>${esc(loan.note || "")}</p>${loan.active.map((r) => `<div class="fm-row"><b>${esc(r.name)}</b><span>${esc(tname(r.team) || r.club)} · ${r.role === "start" ? "预计首发" : r.role === "sub" ? "预计替补" : "机会减少"}</span><small>培养 ${r.weeks} 周 · 估算首发 ${r.starts} / 替补 ${r.subs} · 属性 +${r.up} / -${r.down} · ${esc(r.end)} 归队</small><button class="btn sm" data-loan-recall="${r.card}" ${d.window && d.window.open ? "" : "disabled"}>召回</button></div>`).join("") || `<div class="empty-note">暂无外租球员</div>`}</div>`, [{ label: "关闭" }]);
  $$("[data-loan-recall]", el).forEach((b) => b.onclick = async () => { const r = await post("/api/loan/recall", { card: +b.dataset.loanRecall }); if (mkFail(r)) return; el.remove(); await mkAfter("球员已归队预备队"); });
}
// mkSubstitute（新援安排上阵，登记与定位）在 58-lineup.js
async function offerAct(kind, id) {
  const r = await post(`/api/market/${kind}`, { offer: id }); if (mkFail(r)) return;
  sound("ok"); await mkAfter(kind === "accept" ? `已卖出 ${r.name}，${money(r.fee, 1)}${r.club ? ` · 加盟 ${tname(r.club) || ""}${r.placed ? (r.placed.starts ? "，打首发" : "，先做替补") : ""}` : ""}` : "已拒绝");   // M8-W3：买家付钱并让他上场
}
/* ================= 联赛球员库（M8-W0 / W1，2026-11-14）=================
   契约 INDEPENDENT_MASTER_LEAGUE_M8_LIVING_LEAGUE.md；数据 GET /api/biz/world（iml_world）：我们这个联赛 20 队每个球员的年龄、位置、能力（有卡才有）、合同到期、
   周薪、身价，以及俱乐部的规模档、转会预算、周薪上限。身价、周薪优先用真实数据，没有的按公式估（不标“估”，用户要求）；没有游戏卡的球员只记录。
   W1 起每个赛季末世界会动：合同到期续约或放走（成为自由球员）、老将退役、俱乐部补员和青训新人；左栏最后一项是自由球员池，名单下方写这支球队最近的变动。
   W2 起转会窗开着时（夏 7/1–8/31、冬 1 月）CPU 球队之间每天可能成交、或签下自由球员；变动里写日期、去向和转会费。
   W3 起我们的买卖也是世界里的交易：买人付给卖方俱乐部，卖人由想要他、付得起的球队出价，成交后他在那支球队上场；CPU 抢先签下我们在报价的人，报价作废。 */
/* 2026-11-15（用户：“其他联赛球员的身价/要价”）：顶部切换四个联赛（西甲/意甲/法甲读 /api/biz/world_<id>，iml_world_leagues）；每个有卡的球员多一列
   “要价”（转会市场同一口径：挂牌更便宜、非卖品不标价），右侧“报价”直接发起（和市场里一样，要转会窗开着）。跨联赛转会在变动里写对方联赛。 */
let wlSel = null, wlSort = "pos", wlLg = 0;
const WL_ASK = (mk) => { const m = new Map(); for (const x of (mk && !mk.demo && mk.market) || []) if (x.source != null) m.set(`${x.club.id}:${x.source}`, x); return m; };
const WL_GRP = { G: ["GK", "门将"], D: ["DF", "后卫"], M: ["MF", "中场"], F: ["FW", "前锋"] };
const WL_SORTS = [["pos", "位置"], ["ovr", "能力"], ["age", "年龄"], ["until", "合同"], ["value", "身价"]];
const WL_CMP = {
  pos: (a, b) => "GDMF".indexOf(a.grp) - "GDMF".indexOf(b.grp) || (b.ovr || 0) - (a.ovr || 0) || b.value - a.value,
  ovr: (a, b) => (b.ovr || 0) - (a.ovr || 0) || b.value - a.value,
  age: (a, b) => a.age - b.age || b.value - a.value,
  until: (a, b) => a.until - b.until || b.value - a.value,
  value: (a, b) => b.value - a.value,
};
const WL_EVT = { retire: "退役", release: "被放走", resign: "续约", sign: "签下自由球员", youth: "青训新人", transfer: "转会" };
// 一条变动：赛季末的写赛季，转会窗里的写日期；转会写“从 A 加盟 B · €nM”，看卖方时写“加盟 B”
const wlEvText = (e, d, yr) => { const when = e.date ? e.date.slice(5).replace("-", "/") : `${yr(e.season - 1)}/${String(e.season + d.start_year).slice(2)}`;
  const out = e.from === wlSel, lgOf = (id) => { const t = (d.tabs || []).find((x) => x.id === id); return t && id !== d.competition ? `（${esc(t.name)}）` : ""; };      // 跨联赛：对方后面写联赛
  const away = e.xl ? lgOf(out ? e.xl[1] : e.xl[0]) : "";
  if (e.kind === "transfer") return `${when} ${out ? `转出：${esc(e.name)} → ${esc(tname(e.club) || "")}${away}` : `转入：${esc(e.name)} ← ${esc(tname(e.from) || "")}${away}`} · ${money(e.fee, 1)}`;
  return `${when} ${WL_EVT[e.kind] || e.kind}：${esc(e.name)}`; };
async function viewWorld(name) {
  const key = wlLg ? `world_${wlLg}` : "world";
  const [d, mk] = await Promise.all([biz(key), biz("market").catch(() => null)]); if (!d || d.demo || !Array.isArray(d.clubs)) { if (wlLg) { wlLg = 0; return viewWorld(name); } return `<div class="view"><div class="card"><div class="empty-note">联赛球员库需要真实赛季数据（新建游戏后可用）</div></div></div>`; }
  for (const [k, v] of Object.entries(d.teams || {})) if (!S.teams[k]) S.teams[k] = v;      // 其他联赛的队名与颜色（不覆盖本联赛已有的）
  const abroad = !!wlLg;
  if ((abroad || wlSel !== 0) && !d.clubs.some((c) => c.id === wlSel)) wlSel = (d.clubs.find((c) => c.mine) || d.clubs[0]).id;
  const free = !abroad && wlSel === 0, yr = (u) => `${d.start_year + u}`, ref = mk && !mk.demo ? mk.star_ref : null;
  const mineSel = !free && (d.clubs.find((x) => x.id === wlSel) || {}).mine;      // 我队显示具体能力；别队按星级（相对我队，FM 式）
  const c = free ? { id: 0, name: "自由球员", players: d.free, n: d.free_n } : d.clubs.find((x) => x.id === wlSel);
  const tier = (t) => ["", "豪门", "强队", "中游", "弱旅"][t] || "";
  const asks = WL_ASK(mk), win = mk && mk.window, canBid = !free && !mineSel && mk && !mk.demo;
  const lgTabs = (d.tabs || []).length > 1 ? `<div class="wl-lgs">${d.tabs.map((t) => `<button class="chip sm${(t.own ? 0 : t.id) === wlLg ? " on" : ""}" data-wllg="${t.own ? 0 : t.id}">${esc(t.name || "本联赛")}</button>`).join("")}</div>` : "";
  const list = lgTabs + d.clubs.map((x) => `<button class="wl-c${x.id === wlSel ? " on" : ""}${x.mine ? " me" : ""}" data-wl="${x.id}">${crest(x.id, "sm")}<span class="wl-n">${esc(tname(x.id) || x.name)}</span><small>${tier(x.tier)}</small></button>`).join("")
    + (abroad ? "" : `<button class="wl-c wl-free${free ? " on" : ""}" data-wl="0"><span class="wl-n">自由球员</span><small>${d.free_n}</small></button>`);
  const askCell = (p) => { const m = canBid && /^\d+$/.test(String(p.id)) ? asks.get(`${c.id}:${p.id}`) : null;
    if (!m) return `<td class="n"><span class="muted">—</span></td><td class="c"></td>`;
    const live = m.bid && ["pending", "countered", "agreed", "personal"].includes(m.bid.state);
    const btn = live ? `<span class="muted" style="font-size:11px">在谈</span>` : win && win.open ? `<button class="btn sm gold" data-mkbid="${m.id}">报价</button>` : `<span class="muted" style="font-size:11px" title="转会窗关闭">窗口关</span>`;
    return `<td class="n">${mkPrice(m, mk.budget, true)}</td><td class="c">${btn}</td>`; };
  // 2026-11-15 用户：“联赛球员里很多无卡的，无卡要去掉”——只列有游戏卡的球员（无卡的只在世界里记录），并配头像；点头像 / 整行打开球员页（我队用球员详情，他队用球探报告）
  const vis = c.players.filter((p) => p.card), who = (p) => ({ pid: p.card });
  const rows = [...vis].sort(WL_CMP[wlSort]).map((p) => { const [cls, zh] = WL_GRP[p.grp] || ["MF", ""];
    return `<tr class="${mineSel ? "" : "go-row"}"${mineSel ? "" : pgo(who(p), free ? "free" : c.id)}><td><span class="pos ${cls}" title="${zh}">${esc(p.pos || cls)}</span></td><td class="name">${pface(who(p))}${p.shirt ? `<i class="wl-sh">${p.shirt}</i>` : ""}<b>${esc(p.name)}</b></td>
      <td class="n">${p.age}</td><td class="n">${mineSel || ref == null || p.ca == null ? (p.ovr ? ovr(p.ovr) : `<span class="muted">—</span>`) : starsHtml(starVal(p.ca, ref))}</td><td class="n">${free ? "—" : yr(p.until)}</td><td class="n">${kfmt(p.wage)}</td><td class="n"><span class="num" style="color:var(--gold)">${money(p.value, 1)}</span></td>${canBid ? askCell(p) : ""}</tr>`; }).join("");     // 估算值不标“估”（用户 2026-11-14）：数据里仍有 est 位，只是不显示
  const ev = (d.log || []).filter((e) => free ? (e.kind === "release" || e.kind === "retire") : (e.club === wlSel || e.from === wlSel)).slice(-8).reverse();
  const evHtml = ev.length ? `<div class="wl-ev"><b>最近变动</b>${ev.map((e) => `<span class="k-${e.kind}">${wlEvText(e, d, yr)}</span>`).join("")}</div>` : "";
  const head = free ? `${c.n} 人（只列身价最高、有游戏卡的 ${vis.length} 人） · 已退休 ${d.retired_n} 人` : `${vis.length} 人 · 阵容总值 ${money(c.squad_value, 0)} · 转会预算 ${money(c.budget, 0)} · 周薪上限 ${kfmt(c.wage_cap)}`;
  return `<div class="view v-world" style="grid-template-columns:176px minmax(0,1fr)">
    <div class="card wl-list scroll" style="--i:0">${list}</div>
    <div class="card" style="--i:1"><div class="ch">${free ? "" : crest(c.id, "sm") + " "}${esc(free ? "自由球员" : tname(c.id) || c.name)}<span class="r">${head}</span></div>
      <div class="filters">${WL_SORTS.map(([k, l]) => `<button class="chip${wlSort === k ? " on" : ""}" data-wls="${k}">${l}</button>`).join("")}${free ? "" : `<button class="chip" data-team="${c.id}">球队资料 ›</button>`}</div>
      <div class="cb scroll"><table class="wl-table${canBid ? " wl-ask" : ""}"><thead><tr><th>位置</th><th>球员</th><th class="n">年龄</th><th class="n">能力</th><th class="n">合同至</th><th class="n">周薪</th><th class="n">身价</th>${canBid ? `<th class="n" title="俱乐部要价（和转会市场同一口径）">要价</th><th class="c"></th>` : ""}</tr></thead><tbody>${rows || `<tr><td colspan="${canBid ? 9 : 7}"><div class="empty-note">${free ? "现在没有自由球员（赛季末合同到期、没被续约的球员会来到这里）" : "没有球员"}</div></td></tr>`}</tbody></table>
      ${evHtml}<div class="wl-note">合同至＝该年 6 月；只列游戏里有卡的球员，点头像或整行看球员资料。要价＝俱乐部开价（报价低于它可能被还价或拒绝）。转会窗开着时各队每天可能有转会，四个联赛之间也会互相买人；我们的买卖也记在这里。</div></div></div></div>`;
}
/* 自由球员（M8-W4）：世界里合同到期没续约、或被放走的球员，有游戏卡的才能签。没有转会费，直接和球员谈周薪/年限/定位（M6 的球员段），
   他第二天答复；不受转会窗限制。E360（2026-11-18）：原右栏“联赛转会新闻”搬到 主页 · 新闻 · 转会 频道，这里列表占满，表头上方一个“转会新闻 ›”链接。 */
let faSort = "ovr";
async function viewFree(name) {
  const d = await biz("market");
  if (!d || d.demo || !Array.isArray(d.free)) return `<div class="view"><div class="card"><div class="empty-note">自由球员需要真实赛季数据（新建游戏后可用）</div></div></div>`;
  const cmp = { ovr: (a, b) => b.overall - a.overall, age: (a, b) => a.age - b.age, wage: (a, b) => a.wage - b.wage, pot: (a, b) => b.potential - a.potential };
  const rows = [...d.free].sort(cmp[faSort]).map((p) => `<tr><td>${pos(p.position)}</td><td class="name">${pfaceGo(p, "free")}<b>${esc(p.name)}</b>${p.last_club ? ` <small class="muted">原 ${esc(p.last_club)}</small>` : ""}</td>
    <td class="n">${p.age}</td><td class="n">${starsHtml(starVal(p.ca, d.star_ref))}</td><td class="n">${starsHtml(starVal(p.ca_pot ? p.ca_pot[1] : null, d.star_ref), null, "pot")}</td><td class="n">${kfmt(p.wage)}</td>
    <td class="c">${p.talks ? (p.talks.state === "agreed" ? `<button class="btn sm gold" data-terms="${p.talks.id}">谈条款</button>` : `<span class="muted">等他答复</span>`) : `<button class="btn sm gold" data-mkfree="${p.pid}">谈合同</button>`}</td></tr>`).join("");
  return `<div class="view" style="grid-template-columns:minmax(0,1fr)">
    <div class="card" style="--i:0">
      <div class="filters">${[["ovr", "能力"], ["pot", "潜力"], ["age", "年龄"], ["wage", "期望周薪"]].map(([k, l]) => `<button class="chip${faSort === k ? " on" : ""}" data-fas="${k}">${l}</button>`).join("")}
        <span class="fa-sum muted">${d.free.length} 人可签 · 不需要转会费 · 任何时候都能谈</span><button class="chip fa-xn" data-news-xfer="1">转会新闻 ›</button></div>
      <div class="cb scroll">${rows ? `<table><thead><tr><th>位置</th><th>球员</th><th class="n">年龄</th><th class="n">能力</th><th class="n">潜力</th><th class="n">期望周薪</th><th class="c"></th></tr></thead><tbody>${rows}</tbody></table>`
        : `<div class="empty-note">现在没有可签的自由球员。赛季末合同到期、没被续约的球员会来到这里；没有游戏卡的球员不能签。</div>`}</div></div></div>`;
}
/* ================= 阵容深度（M6-F1，2026-11-14）=================
   契约 INDEPENDENT_MASTER_LEAGUE_M6_NEGOTIATION.md §3.4；数据 GET /api/biz/depth（iml_depth：按当前阵型的首发位、卡片位置适应、伤停，
   每个位置组给“充足 / 偏薄 / 急需”和一条理由）。FM 式：左边球场上每个位置组一块（颜色＝评级、x/y＝能上场人数 / 阵型需要），
   右边选中位置组的详情——理由、23 人里能踢的人（天然位置 / 能踢）、预备队、“去市场找”（带精确位置筛选进转会市场）。 */
let dpSel = null;
const DP_AT = { ST: [50, 12], LW: [14, 31], AM: [50, 31], RW: [86, 31], CM: [50, 52], LB: [14, 72], CB: [50, 72], RB: [86, 72], GK: [50, 91] };
const DP_C = { ok: "var(--win)", thin: "var(--draw)", need: "var(--loss)", spare: "#ffffff40" };
async function viewDepth(name) {
  const d = await biz("depth"); if (!d || !d.units) return viewPlan("squad", name);
  const units = d.units, worst = units.find((u) => u.rating === "need") || units.find((u) => u.rating === "thin");
  if (!units.some((u) => u.unit === dpSel)) dpSel = (worst || units.find((u) => u.rating !== "spare") || units[0]).unit;
  const avail = (u) => u.players.filter((p) => !p.injured).length;
  const tile = (u) => { const [x, y] = DP_AT[u.unit] || [50, 50];
    return `<button class="dp-tile ${u.rating}${u.unit === dpSel ? " on" : ""}" data-dpu="${u.unit}" style="left:${x}%;top:${y}%;--rc:${DP_C[u.rating]}" title="${esc(u.reason)}">
      <b>${esc(u.name)}</b><span>${u.rating === "spare" ? "" : `<em class="num">${avail(u)}</em>/${u.need} `}<i>${esc(u.rating_zh)}</i></span></button>`; };
  const count = (r) => units.filter((u) => u.rating === r).length;
  return `<div class="view" style="grid-template-columns:minmax(0,1.05fr) minmax(0,1fr)">
    <div class="card dp-pitchcard" style="--i:0"><div class="ch">阵容深度<span class="r">${esc(d.formation || "")} · 首发平均 <b>${Math.round(d.xi_avg)}</b> · <span style="color:var(--loss)">急需 ${count("need")}</span> · <span style="color:var(--draw)">偏薄 ${count("thin")}</span></span></div>
      <div class="dp-pitch"><i class="dp-mid"></i><i class="dp-circ"></i><i class="dp-box t"></i><i class="dp-box b"></i>${units.map(tile).join("")}</div></div>
    <div class="card dp-detail" style="--i:1" id="dp-detail">${dpDetail(units.find((u) => u.unit === dpSel))}</div></div>`;
}
function dpDetail(u) {
  if (!u) return `<div class="empty-note">选一个位置</div>`;
  const row = (p, res) => `<div class="dp-p${p.injured ? " hurt" : ""}" data-player="${esc(p.pid)}">${pface(p)}<b>${esc(p.name)}</b><span class="dp-tags">${p.natural ? `<u class="nat">${esc(p.position)}</u>` : `<u>能踢 · ${esc(p.position)}</u>`}${p.starter ? `<u class="sx">首发</u>` : ""}${p.injured ? `<u class="inj">伤停</u>` : ""}${res ? `<u>预备队</u>` : ""}</span>${ovr(p.overall)}</div>`;
  const pos = u.positions.map((x) => POS_ZH[x] || x).join(" / ");
  return `<div class="ch"><span class="dp-h" style="--rc:${DP_C[u.rating]}">${esc(u.name)}<i>${esc(u.rating_zh)}</i></span><span class="r">${esc(pos)}${u.need ? ` · 首发 ${u.need} 人` : ""}</span></div>
    <div class="cb dp-body"><div class="dp-why" style="--rc:${DP_C[u.rating]}">${esc(u.reason)}</div>
      <div class="dp-list scroll">${u.players.map((p) => row(p, false)).join("") || `<div class="empty-note">23 人名单里没有能踢这里的人</div>`}${u.reserve.length ? `<div class="ibg">预备队</div>${u.reserve.map((p) => row(p, true)).join("")}` : ""}</div>
      <div class="dp-acts"><button class="btn ${u.rating === "need" || u.rating === "thin" ? "gold" : ""}" data-dpmk="${u.unit}">去市场找${esc(u.name)}</button></div></div>`;
}
const POS_ZH = { GK: "门将", CB: "中卫", LB: "左后卫", RB: "右后卫", DMF: "后腰", CMF: "中前卫", LMF: "左前卫", RMF: "右前卫", AMF: "前腰", LWF: "左边锋", RWF: "右边锋", SS: "影锋", CF: "中锋" };
async function dpPick(unit) {
  dpSel = unit; sound("cursor");
  const d = await biz("depth"); const u = d && d.units.find((x) => x.unit === unit); if (!u) return;
  $$("#page .dp-tile").forEach((t) => t.classList.toggle("on", t.dataset.dpu === unit));
  const box = $("#dp-detail"); if (box) { box.innerHTML = dpDetail(u); bindPage(box); }
}
// “去市场找”：带上这个位置组的精确位置（也算能踢的人）、清掉别的筛选，进转会市场；市场按“比我队这里最好的人强”标出提升
async function dpMarket(unit) {
  const d = await biz("depth"); const u = d && d.units.find((x) => x.unit === unit); if (!u) return;
  mkResetFilters(); mkF.pos = u.positions; mkF.posName = u.name; mkF.can = true;
  const best = u.players.filter((p) => !p.injured)[0];
  mkF.beat = best ? best.overall : 0; mkSel = null; sound("page"); openSec("transfer", 0);
}
/* ================= 阵容助手（M6-F2，2026-11-14）=================
   契约 INDEPENDENT_MASTER_LEAGUE_M6_NEGOTIATION.md §3.6；数据 GET /api/biz/lineup（iml_lineup），写入 POST /api/formation/arrange（整套首发）。
   三块：推荐阵容（按当前阵型、位置适应、疲劳、伤停算整套首发，门将只放门将位，同一真人不重复）、恢复上场阵容（上一场的首发）、
   轮换建议（首发伤停 / 疲劳 / 刚复出，配同位置的休息好的替补，写明原因，可单独保留某人）。
   另外：新援“安排上阵”先给一个建议换下的人和理由（登记与定位，最多两步：看建议 → 确认）。 */
const luOk = (d) => !!(d && !d.demo && d.recommend);
const luDrop = () => { delete BIZ.lineup; delete BIZ.depth; delete BIZ.brief; };
const luFresh = () => { luDrop(); return biz("lineup").catch(() => null); };
const LU_KIND = { injured: ["伤停", "var(--loss)"], tired: ["疲劳", "var(--draw)"], back: ["刚复出", "var(--blue)"] };
const luPlayer = (p, extra = "") => `<div class="lu-p">${pface(p)}<b>${esc(p.name)}</b><span class="lu-pos">${esc(p.position)}</span>${p.suspended ? `<u class="inj">红牌停赛</u>` : p.injured ? `<u class="inj">伤停</u>` : p.fatigue >= 60 ? `<u class="tir">疲劳 ${Math.round(p.fatigue)}</u>` : ""}${extra}${ovr(p.overall)}</div>`;
async function luApply(spots) {
  const r = await post("/api/formation/arrange", { spots });
  if (!r || r.error) { toast(String((r && r.error) || "").includes("goalkeeper") ? "门将只能守门，这个阵容不行" : FM_ERR[r && r.reason] || (r && r.error) || "调整失败"); return false; }
  $$("#mkdlg").forEach((e) => e.remove()); luDrop();
  try { await team(me(), true); } catch (e) { /* 下次进页面会重取 */ }
  sound("ok"); quietDraw = true; draw(); return true;
}
// 2026-11-18 用户：“再优化一下这个阵容助手的UI吧 现在太不直观了看着 中间最重要的信息都被挤着了”——
// 换上 / 换下不再分两栏：按位置配成一行“位置 · 换下的人 → 换上的人 · 为什么”（current[i] 与 spots[i] 是同一位置前后的槽位），
// 顶部写平均能力变化并解释“为什么降了还推荐”，应用按钮固定在底部；关闭改成标签栏右侧的 ✕，内容区跟着屏幕高度走。
function luWhy(tab, o, n, role) {
  if (tab === "last") return "上一场就是他首发";
  if (o && o.injured) return "伤停，必须换下";
  if (o && o.suspended) return "红牌停赛，必须换下";
  if (o && o.fatigue >= 50) return `疲劳 ${Math.round(o.fatigue)}，换体能更好的${n && n.position === role ? "同位置" : ""}球员`;
  if (o && n && role && o.position !== role && n.position === role) return `${role} 是他的本职位置，更合适`;
  if (o && n && (n.overall || 0) > (o.overall || 0)) return "能力更高";
  return "按位置适应与体能综合安排";
}
// 换下 / 换上配对：推荐阵容常常连带把场上的人挪位置，严格按“同一位置”配会出现半边空的行，所以按最像的一对来配——
// 同一个站位 → 同一个角色 → 同一条线（后卫 / 中场 / 前锋）→ 剩下的按顺序；行首写换上的人要踢的位置。
function luPairs(tab, x, d) {
  const cur = d.current || [], to = x.spots || [];
  const roles = lastFm && Array.isArray(lastFm.spots) ? lastFm.spots.map((s) => s.role) : [];
  const roleAt = (arr, slot, p) => { const i = arr.indexOf(slot); return (i >= 0 && roles[i]) || p.position; };
  const outs = x.outs.map((o) => ({ p: o, i: cur.indexOf(o.slot), role: roleAt(cur, o.slot, o) }));
  const ins = x.ins.map((n) => ({ p: n, i: to.indexOf(n.slot), role: roleAt(to, n.slot, n) }));
  const line = (r) => (typeof FM_GRP !== "undefined" && FM_GRP[r]) || "m";
  const rows = [], left = new Set(outs);
  for (const test of [(o, n) => o.i >= 0 && o.i === n.i, (o, n) => o.role === n.role, (o, n) => line(o.role) === line(n.role), () => true]) {
    for (const n of ins) {
      if (n.used) continue;
      const o = [...left].find((c) => test(c, n)); if (!o) continue;
      left.delete(o); n.used = true; rows.push({ role: n.role, o: o.p, n: n.p });
    }
  }
  ins.filter((n) => !n.used).forEach((n) => rows.push({ role: n.role, o: null, n: n.p }));
  [...left].forEach((o) => rows.push({ role: o.role, o: o.p, n: null }));
  rows.sort((a, b) => "gdmf".indexOf(line(a.role)) - "gdmf".indexOf(line(b.role)));      // 门将 → 后卫 → 中场 → 前锋
  const side = (p, hint) => p ? luPlayer(p) : `<span class="lu-none">${hint}</span>`;
  return rows.map(({ role, o, n }) => `<div class="lu-pair"><span class="lu-role">${esc(role)}</span>
    <div class="lu-side out">${side(o, "（原位置的人换到别处）")}</div><span class="lu-arw">→</span><div class="lu-side in">${side(n, "（由场上球员换位补上）")}</div>
    <small class="lu-why">${esc(luWhy(tab, o, n, role))}</small></div>`).join("");
}
function luPanel(tab, d, keep) {
  if (tab === "rec" || tab === "last") {
    const x = tab === "rec" ? d.recommend : d.restore;
    if (!x) return `<div class="empty-note">还没有比赛记录，打完一场就能恢复上一场的首发</div>`;
    if (x.same) return `<div class="lu-same">${svg("check", 2.2)}<b>${tab === "rec" ? "现在的首发已经是最合适的安排" : "现在的首发就是上一场的首发"}</b><small>平均能力 ${x.avg_after}</small></div>`;
    const lost = x.missing && x.missing.length ? `<div class="lu-warn">上一场首发中 ${x.missing.map((p) => esc(p.name)).join("、")} 现在不能上场，已由最合适的人顶上</div>` : "";
    const hurt = x.hurt && x.hurt.length ? `<div class="lu-warn">${x.hurt.map((p) => esc(p.name)).join("、")} 伤停但没有更合适的健康球员，仍排在首发</div>` : "";
    const delta = +(x.avg_after - x.avg_before).toFixed(1);
    const note = tab === "last" ? "恢复成上一场比赛的首发"
      : delta < 0 ? "平均能力略降：换下了疲劳 / 位置不合适的球员，场上体能和站位更好"
      : delta > 0 ? "平均能力更高，同时照顾了体能与位置" : "能力不变，体能与位置更合适";
    const n = x.ins.length;
    return `<div class="lu-head"><div class="lu-avg"><small>平均能力</small><b class="num">${x.avg_before}<i>→</i><em class="${delta < 0 ? "dn" : delta > 0 ? "up" : ""}">${x.avg_after}</em></b></div>
        <p>${esc(note)}<br><span>${n ? `换 ${n} 人` : "只调整位置"}${x.moved ? ` · 另有 ${x.moved} 人换位置` : ""}</span></p></div>${lost}${hurt}
      <div class="lu-pairs">${luPairs(tab, x, d)}</div>
      <div class="lu-acts lu-sticky"><button class="btn pri" data-lu-apply="${tab}">${tab === "rec" ? "应用推荐阵容" : "恢复上一场阵容"}</button></div>`;
  }
  const rows = d.rotation;
  if (!rows.length) return `<div class="lu-same">${svg("check", 2.2)}<b>现在不需要轮换</b><small>首发体能正常，也没有伤员</small></div>`;
  const n = rows.filter((r) => r.in && keep.has(r.slot_out)).length;
  return `<div class="lu-rot">${rows.map((r) => { const [kz, kc] = LU_KIND[r.kind]; const on = !!r.in && keep.has(r.slot_out);
    return `<label class="lu-r${r.in ? "" : " none"}" style="--k:${kc}"><input type="checkbox" data-lu-keep="${r.slot_out}" ${on ? "checked" : ""} ${r.in ? "" : "disabled"}>
      <span class="lu-k">${kz}</span><div class="lu-w">${luPlayer(r.out)}<span class="lu-arrow">→</span>${r.in ? luPlayer(r.in) : `<span class="lu-none">没有合适的替补</span>`}</div>
      <small>${esc(r.reason)}</small></label>`; }).join("")}</div>
    <div class="lu-acts"><small class="lu-note">取消勾选＝保留这名首发</small><button class="btn pri" data-lu-apply="rot" ${n ? "" : "disabled"}>接受所选${n ? ` (${n})` : ""}</button></div>`;
}
async function luAssist(tab0) {
  const d = await luFresh(); if (!luOk(d)) return toast("阵容助手暂时用不了");
  let tab = tab0 || (d.rotation.length ? "rot" : "rec"); const keep = new Set(d.rotation.filter((r) => r.in).map((r) => r.slot_out));
  const tabs = [["rec", "推荐阵容"], ["last", "上一场阵容"], ["rot", `轮换建议${d.rotation.length ? ` <b class="lu-n">${d.rotation.length}</b>` : ""}`]];
  const body = () => `<div class="lu-box"><div class="lu-tabs">${tabs.map(([k, l]) => `<button type="button" data-lu-tab="${k}" class="${k === tab ? "on" : ""}">${l}</button>`).join("")}<span class="lu-fm">${esc(d.formation || "")}</span>
      <button type="button" class="lu-x" data-lu-close aria-label="关闭" title="关闭">✕</button></div>
    <div class="lu-panel scroll" id="lu-panel">${luPanel(tab, d, keep)}</div></div>`;
  const el = mkDialog("阵容助手", body(), [], "fm lu");
  const bind = () => {
    $$("[data-lu-close]", el).forEach((b) => b.onclick = () => { sound("back"); el.remove(); });
    $$("[data-lu-tab]", el).forEach((b) => b.onclick = () => { tab = b.dataset.luTab; sound("cursor"); $(".lu-box", el).outerHTML = body(); bind(); });
    $$("[data-lu-keep]", el).forEach((c) => c.onchange = () => { const s = +c.dataset.luKeep; c.checked ? keep.add(s) : keep.delete(s); sound("cursor"); $("#lu-panel", el).innerHTML = luPanel(tab, d, keep); bind(); });
    $$("[data-lu-apply]", el).forEach((b) => b.onclick = async () => {
      const k = b.dataset.luApply; b.disabled = true;
      const spots = k === "rec" ? d.recommend.spots : k === "last" ? d.restore.spots : d.current.map((s, i) => { const r = d.rotation.find((x) => x.spot === i && x.in && keep.has(x.slot_out)); return r ? r.in.slot : s; });
      if (!(await luApply(spots))) b.disabled = false;
    });
  };
  bind();
}
// 登记与定位：新援在预备队 → 先给建议换下谁（同位置最弱的替补）和理由，确认即换入；也可以从下面选别人
async function mkSubstitute(pid) {
  const [t, lu] = await Promise.all([team(me()), luFresh()]), r = t.reserve.find((x) => String(x.pid) === String(pid)); if (!r) return;
  const nc = luOk(lu) && lu.newcomers[String(pid)], rep = nc && nc.replace, role = nc ? nc.role_zh : "";
  const rows = [...t.squad].sort((a, b) => ((b.group === r.group) - (a.group === r.group)) || (b.starter - a.starter) || (b.overall || 0) - (a.overall || 0));
  const go = async (slot, close) => {
    const res = await post("/api/formation/substitute", { slot, card: r.pid });
    if (res && !res.error) { sound("ok"); luDrop(); await mkAfter(""); return true; }
    toast(FM_ERR[res && res.reason] || (res && res.error) || "换人失败"); return false;
  };
  const sug = rep ? `<div class="lu-sug"><small>建议换下</small><div class="lu-sug-r">${pface(rep)}<b>${esc(rep.name)}</b><span class="lu-pos">${esc(rep.position)}</span>${ovr(rep.overall)}</div><small>${esc(rep.reason)}${role ? ` · 他的合同定位是“${esc(role)}”` : ""}</small></div>` : "";
  const el = mkDialog("换下谁？", `<div class="mk-dl"><div class="who">${pface(r, "lg")}${ovr(r.overall)}<div><b>${esc(r.name)}</b><small>${esc(r.position)} · 预备队 → 23 人名单${role ? ` · ${esc(role)}` : ""}</small></div></div></div>${sug}
    <div class="mk-pick scroll">${rows.map((p) => `<button class="mk-pk${rep && p.slot === rep.slot ? " rec" : ""}" data-slot="${p.slot}">${pos(p.position, p.group)}${pface(p)}<b>${esc(p.name)}</b>${ovr(p.overall)}<em>${p.starter ? "首发" : "替补"}${rep && p.slot === rep.slot ? " · 建议" : ""}</em></button>`).join("")}</div>`,
    [{ label: "取消" }, ...(rep ? [{ label: `换下 ${esc(rep.name)}`, pri: true, fn: () => go(rep.slot) }] : [])], "sub");
  $$(".mk-pk[data-slot]", el).forEach((b) => b.onclick = async () => { b.disabled = true; if (!(await go(+b.dataset.slot))) b.disabled = false; });
}
/* ================= 赛前简报（M7-G4，2026-11-14）=================
   契约 INDEPENDENT_MASTER_LEAGUE_M7_DEVELOPMENT.md 3.4；数据 GET /api/biz/brief（iml_brief）：最多三条——对手（联赛名次、近五场、主要得分手）、
   我方风险（伤停 / 疲劳 / 位置偏薄）、一项建议（轮换 / 推荐阵容 / 去市场 / 训练）。只写真数据支持的，数据不够就少于三条；每条建议带能直接打开的按钮。
   入口：主页“下一场”横幅右上角的“简报”。 */
const BR_ICON = { rival: "person", risk: "med", advice: "bolt" };
async function openBrief() {
  delete BIZ.brief; const d = await biz("brief").catch(() => null);
  if (!d || d.demo || !Array.isArray(d.items) || !d.fixture) return toast("赛前简报暂时用不了");
  const rows = d.items.map((i, n) => `<div class="br-r k-${i.kind}"><span class="br-ic">${svg(BR_ICON[i.kind] || "check", 2)}</span><div class="br-t"><small>${esc(i.title)}</small><p>${esc(i.text)}</p></div>${i.act ? `<button class="btn sm${i.kind === "advice" ? " pri" : ""}" data-br="${n}">${esc(i.label)}</button>` : ""}</div>`).join("");
  const el = mkDialog(`赛前简报 · 第 ${d.fixture} 轮 vs ${esc(d.opponent.name)}`, `<div class="lu-box"><div class="br-list">${rows || `<div class="empty-note">暂时没有可说的</div>`}</div></div>`, [{ label: "关闭" }], "fm lu");
  $$("[data-br]", el).forEach((b) => b.onclick = () => {
    const a = d.items[+b.dataset.br].act; $$("#mkdlg").forEach((e) => e.remove()); sound("page");
    if (a.type === "team") openTeam(a.id); else if (a.type === "assist") luAssist(a.tab); else if (a.type === "market") dpMarket(a.unit);
    else if (a.type === "tab") navLink(a.to);
  });
}
// ---- 训练
const LV = { rest: ["休息", 0, "#7d7d87"], recovery: ["恢复", 25, "#4ea8ff"], normal: ["常规", 55, "#34d399"], intense: ["高强度", 90, "#f0566a"] };
const CYCLE = ["normal", "intense", "recovery", "rest"];
let wk = null, focusK = null;
// 真数据（iml_biz.training，带 effects）：日程/重点点一下就写服务端（POST /api/training/plan），下一场比赛开始前生效；示例数据只在本页切换。
// 负荷与风险按服务端同一公式（iml_training.effects：休息 0 / 恢复 0.4 / 常规 1 / 高强度 2，常规周 = 5）
const DAYW = { rest: 0, recovery: 0.4, normal: 1, intense: 2 };
const roundEven = (x) => { const f = Math.floor(x); return x - f === 0.5 ? (f % 2 === 0 ? f : f + 1) : Math.round(x); };   // = Python round()（同样的浮点误差，只有恰好 .5 才取偶）
let trainReal = false;   // 训练页当前是不是服务端真数据（不看 BIZ 缓存：保存后缓存会被清掉再取）
function weekFx(days) {
  const load = Math.round(days.reduce((a, k) => a + DAYW[k], 0) * 100) / 100;
  return { load, risk: Math.max(0.7, Math.min(1.6, 1 + 0.15 * (load - 5))), fatigue: roundEven(2.5 * (load - 5)), bonus: load < 3 ? 0 : load < 7 ? 1 : 2,
    legs: days[days.length - 1] === "rest" || days[days.length - 1] === "recovery" ? "fresh" : days[days.length - 1] === "intense" ? "heavy" : null };
}
const TR_ERR = { "bad-plan": "这个训练计划不行", "bad-individual": "个人训练最多 5 人", "unknown-card": "这名球员不在大师联赛存档里", busy: "正在进入比赛，稍后再改训练" };
async function trainSave(path, body) {
  const r = await post(path, body);
  if (!r || r.error) { toast(TR_ERR[r && r.reason] || (r && r.error) || "保存失败"); wk = null; delete BIZ.training; draw(); return false; }
  delete BIZ.training; return true;
}
const growthTail = (g) => g.cat ? `<span class="${g.n < 0 ? "tag-dn" : "tag-up"}" style="white-space:nowrap">${esc(g.cat_name)} ${g.n < 0 ? "−" + -g.n : "+" + g.n}</span>` : `<span class="num up" style="font-size:16px;text-align:right">${g.to}</span>`;
/* ---- M7-G1（2026-11-14）周计划：三个方案 + 系统建议 + 整季委托 + 日选择菜单 + 结论上移（体验评审 U06 / U09，M7 规划 3.1）----
   服务端（iml_training / iml_biz.training）给 templates / suggest / auto / can_restore / effects.risk_label；示例数据和旧宿主没有这些字段，走原页面。 */
const TR_TIP = { rest: ["休息", "负荷 0 · 体能恢复最多"], recovery: ["恢复", "负荷 0.4 · 轻度恢复"], normal: ["常规", "负荷 1"], intense: ["高强度", "负荷 2 · 受伤风险升高，疲劳多 +1"] };
const TR_RISK = (l) => (l.startsWith("明显低") || l.startsWith("略低") ? "var(--win)" : l.startsWith("与常规") ? "var(--draw)" : "var(--loss)");
function closeTrMenu() { const m = $("#tr-menu"); if (m) m._off && m._off(); }
// 小菜单：贴在按钮旁，items = [{label, hint, on, warn}]，点外面 / Esc 关闭；放不下时翻到按钮上方、内部可滚动
function trMenu(anchor, items, pick) {
  closeTrMenu();
  const m = document.createElement("div"); m.className = "tr-menu"; m.id = "tr-menu"; m.setAttribute("role", "menu");
  m.innerHTML = items.map((it, i) => `<button type="button" role="menuitem" data-i="${i}" class="${it.on ? "on" : ""}${it.warn ? " warn" : ""}"><b>${esc(it.label)}</b>${it.hint ? `<small>${esc(it.hint)}</small>` : ""}${it.on ? `<i>${svg("check", 2.4)}</i>` : ""}</button>`).join("");
  document.body.appendChild(m);
  const r = anchor.getBoundingClientRect(), mw = m.offsetWidth, mh = m.offsetHeight;
  m.style.left = `${Math.min(Math.max(6, r.left + r.width / 2 - mw / 2), innerWidth - mw - 6)}px`;
  const below = r.bottom + 4, y = below + mh > innerHeight - 6 ? Math.max(6, r.top - mh - 4) : below; m.style.top = `${y}px`;
  const off = () => { document.removeEventListener("pointerdown", away, true); document.removeEventListener("keydown", key, true); m.remove(); };
  const away = (e) => { if (!m.contains(e.target)) off(); }, key = (e) => { if (e.key === "Escape") { e.stopPropagation(); sound("back"); off(); } };
  m._off = off; document.addEventListener("pointerdown", away, true); document.addEventListener("keydown", key, true);
  $$("button", m).forEach((b) => b.onclick = (e) => { e.stopPropagation(); off(); sound("cursor"); pick(items[+b.dataset.i]); });
}
async function trSavePlan(body) { wk = null; const ok = await trainSave("/api/training/plan", body); if (ok) { quietDraw = true; draw(); } return ok; }
const trTemplate = (k) => trSavePlan({ template: k });
const trAuto = async () => { const d = await biz("training"); if (d) trSavePlan({ auto: !d.auto }); };
const trRestore = () => trSavePlan({ restore: true });
async function trDayMenu(i, anchor) {
  const d = await biz("training"); if (!d || !d.templates) return;
  const days = d.week.filter((x) => x.kind !== "match" && !x.fixed).map((x) => x.kind), cur = days[i];
  const items = Object.keys(TR_TIP).map((k) => ({ k, label: TR_TIP[k][0], hint: TR_TIP[k][1] + (i === 4 ? (k === "intense" ? " · 周五练高强度：赛前状态 −1 档" : k === "rest" || k === "recovery" ? " · 赛前状态 +1 档" : "") : ""), on: k === cur, warn: k === "intense" && i === 4 }));
  trMenu(anchor, items, (it) => { if (it.k === cur) return; const nd = days.slice(); nd[i] = it.k; trSavePlan({ days: nd.map((k) => (k === "intense" ? "high" : k)) }); });
}
async function viewWeek(name) {
  const d = await biz("training"); if (!d) return viewPlan("training", name);
  if (d.demo || !d.templates) return viewWeekOld(d);
  trainReal = true; wk = null;
  // E365（2026-11-18）改版：左 = 我能改的（日程柱状条 + 三个方案 + 建议），右 = 结果（赛前状态/疲劳/受伤三格 + 团队重点 + 成长结算入口）
  const fx = d.effects, cur = fx.template, sg = d.suggest, tpl = (k) => d.templates.find((t) => t.k === k) || { name: k };
  const legs = fx.legs === "fresh" ? ["提升", "var(--win)", "周五恢复/休息：体能好的球员赛前状态 +1 档"] : fx.legs === "heavy" ? ["下滑", "var(--loss)", "周五高强度：全队赛前状态 −1 档"] : ["不变", "var(--ink)", "周五常规训练，赛前状态不变"];
  const fat = fx.fatigue_delta, mini = (days) => days.map((k) => `<s style="height:${Math.max(12, LV[k][1])}%;--c:${LV[k][2]}"></s>`).join("");
  const hint = d.auto ? `<span class="wk-sg auto">委托中 · 下一场按“${esc(tpl(sg.template).name)}”：${esc(sg.reason)}</span>`
    : sg.template !== cur ? `<span class="wk-sg"><span class="wk-sgt">建议“${esc(tpl(sg.template).name)}”：${esc(sg.reason)}</span><button class="chip sm" data-tpl="${sg.template}">采用</button></span>` : `<span class="wk-sg ok">${svg("check", 2.4)}与建议一致：${esc(sg.reason)}</span>`;
  const dcol = (x, i) => {
    if (x.kind === "match") return `<div class="wd match" title="${x.opp ? "vs " + esc(x.opp) : "比赛日"}"><small>${esc(x.day)}</small><span class="wd-m"><b>比赛</b><em>${x.opp ? esc(x.opp) : ""}</em></span><b class="wd-k">比赛日</b></div>`;
    const lv = LV[x.kind], col = `<small>${esc(x.day)}</small><span class="wd-c"><i style="height:${Math.max(6, lv[1])}%;--c:${lv[2]}"></i></span>`;
    return x.fixed ? `<div class="wd fixed" title="固定安排">${col}<b class="wd-k" style="color:${lv[2]}">${lv[0]}</b></div>`
      : `<button class="wd" data-day="${i}" aria-haspopup="menu" title="${esc(TR_TIP[x.kind][1])}">${col}<b class="wd-k" style="color:${lv[2]}">${lv[0]}<span class="wd-dd">▾</span></b></button>`;
  };
  const tile = (label, val, color, tip) => `<div class="wk-t" title="${esc(tip)}"><small>${label}</small><b style="color:${color}">${val}</b></div>`;
  // 成长结算入口：上次结算那轮有几人变化 + 距下次结算（旧宿主没有 to_settle 就不写）
  const last = d.growth[0], lastWhen = last ? last.when.split(" · ").find((s) => s.includes("轮")) || last.when.split(" · ")[0] : "", lastN = last ? new Set(d.growth.filter((g) => g.when === last.when).map((g) => g.name)).size : 0;
  const settle = [last ? `上次${esc(lastWhen.replace(/\s/g, ""))} ${lastN} 人有变化` : "还没有成长记录", d.to_settle ? `距下次结算 <b>${d.to_settle}</b> 轮` : ""].filter(Boolean).join(" · ");
  return `<div class="view wk2" style="grid-template-columns:minmax(0,1.65fr) minmax(0,1fr)">
    <div class="card key wk-card" style="--i:0"><div class="ch">本周日程<span class="r">点一天改强度 · 自动保存，下一场起生效</span></div><div class="cb wk-body">
      <div class="wk-days">${d.week.map(dcol).join("")}</div>
      <div class="wk-tpls">${d.templates.map((t) => `<button class="tp${t.k === cur ? " on" : ""}" data-tpl="${t.k}" title="${esc(t.desc)}">${t.k === sg.template ? `<i>建议</i>` : ""}<span class="tp-m">${mini(t.days)}</span><span class="tp-t"><b>${esc(t.name)}</b><small>${esc(t.desc)}</small></span></button>`).join("")}</div>
      <div class="wk-foot"><div class="wk-hint">${hint}</div><span class="wk-side"><button class="chip sm${d.auto ? " on" : ""}" data-tauto title="每个比赛周按球队疲劳自动选方案；你改动任何一天都会自动关闭">整季委托</button><button class="chip sm" data-trestore ${d.can_restore ? "" : "disabled"} title="回到上一次改之前的一周">恢复上次</button></span></div></div></div>
    <div class="card wk-outc" style="--i:1"><div class="ch">下一场影响</div><div class="cb scroll wk-out">
      <div class="wk-tiles">${tile("赛前状态", legs[0], legs[1], legs[2])}${tile("疲劳", `${fat > 0 ? "+" : fat < 0 ? "−" : "±"}${Math.abs(fat)}`, fat > 0 ? "var(--loss)" : fat < 0 ? "var(--win)" : "var(--ink)", "本周训练给全队带来的疲劳变化（相对常规周）")}${tile("受伤风险", fx.risk_label.startsWith("与常规") ? "正常" : esc(fx.risk_label.replace("于常规", "")), TR_RISK(fx.risk_label), `${fx.risk_label}（×${fx.risk.toFixed(2)}，相对常规周，不是绝对受伤率）`)}</div>
      <div class="wk-sub">团队重点<small>${fx.focus_bonus ? `下场该类 +${fx.focus_bonus}` : "本周强度太低，下场无加成"} · 也决定成长落点</small></div>
      <div class="focus wk-focus">${d.focuses.map((f) => `<button class="fo${f.k === d.focus ? " on" : ""}" data-focus="${f.k}" title="${esc(f.desc)}"><b>${esc(f.name)}</b><small>${esc(f.desc)}</small></button>`).join("")}</div>
      <button class="wk-more" data-tab="training:2"><span>成长：${settle}</span><b>›</b></button></div></div></div>`;
}
function viewWeekOld(d) {
  if (!wk) { wk = d.week.map((x) => ({ ...x })); focusK = d.focus; }
  const real = trainReal = !d.demo, days = wk.filter((x) => x.kind !== "match" && !x.fixed).map((x) => x.kind), fx = weekFx(days);
  const rc = fx.risk > 1.15 ? "var(--loss)" : fx.risk >= 0.95 ? "var(--draw)" : "var(--win)";
  const legs = fx.legs === "fresh" ? ["状态提升", "var(--win)", "周五恢复/休息：体能好的球员赛前状态 +1 档"] : fx.legs === "heavy" ? ["状态下滑", "var(--loss)", "周五高强度：全队赛前状态 −1 档"] : ["状态不变", "var(--ink3)", "周五常规训练，赛前状态不变"];
  const meters = real ? `<div class="meter" style="margin-top:10px"><span>受伤风险</span><b style="color:${rc}">×${fx.risk.toFixed(2)}</b></div>${bar((fx.risk - 0.7) / 0.9 * 100, rc)}
      <div class="meter fs-s" style="margin-top:8px"><span>疲劳 <b style="color:${fx.fatigue > 0 ? "var(--loss)" : "var(--win)"}">${fx.fatigue > 0 ? "+" : ""}${fx.fatigue}</b> · 加成 <b title="团队重点类别下一场的临时加成">${fx.bonus ? "+" + fx.bonus : "无"}</b></span><b style="color:${legs[1]}" title="${legs[2]}">${legs[0]}</b></div>`
    : `<div class="meter" style="margin-top:12px"><span>受伤风险</span><b style="color:${rc}">${fx.risk > 1.15 ? "高" : fx.risk >= 0.95 ? "中" : "低"}</b></div>${bar((fx.risk - 0.7) / 0.9 * 100, rc)}`;
  return `<div class="view" style="grid-template-columns:1fr 1fr;grid-template-rows:auto minmax(0,1fr)">
    <div class="card" style="grid-column:1/3;--i:0"><div class="ch">本周日程<span class="r">点一天切换强度${real ? " · 自动保存，下一场起生效" : ""} · 赛前一天恢复＝赛前状态提升</span></div><div class="cb"><div class="week">
      ${wk.map((x, i) => x.kind === "match" ? `<div class="day match"><small>${esc(x.day)}</small><b>比赛日</b><small>${x.opp ? "vs " + esc(x.opp) : ""}</small></div>`
        : x.fixed ? `<div class="day" style="opacity:.55"><small>${esc(x.day)}</small><b style="color:${LV[x.kind][2]}">${LV[x.kind][0]}</b><div class="bar"><i data-w="0"></i></div></div>`
        : `<button class="day" data-day="${i}"><small>${esc(x.day)}</small><b style="color:${LV[x.kind][2]}">${LV[x.kind][0]}</b><div class="bar"><i data-w="${LV[x.kind][1]}" style="--c:${LV[x.kind][2]}"></i></div></button>`).join("")}</div></div></div>
    <div class="card" style="--i:1"><div class="ch">团队重点</div><div class="cb scroll"><div class="focus">${d.focuses.map((f) => `<button class="fo${f.k === focusK ? " on" : ""}" data-focus="${f.k}"><b>${esc(f.name)}</b><small>${esc(f.desc)}</small></button>`).join("")}</div>
      ${meters}</div></div>
    <div class="card" style="--i:2"><div class="ch">最近成长<button class="r" data-tab="training:2">全部 ›</button></div><div class="cb scroll">
      ${d.growth.slice(0, 5).map((g) => `<div class="gr${g.cat ? " cat" : ""}">${pos(g.position)}<b>${pface(g)}${esc(g.name)}</b>${g.cat ? `<span class="muted fs-s">${esc(g.when.split(" · ")[0])}</span>` : bar((g.to - 60) / 40 * 100, "var(--win)")}${growthTail(g)}</div>`).join("") || `<div class="empty-note">还没有成长记录：每场比赛后按训练计划结算</div>`}</div></div></div>`;
}
const FOCI = ["射门", "传球", "盘带", "防守", "体能", "速度"];
const ifocus = {};
// 个人训练（真数据）：类别 = 游戏自己的 careerplan 十组；点类别在“自动（按团队重点）→ 各类别”之间循环；最多 slots 人
const IND_FIELD = ["SHOOT", "PASS", "DRIBLE", "QUICKNESS", "STRENGTH", "AERIAL", "DEFENCE"], IND_GK = ["GK1", "GK2", "GK3", "QUICKNESS", "STRENGTH", "AERIAL"];
// M7-G2：点培养目标 → 小菜单（自动 + 各目标，门将只有门将目标），不再循环切换
async function trGoalMenu(pid, anchor) {
  const d = await biz("training"); if (!d || d.demo) return;
  const p = d.players.find((x) => String(x.pid) === String(pid)); if (!p) return;
  const keys = p.position === "GK" ? IND_GK : IND_FIELD, name = (k) => (d.goals && d.goals[k]) || (d.categories.find((c) => c.k === k) || {}).name || k;
  const items = [{ k: null, label: "自动", hint: "跟随团队重点", on: !p.individual }, ...keys.map((k) => ({ k, label: name(k), on: p.individual && p.cat === k }))];
  trMenu(anchor, items, async (it) => { if (it.on) return; if (await trainSave("/api/training/individual", { card: p.pid, category: it.k })) { quietDraw = true; draw(); } });
}
async function viewIndividual(name) {
  const d = await biz("training"); if (!d) return viewPlan("training", name);
  if (d.demo) return `<div class="view" style="grid-template-columns:minmax(0,1fr)"><div class="card"><div class="ch">个人训练<span class="r">点训练方向切换 · 进度满了能力 +1</span></div>
    <div class="cb scroll"><table><thead><tr><th>位置</th><th>球员</th><th class="n">能力</th><th>训练方向</th><th style="width:34%">本月进度</th></tr></thead><tbody>
    ${d.players.map((p, i) => `<tr><td>${pos(p.position)}</td><td class="name">${pface(p)}<b>${esc(p.name)}</b></td><td class="n">${ovr(p.overall)}</td><td><button class="chip on" data-ifo="${i}">${esc(ifocus[i] || p.focus)}</button></td><td>${bar(p.progress, "var(--win)")}</td></tr>`).join("")}</tbody></table></div></div></div>`;
  const used = d.players.filter((p) => p.individual).length;
  // 发展（iml_growth，对标 FM）：年龄阶段 + 潜力 + 本季势头；个人训练只决定成长落在哪些能力上，不加速
  const STC = { growth: "var(--win)", peak: "var(--draw)", decline: "var(--loss)" };
  // 潜力是隐藏值：服务端只给球探区间 [低, 高]（球员来得越久越准；衰退期 = 当前能力）
  const potCell = (p) => { const r = p.potential; if (!Array.isArray(r)) return `<span class="muted">—</span>`;
    const up = r[1] > p.overall; return `<span class="num ${up ? "up" : "muted"}" title="球探估计的潜力区间，球员在队时间越长越准">${r[0] === r[1] ? r[0] : `${r[0]}–${r[1]}`}</span>`; };
  const season = (p) => (p.up || p.down) ? `${p.up ? `<span class="up">+${p.up}</span>` : ""}${p.up && p.down ? " " : ""}${p.down ? `<span class="dn">−${p.down}</span>` : ""}` : `<span class="muted">—</span>`;
  return `<div class="view" style="grid-template-columns:minmax(0,1fr)"><div class="card"><div class="ch">个人训练<span class="r">已用 <b>${used}</b> / ${d.slots} · 点目标选方向 · 方向只决定成长落在哪些能力上 · 每 ${d.settle_every || 4} 轮结算一次${d.to_settle ? ` · 距下次结算 <b>${d.to_settle}</b> 轮` : ""}</span></div>
    <div class="cb scroll"><table><thead><tr><th>位置</th><th>球员</th><th class="n">年龄</th><th class="n">能力</th><th class="n" title="球探估计的潜力区间（隐藏值，不是精确数）">潜力</th><th>培养目标</th><th style="width:20%">发展</th><th style="width:14%" title="这个周期已经攒下的成长，下次结算时按整点兑现（预计值）">本期积累</th><th class="n" title="本季能力项变化（+成长 / −衰退）">本季</th></tr></thead><tbody>
    ${d.players.map((p) => `<tr class="go-row" data-player="${p.pid}"><td>${pos(p.position)}</td><td class="name">${pface(p)}<b>${esc(p.name)}</b>${p.reason ? `<small class="tr-why"><span class="tr-rec">${p.recent ? `近期 ${esc(p.recent.text)}（${esc(p.recent.when.split(" · ")[0])}）` : "正在观察"}</span> · <span class="tr-rs ${esc(p.reason.kind)}">${esc(p.reason.text)}</span></small>` : ""}</td><td class="n" title="联赛年龄${p.card_age ? `（卡面 ${p.card_age} 岁）` : ""}">${p.age ?? "—"}</td><td class="n">${ovr(p.overall)}</td>
      <td class="n" style="white-space:nowrap">${potCell(p)}</td>
      <td><button class="chip${p.individual ? " on" : ""}" data-ind="${p.pid}" title="${p.individual ? "个人训练：一半成长落在这一类" : "自动：按团队重点"}">${p.individual ? "" : "自动 · "}${esc(p.goal || p.cat_name)}${p.goal ? " ▾" : ""}</button></td>
      <td title="${esc(p.stage_name || "")}${p.stage === "decline" ? `：每季约 −${p.decline} 项能力点（身体优先）` : ""}"><span style="display:grid;grid-template-columns:auto 1fr;gap:6px;align-items:center"><small style="color:${STC[p.stage] || "var(--ink3)"};white-space:nowrap">${esc(p.stage_name || "")}</small>${bar(p.stage === "decline" ? Math.min(100, p.decline * 3) : p.momentum, STC[p.stage] || "var(--win)")}</span></td>
      <td title="已攒 ${(p.pending || 0).toFixed(2)} 点，下次结算时兑现整点">${p.stage === "decline" ? `<span class="muted fs-s">衰退期</span>` : `<span class="tr-pg"><i style="width:${Math.min(100, Math.round((p.pending || 0) * 100))}%"></i></span><small class="tr-pgn">${(p.pending || 0) >= 0.05 ? "+" + (p.pending).toFixed(1) : "刚结算"}</small>`}</td>
      <td class="n" style="white-space:nowrap">${season(p)}</td></tr>`).join("")}</tbody></table></div></div></div>`;
}
async function viewGrowth(name) {
  const d = await biz("training"); if (!d) return viewPlan("training", name);
  return `<div class="view" style="grid-template-columns:minmax(0,1fr)"><div class="card"><div class="ch">成长记录<span class="r">${d.growth.length} 条</span></div><div class="cb scroll">
    ${d.growth.map((g) => g.changes ? `<div class="grow2 cat">${pos(g.position)}<b>${pface(g)}${esc(g.name)}</b><span class="muted">${esc(g.when)}</span><span style="white-space:normal;text-align:right">${g.changes.map((c) => `<span class="${c.delta < 0 ? "tag-dn" : "tag-up"}" style="display:inline-block;margin:1px 0 1px 3px">${esc(c.name)} ${c.delta < 0 ? "−" + -c.delta : "+" + c.delta}</span>`).join("")}</span></div>`
      : g.cat ? `<div class="grow2 cat">${pos(g.position)}<b>${pface(g)}${esc(g.name)}</b><span class="muted">${esc(g.when)}</span>${growthTail(g)}</div>`
      : `<div class="grow2">${pos(g.position)}<b>${pface(g)}${esc(g.name)}</b><span class="muted">${esc(g.when)}</span><span class="num">${g.from}</span><span class="up">→</span><span class="num up">${g.to}</span><span class="tag-up">+${g.to - g.from}</span></div>`).join("")
      || `<div class="empty-note">还没有成长记录：每场比赛后按训练计划结算</div>`}</div></div></div>`;
}
// ---- 财务
async function viewFinance(name) {
  const [d, club] = await Promise.all([biz("finance"), biz("club")]); if (!d) return viewPlan("finance", name);
  // 体验评审 U13：没有记账记录 ≠ 收支为 0。月份全空、账本为空时说明原因，不画成一个看似完整的零收入赛季
  // 账本为空就是没有记录（服务端会把当月写成 0/0，那不是“真实为 0”）
  const noBook = !d.ledger.length && d.months.every((m) => !m.inc && !m.exp);
  const NO_BOOK = "尚无记账记录：每月 1 日记入转播、赞助与薪资，每场比赛记入门票（开始记账之前的日子没有账目）";   // M5-D-d：按月结算
  // 2026-11-17 用户：“顺手优化一下这个财务概览的UI吧 有点太丑了”——三张卡各答一个问题：
  //   转会资金（多少、被什么占着：一根分段条＋图例）/ 薪资（周薪对上限、占收入比例、董事会）/ 本季经营（盈亏、每月净额小图、构成）。
  // E342：转会预算的大数字＝扣掉“划给周薪”之后的钱（含已承诺给报价的部分）；分段条按总额画三段
  const rsv = club && club.wage_alloc ? club.wage_alloc.reserved : 0, tb = +(d.balance - rsv).toFixed(1);
  const com = club ? Math.max(0, +(club.committed || 0)) : 0, free = Math.max(0, +(tb - com).toFixed(1)), tot = Math.max(1e-9, d.balance);
  const pc = (v) => `${Math.max(0, Math.min(100, v / tot * 100)).toFixed(2)}%`;
  const fund = [["可用于转会", free, "var(--gold)", "现在能报价的钱"], ["报价占用", com, "var(--draw)", "已承诺给在谈报价的钱：报价结束后释放或付出"], ["划给周薪", rsv, "var(--blue)", "划给周薪上限的部分：不能用于转会费；没用掉的周薪空间可以退回"]];
  const fundCard = `<div class="card key fz" style="--i:0"><div class="ch">转会资金</div><div class="cb scroll fz-cb">
      <div class="fz-big"><span class="num" style="color:var(--gold)" data-to="${tb}" data-pre="€" data-suf="M" data-dec="1">${money(tb)}</span><small>转会预算${rsv ? `（总额 ${money(d.balance, 1)}）` : ""}</small></div>
      <div class="fz-stack" role="img" aria-label="资金分配">${fund.filter((f) => f[1] > 0).map((f) => `<i style="width:${pc(f[1])};background:${f[2]}" title="${f[0]} ${money(f[1], 1)}"></i>`).join("")}</div>
      <div class="fz-rows">${fund.filter((f, i) => i === 0 || f[1] > 0).map((f) => `<div class="fz-row" title="${f[3]}"><i style="background:${f[2]}"></i><span>${f[0]}</span><b class="num">${money(f[1], 1)}</b></div>`).join("")}</div>
      <p class="fz-note">赛季中只随转会变动；本季经营结余在赛季结束时计入${d.board ? `<br><span title="上赛季结束时董事会的拨款">${esc(d.board.note)}</span>` : ""}</p>
      <div class="fz-foot">${wageAllocBtn(club)}</div></div></div>`;
  // 薪资：周薪条上画出“原上限”和“划拨的上限”两段，余量写清楚；薪资占收入对着董事会 60% 线
  const pay = d.wages.total, cap = d.wages.cap, alloc = club && club.wage_alloc ? club.wage_alloc.alloc : 0, cap0 = cap - alloc;
  const wtop = Math.max(cap, pay) || 1, wp = (v) => `${Math.max(0, Math.min(100, v / wtop * 100)).toFixed(2)}%`, full = pay / (cap || 1);
  const ratio = d.ratio, rTone = ratio == null ? "" : ratio > 0.6 ? "var(--loss)" : ratio > 0.55 ? "var(--draw)" : "var(--win)";
  const wageCard = `<div class="card fz" style="--i:1"><div class="ch">薪资<span class="r"><button class="btn sm" data-tab="finance:1">明细</button></span></div><div class="cb scroll fz-cb">
      <div class="fz-big"><span class="num">${kfmt(pay)}</span><small>每周 · 一季约 ${money(pay * 52 / 1000, 1)}</small></div>
      <div class="fz-wbar${full > 1 ? " over" : full > 0.95 ? " tight" : ""}"><b style="width:${wp(pay)}"></b>${alloc ? `<s style="left:${wp(cap0)};width:${wp(alloc)}" title="划拨来的上限 ${kfmt(alloc)}"></s>` : ""}<em style="left:${wp(cap)}"></em></div>
      <div class="fz-rows">
        <div class="fz-row"><span>周薪上限</span><b class="num">${kfmt(cap)}</b></div>
        ${alloc ? `<div class="fz-row sub"><i style="background:var(--blue)"></i><span>其中由转会预算划拨</span><b class="num">${kfmt(alloc)}</b></div>` : ""}
        <div class="fz-row"><span>周薪余量</span><b class="num" style="color:${full >= 1 ? "var(--loss)" : "var(--win)"}">${kfmt(Math.max(0, cap - pay))}</b></div></div>
      ${ratio == null ? "" : `<div class="fz-gauge" title="本季薪资 ÷ 本季收入；董事会希望不超过 60%"><div class="meter"><span>薪资占收入</span><b style="color:${rTone}">${Math.round(ratio * 100)}%</b></div>
        <div class="fz-gt"><b style="width:${Math.min(100, ratio * 100 / 1.0).toFixed(1)}%;background:${rTone}"></b><em style="left:60%" title="董事会 60% 线"></em></div></div>`}
      ${club ? `<div class="fz-gauge"><div class="meter"><span>董事会满意度</span><b style="color:${gaugeColor(club.board.trust)}">${esc(club.board.verdict)}</b></div>${bar(club.board.trust, gaugeColor(club.board.trust))}</div>` : ""}</div></div>`;
  // 本季经营：盈亏大数字、每月净额（正绿负红，以 0 为基线）、构成
  const nets = d.months.map((m) => (m.inc == null && m.exp == null ? null : +((m.inc || 0) - (m.exp || 0)).toFixed(1)));
  // 0 线随数据移动：全亏的赛季不留半格空白（pmx/qmx＝最大盈利/最大亏损，z＝0 线到顶部的比例）
  const known = nets.filter((v) => v != null), pmx = Math.max(0, ...known), qmx = Math.max(0, ...known.map((v) => -v));
  const nmx = Math.max(0.1, pmx + qmx), z = pmx + qmx > 0 ? pmx / nmx : 0.5;
  const inc = d.ledger.filter((l) => l.v > 0).reduce((a, l) => a + l.v, 0), exp = d.ledger.filter((l) => l.v < 0).reduce((a, l) => a - l.v, 0);
  const lmx = Math.max(1, ...d.ledger.map((l) => Math.abs(l.v)));
  const ops = d.ops, opsTxt = ops == null ? "—" : `${ops >= 0 ? "+" : "−"}${money(Math.abs(ops))}`;
  const opsCard = noBook ? `<div class="card fz" style="--i:2"><div class="ch">本季经营</div><div class="cb"><div class="empty-note">${NO_BOOK}</div></div></div>`
    : `<div class="card fz" style="--i:2"><div class="ch">本季经营<span class="r">€M</span></div><div class="cb scroll fz-cb">
      <div class="fz-big" title="转播、赞助、门票、奖金减去薪资与运营开支；赛季结束时由董事会计入下赛季转会预算（亏损则扣减）"><span class="num" style="color:${ops == null || ops >= 0 ? "var(--win)" : "var(--loss)"}">${opsTxt}</span><small>收入 ${money(inc, 1)} · 支出 ${money(exp, 1)} · 季末计入转会预算</small></div>
      <div class="fz-net" style="--z:${(z * 100).toFixed(1)}%;--zn:${z.toFixed(3)}" title="每月净额（收入 − 支出）">${nets.map((v, i) => `<div class="${v == null ? "na" : v >= 0 ? "pos" : "neg"}" title="${esc(d.months[i].m)}${v == null ? "" : ` ${v >= 0 ? "+" : ""}${v}M`}"><i style="height:${v == null ? 0 : Math.max(2, Math.abs(v) / nmx * 100).toFixed(1)}%"></i><small>${esc(String(d.months[i].m).replace("月", ""))}</small></div>`).join("")}</div>
      <div class="fz-led">${d.ledger.map((l) => `<div><span>${esc(l.name)}</span><b class="num ${l.v > 0 ? "up" : "dn"}">${l.v > 0 ? "+" : ""}${l.v}</b><i style="--w:${(Math.abs(l.v) / lmx * 100).toFixed(1)}%;--c:${l.v > 0 ? "var(--win)" : "var(--loss)"}"></i></div>`).join("")}</div></div></div>`;
  return `<div class="view fz-view">${fundCard}${wageCard}${opsCard}</div>`;
}
// E342（2026-11-17 用户：“有很多的转会预算但是周薪预算不能调 就会导致有钱但是签不下人”）：FM 式预算调节——
// 把一部分转会预算划给周薪上限：上限每 +€1K/周，预留一年的这份薪水（€0.052M）不能再用于转会费；没用掉的周薪空间随时可以按同样比例退回。
// 钱不会凭空多出或消失（薪水照常从经营账户付），来回调整不赚不亏。服务端 iml_market.adjust_wage_budget。
const wageAllocBtn = (club) => club && club.wage_alloc ? `<button class="btn sm" style="margin-top:10px;width:100%" data-wagealloc="1">调整周薪预算${club.wage_alloc.alloc ? ` · 已划拨 ${kfmt(club.wage_alloc.alloc)}` : ""}</button>` : "";
async function wageAllocDialog() {
  const club = await biz("club"), a = club && club.wage_alloc; if (!a) return;
  const cap0 = club.wage_cap, pay = club.weekly_wages, lo = cap0 - a.back, hi = cap0 + a.add, avail0 = club.available;
  const main = fmQuote("董事会", `转会预算可以划一部分给周薪：周薪上限每增加 <b>€1K/周</b>，就从转会预算里预留一年的这份薪水 <b>€${a.per_k.toFixed(3)}M</b>，不能再用来付转会费。没用掉的周薪空间随时可以按同样比例退回转会预算。`)
    + fmSec("新的周薪上限", fmStep("wa-cap", cap0, { step: 5, min: lo, max: hi, unit: "K/周" }) + fmMeter("wa-m", "wa-cap"))
    + fmSec("调整后", `<div id="wa-tiles"></div>`)
    + `<p class="muted fs-s" style="margin-top:6px">上限最低 ${kfmt(lo)}（现有周薪 ${kfmt(pay)}，只能退回没用掉的部分）· 最高 ${kfmt(hi)}（可用转会预算 ${money(avail0, 1)}）</p>`;
  const el = mkDialog("调整周薪预算", main, [{ label: "取消" }, { label: "确定", pri: true, fn: async () => {
    const delta = Math.round(+$("#wa-cap", el).value - cap0); if (!delta) { $$("#mkdlg").forEach((e) => e.remove()); return; }
    const r = await post("/api/contract/wage_budget", { delta }); if (mkFail(r)) return false; sound("ok"); delete BIZ.club; delete BIZ.finance; delete BIZ.market; delete BIZ.offers; await mkAfter(""); } }], "fm");
  const upd = () => { const inp = $("#wa-cap", el); let cap = Math.round(+inp.value || cap0); cap = Math.max(lo, Math.min(hi, cap));
    const delta = cap - cap0, avail = avail0 - delta * a.per_k;
    fmMeterSet($("#wa-m", el), { base: 0, add: cap, cap: cap0, max: Math.max(hi, 1), tone: delta ? "ok" : "mid", limit: false, label: delta ? `${delta > 0 ? "+" : "−"}${kfmt(Math.abs(delta))} / 周` : "未调整", value: kfmt(cap) });
    $("#wa-tiles", el).innerHTML = fmTiles([["可用转会预算", money(avail, 1), avail < avail0 ? "var(--loss)" : avail > avail0 ? "var(--win)" : ""], ["周薪空间", kfmt(Math.max(0, cap - pay)), "var(--gold)"], ["为周薪预留", money(a.reserved + delta * a.per_k, 1)]]); };
  fmBind(el, upd); upd();
}
async function viewWages(name) {
  const [d, club] = await Promise.all([biz("finance"), biz("club")]); if (!d) return viewPlan("finance", name);
  const w = d.wages, top = Math.max(0.01, ...w.players.map((p) => p.wage));
  return `<div class="view" style="grid-template-columns:210px minmax(0,1fr)">
    <div class="card plan-hero" style="--i:0;justify-content:flex-start"><small>周薪合计</small><b class="num" style="font-size:40px;color:var(--gold)">${kfmt(w.total)}</b>
      <div class="meter"><span>上限 ${kfmt(w.cap)}</span><b>${Math.round(w.total / w.cap * 100)}%</b></div>${bar(w.total / w.cap * 100, w.total / w.cap > .9 ? "var(--loss)" : "var(--draw)")}
      <p>周薪超过上限后不能再签新球员；卖人或降薪可以腾出空间，也可以把转会预算划一部分给周薪。</p>${wageAllocBtn(club)}</div>
    <div class="card" style="--i:1"><div class="ch">球员周薪<span class="r">${w.players.length} 人</span></div><div class="cb scroll"><table><tbody>
      ${w.players.map((p) => `<tr class="go-row" data-player="${p.pid}"><td>${pos(p.position)}</td><td class="name">${pface(p)}<b>${esc(p.name)}</b></td><td style="width:40%">${bar(p.wage / top * 100, "var(--gold)")}</td><td class="n"><span class="num" style="color:var(--gold)">${kfmt(p.wage)}</span></td><td class="n muted">${p.until}.06</td></tr>`).join("")}</tbody></table></div></div></div>`;
}
async function viewSponsors(name) {
  const d = await biz("finance"); if (!d) return viewPlan("finance", name);
  const total = d.sponsors.reduce((a, s) => a + s.amount, 0);
  return `<div class="view" style="grid-template-columns:minmax(0,1fr)"><div class="card"><div class="ch">赞助合同<span class="r">每季合计 <b style="color:var(--gold)">${money(total)}</b></span></div>
    <div class="cb scroll"><div class="ycards">${d.sponsors.map((s, i) => `<div class="ycard" style="--i:${i}"><div class="yt"><span class="pos MF" style="width:auto;padding:2px 6px">${esc(s.kind)}</span><span class="muted">至 ${s.until}</span></div><b>${esc(s.name)}</b>
      <span class="num" style="font-size:30px;color:var(--gold)">${money(s.amount)}<small style="font-size:12px;color:var(--ink3)"> / 季</small></span><small>奖金条款：${esc(s.bonus)}</small></div>`).join("")}</div></div></div></div>`;
}
// ---- 赛季 · 数据榜 / 荣誉
// RC29.3: short player names for narrow lists - "Matheus Cunha" -> "M. Cunha", single names unchanged
function shortName(n) {
  n = String(n || "").trim(); const w = n.split(/\s+/);
  if (w.length < 2 || n.length <= 12) return n;
  const lastStart = w.length > 2 && /^(de|da|van|von|der|di|le|la|del|dos|el|ter|ten)$/i.test(w[w.length - 2]) ? w.length - 2 : w.length - 1;
  return `${w[0][0]}. ${w.slice(lastStart).join(" ")}`;
}
async function viewStats(name) {
  const d = await biz("stats"); if (!d) return viewPlan("season", name);
  // 2026-11-15 用户：“再优化一下这个数据榜的UI”——行更紧凑（一屏多看几人）、前三名金银铜、名次与数值之间用条形显示相对多少（空着的位置不再浪费）
  // 2026-11-15 用户：“射手榜球员头像点不进去”——整行可点：我队球员开球员详情，他队球员开球探报告
  const row = (i, tid, r, bar, val, tip, kind) => `<tr class="${r.pid ? "go-row " : ""}${tid === me() ? "me" : ""}"${pgo(r, tid, kind, r.n)}><td class="rk">${i + 1}</td><td class="name rc-nm"><span class="tn" title="${esc(r.name)}">${crest(tid, "sm")}<span class="rc-pl"><b translate="no">${esc(shortName(r.name))}</b><small>${esc(tname(tid))}</small></span></span></td><td class="n"${tip ? ` title="${esc(tip)}"` : ""}>${val}</td></tr>`;
  const col = (title, rows, unit, cls) => { const top = Math.max(1, ...rows.map((r) => r.n));
    return `<div class="card st-col ${cls}"><div class="ch">${title}<span class="r">${rows.length ? `第 1 名 ${rows[0].n} ${unit}` : ""}</span></div><div class="cb scroll"><table><tbody>${rows.map((r, i) => row(i, r.team == null ? me() : r.team, r, r.n / top * 100, `<span class="num">${r.n}</span>`, "", cls === "st-g" ? "g" : "a")).join("")}</tbody></table></div></div>`; };
  // E307 C2：评分榜（场均评分，至少 min_apps 场；实测 + 模拟，宿主 iml_ratings）
  const rb = await api("/api/ratings/board").catch(() => null), rated = rb && !rb.error && (rb.rows || []).length ? rb : null;
  const ratingCol = () => `<div class="card st-col st-r"><div class="ch">评分榜<span class="r">场均 · ≥${rated.min_apps} 场</span></div><div class="cb scroll"><table><tbody>${rated.rows.map((r, i) =>
    row(i, r.team, r, (r.avg - 5.5) / 3.5 * 100, rpRt(r.avg), `${r.apps} 场 · 全场最佳 ${r.best} 次`)).join("")}</tbody></table></div></div>`;
  return `<div class="view${rated ? " st3" : ""}" style="grid-template-columns:${rated ? "repeat(3,minmax(0,1fr))" : "minmax(0,1fr) minmax(0,1fr)"}">${col("射手榜", d.scorers, "球", "st-g")}${col("助攻榜", d.assisters, "次", "st-a")}${rated ? ratingCol() : ""}</div>`;
}/* 日程：日历式的赛季赛程。原生赛程没有日期，服务端 (iml_ui.round_date) 按“每周一轮、冬歇两周”排出模拟日期 */
let calMonth = null;
const WEEK = ["一", "二", "三", "四", "五", "六", "日"];
const ymd = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const parseD = (s) => { const [y, m, d] = s.split("-").map(Number); return new Date(y, m - 1, d); };
// 2026-11-18 用户：“欧冠赛程不会显示在我们的日程表”——日程原来只读联赛 S.schedule；现在把 /api/europe 里我队的欧战场次（联赛阶段＋淘汰赛各回合）一起排进来，
// 点已踢的欧战场次打开同一张战报页（eu:<场次>），中立场决赛不写主客。读欧战失败只显示联赛，不挡日程。
const EU_SHORT = { ucl: "UCL", uel: "UEL" };
async function calEuro() {
  const d = await euTeamsAll().catch(() => null);
  if (!d || d.error || !d.comps) return [];
  const out = [], add = (c, l, label) => { if (!l.mine || !l.date) return;
    out.push({ eu: c.id, id: "eu:" + l.id, date: String(l.date).slice(0, 10), home: l.home, away: l.away, neutral: l.neutral, label: `${EU_SHORT[c.id] || c.name} ${label}`,
      result: l.hg == null ? null : { home_goals: l.hg, away_goals: l.ag } }); };
  for (const c of d.comps) {
    (c.matchdays || []).forEach((md) => md.matches.forEach((l) => add(c, l, `联赛阶段第 ${md.md} 轮`)));
    (c.ko || []).forEach((r) => r.ties.forEach((t) => t.legs.forEach((l, i) => add(c, l, `${EU_STAGE[r.stage] || r.name}${t.legs.length > 1 ? (i ? " · 2nd leg" : " · 1st leg") : ""}`))));
  }
  return out;
}
async function viewCalendar() {
  const sch = [...(S.schedule || []).map((f) => ({ ...f, label: `第 ${f.round} 轮` })), ...await calEuro()].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
  if (!sch.length) return `<div class="view"><div class="card"><div class="empty-note">没有赛程</div></div></div>`;
  const nextM = sch.find((x) => !x.result), months = [...new Set(sch.map((x) => x.date.slice(0, 7)))];
  if (!calMonth || !months.includes(calMonth)) calMonth = (nextM || sch[sch.length - 1]).date.slice(0, 7);
  const [Y, M] = calMonth.split("-").map(Number), first = new Date(Y, M - 1, 1), days = new Date(Y, M, 0).getDate(), lead = (first.getDay() + 6) % 7;
  const by = {}; sch.forEach((x) => { if (!by[x.date]) by[x.date] = x; });
  const di = dayInfo(), todayKey = di ? ymd(di.today) : "";
  const ha = (f, home) => (f.neutral ? "中" : home ? "主" : "客");
  const cell = (n) => { const key = `${calMonth}-${String(n).padStart(2, "0")}`, f = by[key], td = key === todayKey ? " today" : "";
    if (!f) return `<div class="cd${td}"><i>${n}</i></div>`;
    const home = f.home === me(), opp = home ? f.away : f.home, rs = f.result ? resultOf(f) : null, isNext = nextM && nextM.id === f.id;
    const mine = f.result ? (home ? f.result.home_goals : f.result.away_goals) : null, theirs = f.result ? (home ? f.result.away_goals : f.result.home_goals) : null;
    return `<div class="cd match${f.eu ? ` eu eu-${f.eu}` : ""}${isNext ? " next" : ""}${rs ? ` ${rs}` : ""}${td}" ${f.result ? `data-fx="${f.id}" data-sound="page"` : `data-team="${opp}"`} title="${esc(f.label)} · ${esc(tname(opp))}"><i>${n}</i>${f.eu ? `<b class="cd-eu">${EU_SHORT[f.eu] || ""}</b>` : ""}${crest(opp, "sm")}<small>${esc(tname(opp))}</small><em>${f.result ? `${mine}:${theirs}` : ha(f, home)}</em></div>`; };
  const cells = Array.from({ length: lead }, () => `<div class="cd off"></div>`).concat(Array.from({ length: days }, (_, i) => cell(i + 1))).join("");
  const list = sch.filter((x) => x.date.startsWith(calMonth)).map((f) => { const home = f.home === me(), opp = home ? f.away : f.home, rs = f.result ? resultOf(f) : null, d = parseD(f.date);
    return `<div class="fxl${nextM && nextM.id === f.id ? " next" : ""}" ${f.result ? `data-fx="${f.id}" data-sound="page"` : `data-team="${opp}"`}><span class="fs-s">${d.getMonth() + 1}/${d.getDate()} 周${WEEK[(d.getDay() + 6) % 7]}</span>${crest(opp, "sm")}<span>${esc(tname(opp))}${f.eu ? ` <small class="muted">${esc(f.label)}</small>` : ""}${nextM && nextM.id === f.id ? " · 下一场" : ""}</span><span class="num"${rs ? ` style="color:var(--${rs === "W" ? "win" : rs === "L" ? "loss" : "draw"})"` : ""}>${f.result ? `${f.result.home_goals}:${f.result.away_goals}` : ha(f, home)}</span></div>`; }).join("");
  const i = months.indexOf(calMonth);
  return `<div class="view v-cal">
    <div class="card" style="--i:0"><div class="ch cal-h"><button class="cal-nav" data-cal="${i > 0 ? months[i - 1] : ""}" ${i > 0 ? "" : "disabled"} aria-label="上个月">‹</button><b>${Y} 年 ${M} 月</b><button class="cal-nav" data-cal="${i < months.length - 1 ? months[i + 1] : ""}" ${i < months.length - 1 ? "" : "disabled"} aria-label="下个月">›</button>${nextM ? `<button class="cal-today" data-cal="${nextM.date.slice(0, 7)}">回到下一场</button>` : ""}</div>
      <div class="cb cal-cb"><div class="cal-week">${WEEK.map((w) => `<span>${w}</span>`).join("")}</div><div class="cal-grid" style="grid-template-rows:repeat(${Math.ceil((lead + days) / 7)},minmax(0,1fr))">${cells}</div></div></div>
    <div class="card" style="--i:1"><div class="ch">${M} 月赛程<span class="r">${S.career.league_name}</span></div><div class="cb scroll">${list || `<div class="empty-note">这个月没有比赛</div>`}</div><div class="foot-note">模拟排期：每周一轮，冬歇两周</div></div></div>`;
}
// 荣誉页（球队 · 荣誉）见 66-honors-hall.js

/* ---- 球队 · 荣誉：奖杯展厅 + 联赛名次走势（2026-11-14 重做，用户：“太像表格，没有展厅感”“历史名次要有走势图”） ----
   数据：/api/biz/honors（iml_biz.honors）。real＝俱乐部现实历史（iml_club_history 静态底稿，只有五大联赛球队有）；
   seasons/cabinet＝本生涯（iml_honors_v1）。两者分开计数：现实冠军不算进生涯荣誉，新建游戏也不会清掉现实历史。
   奖杯是我们自己画的通用造型（按赛事类型分 7 种），不是各赛事真实奖杯的样子，也不用 FM 的奖杯图。
   走势图：纵轴＝“总排名”（第 n 级联赛的第 p 名 → (n-1)×色带名次数+p，色带至少 20 名），按级别分色带，所以降级/升级是真的跌下/爬上一个色带；
   级别不明的赛季不画（断线），不猜。本生涯的赛季接在现实历史之后（第 1 季＝2026-27），用球队主色区分。 */
let hallData = null, hallRange = 30, hallPick = -1;

// 赛事 → 奖杯造型
function cupKind(id) {
  if (/top_division/.test(id)) return "league";
  if (/uefa_champions/.test(id)) return "ucl";
  if (/club_world|intercontinental/.test(id)) return "world";
  if (/community_shield|supercopa|supercoppa|supercup|trophee|eva_duarte/.test(id)) return "super";
  if (/league_cup|copa_de_la_liga|ligapokal|coupe_de_la_ligue/.test(id)) return "lcup";
  if (/uefa_|fairs|cup_winners|intertoto/.test(id)) return "euro";
  return "cup";
}
const CUP_METAL = { league: "g", world: "g", ucl: "s", cup: "s", lcup: "s", euro: "s", super: "s" };
const CUP_SHAPE = {
  // 底座（木纹台座）各奖杯共用；以下只画杯身。viewBox 0 0 40 56
  league: `<path d="M9 9h22c0 13-4 20-11 21C13 29 9 22 9 9z"/><rect x="8" y="5" width="24" height="4" rx="1.5"/><circle cx="20" cy="3" r="2"/><rect x="18" y="30" width="4" height="7"/><path d="M13 37h14l2 6H11z"/>`,
  ucl: `<path d="M12 8h16c0 13-3 19-8 20-5-1-8-7-8-20z"/><path d="M12 9C2 4 1 25 14 24" fill="none" stroke-width="2.6"/><path d="M28 9c10-5 11 16-2 15" fill="none" stroke-width="2.6"/><rect x="18.5" y="28" width="3" height="9"/><path d="M13 37h14l2 6H11z"/>`,
  world: `<circle cx="20" cy="14" r="9"/><path d="M11 14h18M20 5c-5 5-5 13 0 18M20 5c5 5 5 13 0 18" fill="none" stroke-width=".9" class="ln"/><path d="M15 22c2 4 3 8 3 14h4c0-6 1-10 3-14z"/><path d="M13 37h14l2 6H11z"/>`,
  cup: `<path d="M11 9h18c0 12-4 18-9 19-5-1-9-7-9-19z"/><path d="M11 11c-7 0-7 10 2 12M29 11c7 0 7 10-2 12" fill="none" stroke-width="2"/><rect x="18" y="28" width="4" height="8"/><path d="M13 36h14l2 7H11z"/>`,
  lcup: `<path d="M13 14h14c0 10-3 14-7 15-4-1-7-5-7-15z"/><path d="M13 16c-5 0-5 7 1 9M27 16c5 0 5 7-1 9" fill="none" stroke-width="1.8"/><rect x="18.5" y="29" width="3" height="7"/><path d="M14 36h12l2 7H12z"/>`,
  euro: `<path d="M15 6h10l3 7c0 10-3 15-6 18h-4c-3-3-6-8-6-18z"/><rect x="14" y="4" width="12" height="3" rx="1"/><rect x="18" y="31" width="4" height="6"/><path d="M13 37h14l2 6H11z"/>`,
  super: `<path d="M11 8h18v12c0 9-9 14-9 14s-9-5-9-14z"/><path d="M20 13l1.6 3.4 3.7.4-2.8 2.5.8 3.6-3.3-1.9-3.3 1.9.8-3.6-2.8-2.5 3.7-.4z" class="ln"/><rect x="18.5" y="33" width="3" height="4"/><path d="M13 37h14l2 6H11z"/>`,
};
const CUP_SIZE = { league: 1, ucl: 1, world: .94, cup: .9, euro: .86, lcup: .8, super: .78 };
// 用户自制奖杯图（2026-11-14 用户：“奖杯我已经在做图片了 到时候接入就好了”）：放 app/img/trophy/<赛事编号>.png
// （编号见 build_iml_club_history.COMP_ZH，本生涯联赛冠军用 career_league.png）；有图就用图，没图退回下面的占位矢量奖杯。
const CAREER_CUP_ART = { 113: "england_top_division", 119: "spain_top_division", 116: "italy_top_division", 122: "france_top_division", 900307: "germany_top_division" };   // 本生涯联赛冠军 → 该联赛真实奖杯图
const trophyArt = (id, kind) => `<span class="tr-art" style="--k:${CUP_SIZE[kind]}"><img src="/img/trophy/${esc(id)}.png" alt="" onload="this.parentNode.classList.add('img')" onerror="this.remove()">${trophySvg(kind)}</span>`;
const trophySvg = (kind) => `<svg class="tr ${CUP_METAL[kind]}" viewBox="0 0 40 56" style="--k:${CUP_SIZE[kind]}"><g class="body">${CUP_SHAPE[kind]}</g><rect x="8" y="43" width="24" height="9" rx="1.5" class="plinth"/><rect x="14" y="46" width="12" height="3" rx=".5" class="plate"/></svg>`;
const HALL_DEFS = `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
  <linearGradient id="trG" x1="0" x2="1"><stop offset="0" stop-color="#8a6a1e"/><stop offset=".35" stop-color="#f6d77a"/><stop offset=".55" stop-color="#fff2c2"/><stop offset=".8" stop-color="#c99a2e"/><stop offset="1" stop-color="#7a5a14"/></linearGradient>
  <linearGradient id="trS" x1="0" x2="1"><stop offset="0" stop-color="#6f747d"/><stop offset=".35" stop-color="#d9dde3"/><stop offset=".55" stop-color="#ffffff"/><stop offset=".8" stop-color="#a7adb6"/><stop offset="1" stop-color="#5d626a"/></linearGradient>
  <linearGradient id="trW" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4a3424"/><stop offset="1" stop-color="#22170f"/></linearGradient></defs></svg>`;

const seasonLabel = (y) => `${y}-${String((y + 1) % 100).padStart(2, "0")}`;
function hallSeries(d) {
  const real = (d.real && d.real.positions) || [];
  const pts = real.map((p) => ({ y: p.year, tier: p.tier, pos: p.position, label: p.season, career: false }));
  const base = pts.length ? Math.max(...pts.map((p) => p.y)) + 1 : 2026;
  (d.seasons || []).forEach((s) => { if (s.rank && !s.running) pts.push({ y: Math.max(base, 2025 + (+s.season || 1)), tier: 1, pos: s.rank, label: `本生涯第 ${s.season} 季`, career: true }); });
  return pts.sort((a, b) => a.y - b.y);
}

function trendSvg(d, W = 420, H = 210) {
  const all = hallSeries(d);
  if (!all.length) return `<div class="empty-note">没有收录历史名次</div>`;
  const maxY = all[all.length - 1].y, minY = hallRange ? Math.max(all[0].y, maxY - hallRange + 1) : all[0].y;
  const pts = all.filter((p) => p.y >= minY).map((p) => (p.tier > 5 ? { ...p, tier: null } : p));   // 第 6 级以下当作不明，不画
  const known = pts.filter((p) => p.tier);
  const tiers = Math.min(5, Math.max(1, ...known.map((p) => p.tier)));     // 一直在顶级就只画一条色带，不留空的“次级”
  const band = Math.max(20, ...known.map((p) => p.pos));                  // 每级色带按 20 名起算（英冠 24 队时放宽）
  const L = 30, R = 8, T = 8, B = 18, span = Math.max(1, maxY - minY);
  const x = (yr) => L + (yr - minY) / span * (W - L - R);
  const yv = (p) => T + ((p.tier - 1) * band + p.pos - .5) / (tiers * band) * (H - T - B);
  const bandH = (H - T - B) / tiers, TIER = ["顶级", "次级", "第3级", "第4级", "第5级"];
  let g = "";
  for (let i = 0; i < tiers; i++) g += `<rect x="${L}" y="${T + i * bandH}" width="${W - L - R}" height="${bandH}" class="band b${i % 2}"/><text x="${L - 4}" y="${T + i * bandH + 11}" class="tl">${TIER[i]}</text>`;
  const step = span > 60 ? 20 : span > 24 ? 10 : 5;
  for (let yr = Math.ceil(minY / step) * step; yr <= maxY; yr += step) g += `<line x1="${x(yr)}" x2="${x(yr)}" y1="${T}" y2="${H - B}" class="vg"/><text x="${x(yr)}" y="${H - 5}" class="xl">${yr}</text>`;
  const firstCareer = pts.find((p) => p.career);
  if (firstCareer) g += `<line x1="${x(firstCareer.y) - 3}" x2="${x(firstCareer.y) - 3}" y1="${T}" y2="${H - B}" class="cl"/><text x="${x(firstCareer.y) - 1}" y="${T + 9}" class="ct" text-anchor="end">本生涯</text>`;
  // 线：相邻赛季、级别已知才连；本生涯另起一段
  let seg = [], lines = "";
  const flush = (career) => { if (seg.length > 1) lines += `<polyline points="${seg.join(" ")}" class="ln${career ? " car" : ""}"/>`; seg = []; };
  pts.forEach((p, i) => {
    const prev = pts[i - 1];
    if (!p.tier || (prev && (p.y - prev.y > 1 || !prev.tier || prev.career !== p.career))) flush(prev && prev.career);
    if (p.tier) seg.push(`${x(p.y).toFixed(1)},${yv(p).toFixed(1)}`);
  });
  flush(pts.length && pts[pts.length - 1].career);
  const dots = known.map((p) => { const champ = p.tier === 1 && p.pos === 1;
    return `<circle cx="${x(p.y).toFixed(1)}" cy="${yv(p).toFixed(1)}" r="${champ ? 3.4 : p.career ? 2.8 : 1.7}" class="${champ ? "champ" : ""}${p.career ? " car" : ""}"><title>${esc(p.label)} · ${TIER[p.tier - 1] || `第${p.tier}级`}第 ${p.pos} 名</title></circle>`; }).join("");
  return `<svg class="trend" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" style="--club:${tcolor(me())}">${g}${lines}${dots}</svg>`;
}

function trophyDetail(i) {
  const d = hallData; if (!d) return "";
  const h = d.cups[i];
  if (!h) return "";                                          // 2026-11-14 用户：去掉提示小字
  const yrs = [...(h.seasons || []), ...(h.careerSeasons || [])];        // 现实年份在前，本生涯赛季接在后面
  return `<b>${esc(h.name)}</b><em class="num">×${h.count}</em><span>${esc(yrs.join("　") || "年份待核")}</span>`;
}

async function viewHonors(name) {
  const d = await biz("honors"); if (!d) return viewPlan("squad", name);
  const real = d.real;
  // 展柜：现实主要冠军（按联赛→国内杯→欧洲/世界排）＋本生涯联赛冠军（有才放，带“本生涯”绶带）
  const careerTitles = d.seasons.filter((s) => (s.trophies || []).includes("联赛冠军"));
  const cups = (real ? real.honours.map((h) => ({ ...h, kind: cupKind(h.id) })) : []);
  // 2026-11-16 用户：“英超夺冠了 拿的奖杯居然不是英超 拿的我们自己画的奖杯”→“你应该和那个英格兰顶级联赛放在一起啊”：
  // 本生涯联赛冠军按所在联赛归到现实同一座奖杯上（英超→英格兰顶级联赛，次数相加，绶带标本生涯几次）；现实里还没拿过这座（或无现实资料）
  // 时单放一座、用该联赛的真实奖杯图。有升降级后一个生涯可能拿过不同联赛的冠军，各归各的。次级联赛没有奖杯图时仍用占位矢量奖杯。
  const byComp = new Map();
  careerTitles.forEach((s) => { const k = String(s.comp ?? s.league); if (!byComp.has(k)) byComp.set(k, { comp: s.comp, league: s.league, list: [] }); byComp.get(k).list.push(s); });
  [...byComp.values()].reverse().forEach((g) => {
    const art = CAREER_CUP_ART[g.comp], n = g.list.length, labels = g.list.map((s) => `本生涯第 ${s.season} 季`);
    const same = art && cups.find((c) => c.id === art);
    if (same) Object.assign(same, { count: same.count + n, careerN: n, careerSeasons: labels });
    else cups.unshift({ id: art || `career_league_${g.comp}`, art: art || "career_league", name: `${g.league || "联赛"}冠军`, count: n, kind: "league", careerN: n, careerSeasons: labels, seasons: [] });
  });
  hallData = { ...d, cups }; hallPick = -1;
  const total = cups.reduce((n, c) => n + c.count, 0);
  const shelf = cups.length ? cups.map((c, i) => `<button class="tro${c.careerN ? " car" : ""}" data-cup="${i}" title="${esc(c.name)}${c.last ? ` · 最近 ${esc(c.last)}` : ""}">${trophyArt(c.art || c.id, c.kind)}${c.careerN ? `<i class="rib">本生涯${c.careerN > 1 || c.count > c.careerN ? ` +${c.careerN}` : ""}</i>` : ""}<b class="num">${c.count}</b><small>${esc(c.name)}</small></button>`).join("")
    : `<div class="hall-empty">${trophySvg("league")}<span>${real ? "展柜还在等第一座主要奖杯" : "这支球队没有收录现实历史资料"}</span></div>`;
  const cab = d.cabinet.map((c) => `<span title="本生涯 · ${esc(c.name)}">${esc(c.name)} <b class="num">${c.count}</b></span>`).join("");
  return `${HALL_DEFS}<div class="view v-hall">
    <div class="card hall" style="--i:0"><div class="ch">荣誉展厅<span class="r">${real ? `${total} 座主要奖杯${real.founded ? ` · ${real.founded} 年建队` : ""}${real.stadium ? ` · ${esc(real.stadium)}` : ""}` : "本生涯"}</span></div>
      <div class="hall-room"><div class="hall-shelf">${shelf}</div></div>
      <div class="hall-detail">${trophyDetail(-1)}</div>
      <div class="hall-career"><i>本生涯</i>${cab}<button class="btn" data-hall-seasons>历届赛季 ›</button></div></div>
    <div class="card hall-trend" style="--i:1"><div class="ch">联赛名次走势<span class="r seg">${[[30, "近30季"], [0, "全部"]].map(([v, t]) => `<button data-trend="${v}" class="${hallRange === v ? "on" : ""}">${t}</button>`).join("")}</span></div>
      <div class="cb trend-box">${trendSvg(hallData)}</div>
      <div class="foot-note"><i class="lg-dot champ"></i>顶级联赛冠军 <i class="lg-dot car"></i>本生涯</div></div></div>`;
}

function hallSeasons() {
  const d = hallData; if (!d) return;
  sound("page");
  openLayer("历届赛季", "本生涯", `<div class="card"><div class="cb scroll"><table><thead><tr><th>赛季</th><th>联赛</th><th class="n">排名</th><th class="n">积分</th><th>冠军</th><th>荣誉</th></tr></thead><tbody>
    ${d.seasons.map((s) => `<tr><td>第 ${s.season} 季</td><td>${esc(s.league)}</td><td class="n">${s.rank ?? "进行中"}</td><td class="n">${s.points ?? "—"}</td><td>${esc(s.champion_name || "—")}</td><td>${esc(s.trophy || "—")}</td></tr>`).join("")}</tbody></table></div></div>`);
}

function drawTrend(root) {
  const box = $(".trend-box", root); if (!box || !hallData) return;
  const W = Math.max(200, box.clientWidth - 12), H = Math.max(120, box.clientHeight - 6);
  box.innerHTML = trendSvg(hallData, W, H);
}
// 展厅里的点击只换局部（详情条 / 走势图），不整页重画
function bindHall(root) {
  $$("[data-cup]", root).forEach((el) => el.addEventListener("click", (e) => {
    e.stopPropagation(); const i = +el.dataset.cup; hallPick = hallPick === i ? -1 : i; sound("cursor");
    $$("[data-cup]", root).forEach((b) => b.classList.toggle("on", +b.dataset.cup === hallPick));
    const box = $(".hall-detail", root); if (box) box.innerHTML = trophyDetail(hallPick);
  }));
  $$("[data-trend]", root).forEach((el) => el.addEventListener("click", (e) => {
    e.stopPropagation(); hallRange = +el.dataset.trend; sound("cursor");
    $$("[data-trend]", root).forEach((b) => b.classList.toggle("on", +b.dataset.trend === hallRange));
    drawTrend(root);
  }));
  if ($(".trend-box", root)) requestAnimationFrame(() => drawTrend(root));       // 按实际框大小重画（像素坐标，字不变形、不留白）
  $$("[data-hall-seasons]", root).forEach((el) => el.addEventListener("click", (e) => { e.stopPropagation(); hallSeasons(); }));
}
// ---- 欧冠 / 欧联赛事标志（UEFA 官网 dark 版 SVG，2026-11-17 用户指定，仅自用不分发）。由 outputs/runs/20261117-E336-uefa-logos/download/*.svg 原样内联，
// 不走 /img 文件（手机宿主对 .svg 的类型未验）。侧栏两个赛事按钮用它，68-europe.js 读 EU_LOGO。
const EU_LOGO = {
  ucl: "<svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"> <path d=\"M25.1539 27.5825C24.9346 27.5825 24.7483 27.4137 24.7483 27.182C24.7483 26.9531 24.9346 26.784 25.1539 26.784C25.3713 26.784 25.5579 26.9531 25.5579 27.182C25.5579 27.4137 25.3713 27.5825 25.1539 27.5825ZM24.8286 27.182C24.8286 27.3745 24.9714 27.5161 25.1539 27.5161C25.3344 27.5161 25.4776 27.3745 25.4776 27.182C25.4776 26.9934 25.3344 26.8507 25.1539 26.8507C24.9714 26.8507 24.8286 26.9934 24.8286 27.182ZM25.0693 27.214V27.4137H25V26.9531H25.1753C25.284 26.9531 25.3377 26.9934 25.3377 27.084C25.3377 27.1664 25.2859 27.202 25.2187 27.2108L25.3488 27.4137H25.2712L25.1502 27.214H25.0693ZM25.0693 27.1545H25.1533C25.2122 27.1545 25.2653 27.1511 25.2653 27.0801C25.2653 27.0228 25.2134 27.0126 25.1644 27.0126H25.0693V27.1545ZM25.193 18.5927C25.1622 18.656 25.1013 18.6994 25.0314 18.7075C23.4399 18.8927 21.7485 18.6708 21.0966 18.5682C20.0081 17.4783 18.8297 16.266 17.961 15.2067C17.8718 15.098 17.8678 14.9429 17.9496 14.8285C19.1883 13.0979 20.3228 11.7242 20.8026 11.1803C22.1727 10.8809 23.5393 10.616 24.4619 10.5784C24.5316 10.5755 24.5981 10.6077 24.6387 10.6644C25.8283 12.3224 26.6791 13.911 26.952 14.4916C26.4058 15.9622 25.7488 17.4481 25.193 18.5927ZM23.6742 21.3982C22.7971 22.8701 22.1305 23.7577 21.917 24.0273C21.627 24.4375 20.888 25.5062 19.7401 26.5868C19.6667 26.6558 19.5712 26.6957 19.4706 26.7C18.033 26.76 16.6961 26.659 16.1756 26.5451C15.735 26.3626 14.7092 25.9002 13.4965 25.2282C13.3909 25.1698 13.3285 25.0555 13.3366 24.9351C13.3997 23.9931 13.6979 22.6513 13.9619 21.2325C14.6141 20.0846 15.2901 18.775 15.9913 17.6992C16.0652 17.586 16.2037 17.5334 16.3341 17.569C18.4336 18.1435 20.2554 18.5796 20.995 18.7464C22.0075 19.9233 22.989 20.7508 23.6493 21.2636C23.6903 21.2956 23.7009 21.3534 23.6742 21.3982ZM10.9721 23.4437C10.8657 23.5099 10.7301 23.5063 10.628 23.4339C9.71379 22.7851 8.62287 21.9567 7.71448 21.1057C7.17863 20.188 6.76519 19.0132 6.4768 18.013C6.45822 17.9485 6.47243 17.8789 6.51475 17.8269C7.53415 16.571 8.75778 15.5772 9.26912 15.1988C10.4231 15.6977 11.7476 16.1377 12.9061 16.5238C13.0246 16.5633 13.1082 16.6696 13.118 16.7941C13.2815 18.8599 13.659 20.5302 13.76 21.1685C13.3274 21.6318 12.197 22.6818 10.9721 23.4437ZM5.89427 15.3163C5.74313 14.341 5.64351 13.3171 5.63259 12.8481C5.60745 11.7651 5.77935 10.8062 5.97874 9.91806C6.01137 9.77286 6.08678 9.64092 6.19654 9.54006C6.77549 9.00858 7.82284 8.07068 8.48392 7.64584C9.10689 7.24551 10.8383 6.6853 11.5523 6.47732C11.6908 6.43704 11.8382 6.49871 11.9094 6.62409C11.9952 6.77507 12.0852 6.92527 12.1801 7.07298C12.7423 7.94999 13.3617 8.70521 13.6226 9.032C13.2768 10.4082 13.13 11.9511 13.0629 13.2526C13.0566 13.3747 12.9792 13.4817 12.8654 13.5262C11.0586 14.2324 9.69318 14.7849 9.23445 14.9971C7.99334 15.0496 6.81093 15.2615 6.01293 15.4014C5.95641 15.4112 5.90317 15.3728 5.89427 15.3163ZM15.2222 5.72554C17.0799 5.47962 18.7796 5.4434 19.4327 5.46151C20.6215 6.25374 21.7831 7.29906 22.7103 8.2902C22.7754 8.35984 22.7851 8.46445 22.7339 8.5447C22.072 9.58159 21.1099 10.5771 20.6872 11.0107C19.12 11.3824 17.4581 11.9236 16.1095 12.3672C15.9781 12.4103 15.834 12.3614 15.7557 12.2474C14.7323 10.7574 14.0818 9.48057 13.8267 9.00639C14.1035 7.7645 14.4906 6.65844 15.0011 5.86559C15.0506 5.78877 15.1315 5.7374 15.2222 5.72554ZM27.4106 18.0951C27.3773 18.1104 27.3392 18.087 27.3372 18.0503C27.2593 16.521 27.1189 15.0352 27.0455 14.4916C27.0513 13.1708 26.8327 11.8004 26.6149 10.7898C26.6071 10.7532 26.6391 10.7204 26.6758 10.7279C27.923 10.9832 28.3232 11.451 28.3232 11.451C27.663 9.96787 26.7118 8.85026 25.6778 8.00557C24.7939 6.151 23.7767 5.29351 23.7767 5.29351C23.859 5.70368 23.8021 6.16755 23.6563 6.64611C23.6471 6.67671 23.6124 6.69123 23.5838 6.67718C21.8896 5.84732 20.1401 5.46807 19.4633 5.3733C18.452 4.88085 17.3475 4.55499 16.4494 4.30799C16.4254 4.30143 16.419 4.27021 16.4382 4.25428C17.6304 3.26298 18.727 3.01082 18.727 3.01082C16.7856 2.93276 15.1146 3.28453 13.7175 3.82257C11.63 3.65488 10.3002 4.01852 10.3002 4.01852C10.3002 4.01852 10.8768 4.70972 11.1007 5.09444C11.1279 5.14112 11.1137 5.20046 11.0693 5.23121C9.75641 6.14304 8.8143 7.14464 8.44301 7.56152C8.0291 7.61773 7.31244 7.71688 6.68649 7.87145C6.66151 7.87754 6.64043 7.85256 6.65043 7.82867C7.27731 6.33352 7.96055 5.5057 7.96055 5.5057C7.96055 5.5057 3.93197 8.37077 3.16831 13.5192C3.16831 13.5192 3.49979 12.6065 4.62161 11.2233C4.63629 11.2051 4.66502 11.209 4.6747 11.2302C4.99243 11.9349 5.35576 12.5608 5.53844 12.8481C4.92155 13.8425 4.49561 14.9272 4.23346 15.8146C4.22425 15.8456 4.20099 15.8701 4.17085 15.8816C3.23779 16.2362 3 16.5747 3 16.5747C3.14505 17.0709 3.42984 17.5545 3.78989 18.0104C3.82111 18.0499 3.83704 18.0992 3.83485 18.1495C3.73571 20.3466 4.44362 21.7929 4.44362 21.7929C4.60335 21.0255 4.9164 20.2801 5.31173 19.5803C5.32734 19.5525 5.36435 19.5455 5.38948 19.5655C6.31021 20.2979 7.26404 20.938 7.64251 21.1654C7.83799 21.6647 8.39679 22.9601 9.14374 24.2892C9.15951 24.3171 9.14655 24.3526 9.11657 24.3636C8.22223 24.69 7.30447 24.8377 6.46322 24.6323C6.46322 24.6323 7.47778 25.8981 10.6077 26.4379C11.4761 27.4653 12.5328 28.3162 13.7667 28.6121C13.7667 28.6121 13.405 28.2138 13.3157 26.7299C13.3139 26.6999 13.3378 26.6743 13.3681 26.6747C14.1407 26.6865 15.1891 26.7032 16.1486 26.6335C16.4886 26.9021 17.2309 27.491 17.9547 27.8667C17.9906 27.8853 17.9928 27.9362 17.9582 27.9571C16.6858 28.7274 15.8393 28.7946 15.8393 28.7946C21.6027 28.9175 25.0631 25.1545 25.0631 25.1545C24.1138 25.7796 23.0175 26.1684 21.9263 26.4001C21.8895 26.4081 21.8573 26.3753 21.8648 26.3384C22.0676 25.357 22.0108 24.4081 21.9964 24.0735C23.3639 23.7343 24.5569 23.1225 25.4398 22.4974C25.4578 22.4847 25.4815 22.4846 25.4995 22.4972C25.8672 22.753 26.1818 23.0404 26.4958 23.5188C26.4958 23.5188 27.0936 22.6718 27.2995 20.7095C28.7799 18.7748 29 16.7945 29 16.7945C28.6286 17.3761 28.0676 17.7949 27.4106 18.0951Z\" fill=\"white\"/> </svg>",
  uel: "<svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\"> <g clip-path=\"url(#clip0_6027_4392)\"> <path d=\"M12.0662 26.496H19.9444L17.7984 19.8256L22.0862 4.12312L18.9704 2.15869L15.5815 21.4817L11.2616 4.18504L10.6241 6.26206L14.1756 20.0513L12.0662 26.496ZM11.6955 27.6288L10.9311 29.9641H21.0602L20.3088 27.6288H11.6955ZM17.6912 2L12.313 3.49273L15.4337 16.5519L17.6912 2Z\" fill=\"white\"/> <path d=\"M5.79162 21.5932V13.2612L9.95099 9.15466L9.21484 6.68181L3.5 12.324V22.5304L9.75172 28.7024L10.6053 26.3456L5.79162 21.5932Z\" fill=\"#FF6900\"/> <path d=\"M26.1706 21.5932V13.2612L22.0112 9.15466L22.7474 6.68181L28.4622 12.324V22.5304L22.2105 28.7024L21.3569 26.3456L26.1706 21.5932Z\" fill=\"#FF6900\"/> <path d=\"M26.9081 28.9674L26.6002 29.764L26.2924 28.9674H26.1034V29.9641H26.281V29.3663L26.5126 29.9641H26.688L26.9195 29.3663V29.9641H27.0971V28.9674H26.9081ZM25.1899 29.1247H25.5007V29.9641H25.676V29.1247H25.9868V28.9674H25.1899V29.1247Z\" fill=\"white\"/> </g> <defs> <clipPath id=\"clip0_6027_4392\"> <rect width=\"25\" height=\"28\" fill=\"white\" transform=\"translate(3.5 2)\"/> </clipPath> </defs> </svg>",
};
// ---- 赛季 · 联赛（2026-11-15 用户：“基本赛季模拟，同时模拟4大联赛，我选了英超，还可以看到西甲”）
// 英超（本联赛）与西甲 / 意甲 / 法甲并排看：积分榜、每轮赛果、射手/助攻榜、历届冠军。其他联赛由宿主按生涯日期模拟（iml_leagues），这里只读。
let lgpSel = 0, lgpRound = null, lgpBoard = "goal";
document.addEventListener("click", (event) => {
  const t = event.target.closest("[data-lgp]");
  if (!t || cur.sec !== "season" || SECTIONS.season.tabs[cur.tab][1] !== viewLeagues) return;
  const k = t.dataset.lgp, v = t.dataset.v;
  if (k === "league") { lgpSel = Number(v); lgpRound = null; }
  else if (k === "round") lgpRound = Number(v);
  else if (k === "board") lgpBoard = v;
  sound("cursor"); draw();
});
const lgpDate = (iso) => { const m = /^\d{4}-(\d\d)-(\d\d)/.exec(iso || ""); return m ? `${+m[1]} 月 ${+m[2]} 日` : ""; };
// ---- RC29.5: league newsroom (FM-style) built from the league page data
const LGN_H = {
  leader: ["{t} out in front after round {r}", "Pace-setters {t} stay top", "Top of the pile: {t}", "{t} hold the summit — {g} clear"],
  streak: ["{t} can't stop winning: {n} in a row", "Red-hot {t} make it {n} straight", "Unstoppable? {t} stretch winning run to {n}"],
  slump: ["Crisis talk at {t}: {n} defeats on the bounce", "Alarm bells ring at {t}", "{t} in freefall — what next?"],
  thrash: ["{w} run riot against {l}", "Statement made: {w} {s} {l}", "{w} put on a show, {l} left shell-shocked"],
  upset: ["Giant-killing! {w} stun {l}", "Nobody saw that coming: {w} beat {l}", "{w} rip up the script against {l}"],
  topclash: ["Heavyweights collide: {h} {s} {a}", "Summit meeting ends {h} {s} {a}", "Title six-pointer: {h} {s} {a}"],
  boot: ["{p} leads the Golden Boot race on {n}", "Catch him if you can: {p} on {n}", "{p} sets the scoring pace"],
  assist: ["Creator-in-chief: {p} tops the assist charts", "{p} the league's master provider", "Playmaker {p} pulling the strings"],
  deal: ["DONE DEAL: {p} on the move", "Here we go! {p} completes switch", "Transfer bombshell: {p} seals move"],
  bottom: ["Pressure mounts on {t} boss", "Rock bottom: {t} searching for answers", "{t} manager fighting for his job"],
};
const LGN_Q = {
  streak: ["We take it one game at a time. Nobody here is getting carried away.", "The confidence is flowing. You can feel it in training."],
  slump: ["It's on me. I need to find a solution, and quickly.", "The players are hurting. We will come out of this together."],
  bottom: ["I have the backing of the board. Ask me again in a month.", "We are not where we want to be, but I believe in this group."],
};
function lgNews(d) {
  const out = [], hash = (x) => { let h = 7; for (const c of String(x)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h; };
  const pick = (arr, k) => arr[hash(k + d.id + d.season) % arr.length];
  const fill = (t, o) => t.replace(/\{(\w+)\}/g, (_, k) => o[k] ?? "");
  const tb = d.table || [], pos = Object.fromEntries(tb.map((x) => [x.team, x.position])), rd = (d.rounds || [])[0];
  if (rd && rd.fixtures.some((f) => f.hg != null)) {
    const fx = rd.fixtures.filter((f) => f.hg != null), when = `Round ${rd.round}`;
    const top = fx.filter((f) => pos[f.home] <= 4 && pos[f.away] <= 4)[0];
    if (top) out.push({ tag: "Big match", tone: "blue", team: top.home, when, h: fill(pick(LGN_H.topclash, "tc" + rd.round), { h: tname(top.home), a: tname(top.away), s: `${top.hg}-${top.ag}` }), b: "A clash with title implications — and plenty of talking points." });
    const big = fx.slice().sort((a, b) => Math.abs(b.hg - b.ag) - Math.abs(a.hg - a.ag))[0];
    if (big && Math.abs(big.hg - big.ag) >= 3) { const w = big.hg > big.ag ? big.home : big.away, l = w === big.home ? big.away : big.home; out.push({ tag: "Match report", tone: "green", team: w, when, h: fill(pick(LGN_H.thrash, "th" + rd.round), { w: tname(w), l: tname(l), s: `${Math.max(big.hg, big.ag)}-${Math.min(big.hg, big.ag)}` }), b: `${tname(w)} were ruthless from start to finish.` }); }
    const ups = fx.find((f) => f.hg !== f.ag && Math.abs((pos[f.home] || 10) - (pos[f.away] || 10)) >= 9 && ((f.hg > f.ag) === (pos[f.home] > pos[f.away])));
    if (ups) { const w = ups.hg > ups.ag ? ups.home : ups.away, l = w === ups.home ? ups.away : ups.home; out.push({ tag: "Upset", tone: "red", team: w, when, h: fill(pick(LGN_H.upset, "up" + rd.round), { w: tname(w), l: tname(l) }), b: `${tname(l)} were left stunned by a side ${pos[w] - pos[l]} places below them.` }); }
  }
  if (tb.length && tb[0].played) {
    const gap = tb[0].points - (tb[1] ? tb[1].points : 0);
    out.push({ tag: "Title race", tone: "gold", team: tb[0].team, when: "Table", h: fill(pick(LGN_H.leader, "ld" + tb[0].played), { t: tname(tb[0].team), r: tb[0].played, g: `${gap} point${gap === 1 ? "" : "s"}` }), b: gap ? `${tname(tb[0].team)} lead ${tname(tb[1].team)} by ${gap}.` : `Level on points with ${tname(tb[1].team)} — only goal difference separates them.` });
    for (const x of tb) {
      const f = x.form || [], last = f.slice(-6);
      let n = 0; for (let i = last.length - 1; i >= 0 && last[i] === "W"; i--) n++;
      let m = 0; for (let i = last.length - 1; i >= 0 && last[i] === "L"; i--) m++;
      if (n >= 4) out.push({ tag: "Hot streak", tone: "green", team: x.team, when: "Form", h: fill(pick(LGN_H.streak, "st" + x.team + n), { t: tname(x.team), n }), q: pick(LGN_Q.streak, "q" + x.team), by: `${tname(x.team)} head coach` });
      if (m >= 3) out.push({ tag: "Crisis", tone: "red", team: x.team, when: "Form", h: fill(pick(LGN_H.slump, "sl" + x.team + m), { t: tname(x.team), n: m }), q: pick(LGN_Q.slump, "q" + x.team), by: `${tname(x.team)} head coach` });
    }
    const bot = tb[tb.length - 1];
    if (bot && bot.played >= 6) out.push({ tag: "Under pressure", tone: "red", team: bot.team, when: "Table", h: fill(pick(LGN_H.bottom, "bt" + bot.played), { t: tname(bot.team) }), q: pick(LGN_Q.bottom, "qb" + bot.team), by: `${tname(bot.team)} head coach` });
  }
  const sc = (d.scorers || [])[0], as = (d.assisters || [])[0];
  if (sc) out.push({ tag: "Golden Boot", tone: "gold", team: sc.team, pid: sc.pid, when: "Stats", h: fill(pick(LGN_H.boot, "bo" + sc.n), { p: sc.name, n: `${sc.n} goal${sc.n === 1 ? "" : "s"}` }), b: (d.scorers || []).slice(1, 3).map((r) => `${r.name} (${r.n})`).join(" and ") + ((d.scorers || []).length > 1 ? " are in hot pursuit." : "") });
  if (as) out.push({ tag: "Playmaker", tone: "blue", team: as.team, pid: as.pid, when: "Stats", h: fill(pick(LGN_H.assist, "as" + as.n), { p: as.name }), b: `${as.n} assist${as.n === 1 ? "" : "s"} so far this season.` });
  for (const mv of (d.moves || []).filter((m) => m.kind === "transfer").slice(0, 2)) {
    const who = (mv.text.match(/^(.+?) 以/) || [])[1] || mv.text.split(" ")[0];
    out.push({ tag: "Done deal", tone: "gold", team: null, when: /^\d{4}-/.test(mv.when) ? lgpDate(mv.when) : mv.when, h: fill(pick(LGN_H.deal, "dl" + who), { p: who }), b: mv.text });
  }
  return out.slice(0, 8);
}
function lgNewsStrip(d) {
  const n = lgNews(d);
  if (!n.length) return "";
  const vis = (x) => x.pid ? pface(x, "bdo-pf") : x.team != null ? crest(x.team, "sm") : `<i class="cn-dot"></i>`;
  return `<div class="card lgp-news"><div class="ch">${esc(d.name)} newsroom<span class="r">${n.length} stories</span></div><div class="cb"><div class="cn-strip lg">${n.map((x, i) => `<article class="cn-tile tone-${x.tone}${i === 0 ? " cn-first" : ""}"><span class="cn-rv">${vis(x)}</span><span class="cn-rt"><small><b class="cn-tag">${esc(x.tag)}</b>${esc(x.when)}</small><b>${esc(x.h)}</b>${x.q || x.b ? `<em>${esc(x.q ? `“${x.q}” — ${x.by}` : x.b)}</em>` : ""}</span></article>`).join("")}</div></div></div>`;
}
let lgpBig = null;
document.addEventListener("click", (ev) => {
  const b = ev.target.closest("[data-lgbig]"); if (!b || !lgpBig) return;
  ev.stopPropagation(); ev.preventDefault();
  const k = b.dataset.lgbig, L = lgpBig;
  const full = (rows, unit) => rows.length ? `<table class="lgp-stats big"><thead><tr><th>#</th><th>Player</th><th>Club</th><th class="n">${unit}</th></tr></thead><tbody>${rows.map((r) => `<tr><td class="rk">${r.rank}</td><td class="name"><b translate="no">${esc(r.name)}</b></td><td><span class="tn">${crest(r.team, "sm")}<small>${esc(tname(r.team))}</small></span></td><td class="n"><b>${r.n}</b></td></tr>`).join("")}</tbody></table>` : `<div class="empty-note">Nothing yet</div>`;
  const regular = (L.season || []).filter((r) => r.apps >= Math.max(1, Math.round(Math.max(...(L.season || [{ apps: 1 }]).map((x) => x.apps)) / 3)));
  const body = k === "stats" ? (L.season ? `<div class="lgp-sub">Goals + assists</div>${L.seasonTbl(L.season.slice(0, 40), true)}<div class="lgp-sub">Best average rating <small>(regular starters)</small></div>${L.seasonTbl(regular.slice().sort((x, y) => y.avg - x.avg).slice(0, 25), true)}` : L.statTbl(L.stats, true)) : k === "assist" ? full(L.assisters, "Assists") : full(L.scorers, "Goals");
  const el = document.createElement("div"); el.className = "lgp-modal";
  el.innerHTML = `<div class="lgp-mbox"><div class="lgp-mh"><b>${esc(L.name)} · ${k === "stats" ? "Player stats" : k === "assist" ? "Top assists" : "Top scorers"}</b><button class="lgp-x" aria-label="Close">✕</button></div><div class="lgp-mb">${body}</div></div>`;
  el.addEventListener("click", (e) => { if (e.target === el || e.target.closest(".lgp-x")) el.remove(); });
  document.body.appendChild(el); sound("page");
}, true);
async function viewLeagues(name) {
  const key = lgpSel ? `league_${lgpSel}` : "leagues";
  delete BIZ[key]; // 每次进入重读：继续推进后，其他联赛的赛果才会更新
  const d = await biz(key);
  if (!d) return viewPlan("season", name);
  if (d.error) return `<div class="view"><div class="card"><div class="empty-note">读取失败<br><small>${esc(d.error)}</small></div></div></div>`;
  lgpSel = d.id;
  for (const [k, v] of Object.entries(d.teams || {})) if (!S.teams[k]) S.teams[k] = v; // 其他联赛的球队名与颜色（不覆盖本联赛已有的）
  const li = d.league;
  // E323：顶级联赛与次级联赛分两组（level 1 / 2；德甲没有次级联赛，算顶级），组前一个小标签
  const tabBtn = (t) => `<button class="lgp-tab${t.id === d.id ? " on" : ""}" data-lgp="league" data-v="${t.id}" aria-pressed="${t.id === d.id}">${t.logo ? `<img class="lgp-logo" src="/img/comp/L${t.id}.png" alt="">` : ""}<span><b>${esc(t.name)}${t.own ? "<em>我的联赛</em>" : ""}</b><small>${t.complete ? `已结束 · ${esc(tname(t.champion))} 夺冠` : t.round ? `第 ${t.round} / ${t.total} 轮 · ${esc(tname(t.leader))} 领跑` : "未开赛"}</small></span></button>`;
  const lv2 = d.tabs.filter((t) => t.level === 2), lv1 = d.tabs.filter((t) => t.level !== 2);
  const tabs = false ? `<span class="lgp-grp">顶级</span>${lv1.map(tabBtn).join("")}<span class="lgp-grp">次级</span>${lv2.map(tabBtn).join("")}` : d.tabs.map(tabBtn).join("");
  // 积分榜
  // 2026-11-15 用户“别的联赛的球队资料点不开”：其他联赛的积分榜行也能点开球队资料（/api/team 对其他联赛的球队读它那个联赛的世界）
  const rows = d.table.map((x) => `<tr class="go-row ${d.own && x.team === d.user_team ? "me" : ""}${x.zone ? ` z-${x.zone}` : ""}" data-team="${x.team}"><td class="muted">${x.position}</td><td class="name"><span class="tn">${crest(x.team, "sm")}<span style="font-weight:${d.own && x.team === d.user_team ? 800 : 500}">${esc(tname(x.team))}</span></span></td><td class="n">${x.played}</td><td class="n">${x.won}</td><td class="n">${x.drawn}</td><td class="n">${x.lost}</td><td class="n">${x.gd > 0 ? "+" : ""}${x.gd}</td><td class="n"><span class="num">${x.points}</span></td></tr>`).join("");
  const table = `<div class="card" style="--i:0"><div class="ch">${esc(d.name)} 积分榜<span class="r">第 ${esc(d.season)} 赛季</span></div><div class="cb scroll" style="padding-top:0"><table><thead><tr><th>#</th><th>球队</th><th class="n">赛</th><th class="n">胜</th><th class="n">平</th><th class="n">负</th><th class="n">净</th><th class="n">分</th></tr></thead><tbody>${rows}</tbody></table>${zoneKey(d.zones)}${d.note ? `<div class="foot-note">${esc(d.note)}</div>` : ""}</div></div>`;
  // 每轮赛果（可翻页；最后一页是下一轮的对阵）
  const byRound = new Map(d.rounds.map((r) => [r.round, r]));
  if (d.next) byRound.set(d.next.round, d.next);
  const last = d.next ? d.next.round : d.rounds.length ? d.rounds[0].round : 0;
  if (lgpRound == null || !byRound.has(lgpRound)) lgpRound = d.rounds.length ? d.rounds[0].round : last;
  const rd = byRound.get(lgpRound);
  const fx = rd ? rd.fixtures.map((f) => `<div class="mrow${f.mine ? " mine" : ""}"${d.own && f.hg != null ? ` data-fx="${f.id}" data-sound="page"` : ""}${!d.own && f.hg != null ? ` data-lgfx="${d.id}:${rd.round}:${f.home}:${f.away}"` : ""}${d.own || f.hg != null ? "" : ` style="cursor:default"`}><span>${esc(tname(f.home))}</span>${crest(f.home, "sm")}<span class="sc">${f.hg == null ? "vs" : `${f.hg} - ${f.ag}`}</span>${crest(f.away, "sm")}<span>${esc(tname(f.away))}</span></div>`).join("") : "";
  const results = `<div class="card" style="--i:1"><div class="ch lgp-nav"><button class="cal-nav" data-lgp="round" data-v="${lgpRound - 1}" ${lgpRound > 1 ? "" : "disabled"} aria-label="上一轮">‹</button><b>${rd ? `第 ${rd.round} 轮` : "赛果"}</b><button class="cal-nav" data-lgp="round" data-v="${lgpRound + 1}" ${lgpRound < last ? "" : "disabled"} aria-label="下一轮">›</button><span class="r">${rd ? esc(lgpDate(rd.date)) : ""}${rd && !rd.fixtures.some((f) => f.hg != null) ? " · 尚未开赛" : ""}</span></div><div class="cb scroll">${fx || `<div class="empty-note">还没有赛果<br><small>点击继续推进生涯后，随日期开赛</small></div>`}</div></div>`;
  // 射手 / 助攻 / 历届冠军
  // 2026-11-15 用户：“联赛射手榜头像点不进去、希望有头像并能点进去”——整行可点（我队球员→详情，其他队→球探报告），hint 带上榜里的数
  const lead = (list, unit) => list.length ? `<table class="lgp-lead"><tbody>${list.map((r) => `<tr class="${r.pid ? "go-row " : ""}${r.mine ? "me" : ""}"${pgo(r, r.team, unit === "球" ? "g" : "a", r.n)}><td class="rk">${r.rank}</td><td class="name rc-nm"><span class="tn" title="${esc(r.name)}">${crest(r.team, "sm")}<span class="rc-pl"><b translate="no">${esc(shortName(r.name))}</b><small>${esc(tname(r.team))}</small></span></span></td><td class="n"><span class="num">${r.n}</span><small>${unit}</small></td></tr>`).join("")}</tbody></table>` : `<div class="empty-note">还没有${unit === "球" ? "进球" : "助攻"}记录</div>`;
  const hist = d.history.length ? d.history.map((h) => `<div class="lgp-h"><i>第 ${h.season} 赛季</i>${crest(h.champion, "sm")}<span><b>${esc(tname(h.champion))}</b><small>${h.points != null ? `${h.points} 分` : ""}${h.runner_up != null ? ` · 亚军 ${esc(tname(h.runner_up))}` : ""}${h.scorer ? ` · 射手王 ${esc(h.scorer.name)} ${h.scorer.n} 球` : ""}</small></span></div>`).join("") : `<div class="empty-note">还没有完整的赛季<br><small>赛季结束后这里记录每届冠军与射手王</small></div>`;
  const mv = (d.moves || []).length ? d.moves.map((m) => `<div class="lgp-m k-${m.kind}"><small>${/^\d{4}-/.test(m.when) ? esc(lgpDate(m.when)) : esc(m.when)}</small><span>${esc(m.text)}</span></div>`).join("") : `<div class="empty-note">还没有转会动态<br><small>转会窗（7～8 月、1 月）里各队会互相买人，赛季末有退役与青训</small></div>`;
  const statRows = (() => { const m = new Map(); for (const r of d.scorers || []) m.set(r.name + "|" + r.team, { name: r.name, team: r.team, pid: r.pid, g: r.n, a: 0 }); for (const r of d.assisters || []) { const k = r.name + "|" + r.team, x = m.get(k) || { name: r.name, team: r.team, pid: r.pid, g: 0, a: 0 }; x.a = r.n; m.set(k, x); } return [...m.values()].sort((x, y) => (y.g + y.a) - (x.g + x.a) || y.g - x.g); })();
  const statTbl = (rows, big) => rows.length ? `<table class="lgp-stats${big ? " big" : ""}"><thead><tr><th>#</th><th>Player</th><th class="n">G</th><th class="n">A</th><th class="n">G+A</th>${big ? `<th class="n">Goal share</th>` : ""}</tr></thead><tbody>${rows.map((r, i) => `<tr class="${r.pid ? "go-row" : ""}"${pgo(r, r.team, "g", r.g)}><td class="rk">${i + 1}</td><td class="name"><span class="tn">${crest(r.team, "sm")}<b translate="no">${esc(big ? r.name : shortName(r.name))}</b></span></td><td class="n">${r.g}</td><td class="n">${r.a}</td><td class="n"><b>${r.g + r.a}</b></td>${big ? `<td class="n muted">${(() => { const t = (d.table || []).find((x) => x.team === r.team); return t && t.gf ? Math.round(r.g / t.gf * 100) + "%" : "—"; })()}</td>` : ""}</tr>`).join("")}</tbody></table>` : `<div class="empty-note">No goals yet</div>`;
  lgpBig = { stats: statRows, scorers: d.scorers || [], assisters: d.assisters || [], name: d.name, statTbl, lead };
  let season = null;
  if (lgpBoard === "stats" && !d.own) { try { season = await api(`/api/rc29/lgstats/${d.id}`); } catch (e) { season = null; } }
  const rpill = (v) => `<b class="mr-pill ${v >= 7.3 ? "hi" : v >= 6.7 ? "mid" : "lo"}">${v.toFixed(2)}</b>`;
  const seasonTbl = (rows, big) => rows.length ? `<table class="lgp-stats${big ? " big" : ""}"><thead><tr><th>#</th><th>Player</th><th class="n">Apps</th><th class="n">G</th><th class="n">A</th>${big ? `<th class="n">MOTM</th>` : ""}<th class="n">Avg</th></tr></thead><tbody>${rows.map((r, i) => `<tr class="${r.pid ? "go-row" : ""}"${pgo(r, r.team, "g", r.g)}><td class="rk">${i + 1}</td><td class="name"><span class="tn">${pface(r, "lgp-pf")}${crest(r.team, "sm")}<b translate="no">${esc(big ? r.name : shortName(r.name))}</b></span></td><td class="n">${r.apps}</td><td class="n">${r.g}</td><td class="n">${r.a}</td>${big ? `<td class="n">${r.motm}</td>` : ""}<td class="n">${rpill(r.avg)}</td></tr>`).join("")}</tbody></table>` : `<div class="empty-note">No matches played yet</div>`;
  if (season && season.players) { lgpBig.season = season.players; lgpBig.seasonTbl = seasonTbl; }
  const board = lgpBoard === "assist" ? lead(d.assisters, "次") : lgpBoard === "stats" ? (season && season.players ? seasonTbl(season.players.slice(0, 20), false) : statTbl(statRows.slice(0, 15), false)) : lgpBoard === "hist" ? hist : lgpBoard === "moves" ? mv : lead(d.scorers, "球");
  const side = `<div class="card" style="--i:2"><div class="ch lgp-seg">${[["goal", "射手"], ["assist", "助攻"], ["stats", "Stats"], ["hist", "冠军"], ["moves", "转会"]].map(([k, t]) => `<button class="${lgpBoard === k ? "on" : ""}" data-lgp="board" data-v="${k}">${t}</button>`).join("")}${["goal", "assist", "stats"].includes(lgpBoard) ? `<button class="lgp-big" data-lgbig="${lgpBoard}" title="Full table">⤢</button>` : ""}</div><div class="cb scroll">${board}</div></div>`;
  return `<div class="view v-lgp"><div class="lgp-tabs" role="tablist">${tabs}</div>${table}${results}${side}</div>`;
}
// ---- 赛季 · 欧战（E336，2026-11-17 用户：“先做欧战引擎”；同日“做成专门的欧冠主题……就弄个抽奖动画和联赛阶段UI和淘汰赛阶段UI”）
// 页签留在“赛季 · 欧战”，整块换成星空主题（欧冠深蓝 / 欧联橙黑）。左侧竖向主题侧栏（2026-11-17 用户“把上方的顶栏放到侧栏”，手机横屏高度更紧）：
// 欧冠/欧联两个奖杯按钮（即赛事切换）、联赛阶段 / 淘汰赛 / 附加赛、底部重看抽签。对阵树各场之间画连线（euLines，按实际位置量）。
// 联赛阶段：36 队积分榜（1-8 直通 16 强、9-24 附加赛、25-36 出局）＋ 8 个比赛日的赛果。淘汰赛：左右对称的对阵树（16 强→决赛，中间奖杯），
// 附加赛单独一屏；点格子看两回合、加时、点球。抽签动画：我队所在赛事每个抽签节点（联赛阶段 8 个对手、附加赛、16 强）第一次打开时自动播放一次，可重看；
// 抽签结果早已由宿主算好，动画只负责“演”出来。数据来自宿主 GET /api/europe（iml_europe）。下一场欧战比赛的模拟仍走顶栏按钮。
// 素材（用户 AI 生成，放 app/img/eu/）：<赛事>-bg.jpg 背景、<赛事>-emblem.png 徽章、<赛事>-trophy.png 奖杯；缺图时用 CSS 星空与符号兜底（onerror 移除）。
let euSel = null, euMD = null, euMode = null, euLast = null, euScrollKey = "";     // euMode: league | ko（对阵树）| po（附加赛）
const euTimers = [];
document.addEventListener("click", (event) => {
  const t = event.target.closest("[data-eu]");
  if (!t || cur.sec !== "season" || SECTIONS.season.tabs[cur.tab][1] !== viewEurope) return;
  const k = t.dataset.eu, v = t.dataset.v;
  if (k === "comp") { euSel = v; euMD = null; euMode = null; }
  else if (k === "md") euMD = Number(v);
  else if (k === "mode") euMode = v;
  else if (k === "tie") { sound("page"); return euTiePop(v); }
  else if (k === "draw") { sound("page"); return euDraw(); }
  else if (k === "sim") { sound("page"); return openEuroSim(); }
  sound("cursor"); draw();
});
const EU_THEME = { ucl: { cls: "eu-ucl", title: "欧洲冠军杯", en: "CHAMPIONS CUP", glyph: "★" }, uel: { cls: "eu-uel", title: "欧洲联盟杯", en: "EUROPA CUP", glyph: "◆" } };
// 奖杯图：沿用荣誉页已随包的 app/img/trophy（E307 奖杯展览厅素材，用户 2026-11-17“我们不是有欧冠和欧联的奖杯素材了吗”）；头部两个按钮与对阵树中间都用它
const EU_TROPHY = { ucl: "/img/trophy/uefa_champions_league.png", uel: "/img/trophy/uefa_europa_league.png" };
const EU_ZONE ={ r16: "直通 16 强", po: "淘汰附加赛", out: "出局" };
const EU_STAGE = { league: "League phase", po: "Knockout play-off", r16: "Round of 16", qf: "Quarter-final", sf: "Semi-final", final: "Final" };
const EU_REACH = { champion: "冠军", final: "决赛", sf: "半决赛", qf: "8 强", r16: "16 强", po: "附加赛", league: "联赛阶段" };
const EU_R16 = [1, 8, 4, 5, 2, 7, 3, 6];        // 与 iml_europe.R16_ORDER 一致：第 n 场 16 强的种子；第 n 场 8 强＝16 强第 2n-1 与 2n 场胜者
// 已放进 app/img/eu/ 的素材（预览服务器与宿主对缺失图片会回占位图而不是 404，onerror 靠不住，所以只引用登记过的文件）。到图后在这里加名字，如 "ucl-bg"
const EU_ART = new Set(["ucl-bg", "uel-bg"]);     // 2026-11-17 用户 AI 生成：ucl-bg 深蓝夜空＋顶部灯光、uel-bg 橙黑火星＋顶部暖光，均居中裁成 1732×800
const euImg = (c, kind, ext = "png") => (EU_ART.has(`${c}-${kind}`) ? `<img class="eu-${kind}-img" src="/img/eu/${c}-${kind}.${ext}" alt="" onerror="this.remove()">` : "");
function euScore(m) { return m.hg == null ? "vs" : `${m.hg} - ${m.ag}`; }
function euRow(m) {
  const tag = m.mine && m.src === "sim" ? "模拟" : m.mine && m.src === "auto" ? "自动模拟" : "";
  return `<div class="mrow${m.mine ? " mine" : ""}" style="cursor:default"${tag ? ` title="${tag}"` : ""}><span>${esc(tname(m.home))}</span>${crest(m.home, "sm")}<span class="sc">${euScore(m)}</span>${crest(m.away, "sm")}<span>${esc(tname(m.away))}</span></div>`
    + (m.mine && m.scorers && m.scorers.length ? `<div class="eu-goals">${m.scorers.map((g) => `⚽ ${esc(g.name || "")}${g.assist ? `<small>（${esc(g.assist)}）</small>` : ""}`).join("　")}</div>` : "");
}
// 一组对决的完整详情（弹窗用）
function euTie(t) {
  const legs = t.legs.map((l, i) => `<div class="eu-leg"><small>${t.legs.length > 1 ? (i ? " · 2nd leg" : " · 1st leg") : "决赛"} · ${esc(lgpDate(l.date))}${l.neutral ? " · 中立场" : ""}</small>${euRow(l)}</div>`).join("");
  // et / pens 与 agg 同为 [a 方, b 方]；单场决赛也要写出加时比分
  const extra = [t.et ? `加时 ${esc(tname(t.a))} ${t.et[0]}-${t.et[1]} ${esc(tname(t.b))}` : "", t.pens ? `点球 ${t.pens[0]}-${t.pens[1]}` : ""].filter(Boolean).join(" · ");
  const agg = t.agg && t.legs.length > 1 ? `<div class="eu-agg">总比分 ${esc(tname(t.a))} <b>${t.agg[0]} - ${t.agg[1]}</b> ${esc(tname(t.b))}${extra ? ` · ${extra}` : ""}</div>` : extra ? `<div class="eu-agg">${extra}</div>` : "";
  const win = t.winner ? `<div class="eu-win">${crest(t.winner, "sm")}<b>${esc(tname(t.winner))}</b> ${String(t.id).includes("-final-") ? "夺冠" : "晋级"}</div>` : "";
  return `<div class="eu-tie${t.mine ? " mine" : ""}">${legs}${agg}${win}</div>`;
}
const euRound = (c, st) => (c.ko.find((r) => r.stage === st) || {}).ties || [];
function euFindTie(c, id) { for (const r of c.ko) for (const t of r.ties) if (t.id === id) return [r, t]; return []; }

async function viewEurope(name) {
  let d = null;
  try { d = await api("/api/europe"); } catch (e) { d = null; }
  if (!d) return viewPlan("season", name);
  if (d.error) return `<div class="view"><div class="card"><div class="empty-note">欧战读取失败<br><small>${esc(d.error)}</small></div></div></div>`;
  for (const [k, v] of Object.entries(d.teams || {})) if (!S.teams[k]) S.teams[k] = v;
  euLast = d;
  if (!euSel || !d.comps.some((c) => c.id === euSel)) euSel = d.own || "ucl";
  const c = d.comps.find((x) => x.id === euSel), th = EU_THEME[c.id];
  const hasPO = euRound(c, "po").length > 0;
  if (!euMode || (euMode === "po" && !hasPO)) euMode = c.stage === "league" ? "league" : c.stage === "po" ? "po" : "ko";
  const plan = euDrawPlan(d, c);       // 当前查看赛事最近一次抽签（整届：36 队 / 全部对阵）；欧冠欧联都能重看，自动播放只限我队所在赛事
  const body = euMode === "league" ? euLeague(d, c) : euMode === "stats" ? euStats(d, c) : euKO(d, c);
  // 侧栏：奖杯按钮（2026-11-17 用户：“左上角放两个按钮，一个欧冠奖杯一个欧联奖杯”，同日又改到侧栏）＋ 页面切换 ＋ 重看抽签
  const cups = d.comps.map((x) => `<button class="eu-cupbtn eu-${x.id}${x.id === c.id ? " on" : ""}" data-eu="comp" data-v="${x.id}" aria-pressed="${x.id === c.id}" aria-label="${esc(x.name)}" title="${esc(x.name)}">`
    + `${EU_LOGO[x.id]}${d.own === x.id ? "<i></i>" : ""}</button>`).join("");     // 2026-11-17 用户：侧栏改用 UEFA 赛事标志（67-eu-logos.js）；同日又要求侧栏去掉全部文字，名字只留在 aria-label / title
  const items = [["league", "联赛阶段", EU_ICON.league], ["ko", "淘汰赛", EU_ICON.ko], ...(hasPO ? [["po", "附加赛", EU_ICON.po]] : []), ["stats", "Top scorers", EU_ICON.stats]];
  const rail = `<nav class="eu-rail"><div class="eu-cups">${cups}</div><i class="eu-rl"></i>`
    + items.map(([k, t, ic]) => `<button class="eu-ri${euMode === k ? " on" : ""}" data-eu="mode" data-v="${k}" aria-pressed="${euMode === k}" aria-label="${t}" title="${t}">${ic}</button>`).join("")
    + (plan ? `<button class="eu-ri eu-rdraw" data-eu="draw" aria-label="重看抽签" title="重看抽签">${EU_ICON.draw}</button>` : "") + `</nav>`;
  if (euMode === "ko") euTimers.push(setTimeout(euLines, 0));
  // 进联赛阶段页（或换赛事）时把积分榜滚到我队那一行；之后点比赛日不再跳
  const sk = `${c.id}:${euMode}`;
  if (euMode === "league" && euScrollKey !== sk) euTimers.push(setTimeout(() => {
    const box = $(".v-eu .eu-tbl .eu-scroll"), row = box && box.querySelector("tr.me");
    if (row) box.scrollTop = Math.max(0, row.offsetTop - box.clientHeight / 2);
  }, 0));
  euScrollKey = sk;
  // 我队所在赛事：这个抽签节点第一次看到时自动播放
  if (plan && d.own === c.id && !euSeen(plan.key)) euTimers.push(setTimeout(() => { if (!$("#eu-draw") && cur.sec === "season" && SECTIONS.season.tabs[cur.tab][1] === viewEurope) euDraw(); }, 350));
  return `<div class="view v-eu ${th.cls}">${euImg(c.id, "bg", "jpg")}<div class="eu-stars"></div>${rail}<div class="eu-body">${body}</div></div>`;
}

// ---- RC29.3: cup scorers / assists (every match of the cup: ours from the real sheet, the rest generated from the result)
function euStats(d, c) {
  const list = (rows, unit) => (rows && rows.length ? rows.map((x) => `<tr class="${x.team === d.team ? "me" : ""}"><td class="muted">${x.rank}</td><td class="name"><span class="tn">${x.team != null ? crest(x.team, "sm") : ""}<span>${esc(x.name)}</span></span></td><td class="muted eu-club">${x.team != null ? esc(tname(x.team)) : ""}</td><td class="n"><b>${x.n}</b></td></tr>`).join("") : `<tr><td colspan="4" class="muted">No ${unit} yet</td></tr>`);
  const tbl = (title, rows, unit) => `<div class="eu-glass eu-tbl"><div class="eu-gh">${title}<span class="r">${esc(c.name || "")}</span></div><div class="eu-scroll"><table><thead><tr><th>#</th><th>Player</th><th>Club</th><th class="n">${unit === "goals" ? "G" : "A"}</th></tr></thead><tbody>${list(rows, unit)}</tbody></table></div></div>`;
  return tbl("Top scorers", c.scorers, "goals") + tbl("Top assists", c.assists, "assists");
}

// ---- 联赛阶段：积分榜 + 比赛日
function euLeague(d, c) {
  const rows = c.table.map((x) => `<tr class="go-row eu-z-${x.zone}${x.team === d.team ? " me" : ""}" data-team="${x.team}"><td class="muted">${x.position}</td><td class="name"><span class="tn">${crest(x.team, "sm")}<span>${esc(tname(x.team))}</span></span></td><td class="n">${x.played}</td><td class="n hx">${x.won}</td><td class="n hx">${x.drawn}</td><td class="n hx">${x.lost}</td><td class="n">${x.gd > 0 ? "+" : ""}${x.gd}</td><td class="n"><b>${x.points}</b></td></tr>`).join("");
  const key = `<div class="eu-key">${Object.entries(EU_ZONE).map(([k, v]) => `<span class="eu-z-${k}"><i></i>${v}</span>`).join("")}${d.basis === "strength" ? `<span class="r">首个赛季按实力定资格</span>` : ""}</div>`;
  const mds = c.matchdays, firstOpen = mds.find((m) => m.matches.some((x) => x.hg == null));
  if (euMD == null || !mds[euMD - 1]) euMD = firstOpen ? Math.max(1, firstOpen.md - (firstOpen.matches.some((x) => x.hg != null) ? 0 : 1)) : mds.length;
  const md = mds[euMD - 1], list = [...md.matches.filter((m) => m.mine), ...md.matches.filter((m) => !m.mine)];
  const dots = mds.map((m) => `<button class="${m.md === euMD ? "on" : ""}${m.matches.some((x) => x.mine) ? " me" : ""}${m.matches.every((x) => x.hg != null) ? " done" : ""}" data-eu="md" data-v="${m.md}">${m.md}</button>`).join("");
  return `<div class="eu-glass eu-tbl"><div class="eu-gh">联赛阶段积分榜<span class="r">${esc(c.stage === "league" ? `${firstOpen ? `第 ${firstOpen.md} 比赛日前` : ""}` : "已结束")}</span></div>`
    + `<div class="eu-scroll"><table><thead><tr><th>#</th><th>球队</th><th class="n">赛</th><th class="n hx">胜</th><th class="n hx">平</th><th class="n hx">负</th><th class="n">净</th><th class="n">分</th></tr></thead><tbody>${rows}</tbody></table></div>${key}</div>`
    + `<div class="eu-glass eu-mds"><div class="eu-gh">第 ${euMD} 比赛日<span class="r">${esc(lgpDate(md.date))}</span></div><div class="eu-dots">${dots}</div><div class="eu-scroll">${list.map(euRow).join("")}</div></div>`;
}

// ---- 淘汰赛：对阵树 / 附加赛
const euWinOf = (s) => (s.tie && s.tie.winner) || "待定";
function euSlot(x) { return typeof x === "number" ? `${crest(x, "sm")}<span class="nm">${esc(tname(x))}</span>` : `<i class="eu-q">?</i><span class="nm tbd">${esc(x || "待定")}</span>`; }
// crestOnly：对阵树里只放队徽（放大）＋比分，不写队名（2026-11-17 用户“淘汰赛可以不显示球队名字 就放队徽 可以放大点”）；附加赛一屏仍写名字
function euBox(s, crestOnly = false) {
  const t = s.tie, own = euLast.team;
  const sc = (i) => (t && t.agg ? t.agg[i] : "");
  const res = (x) => (t && t.winner ? (t.winner === x ? " w" : " l") : "");
  const how = t && t.winner ? (t.pens ? "点" : t.et ? "加" : "") : "";
  const slot = (x) => (!crestOnly ? euSlot(x) : typeof x === "number" ? crest(x) : `<i class="eu-q">?</i><small class="tbd">${esc(x || "待定")}</small>`);
  const side = (x, i) => `<div class="${res(x).trim()}">${slot(x)}<b>${sc(i)}${how && t.winner === x ? `<em>${how}</em>` : ""}</b></div>`;
  const mine = (t && t.mine) || s.a === own || s.b === own;
  const label = [s.a, s.b].map((x) => (typeof x === "number" ? tname(x) : x || "待定")).join(" 对 ");
  return `<div class="eu-box${crestOnly ? " co" : ""}${mine ? " me" : ""}${t ? " tap" : ""}" aria-label="${esc(label)}"${s.k ? ` data-k="${s.k}"` : ""}${t ? ` data-eu="tie" data-v="${t.id}"` : ""}>${side(s.a, 0)}${side(s.b, 1)}</div>`;
}
function euKO(d, c) {
  const po = euRound(c, "po");
  if (euMode === "po" && po.length) {
    return `<div class="eu-glass eu-po"><div class="eu-gh">淘汰附加赛<span class="r">联赛阶段 9–24 名两回合，胜者进 16 强</span></div><div class="eu-pog">${po.map((t) => euBox({ tie: t, a: t.a, b: t.b })).join("")}</div></div>`;
  }
  const done = c.stage !== "league", seed = (p) => (done ? (c.table.find((r) => r.position === p) || {}).team : null) || `第 ${p} 名`;
  const r16t = euRound(c, "r16");
  const r16 = EU_R16.map((p, i) => (r16t[i] ? { tie: r16t[i], a: r16t[i].a, b: r16t[i].b } : { a: "附加赛胜者", b: seed(p) }));
  const up = (prev, ties, n) => Array.from({ length: n }, (_, i) => (ties[i] ? { tie: ties[i], a: ties[i].a, b: ties[i].b } : { a: euWinOf(prev[2 * i]), b: euWinOf(prev[2 * i + 1]) }));
  const qf = up(r16, euRound(c, "qf"), 4), sf = up(qf, euRound(c, "sf"), 2), fin = up(sf, euRound(c, "final"), 1);
  [["r16", r16], ["qf", qf], ["sf", sf], ["final", fin]].forEach(([st, arr]) => arr.forEach((s, i) => { s.k = `${st}-${i}`; }));     // 连线用的位置键
  const col = (arr, st) => `<div class="eu-col"><div class="eu-ct">${EU_STAGE[st]}</div><div class="eu-cb">${arr.map((s) => euBox(s, true)).join("")}</div></div>`;
  const fl = fin[0].tie && fin[0].tie.legs[0];
  const mid = `<div class="eu-col eu-mid"><div class="eu-ct">决赛${fl ? ` · ${esc(lgpDate(fl.date))}` : ""}</div><div class="eu-cb">`
    // 冠军：队徽放在奖杯上方、金色光晕，不写字（2026-11-17 用户“夺冠的时候把logo放在上边吧 不要字”）；名字留在 title / aria-label
    + (c.champion ? `<div class="eu-champ-crest" title="${esc(tname(c.champion))} 夺冠" aria-label="${esc(tname(c.champion))} 夺冠">${crest(c.champion)}</div>` : "")
    + `<div class="eu-cup"><img src="${EU_TROPHY[c.id]}" alt=""></div>${euBox(fin[0], true)}</div></div>`;
  const note = c.stage === "league" ? `<div class="eu-note">联赛阶段踢完后抽签：前 8 名等在 16 强，9–24 名先踢附加赛</div>` : "";
  return `<div class="eu-glass eu-br">${note}<div class="eu-tree">${col(r16.slice(0, 4), "r16")}${col(qf.slice(0, 2), "qf")}${col(sf.slice(0, 1), "sf")}${mid}${col(sf.slice(1), "sf")}${col(qf.slice(2), "qf")}${col(r16.slice(4), "r16")}</div></div>`;
}
// 对阵树连线：按各格子的实际位置画折线（16 强第 i 场 → 8 强第 i/2 场 → 半决赛 → 决赛），我队走过的路高亮；尺寸变了重画
function euLines() {
  const tree = $(".v-eu .eu-tree"); if (!tree) return;
  const R = tree.getBoundingClientRect(), get = (k) => tree.querySelector(`[data-k="${k}"]`);
  const paths = { base: [], me: [] };
  const link = (fk, tk, left) => {
    const f = get(fk), t = get(tk); if (!f || !t) return;
    const a = f.getBoundingClientRect(), b = t.getBoundingClientRect();
    const x1 = (left ? a.right : a.left) - R.left, y1 = a.top + a.height / 2 - R.top;
    const x2 = (left ? b.left : b.right) - R.left, y2 = b.top + b.height / 2 - R.top, xm = (x1 + x2) / 2;
    paths[f.classList.contains("me") && t.classList.contains("me") ? "me" : "base"].push(`M${x1.toFixed(1)} ${y1.toFixed(1)}H${xm.toFixed(1)}V${y2.toFixed(1)}H${x2.toFixed(1)}`);
  };
  for (let i = 0; i < 8; i++) link(`r16-${i}`, `qf-${i >> 1}`, i < 4);
  for (let i = 0; i < 4; i++) link(`qf-${i}`, `sf-${i >> 1}`, i < 2);
  for (let i = 0; i < 2; i++) link(`sf-${i}`, "final-0", i < 1);
  const old = tree.querySelector(".eu-lines"); if (old) old.remove();
  tree.insertAdjacentHTML("afterbegin", `<svg class="eu-lines" width="${R.width}" height="${R.height}" aria-hidden="true"><path class="b" d="${paths.base.join("")}"/><path class="m" d="${paths.me.join("")}"/></svg>`);
}
window.addEventListener("resize", () => { if ($(".v-eu .eu-tree")) euLines(); });
// 侧栏图标（无文字，2026-11-17 用户“侧栏的字全部去掉，图标换成更加直观好看的”）：
// 联赛阶段＝带名次圆点、长短递减的排行条；淘汰赛＝两路对阵汇入奖杯；附加赛＝两面盾牌对峙；重看抽签＝装着球的抽签碗
const EU_ICON = {
  stats: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.2l3 2.2-1.1 3.6h-3.8L9 9.4z" fill="currentColor" fill-opacity=".35"/><path d="M12 3.5v3.7M20.3 9.6l-5.3-.2M17.2 19.4l-3.3-6.4M6.8 19.4l3.3-6.4M3.7 9.6l5.3-.2"/></svg>',
  league: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="4.5" cy="6" r="1.7" fill="currentColor" stroke="none"/><path d="M9 6h11"/><circle cx="4.5" cy="12" r="1.7" fill="currentColor" stroke="none"/><path d="M9 12h8"/><circle cx="4.5" cy="18" r="1.7" fill="currentColor" stroke="none" opacity=".5"/><path d="M9 18h5" opacity=".5"/></svg>',
  ko: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2 4h5v5.5h4.5M2 15h5V9.5" opacity=".75"/><path d="M12.5 4.5h8v4a4 4 0 0 1-8 0z" fill="currentColor" fill-opacity=".3"/><path d="M12.5 5.5H11a1.6 1.6 0 0 0 0 3.2h1.6M20.5 5.5H22a1.6 1.6 0 0 1 0 3.2h-1.6M16.5 12.5v3.5M13.5 19h6l-.8-3h-4.4z"/></svg>',
  po: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M2.5 5.5 7 4l4.5 1.5V10c0 3.2-2 5.4-4.5 6.5C4.5 15.4 2.5 13.2 2.5 10z" fill="currentColor" fill-opacity=".3"/><path d="M12.5 9 17 7.5 21.5 9v4.5c0 3.2-2 5.4-4.5 6.5-2.5-1.1-4.5-3.3-4.5-6.5z"/></svg>',
  draw: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><circle cx="8.8" cy="8" r="2.5"/><circle cx="15" cy="7.4" r="2.5" fill="currentColor" fill-opacity=".35"/><circle cx="12.2" cy="3.6" r="1.9"/><path d="M3 11h18l-1.7 7.4a2.4 2.4 0 0 1-2.3 1.8H7a2.4 2.4 0 0 1-2.3-1.8z" fill="currentColor" fill-opacity=".2"/></svg>',
};
function euTiePop(id) {
  const c = euLast && euLast.comps.find((x) => x.id === euSel), [r, t] = c ? euFindTie(c, id) : [];
  if (!t || $("#eu-pop")) return;
  const el = document.createElement("div"); el.id = "eu-pop"; el.className = "dlg-back";
  el.innerHTML = `<div class="dlg eu-pop ${EU_THEME[c.id].cls}" role="dialog" aria-modal="true"><b class="dlg-t">${esc(c.name)} · ${esc(r.name)}</b>${euTie(t)}<div class="dlg-b"><button id="eu-pop-x" class="pri">关闭</button></div></div>`;
  document.body.appendChild(el);
  const close = () => { document.removeEventListener("keydown", onKey); el.remove(); };
  const onKey = (ev) => { if (ev.key === "Escape") close(); };
  document.addEventListener("keydown", onKey);
  el.addEventListener("click", (ev) => { if (ev.target === el || ev.target.id === "eu-pop-x") { sound("back"); close(); } });
}

// ---- 抽签动画
const euSeen = (k) => { try { return localStorage.getItem("eu-draw:" + k) === "1"; } catch (e) { return true; } };
// 整届抽签（2026-11-17 用户：“这个抽签难道只做我们自己组的吗……就像真实电视转播”→“36队全抽”）。结果早已由宿主算好，这里只“演”：
// 联赛阶段＝按第 1～4 档逐个抽出 36 队，每抽出一队揭晓它的 8 个对手（4 档 × 主/客），抽到我队停顿高亮，抽完是 36 队对手总表；
// 附加赛 / 16 强＝8 组对阵逐组抽（先抽出一队，再抽出对手）。最近一次抽签：16 强 > 附加赛 > 联赛阶段。顺序按赛季+赛事定种子，重看一样。
function euRng(key) { let h = 2166136261; for (const ch of key) h = Math.imul(h ^ ch.charCodeAt(0), 16777619); return () => { h += 0x6d2b79f5; let t = h; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
function euShuffle(a, rnd) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
function euDrawPlan(d, c) {
  c = c || (d && d.comps.find((x) => x.id === d.own)); if (!c) return null;
  const me = d.team, key = (st) => `${d.season}:${c.id}:${st}`;
  for (const st of ["r16", "po"]) {
    const ties = euRound(c, st);
    if (ties.length) return { key: key(st), comp: c, stage: st, me, ties: euShuffle(ties, euRng(key(st))) };
  }
  if (!c.pots || !c.matchdays.some((md) => md.matches.length)) return null;
  const potOf = {}; c.pots.forEach((p, i) => p.forEach((t) => { potOf[t] = i; }));
  const slots = {};       // 队 → 8 格：第 k 档主场在 2k、客场在 2k+1（同档同主客重复时放到空格）
  const put = (t, o, home) => {
    const s = slots[t] || (slots[t] = Array(8).fill(null)), base = (potOf[o] || 0) * 2, want = base + (home ? 0 : 1);
    const at = s[want] == null ? want : s[base + (home ? 1 : 0)] == null ? base + (home ? 1 : 0) : s.indexOf(null);
    if (at >= 0) s[at] = { team: o, home };
  };
  for (const md of c.matchdays) for (const m of md.matches) { put(m.home, m.away, true); put(m.away, m.home, false); }
  const rnd = euRng(key("league"));
  const order = c.pots.flatMap((p) => euShuffle(p, rnd));
  return { key: key("league"), comp: c, stage: "league", me, order, slots, potOf };
}
const EU_SPEEDS = [1, 2, 4];
function euDraw() {
  const d = euLast, c = d && d.comps.find((x) => x.id === euSel), p = c && euDrawPlan(d, c); if (!p || $("#eu-draw")) return;
  try { localStorage.setItem("eu-draw:" + p.key, "1"); } catch (e) {}
  const th = EU_THEME[c.id], me = p.me, league = p.stage === "league";
  const n = league ? p.order.length : p.ties.length;
  const myIdx = league ? p.order.indexOf(me) : p.ties.findIndex((t) => t.a === me || t.b === me);
  let speed = 1, gen = 0, done = 0, finished = false;
  const el = document.createElement("div"); el.id = "eu-draw"; el.className = `eu-draw ${th.cls}${league ? " lg" : " ko"}`;
  const ctl = `<span class="eu-spd">${EU_SPEEDS.map((s) => `<button data-s="${s}" class="${s === 1 ? "on" : ""}">×${s}</button>`).join("")}</span>`
    + (myIdx >= 0 ? `<button class="eu-tome">跳到我队</button>` : "") + `<button class="eu-skip">跳过 ››</button>`;
  const potsHtml = `<div class="eu-pots">${(league ? c.pots : [p.ties.flatMap((t) => [t.a, t.b])]).map((pt, i) => `<div class="eu-pot" data-pot="${i}"><small>${league ? i + 1 : "队"}</small><div>${pt.map((x) => `<i class="eu-ball-s${x === me ? " me" : ""}" data-t="${x}">${crest(x, "sm")}</i>`).join("")}</div></div>`).join("")}</div>`;
  const cur = league
    ? `<div class="eu-cur"><div class="eu-curh"><i class="eu-q">?</i><b>待抽</b><small></small></div><div class="eu-grid"><span></span><span class="h">主</span><span class="h">客</span>${[0, 1, 2, 3].map((k) => `<span class="pn">${k + 1}</span><div class="eu-slot" data-i="${2 * k}"></div><div class="eu-slot" data-i="${2 * k + 1}"></div>`).join("")}</div></div>`
    : `<div class="eu-ties">${p.ties.map((t, i) => `<div class="eu-ktie${t.a === me || t.b === me ? " me" : ""}" data-i="${i}"><span class="s a"><i class="eu-q">?</i></span><em>VS</em><span class="s b"><i class="eu-q">?</i></span></div>`).join("")}</div>`;
  el.innerHTML = `${euImg(c.id, "bg", "jpg")}<div class="eu-stars"></div>`
    + `<div class="eu-dh"><div class="eu-dlogo">${EU_LOGO[c.id]}</div><b class="eu-dtitle">${EU_STAGE[p.stage]} draw</b><span class="eu-prog"><b>0</b> / ${n}</span><span class="eu-dctl">${ctl}</span></div>`
    + `<div class="eu-dbody"><div class="eu-dl">${potsHtml}</div>`
    + `<div class="eu-stage"><div class="eu-spot"></div><div class="eu-orb"><div class="h t"></div><div class="h b"></div><div class="face"></div><div class="burst"></div></div>`
    + `<div class="eu-ribbon"><b>&nbsp;</b><small>&nbsp;</small></div><div class="eu-bowl"><i></i><i></i><i></i><i></i><i></i></div></div>`
    + `<div class="eu-dr-col">${cur}</div></div>`;
  document.body.appendChild(el);
  const $e = (s) => el.querySelector(s), orb = $e(".eu-orb"), face = orb.querySelector(".face"), rib = $e(".eu-ribbon"), prog = $e(".eu-prog b"), skip = $e(".eu-skip");
  const clear = () => { while (euTimers.length) clearTimeout(euTimers.pop()); };
  const close = () => { gen++; clear(); document.removeEventListener("keydown", onKey); el.remove(); };
  const onKey = (ev) => { if (ev.key === "Escape") close(); };
  document.addEventListener("keydown", onKey);
  const wait = (ms) => new Promise((r) => euTimers.push(setTimeout(r, ms / speed)));
  const ballOut = (t) => { const b = el.querySelector(`.eu-ball-s[data-t="${t}"]`); if (b) b.classList.add("out"); };
  const setProg = (k) => {
    done = Math.max(done, k); prog.textContent = String(done);
    if (done > myIdx) { const tm = el.querySelector(".eu-tome"); if (tm) tm.remove(); }      // 我队已经抽过了，“跳到我队”就收起来
  };
  // 揭晓一个球：升起 → 裂开露出队徽 → 彩带写队名
  const reveal = async (g, team, sub, pot) => {
    el.querySelectorAll(".eu-pot").forEach((x) => x.classList.toggle("hot", Number(x.dataset.pot) === pot));
    orb.classList.add("nt"); orb.classList.remove("open", "rise"); rib.classList.remove("show"); void orb.offsetWidth; orb.classList.remove("nt");     // 合球瞬间完成，不让上一个队徽从缝里露出来
    face.innerHTML = crest(team); orb.classList.add("rise");
    orb.style.animationDuration = `${0.95 / speed}s`;
    await wait(team === me ? 1100 : 750); if (g !== gen) return false;
    orb.classList.add("open"); rib.querySelector("b").textContent = tname(team); rib.querySelector("small").textContent = sub; rib.classList.add("show");
    ballOut(team); sound("cursor");
    return true;
  };
  // 联赛阶段：第 i 支球队的 8 个对手填进右侧格子（instant＝快进/跳过时不做动画）
  const showTeam = async (g, i, instant) => {
    const t = p.order[i], s = p.slots[t] || [], mine = t === me, involvesMe = s.some((o) => o && o.team === me);
    const head = $e(".eu-curh"); head.innerHTML = `${crest(t)}<b>${esc(tname(t))}</b><small>第 ${(p.potOf[t] || 0) + 1} 档</small>`;
    $e(".eu-cur").classList.toggle("mine", mine);
    el.querySelectorAll(".eu-slot").forEach((x) => { x.className = "eu-slot"; x.innerHTML = ""; });
    for (let k = 0; k < 8; k++) {
      const o = s[k], cell = el.querySelector(`.eu-slot[data-i="${k}"]`);
      if (o) { cell.innerHTML = `${crest(o.team, "sm")}<span>${esc(tname(o.team))}</span>`; cell.classList.add("got"); if (o.team === me) cell.classList.add("me"); if (!instant) cell.classList.add("new"); }
      if (!instant) { await wait(85); if (g !== gen) return false; }
    }
    if (!instant && (mine || involvesMe)) sound("ok");
    return true;
  };
  const tieSide = (i, side, team) => {
    const box = el.querySelector(`.eu-ktie[data-i="${i}"] .s.${side}`);
    box.innerHTML = `${crest(team, "sm")}<span>${esc(tname(team))}</span>`; box.classList.add("got");
  };
  const instantUpto = (k) => {      // 前 k 个直接落定（不播动画）
    for (let i = 0; i < k; i++) {
      if (league) ballOut(p.order[i]);
      else { const t = p.ties[i]; tieSide(i, "a", t.a); tieSide(i, "b", t.b); ballOut(t.a); ballOut(t.b); }
    }
    if (league && k > 0) showTeam(gen, k - 1, true);
    setProg(k);
  };
  const run = async (from) => {
    const g = ++gen; clear();
    for (let i = from; i < n; i++) {
      if (league) {
        const t = p.order[i], mine = t === me;
        if (!(await reveal(g, t, `第 ${(p.potOf[t] || 0) + 1} 档`, p.potOf[t]))) return;
        if (!(await showTeam(g, i, false))) return;
        setProg(i + 1);
        await wait(mine ? 2400 : 420); if (g !== gen) return;
      } else {
        const t = p.ties[i], mine = t.a === me || t.b === me;
        el.querySelectorAll(".eu-ktie").forEach((x) => x.classList.toggle("cur", Number(x.dataset.i) === i));
        if (!(await reveal(g, t.a, `第 ${i + 1} 组`, 0))) return; tieSide(i, "a", t.a);
        await wait(380); if (g !== gen) return;
        if (!(await reveal(g, t.b, `对阵 ${tname(t.a)}`, 0))) return; tieSide(i, "b", t.b);
        setProg(i + 1); if (mine) sound("ok");
        await wait(mine ? 2000 : 500); if (g !== gen) return;
      }
    }
    finish();
  };
  // 抽完：联赛阶段换成 36 队对手总表（我队那行高亮并滚到可见）；淘汰赛就是填满的对阵表
  const finish = () => {
    gen++; clear(); finished = true; instantUpto(n); el.classList.add("done");
    el.querySelectorAll(".eu-pot, .eu-ktie").forEach((x) => x.classList.remove("hot", "cur"));
    skip.textContent = "完成"; const tm = $e(".eu-tome"); if (tm) tm.remove(); const sp = $e(".eu-spd"); if (sp) sp.remove();
    if (league) {
      const row = (t) => `<div class="eu-sr${t === me ? " me" : ""}"><span class="pn">${(p.potOf[t] || 0) + 1}</span>${crest(t, "sm")}<b>${esc(tname(t))}</b>`
        + `<span class="ops">${(p.slots[t] || []).map((o, k) => (o ? `<i class="${o.home ? "h" : "a"}${o.team === me ? " me" : ""}${k % 2 ? " gap" : ""}" title="${esc(tname(o.team))}${o.home ? "（主）" : "（客）"}">${crest(o.team, "sm")}</i>` : `<i class="${k % 2 ? "gap" : ""}"></i>`)).join("")}</span></div>`;
      $e(".eu-dbody").innerHTML = `<div class="eu-sum"><div class="eu-sumh">36 队对手一览<small>每档两队：左主场 · 右客场</small></div><div class="eu-sumb">${p.order.slice().sort((a, b) => (p.potOf[a] - p.potOf[b]) || p.order.indexOf(a) - p.order.indexOf(b)).map(row).join("")}</div></div>`;
      const r = $e(".eu-sr.me"); if (r) euTimers.push(setTimeout(() => { const b = $e(".eu-sumb"); b.scrollTop = Math.max(0, r.offsetTop - b.clientHeight / 2); }, 0));
    }
    sound("ok");
  };
  el.querySelectorAll(".eu-spd button").forEach((b) => { b.onclick = () => { speed = Number(b.dataset.s); el.querySelectorAll(".eu-spd button").forEach((x) => x.classList.toggle("on", x === b)); sound("cursor"); }; });
  const tome = $e(".eu-tome"); if (tome) tome.onclick = () => { if (finished || done > myIdx) return; sound("cursor"); gen++; clear(); instantUpto(myIdx); run(myIdx); tome.remove(); };
  skip.onclick = () => { if (finished) { sound("back"); close(); } else finish(); };
  euTimers.push(setTimeout(() => run(0), 450));
}
/* ================= 赛季总结与跨赛季（2026-11-14，M4 批 5）=================
   赛季打完后，顶栏右上角和主页横幅变成“赛季总结”。GET /api/season/summary：最终排名与战绩、领奖台、射手 / 助攻、成长与退步；
   “进入新赛季”＝ POST /api/season/next（宿主 iml_host.next_season：记荣誉、全队长一岁、暑期恢复体能与伤病，再开同一支球队的下一赛季；
   重试不会让球员多长一岁）。荣誉页（球队 · 荣誉）读 /api/biz/honors，历届赛季来自同一份记录。 */
const NS_ERR = { busy: "正在进入比赛，稍后再试", "season-active": "赛季还没有结束", "no-season": "还没有赛季", "no-ml-profile": "还没有大师联赛存档", "rollover-failed": "跨赛季结算失败，请重试", "select-failed": "没能开始新赛季，请重试" };
async function openSeasonReview() {
  let d = null; try { d = await api("/api/season/summary"); } catch (e) { d = null; }
  if (!d || d.error || !d.team) return toast("赛季总结暂时不可用");
  sound("page");
  const cup = !!d.is_champion, fill = d.teams > 1 ? Math.round((d.teams - d.rank) / (d.teams - 1) * 100) : 100;
  const tone = cup ? "var(--gold)" : d.rank <= 4 ? "var(--win)" : "var(--blue)";
  const lead = (x) => `<div class="sr-r${x.mine ? " me" : ""}" ${x.pid ? `data-player="${esc(x.pid)}"` : ""}>${pface(x)}<b>${esc(x.name)}</b>${x.team != null ? crest(x.team, "sm") : ""}<span class="num">${x.n}</span></div>`;
  const sec = (icon, title, rows, empty) => `<div class="sr-sec"><span>${svg(icon, 1.8)}${title}</span>${rows.length ? rows.join("") : `<div class="sr-none">${empty}</div>`}</div>`;
  const move = (x, up) => `<div class="sr-r" data-player="${esc(x.pid)}">${pface(x)}<b>${esc(x.name)}</b><span class="${up ? "tag-up" : "tag-dn"}">${up ? "+" : "−"}${Math.abs(x.delta)}</span></div>`;
  const fin = d.finance && typeof d.finance.ops === "number" ? d.finance : null;   // E324：本季经营结余 → 转会预算（服务端 iml_finance.season_outlook）
  const exp = d.expiring || [];                                            // 合同本季到期的球员（服务端 iml_finance.expiring）
  const trophies = (d.trophies || []).map((t) => `<span class="sr-tro">${svg("season", 2)}${esc(t)}</span>`).join("");
  // E323 升降级（服务端 iml_rollover.division：已结算＝存档结果，未结算＝按当前积分榜暂定；德甲等无次级联赛时为 null）
  const dv = d.division, dvMine = dv && dv.mine, dvTag = dv && !dv.settled ? (dv.provisional ? "（暂定）" : "（进入新赛季时生效）") : "";
  const dvBanner = dvMine ? `<div class="sr-div ${dvMine.kind === "up" ? "up" : "down"}">${svg(dvMine.kind === "up" ? "up" : "down", 2)}${dvMine.kind === "up" ? "升级" : "降级"}至${esc(dvMine.to_name || "")}<small>${dv.settled ? "" : dv.provisional ? "暂定" : "下季生效"}</small></div>` : "";
  const dvCrest = (t) => { const n = ((dv.teams || {})[String(t)] || {}); return `<span class="${t === d.team ? "me" : ""}" data-team="${t}" title="${esc(n.name || tname(t))}">${crest(t, "sm")}</span>`; };
  const dvRows = dv ? (dv.pairs || []).map((p) => `<div class="sr-pr"><em>${esc(p.top_name)} <b class="dn">↓</b></em><span>${p.down.map(dvCrest).join("")}</span><em>${esc(p.second_name)} <b class="up">↑</b></em><span>${p.up.map(dvCrest).join("")}</span></div>`) : [];
  const cab = (d.cabinet || []).map((c) => `<span title="${esc(c.name)}">${svg("season", 1.6)}<b class="num">${c.count}</b><small>${esc(c.name)}</small></span>`).join("");
  openLayer("赛季总结", `${esc(d.league)} · 第 ${d.season} 赛季`, `<div class="sr">
    <div class="card sr-hero" style="--hc:${tcolor(d.team)}"><div class="cb sr-hb">
      <div class="sr-me">${crest(d.team, "xl")}<div><b>${esc(tname(d.team))}</b><small>${cup ? "联赛冠军" : `联赛第 ${d.rank} 名 / ${d.teams}`}</small></div>
        <span class="ring sr-ring" style="--v:${fill};--c:${tone}" title="最终排名">${cup ? svg("season", 1.6) : `<b class="num">${d.rank}</b>`}</span></div>
      <div class="sr-rec"><span><b class="num">${d.won}</b><small>胜</small></span><span><b class="num">${d.drawn}</b><small>平</small></span><span><b class="num">${d.lost}</b><small>负</small></span><span><b class="num">${d.gf}:${d.ga}</b><small>进失</small></span><span class="pts"><b class="num">${d.points}</b><small>积分</small></span></div>
      <div class="sr-pod" title="领奖台">${(d.podium || []).map((p, i) => `<span class="${p.team === d.team ? "me" : ""}${i === 0 ? " one" : ""}" data-team="${p.team}" title="${esc(p.name)} · ${p.points} 分"><i>${i + 1}</i>${crest(p.team, "sm")}<em class="num">${p.points}</em></span>`).join("")}</div>
      ${trophies ? `<div class="sr-tros">${trophies}</div>` : ""}${dvBanner}</div></div>
    <div class="card"><div class="cb scroll sr-lead">${dvRows.length ? sec("season", `升降级${dvTag}`, dvRows, "") : ""}${sec("ball", "联赛射手", (d.scorers || []).map(lead), "没有进球记录")}${sec("training", "本队射手", (d.my_scorers || []).map((x) => lead(Object.assign({ mine: true, team: d.team }, x))), "本季没有进球")}${sec("person", "联赛助攻", (d.assisters || []).map(lead), "没有助攻记录")}</div></div>
    <div class="sr-side"><div class="card"><div class="cb scroll sr-lead">${sec("up", "进步", (d.grew || []).map((x) => move(x, true)), "没有明显进步")}${sec("shield", "退步", (d.declined || []).map((x) => move(x, false)), "没有人退步")}</div></div>
      <div class="card sr-next"><div class="sr-cab">${cab}</div>${fin ? `<div class="meter" title="转播、赞助、门票、奖金减去薪资与运营开支；赛季结束时由董事会计入转会预算，亏损则扣减"><span>本季经营结余</span><b class="${fin.ops >= 0 ? "up" : "dn"}">${fin.ops >= 0 ? "+" : "−"}${money(Math.abs(fin.ops))}</b></div><small>${fin.settled ? "已计入" : "进入新赛季时计入"}转会预算：${money(fin.budget, 1)} → ${money(fin.next_budget, 1)}</small>` : ""}${exp.length ? `<button class="sr-exp" id="sr-exp" title="合同到期：去续约"><b class="num">${exp.length}</b> 名球员合同到期 ›</button>` : ""}<button class="btn pri" id="sr-go" data-sound="ok">进入第 ${d.next.season} 赛季${d.next.league ? ` · ${esc(d.next.league)}` : ""} ${svg("play", 2)}</button><small>${seasonEnd() ? "" : "跳过余下休赛期 · "}合同 6/30 到期 · 全队长一岁 · 7 月 1 日季前期开始</small></div></div></div>`);
  if (exp.length) $("#sr-exp").onclick = () => { sound("page"); closeLayer(true); openSec("squad", 3); };
  // 体验评审 U10：确认前按服务端同一套规则（iml_finance.expiring 的 fate）分好组——会离队 / 会自动续约一年，各自列出周薪与原因、顶替的人；
  // 每次点“进入”都重新读一次总结，名单变了（刚续约、刚换人）就按新的分组再确认。旧服务端没有 fate 时按“会离队”显示并注明可能自动续约。
  $("#sr-go").onclick = async () => {
    let sm = d; try { const r = await api("/api/season/summary"); if (r && !r.error && r.team) sm = r; } catch (e) { /* 用页面上的那份 */ }
    const ex = sm.expiring || [], retired = sm.retiring || []; if (!ex.length && !retired.length) return goNext();
    const leave = ex.filter((p) => p.fate !== "extend"), keep = ex.filter((p) => p.fate === "extend"), sum = (a) => a.reduce((t, p) => t + (p.wage || 0), 0);
    const row = (p, note) => `<div class="mk-pk">${pos(p.position)}${pface(p)}<b>${esc(p.name)}</b>${ovr(p.overall)}<em>${esc(note)}</em><span class="num">${kfmt(p.wage)}</span></div>`;
    const grp = (title, rows, foot) => rows ? `<div class="sr-grp"><b>${title}</b>${foot ? `<small>${foot}</small>` : ""}${rows}</div>` : "";
    mkDialog("进入新赛季前确认", `<div class="mk-dl">
      ${retired.length ? `<div class="sr-grp"><b>本季退役 · ${retired.length} 人</b><p>${retired.map((p) => `${esc(p.name)}（${p.age}）`).join("、")}</p><small>旧生涯归档；下季以 16–17 岁青训回到球队，能力与出场记录重新开始。</small></div>` : ""}
      <div class="mk-pick scroll">${grp(`会离队 · ${leave.length} 人`, leave.map((p) => row(p, p.in_squad ? (p.replaced_by ? `由 ${p.replaced_by} 顶替` : "名单内") : "预备队")).join(""), leave.length ? `每周少付 ${kfmt(sum(leave))}${leave.some((p) => p.fate == null) ? " · 名单里没人顶替的会改为自动续约一年" : ""}` : "")}
        ${grp(`会自动续约一年 · ${keep.length} 人`, keep.map((p) => row(p, `续到 ${2026 + (p.extend_until || sm.season + 1)}.06`)).join(""), keep.length ? `原因：23 人名单里没有同位置的预备队员能顶替；周薪不变，合计 ${kfmt(sum(keep))} / 周` : "")}</div>
      ${ex.length ? `<small>想留下谁或改条件，先到“球队 · 合同”续约；确认后按上面的分组处理。</small>` : ""}</div>`,
      [{ label: ex.length ? "去续约" : "返回", fn: () => { $$("#mkdlg").forEach((e) => e.remove()); if (ex.length) { closeLayer(true); openSec("squad", 3); } } }, { label: "确认并进入", pri: true, fn: async () => { $$("#mkdlg").forEach((e) => e.remove()); await goNext(); } }]); };
  async function goNext() {
    const b = $("#sr-go"); if (!b || b.disabled) return; b.disabled = true; const label = b.innerHTML; b.textContent = "正在进入新赛季…";
    const r = await post("/api/season/next", {});
    if (!r || r.error || !r.ok) { b.disabled = false; b.innerHTML = label; return toast(NS_ERR[r && r.reason] || (r && r.error) || "没能开始新赛季，请重试"); }
    sound("ok"); closeLayer(true); cur = { sec: "home", tab: 0 }; calMonth = null; histRound = null;
    for (const k of Object.keys(BIZ)) delete BIZ[k];
    screen = "game"; await refresh(true);            // 不弹提示（2026-11-14 用户）：谁离队 / 自动续约记在通知里（iml_biz 合同消息）
  }
}

/* ================= 子页面层：战报 / 球队 ================= */
function closeLayer(instant) {
  const l = $(".layer"); if (!l) return;
  if (instant || REDUCED) return l.remove();
  l.classList.add("out"); setTimeout(() => l.remove(), 200);
}
function openLayer(title, right, body) {
  $$(".layer").forEach((l) => l.remove());
  const l = document.createElement("div");
  l.className = "layer";
  l.innerHTML = `<div class="lhead"><button class="back" data-sound="back">${svg("back")}返回</button><h3>${title}</h3><span class="r">${right || ""}</span></div><div class="lbody">${body}</div>`;
  $(".main").appendChild(l);
  $(".back", l).onclick = () => closeLayer();
  bindPage(l); animate(l);
}
// 设置（2026-11-13 用户：左下角“菜单”改成“设置”，菜单暂时放进里面）。目前只有一项：回到开场主菜单（继续 / 新建游戏 / 退出）；以后音效、画面等设置加在这里。
async function openSettings() {
  let df = null; try { df = await api("/api/difficulty"); if (!df || df.error || !Array.isArray(df.levels)) df = null; } catch (e) { df = null; }
  openLayer("设置", "", `<div class="set-wrap">
    <div class="card"><div class="ch">通用</div><div class="cb">
      <button class="mn-it" id="set-menu" style="width:100%"><em>01</em><span class="ic">${svg("grid", 1.8)}</span><div><b>主菜单</b><small>回到开场菜单：继续游戏 / 新建游戏 / 退出</small></div><i class="arr">›</i></button>
      ${df ? `<button class="mn-it" id="set-diff" style="width:100%"><em>02</em><span class="ic">${svg("bolt", 1.8)}</span><div><b>对手难度</b></div><i class="arr">${esc(dfLabel(df))} ›</i></button>` : ""}
      <button class="mn-it" id="set-lang" style="width:100%"><em>${df ? "03" : "02"}</em><span class="ic">${svg("globe", 1.8)}</span><div translate="no"><b>语言 / Language</b></div><i class="arr" translate="no">${esc(langInfo(LANG).name)} ›</i></button>
    </div></div></div>`);
  $("#set-menu").onclick = toMenu;
  $("#set-lang").onclick = () => { sound("page"); openLanguage(); };
  if (df) $("#set-diff").onclick = () => { sound("page"); openDifficulty(df); };
}
// 二级菜单：语言（点一种即切换并重新载入；语言名永远用各自的文字写，不参与翻译）
function openLanguage() {
  const rows = LANGS.map((l) => `<button class="df-row${l.code === LANG ? " on" : ""}" data-lang="${l.code}" translate="no" style="white-space:nowrap"><b>${esc(l.name)}</b>${l.code === LANG ? `<span class="df-ck">${svg("check", 2.4)}</span>` : ""}</button>`).join("");
  openLayer("语言 / Language", "", `<div class="set-wrap"><div class="card"><div class="cb scroll"><div class="df-list" id="lang-list">${rows}</div></div></div></div>`);
  const back = $(".layer .back"); if (back) back.onclick = () => openSettings();
  $$("#lang-list .df-row").forEach((row) => row.onclick = () => { if (row.dataset.lang === LANG) return; sound("ok"); setLang(row.dataset.lang); });
}
// 二级菜单：对手难度（只列档位，不带说明小字；点一档即生效，下一场开赛起生效）
function openDifficulty(df) {
  openLayer("对手难度", "", `<div class="set-wrap"><div class="card"><div class="cb scroll"><div class="df-list" id="df-list">${dfRows(df)}</div></div></div></div>`);
  const back = $(".layer .back"); if (back) back.onclick = () => openSettings();     // 音效由 data-sound="back" 播，别再叠一声
  $$("#df-list .df-row").forEach((row) => row.onclick = async () => {
    if (row.dataset.df === df.level) return;
    const r = await post("/api/difficulty", { level: row.dataset.df });
    if (!r || r.error) return toast(FM_ERR[r && r.reason] || (r && r.error) || "调整失败");
    sound("ok"); openDifficulty(r);                  // 成功不弹提示（2026-11-14 用户），面板里已显示新难度
  });
}
async function openReport(id) {
  try { const f = await fixture(id); openLayer("战报", `${esc(tname(f.home))} vs ${esc(tname(f.away))}`, reportBody(f)); }
  catch (e) { toast(`战报读取失败：${e.message}`); }
}
// 球员详情（2026-11-13）：点阵容/球员/替补/合同/伤病里的我方球员打开。只放我们真有的数据：
//   真实 —— /api/team（能力、位置、等级、卡种、号码、首发、出场/进球/助攻）、/api/health（疲劳→体能、伤病剩余场次）、/api/form（状态 A–E）
//   经营层 —— biz("squad")（年龄、潜力、身价、周薪、合同、士气）；还是示例数据时标“示例”
const GRADE_C = { A: "var(--win)", B: "#7bd88f", C: "var(--draw)", D: "#f08a4b", E: "var(--loss)" };
// tid（可选）：球员所在球队；不是我队（或 "free"＝自由球员）时打开他队球员的球探报告（/api/scout，榜单 / 市场 / 联赛球员库都走这里），hint = 榜单里已有的本季进球助攻
async function openPlayer(pid, tid, hint) {
  if (tid === "free") return openRivalPlayer(null, pid, hint || {});
  if (tid != null && tid !== "" && Number(tid) !== me()) return openRivalPlayer(Number(tid), pid, hint || {});
  sound("page");
  let t; try { t = await team(me()); } catch (e) { return toast(`阵容读取失败：${e.message}`); }
  const all = [...t.squad.map((p) => ({ ...p, st: p.starter ? "首发" : "替补" })), ...t.reserve.map((p) => ({ ...p, st: "预备" }))];
  const p = all.find((x) => String(x.pid) === String(pid)); if (!p) return toast("没有找到这名球员");
  const [x, hl, fm, det, trn, rtg] = await Promise.all([biz("squad").catch(() => null), api("/api/health").catch(() => null), api("/api/form").catch(() => null),
    api(`/api/player/${encodeURIComponent(pid)}`).catch(() => null), biz("training").catch(() => null), api(`/api/ratings/player/${encodeURIComponent(pid)}`).catch(() => null)]);
  const rt = rtg && !rtg.error && rtg.apps ? rtg : null;                       // E307 C2：本季评分（实测 + 模拟，宿主 iml_ratings）
  const dev = trn && !trn.demo && Array.isArray(trn.players) ? trn.players.find((r) => String(r.pid) === String(pid)) : null;      // M7-G3：成长三件事分开写
  const d = det && !det.error && det.abilities ? det : null, pf = d ? d.profile || {} : {};
  const b = (x && x.players && x.players[String(pid)]) || {}, demoTag = x && x.demo ? `<i class="pd-demo">示例</i>` : "";
  const h = hl && Array.isArray(hl.players) ? hl.players.find((r) => String(r.pid) === String(pid)) : null;
  const f = fm && Array.isArray(fm.players) ? fm.players.find((r) => String(r.pid) === String(pid)) : null;
  const fit = h ? Math.max(0, Math.round(100 - (h.fatigue || 0))) : b.fitness ?? null, fitTag = h ? "" : demoTag;
  const inj = h ? h.injury : b.injury, injTag = h ? "" : demoTag;
  const injTxt = inj ? (inj.games_left != null ? `还需 ${inj.games_left} 场` : inj.weeks != null ? `约 ${inj.weeks} 周` : "伤停中") : "可以出场";
  const ring = (v, c) => `<div class="pd-ring" style="--v:${v == null ? 0 : v};--c:${c}"><span class="num">${v == null ? "—" : v}</span></div>`;
  const kv = (k, v, tag = "") => `<div class="pd-kv"><span>${k}${tag}</span><b>${v}</b></div>`;
  const perGame = p.apps ? ((p.goals || 0) / p.apps).toFixed(2) : "—";
  // 2026-11-14 用户：“球员详情做成类FM的吧 能力可以做一个五维图之类的”——左身份卡（身体资料直接列出）、中间能力雷达＋最强能力、右侧状态/本季/合同
  const mini = (k, inner, sub, tag = "") => `<div class="pd-mini"><small>${k}${tag}</small>${inner}<em>${sub}</em></div>`;
  const best = d ? pdBest(d, 4) : [];
  // 2026-11-15 用户：“能力图太占位置了 做成缩略图，合同身价、评分也做成小块，点开有二级菜单”——概况只放缩略小块，点开在右侧抽屉里看完整内容
  const hasMoney = b.value != null || b.wage != null, hasDev = !!dev || b.potential != null;
  const sheets = {
    rate: ["近期评分", pdRatings(rt)],
    money: ["合同与成长" + demoTag, (hasMoney ? `<div class="card">${pdMoney(b, p, x)}</div>` : `<div class="card"><div class="empty-note">暂无合同数据</div></div>`) + (hasDev ? `<div class="card"><div class="ch">成长与潜力</div>${dev ? pdDev(dev, f) : ""}${b.potential != null ? `<div class="pd-potrow"><span>当前 ${p.overall ?? "—"}</span><b class="num">潜力 ${b.potential}</b></div>` : ""}</div>` : "")],
  };
  // 类 FM 面板：标题条（名称＋›）＋紧凑内容，整块可点，点开右侧抽屉
  const pan = (key, title, sub, inner) => `<button class="pd-pan" data-sheet="${key}"><div class="pp-h"><b>${title}</b><span>${sub || ""}</span><i>›</i></div><div class="pp-b">${inner}</div></button>`;
  const rrow = (k, v, c) => `<div class="pp-r"><span>${k}</span><b class="num"${c ? ` style="color:${c}"` : ""}>${v}</b></div>`;
  const season = (S && S.career && S.career.season) || 1, left = b.until ? b.until - (2026 + season) + 1 : null;
  const recent = rt ? rt.recent.slice(-6) : [];
  const ratePan = pan("rate", "近期评分", rt ? `${rt.apps} 场${rt.best ? ` · ★${rt.best}` : ""}` : "",
    rt ? `<div class="pp-rate"><div class="pp-avg">${rpRt(rt.avg, true)}<small>场均</small></div><div class="pp-bars">${recent.map((r) => `<div class="pp-bar${r.source === "observed" ? "" : " sim"}"><b class="num">${r.rating.toFixed(1)}</b><span><i style="height:${Math.max(8, Math.round((r.rating - 4) / 6 * 100))}%;background:${pdRCol(r.rating)}"></i></span></div>`).join("")}</div></div>` : `<div class="pp-empty">本季还没有评分</div>`);
  const moneyPan = pan("money", "合同", b.until ? (left != null && left <= 1 ? "本季到期" : left != null ? `剩 ${left} 季` : "") : "",
    hasMoney ? `${rrow("身价", b.value != null ? money(b.value) : "—", "var(--gold)")}${rrow("周薪", b.wage != null ? kfmt(b.wage) : "—", "var(--blue)")}${rrow("合同至", b.until ? `${b.until}.06` : "—", left != null && left <= 1 ? "var(--loss)" : "")}${rrow("潜力", b.potential != null ? b.potential : "未评估")}` : `<div class="pp-empty">暂无合同数据</div>`);
  const tiles = moneyPan;
  const body =`<div class="pd pd2 pd3">
    <div class="card pd-id" style="--i:0">
      ${PD_CARD_BTN(p.pid)}
      <div class="pd-media"><div class="pd-face"><img src="/img/player/${encodeURIComponent(p.pid)}.png" alt="" onerror="this.remove()"></div>
        ${PD_ART}</div>
      <b class="pd-name">${esc(p.name)}</b>
      <div class="pd-tags">${pos(p.position, p.group)}${ovr(p.overall)}${p.shirt ? `<span class="pd-no num">${p.shirt}</span>` : ""}</div>
      <div class="pd-list">${kv("年龄", b.age != null ? `${b.age} 岁` : "—", b.age != null ? demoTag : "")}
        ${d ? `${kv("惯用脚", pf.foot || "—")}${kv("身高体重", `${pf.height || "—"}cm · ${pf.weight || "—"}kg`)}` : ""}
        ${kv("阵容状态", `<span style="color:${p.st === "首发" ? "#fff" : "var(--ink3)"}">${p.st}</span>`)}        <details class="pd-cardinfo"><summary class="pd-kv"><span>卡片资料</span><b>›</b></summary><div>
          <small>联赛年龄随赛季增长，用于成长与合同；卡面资料不会因此改变</small>${d ? kv("卡面年龄", pf.age ?? "—") : ""}${kv("等级", p.level != null ? `${p.level} / ${p.level_limit ?? "—"}` : "—")}${p.kind ? kv("卡种", esc(p.kind)) : ""}</div></details></div>
    </div>
    <div class="pd-mid" style="--i:1">
      <div class="card pd-radar-card pd-rad2"><div class="ch">能力雷达<span class="r">${dev && dev.talent && dev.talent.length ? talentChips(dev.talent, "sm hd") : d ? `${d.position === "GK" ? "门将六项" : "六项综合"} · 满 99` : ""}</span></div>
        <div class="pd-rbody"><div class="pd-radar-box">${pdRadar(d)}</div>
        ${best.length ? `<div class="pd-best"><small>最强能力</small>${best.map((z) => `<span><b class="num" style="color:${abilColor(z.value)}">${z.value}</b>${esc(z.label)}</span>`).join("")}</div>` : ""}</div></div>
      ${pdRatings(rt)}
    </div>    <div class="pd-side pd-side3" style="--i:2">
      <div class="pd-minis">
        ${mini("比赛状态", f ? `<span class="pd-grade num" style="color:${GRADE_C[f.grade] || "var(--ink)"}">${esc(f.grade)}</span>` : `<span class="pd-grade num muted">—</span>`, f ? "本场已定" : "开赛前定")}
        ${mini("体能", ring(fit, gaugeColor(fit ?? 0)), fit == null ? "—" : fit < 70 ? "建议轮换" : "良好", fitTag)}
        ${mini("伤病", `<span class="pd-inj ${inj ? "hurt" : ""}">${svg(inj ? "med" : "check", 2.4)}</span>`, esc(inj ? `${inj.name || inj.kind || "受伤"} · ${injTxt}` : injTxt), injTag)}
        ${mini("士气", ring(b.morale ?? null, gaugeColor(b.morale ?? 0)), b.morale == null ? "暂无" : b.morale >= 70 ? "积极" : b.morale >= 45 ? "一般" : "低落", b.morale != null ? demoTag : "")}
      </div>
      <div class="card pd-season"><div class="pp-h static"><b>本赛季</b></div><div class="pd-nums n5">${[["出场", p.apps ?? 0], ["进球", p.goals ?? 0], ["助攻", p.assists ?? 0], ["场均进球", perGame]].map(([k, v]) => `<div><b class="num">${v}</b><small>${k}</small></div>`).join("")}<div><b>${rt ? rpRt(rt.avg) : `<span class="muted">—</span>`}</b><small>场均评分</small></div></div></div>
      <div class="pd-pans">${tiles}</div>
    </div></div>`;
  const tabs = [["概况", () => body], ["能力", () => pdAbilities(d)], ["位置", () => pdPositions(d)], ["技能", () => pdSkills(d)], ["风格", () => pdStyles(d)]];
  openLayer("球员详情", `${esc(p.name)}${p.shirt ? ` · ${p.shirt} 号` : ""}`,
    `<div class="pd-wrap"><nav class="pd-nav">${tabs.map(([t], i) => `<button class="pd-tab${i === pdTab ? " on" : ""}" data-pdt="${i}">${t}</button>`).join("")}</nav><div class="pd-pane" id="pdpane"></div></div>`);
  const show = (i) => {
    pdTab = i;
    $$(".pd-tab").forEach((b) => b.classList.toggle("on", +b.dataset.pdt === i));
    const pane = $("#pdpane"); if (!pane) return;
    pdSheetClose(true);
    pane.innerHTML = tabs[i][1]();
    bindPage(pane); animate(pane);
    $$("[data-card]", pane).forEach((el) => el.onclick = () => pdFlip(pane, p));
    $$("[data-sheet]", pane).forEach((el) => el.onclick = () => { const s = sheets[el.dataset.sheet]; if (s) pdSheet(s[0], s[1], () => show(1)); });
  };
  $$(".pd-tab").forEach((b) => b.onclick = () => { if (+b.dataset.pdt !== pdTab) sound("cursor"); show(+b.dataset.pdt); });
  show(pdTab < tabs.length ? pdTab : 0);
}
// 球员详情二级菜单（抽屉）：概况里的缩略小块点开后，在 .pd-wrap 里盖一层右侧面板；点遮罩 / × / 切换标签收起。onGo＝面板里的“全部能力 ›”跳转。
function pdSheetClose(instant) {
  const s = $(".pd-sheet"); if (!s) return;
  if (instant || REDUCED) return s.remove();
  s.classList.add("out"); setTimeout(() => s.remove(), 160);
}
function pdSheet(title, html, onGo) {
  pdSheetClose(true); sound("page");
  const wrap = $(".pd-wrap"); if (!wrap) return;
  const s = document.createElement("div");
  s.className = "pd-sheet";
  s.innerHTML = `<div class="pds-bg"></div><div class="pds-panel"><div class="pds-h"><b>${title}</b><button class="pds-x" aria-label="关闭">×</button></div><div class="pds-b">${html}</div></div>`;
  wrap.appendChild(s);
  const close = () => { sound("back"); pdSheetClose(); };
  $(".pds-bg", s).onclick = close; $(".pds-x", s).onclick = close;
  const go = $("[data-pdgo]", s); if (go && onGo) go.onclick = () => { pdSheetClose(true); onGo(); };
  bindPage(s);
}
const pdRCol = (v) => v >= 8 ? "#34d399" : v >= 7 ? "#a3e15f" : v >= 6 ? "#e0b341" : "#f0875a";
// 能力缩略图：不带文字的六边形（两圈刻度＋当前能力多边形）
function pdRadarMini(d) {
  if (!d) return `<span class="muted">—</span>`;
  const ax = pdAxes(d); if (ax.length < 3) return `<span class="muted">—</span>`;
  const c = 50, R = 42, LO = 30, HI = 99, n = ax.length;
  const pt = (i, v) => { const a = -Math.PI / 2 + i * 2 * Math.PI / n, r = R * Math.max(0, Math.min(1, (v - LO) / (HI - LO))); return [c + r * Math.cos(a), c + r * Math.sin(a)]; };
  const poly = (vals) => vals.map((v, i) => pt(i, v).map((z) => z.toFixed(1)).join(",")).join(" ");
  return `<svg class="pd-rmini" viewBox="0 0 100 100"><polygon points="${poly(ax.map(() => HI))}" class="rg out"/><polygon points="${poly(ax.map(() => 65))}" class="rg"/><polygon points="${poly(ax.map((a) => a.value))}" class="rp"/></svg>`;
}
// E307 C2：近期评分（每场一根柱子，高度＝评分，颜色同战报评分徽标；★＝全场最佳；点柱子打开那场战报）。实测比赛与模拟比赛分开标注。
function pdRatings(rt) {
  if (!rt) return `<div class="card"><div class="ch">近期评分</div><div class="empty-note">本季还没有评分</div></div>`;
  const col = (v) => v >= 8 ? "#34d399" : v >= 7 ? "#a3e15f" : v >= 6 ? "#e0b341" : "#f0875a";
  const fid = (r) => { const sc = (S.schedule || []).find((x) => x.round === r.fixture); return sc ? sc.id : null; };
  const bars = rt.recent.map((r) => { const id = fid(r), h = Math.max(6, Math.round((r.rating - 4) / 6 * 100));
    return `<button class="pd-rb"${id ? ` data-fx="${esc(id)}"` : ""} title="第${r.fixture}轮 ${esc(tname(r.opponent))} ${r.score[0]}:${r.score[1]} · ${r.rating.toFixed(1)}${r.source === "observed" ? " · 实测" : " · 模拟"}">
      <b class="num">${r.rating.toFixed(1)}</b><span class="pd-rbw"><i style="height:${h}%;background:${col(r.rating)}${r.source === "observed" ? "" : ";opacity:.75"}"></i></span>${crest(r.opponent, "sm")}${r.best ? `<em>★</em>` : ""}</button>`; }).join("");
  return `<div class="card"><div class="ch">近期评分<span class="r">${rt.apps} 场 · 全场最佳 ${rt.best} 次${rt.observed ? ` · 实测 ${rt.observed} 场` : ""}</span></div>
    <div class="pd-rbars" title="最高 ${rt.high.toFixed(1)} · 最低 ${rt.low.toFixed(1)} · 实色＝实测数据评分，半透明＝模拟评分">${bars}</div></div>`;
}
/* 成长的三件事分开写（M7-G3，体验评审 §9.3）：永久能力（成长/衰退累计，每 4 轮结算）、近期状态（A–E，只影响下一场，不改能力）、
   球探评价（潜力区间，是估计不是保证）。短期进球多不等于能力突涨，短期没进球也不会永久降级；换卡时看“月度/半季”通知里写明哪些能力变了。 */
function pdDev(dev, f) {
  if (!dev) return "";
  const up = dev.up ? `<span class="up">+${dev.up}</span>` : "", down = dev.down ? `<span class="dn">−${dev.down}</span>` : "";
  const pot = Array.isArray(dev.potential) ? (dev.potential[0] === dev.potential[1] ? "已成熟" : `${dev.potential[0]}–${dev.potential[1]}`) : "—";
  const row = (k, v, s, t = "") => `<div class="pd-dv" title="${esc(t)}"><span>${k}</span><b>${v}</b><small>${s}</small></div>`;
  return `<div class="pd-devs">${row("永久能力", up || down ? `本季 ${up}${up && down ? " " : ""}${down}` : "本季无变化", dev.recent ? `最近 ${esc(dev.recent.text)}（${esc(dev.recent.when.split(" · ")[0])}）` : "正在观察", "成长与衰退的累计，每 4 轮结算一次")}
    ${row("近期状态", f ? `状态 ${esc(f.grade)}` : "—", "只影响下一场，不改变能力", "状态 A–E 由体能、近期表现决定")}
    ${row("球探评价", `潜力 ${pot}`, esc(dev.reason ? dev.reason.text : ""), "球探估计的区间，不是保证")}
    ${dev.talent && dev.talent.length ? `<div class="pd-dv" title="青训新人的天赋方向：成长按位置需要×天赋分配"><span>天赋方向</span><b>${talentChips(dev.talent, "sm")}</b><small>强项长得快，弱项长得慢</small></div>` : ""}</div>`;
}
// 球员详情：头像 ⇄ 卡面（2026-11-13）。右上角卡牌图标在原位翻转：小头像翻成宿主 /img/card/<pid>.png（card_art 实时合成，首次几秒，期间显示转圈），
// 再点翻回头像；合成不了就翻回来并提示。切到别的标签再回概况会回到头像。
// 视频卡（2026-11-13）：静态图（m01 缩略图底）先出；再取 <pid>.webm（游戏原生 VP9 视频）+ <pid>.over.png（边框/球员透明层），
// 视频真正开始播放后才淡入盖住静态图；取不到（静态卡、本机没这段视频）就安静地保持静态图。
// 宿主回的 .webm 有两种：VP9 WebM（<video> 播）或 Sofdec MPEG-1 原始流（WebView 不支持，由 mpeg1.js 解码画到 <canvas>），按开头字节区分。
let pdVideoUrl = null, pdMpeg = null;
// 卡面按钮与卡面层（我方球员详情与他队球探报告共用，2026-11-15）
const PD_CARD_BTN = (pid) => `<button class="pd-cardbtn" data-card="${esc(pid)}" aria-label="切换卡面" title="头像 / 卡面"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="2.5" width="12" height="19" rx="2"/><path d="M12 7.2l1.3 2.7 2.9.4-2.1 2 .5 2.9-2.6-1.4-2.6 1.4.5-2.9-2.1-2 2.9-.4z"/></svg></button>`;
const PD_ART = `<div class="pd-art"><img alt="" decoding="async"><div class="pd-live"><video muted loop playsinline preload="auto"></video><canvas class="pd-mpeg"></canvas><img class="pd-over" alt=""></div><div class="pd-wait"><i></i></div></div>`;
function pdLive(art, pid) {
  const live = $(".pd-live", art), video = live && $("video", live), canvas = live && $(".pd-mpeg", live), over = live && $(".pd-over", live);
  if (!video || !over) return;
  const base = `/img/card/${encodeURIComponent(pid)}`;
  fetch(`${base}.webm`).then((r) => r.ok ? r.arrayBuffer() : Promise.reject(r.status)).then((buf) => {
    if (!art.isConnected) return;
    const bytes = new Uint8Array(buf);
    let shown = 0; const reveal = () => { if (++shown === 2 && art.isConnected) art.classList.add("live"); };
    over.onload = reveal; over.onerror = () => {};    // no overlay -> never show a bare background
    over.src = `${base}.over.png`;
    const visible = art.closest(".pd-id")?.classList.contains("showcard");
    if (pdMpeg) { pdMpeg.pause(); pdMpeg = null; }
    if (bytes[0] === 0 && bytes[1] === 0 && bytes[2] === 1 && window.MPEG1 && canvas) {
      art.classList.add("mpeg");
      try { pdMpeg = MPEG1.play(bytes, canvas, reveal, () => art.classList.remove("live")); } catch (e) { return; }
      if (!visible) pdMpeg.pause();
      return;
    }
    art.classList.remove("mpeg");
    if (pdVideoUrl) URL.revokeObjectURL(pdVideoUrl);
    pdVideoUrl = URL.createObjectURL(new Blob([bytes], { type: "video/webm" }));
    video.addEventListener("playing", reveal, { once: true });
    video.src = pdVideoUrl;
    if (visible) video.play().catch(() => {});
  }).catch(() => {});
}
function pdFlip(pane, p) {
  const id = $(".pd-id", pane), art = $(".pd-art", pane), img = art && $("img", art); if (!id || !img) return;
  const on = !id.classList.contains("showcard");
  const video = $(".pd-live video", art);
  if (video && video.src) on ? video.play().catch(() => {}) : video.pause();
  if (pdMpeg && art.classList.contains("mpeg")) on ? pdMpeg.play() : pdMpeg.pause();
  if (on && !art.dataset.st) {                       // first time: ask the host to render it
    art.dataset.st = "loading"; art.classList.add("loading");
    img.onload = () => { art.dataset.st = "ready"; art.classList.remove("loading"); pdLive(art, p.pid); };
    img.onerror = () => {
      art.dataset.st = ""; art.classList.remove("loading"); id.classList.remove("showcard");
      // 宿主对不能渲染的卡会回一行原因（card_art 的 status: reason (kind)），读出来告诉用户，而不是只说“暂时没有”
      fetch(img.src, { cache: "no-store" }).then((r) => r.text()).then((t) => {
        const m = /^(\w+): (.*) \(kind (\d*)\)$/.exec(t.trim());
        const WHY = { missing_material: "本机游戏资源里缺这张卡的卡面素材", unsupported_rule: "这种卡（类型 " + (m && m[3]) + "）还没有卡面渲染规则", video_required: "这是视频卡面，无法静态渲染", review_required: "这种卡的卡面规则还在核对中" };
        toast(m && WHY[m[1]] ? `${WHY[m[1]]}${m[2] ? "：" + m[2] : ""}` : t.length < 120 && t !== "No card art" ? `卡面渲染失败：${t}` : "这张卡暂时没有可渲染的卡面");
      }).catch(() => toast("这张卡暂时没有可渲染的卡面"));
    };
    img.src = `/img/card/${encodeURIComponent(p.pid)}.png`;
  }
  id.classList.toggle("showcard", on); sound("cursor");
}
// 球员详情的二级页（2026-11-13）：数据全部来自 /api/player/<pid>（iml_player：卡片本身 + Player.bin AI 风格）；取不到时说明原因
let pdTab = 0;
const pdNone = () => `<div class="card"><div class="empty-note">这名球员的详细数据暂时读不到</div></div>`;
const abilColor = (v) => v >= 90 ? "#36d399" : v >= 80 ? "#a3e635" : v >= 70 ? "var(--draw)" : v >= 60 ? "#f08a4b" : "var(--ink3)";
/* 合同与身价（2026-11-14 用户：“这个做好一点吧 感觉可以做一些图形这种”）：四个小块——身价/周薪带“队内排名”条，潜力画“当前→潜力”，
   合同画剩余赛季格（每格一季，最多 5 格）。队内比较只用 biz("squad") 里同一份数据。 */
function pdMoney(b, p, x) {
  const all = Object.values((x && x.players) || {});
  const rank = (k) => b[k] == null ? null : 1 + all.filter((o) => (o[k] || 0) > b[k]).length;
  const max = (k) => Math.max(1, ...all.map((o) => o[k] || 0));
  const blk = (k, v, gfx, sub) => `<div class="pd-mb"><small>${k}</small><div class="mid">${gfx}<em>${sub}</em></div><b class="num">${v}</b></div>`;
  const meter = (v, mx, c) => `<div class="pd-mbar"><i style="width:${Math.max(3, Math.min(100, (v || 0) / mx * 100))}%;background:${c}"></i></div>`;
  const cur = p.overall || 0, pot = b.potential ?? null;
  const potBar = `<div class="pd-pot"><i class="cur" style="width:${Math.max(0, Math.min(100, (cur - 40) / 59 * 100))}%"></i>${pot != null && pot > cur ? `<i class="gain" style="left:${(cur - 40) / 59 * 100}%;width:${(pot - cur) / 59 * 100}%"></i>` : ""}</div>`;
  const season = (S && S.career && S.career.season) || 1, endYear = 2026 + season;        // 第 1 季 = 2026-27，季末 2027.06
  const left = b.until ? b.until - endYear + 1 : null;                                    // 含本季在内还剩几季
  const pips = left == null ? "" : `<div class="pd-pips">${Array.from({ length: 5 }, (_, i) => `<i class="${i < left ? (left <= 1 ? "end" : "on") : ""}"></i>`).join("")}</div>`;
  // 2026-11-14 用户：“要先把身价和周薪展示出来吧 队内对比是次要的”——两个大数字在上，队内排名只是下面一条细条＋小字
  const sml = (k, v, gfx, sub) => `<div class="pd-sml"><small>${k}<b class="num">${v}</b><i>${sub}</i></small>${gfx}</div>`;
  const big = (k, v, mtr, sub, cls) => `<div class="pd-big ${cls}"><small>${k}${sub ? `<i>${sub}</i>` : ""}</small><b class="num">${v}</b>${mtr}</div>`;
  return `<div class="pd-money">
    <div class="pd-bigs">${big("身价", money(b.value), meter(b.value, max("value"), "var(--gold)"), rank("value") ? `队内第 ${rank("value")}` : "", "val")}${big("周薪", kfmt(b.wage), meter(b.wage, max("wage"), "var(--blue)"), rank("wage") ? `队内第 ${rank("wage")}` : "", "wage")}</div>
    <div class="pd-smalls">${sml("潜力", pot ?? "—", potBar, pot == null ? "未评估" : pot > cur ? `+${pot - cur}` : "顶峰")}
    ${sml("合同", b.until ? `${b.until}.06` : "—", pips, left == null ? "" : left <= 1 ? "本季到期" : `剩 ${left} 季`)}</div>
    ${b.role ? `<div class="pd-role ${roleCls(b.role)}">定位：<b>${esc(roleTag(b.role))}</b><small>目标首发 ${Math.round(b.role.target * 100)}% · 没兑现的许诺会让续约更贵</small></div>` : ""}
  </div>`;                                                                                  // M6-E2：许诺的定位与本季首发
}/* 能力雷达（2026-11-14 用户“能力可以做一个五维图之类的”）：把游戏的细项能力归成六个轴（取平均），外场球员 速度/射门/传球/盘带/防守/身体，
   门将 意识/接球/解围/反应/扑救范围/出球。刻度 30–99（eFootball 能力很少低于 40，从 0 画会全挤在外圈）。有临时加减时虚线画原始值。 */
const PD_AXES = {
  field: [["速度", ["速度", "加速"]], ["射门", ["射门", "进攻意识", "头球"]], ["传球", ["地面传球", "空中传球", "弧线", "定位球"]],
    ["盘带", ["盘球", "控球", "紧密控球", "身体控制"]], ["防守", ["防守意识", "抢球", "积极性", "防守参与"]], ["身体", ["身体接触", "脚下力量", "跳跃", "体力"]]],
  gk: [["意识", ["守门意识"]], ["接球", ["接球"]], ["解围", ["解围"]], ["反应", ["扑救反应"]], ["扑救范围", ["扑救范围"]], ["出球", ["地面传球", "空中传球"]]],
};
function pdAxes(d) {
  const items = {}; (d.abilities || []).forEach((g) => g.items.forEach((x) => { items[x.label] = x; }));
  return PD_AXES[d.position === "GK" ? "gk" : "field"].map(([name, keys]) => {
    const xs = keys.map((k) => items[k]).filter(Boolean);
    return xs.length ? { name, value: Math.round(xs.reduce((s, x) => s + x.value, 0) / xs.length), base: Math.round(xs.reduce((s, x) => s + (x.base ?? x.value), 0) / xs.length) } : null;
  }).filter(Boolean);
}
function pdBest(d, n) {
  const gk = d.position === "GK";
  return (d.abilities || []).filter((g) => gk || g.group !== "门将").flatMap((g) => g.items).sort((a, b) => b.value - a.value).slice(0, n);
}
function pdRadar(d) {
  if (!d) return `<div class="empty-note">能力数据暂时读不到</div>`;
  const ax = pdAxes(d); if (ax.length < 3) return `<div class="empty-note">能力数据不足</div>`;
  const W = 210, H = 172, cx = 105, cy = 89, R = 60, LO = 30, HI = 99, n = ax.length;
  const pt = (i, v) => { const a = -Math.PI / 2 + i * 2 * Math.PI / n, r = R * Math.max(0, Math.min(1, (v - LO) / (HI - LO))); return [cx + r * Math.cos(a), cy + r * Math.sin(a)]; };
  const poly = (vals) => vals.map((v, i) => pt(i, v).map((z) => z.toFixed(1)).join(",")).join(" ");
  let g = "";
  for (const lv of [50, 70, 90, HI]) g += `<polygon points="${poly(ax.map(() => lv))}" class="rg${lv === HI ? " out" : ""}"/>`;
  ax.forEach((_, i) => { const [x, y] = pt(i, HI); g += `<line x1="${cx}" y1="${cy}" x2="${x.toFixed(1)}" y2="${y.toFixed(1)}" class="rs"/>`; });
  for (const lv of [50, 70, 90]) { const [, y] = pt(0, lv); g += `<text x="${cx + 3}" y="${(y + 3).toFixed(1)}" class="rt">${lv}</text>`; }
  const mod = ax.some((a) => a.base !== a.value);
  const labels = ax.map((a, i) => { const ang = -Math.PI / 2 + i * 2 * Math.PI / n, lx = cx + (R + 12) * Math.cos(ang), ly = cy + (R + 12) * Math.sin(ang) + (Math.sin(ang) > .5 ? 4 : 0);
    const anchor = Math.abs(Math.cos(ang)) < .2 ? "middle" : Math.cos(ang) > 0 ? "start" : "end";
    return `<text x="${lx.toFixed(1)}" y="${(ly - 2).toFixed(1)}" text-anchor="${anchor}" class="rl">${a.name}</text><text x="${lx.toFixed(1)}" y="${(ly + 10).toFixed(1)}" text-anchor="${anchor}" class="rv" style="fill:${abilColor(a.value)}">${a.value}</text>`; }).join("");
  return `<svg class="pd-radar" viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid meet">${g}
    ${mod ? `<polygon points="${poly(ax.map((a) => a.base))}" class="rb"/>` : ""}<polygon points="${poly(ax.map((a) => a.value))}" class="rp"/>
    ${ax.map((a, i) => { const [x, y] = pt(i, a.value); return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="2.6" class="rd"><title>${a.name} ${a.value}</title></circle>`; }).join("")}${labels}</svg>`;
}
function pdAbilities(d) {
  if (!d) return pdNone();
  const gk = d.position === "GK";
  const groups = d.abilities.filter((g) => gk ? true : g.group !== "门将").sort((a, b) => gk ? (a.group === "门将" ? -1 : b.group === "门将" ? 1 : 0) : 0);
  return `<div class="pd-abil2"><div class="card pd-radar-card" style="--i:0"><div class="ch">能力雷达</div><div class="pd-radar-box">${pdRadar(d)}</div></div><div class="pd-abil">${groups.map((g, gi) => `<div class="card" style="--i:${gi}"><div class="ch">${g.group}<span class="r num">${Math.round(g.items.reduce((s, x) => s + x.value, 0) / g.items.length)}</span></div>
    <div class="pd-alist">${g.items.map((x) => { const dlt = x.value - x.base;
      return `<div class="pd-arow"><span>${x.label}</span>${bar(x.value / 99 * 100, abilColor(x.value))}<b class="num" style="color:${abilColor(x.value)}">${x.value}</b>${dlt ? `<i class="${dlt > 0 ? "up" : "dn"}">${dlt > 0 ? "▲" : "▼"}${Math.abs(dlt)}</i>` : "<i></i>"}</div>`; }).join("")}</div></div>`).join("")}
    ${d.modified ? `<div class="pd-foot">▲▼ 为大师联赛中正在生效的临时加减（状态、伤病恢复等），比赛按加减后的数值进行</div>` : ""}</div></div>`;
}
const PD_SPOT = { GK: [6, 50], CB: [22, 50], LB: [25, 15], RB: [25, 85], DMF: [38, 50], CMF: [52, 50], LMF: [53, 14], RMF: [53, 86], AMF: [66, 50], LWF: [81, 16], RWF: [81, 84], SS: [78, 50], CF: [91, 50] };
function pdPositions(d) {
  if (!d) return pdNone();
  const lvl = (pos) => pos === d.position ? 3 : d.aptitude[pos] || 0;
  const names = (n) => Object.keys(PD_SPOT).filter((k) => k !== d.position && (d.aptitude[k] || 0) === n);
  return `<div class="pd-posv">
    <div class="card" style="--i:0"><div class="ch">位置适应<span class="r">登记位置 <b style="color:#fff">${esc(d.position || "—")}</b></span></div>
      <div class="pitch pd-pitch"><div class="circ"></div><div class="box" style="left:6px"></div><div class="box" style="right:6px"></div>
        ${Object.entries(PD_SPOT).map(([k, [x, y]]) => `<span class="pd-spot l${lvl(k)}" style="left:${x}%;top:${y}%">${k}</span>`).join("")}</div>
      <div class="pd-legend"><span><i class="l3"></i>登记位置</span><span><i class="l2"></i>熟练</span><span><i class="l1"></i>可以胜任</span><span><i class="l0"></i>不擅长</span></div></div>
    <div class="card" style="--i:1"><div class="ch">可踢位置</div><div class="pd-list">
      ${[["登记位置", d.position ? [d.position] : []], ["熟练", names(2)], ["可以胜任", names(1)]].map(([k, v]) => `<div class="pd-kv pd-poskv"><span>${k}</span><b>${v.length ? v.map((s) => pos(s)).join("") : "—"}</b></div>`).join("")}</div>
      <div class="pd-foot">站在熟练位置上能力完整发挥；可以胜任的位置会略有下降，不擅长的位置下降明显。</div></div></div>`;
}
function pdSkills(d) {
  if (!d) return pdNone();
  const block = (title, groups, note) => `<div class="card"><div class="ch">${title}<span class="r">${groups.reduce((s, g) => s + g.items.length, 0)} 个</span></div><div class="cb scroll">
    ${groups.length ? groups.map((g) => `<div class="pd-sg"><small>${g.group}</small><div class="pd-chips">${g.items.map((s) => `<span class="pd-chip">${esc(s.label)}</span>`).join("")}</div></div>`).join("") : `<div class="empty-note">${note}</div>`}</div></div>`;
  return `<div class="pd-skills">${block("固有技能", d.skills.innate, "没有固有技能")}${block("附加技能", d.skills.additional, "还没有学会附加技能（训练可学习）")}</div>`;
}
function pdStyles(d) {
  if (!d) return pdNone();
  const src = d.ai_source === "player-bin" ? "来自游戏球员数据" : "来自卡片数据";
  return `<div class="pd-styles">
    <div class="card" style="--i:0"><div class="ch">球员风格</div><div class="pd-ps">
      <div><small>进攻</small><b>${esc(d.play_style.attack)}</b></div><div><small>防守</small><b>${esc(d.play_style.defense)}</b></div></div>
      <div class="pd-foot">决定球员在场上的跑位和参与方式。</div></div>
    <div class="card" style="--i:1"><div class="ch">AI 比赛风格<span class="r">${d.ai_styles.filter((s) => s.on).length} / 7 · ${src}</span></div>
      <div class="pd-ai">${d.ai_styles.map((s) => `<span class="pd-aichip${s.on ? " on" : ""}">${s.on ? svg("check", 2.6) : ""}${esc(s.label)}</span>`).join("")}</div>
      <div class="pd-foot">由电脑控制时（队友 AI、对手 AI）这名球员倾向的打法。</div></div></div>`;
}

/* ---- 他队资料页（2026-11-14 用户：“看别的球队时候的界面 做成类FM那样的 有很多信息可以看的”） ----
   点任意 [data-team]（积分榜、赛程、战报……）打开；我队仍跳“球队”页。整页换成对方主色，五个标签：
     概况 —— 身份卡（主帅/球场/建队/近况）、六项关键数据（带我队对比）、近期赛果与赛程、积分榜邻近区、核心球员
     阵容 —— 该队实际出场的卡（/api/team 的 served），年龄/潜力/身价/周薪按转会市场同一模型估算；可筛位置、点表头排序
     赛程 —— 全季赛程与比分（点已赛场次看战报）、本季逐轮名次走势
     数据 —— 主客场战绩、赛季之最、与我队交手、队内射手/助攻（CPU 每轮记录，与射手榜同源）
     荣誉 —— 现实奖杯展柜 + 现实联赛名次走势（iml_club_history，只有五大联赛球队有；不算本生涯）
   数据都是真的或明确标“估算”；没有的（如他队合同年限、财务）不编。 */
let cpTab = 0, cpGrp = "全部", cpSort = { k: "pos", d: 1 }, cpCtx = null, cpCupPick = -1;
const CP_TABS = ["概况", "阵容", "赛程", "数据", "荣誉", "转会"];      // 转会（M8-W4）：世界里的预算、转入转出、合同

const cpView = (f, tid) => {                               // 一场比赛从 tid 的角度看
  const home = f.home === tid, r = f.result;
  const v = { f, home, opp: home ? f.away : f.home };
  if (r) { v.gf = home ? r.home_goals : r.away_goals; v.ga = home ? r.away_goals : r.home_goals; v.res = v.gf > v.ga ? "W" : v.gf < v.ga ? "L" : "D"; }
  return v;
};
const cpDate = (d) => d ? `${+d.slice(5, 7)}/${+d.slice(8, 10)}` : "";
const cpAvg = (xs) => xs.length ? xs.reduce((s, x) => s + x, 0) / xs.length : null;
const cpOne = () => 1;
const cpFix = (v, d = 1) => v == null || isNaN(v) ? "—" : (+v).toFixed(d);

/* 数据卡与小图（他队资料页、我队“球队 · 概况”共用）。2026-11-14 用户：“加一些图形”→“别的球队的概况也显示‘我队’、图例不够直观”：
   参照一律是“联赛平均”（不再拿我队比）；每个小图自带说明——刻度两端写字、图例一行、胜平负条里直接写数、实力写“联赛第几强”。 */
const cpTile = (k, v, sub, gfx, cls = "", attr = "") => `<div class="cp-tile ${cls}"${attr}><div class="cp-tt"><small>${k}</small><b class="num">${v}</b><em title="${sub || ""}">${sub || ""}</em></div>${gfx || ""}</div>`;
// 排名：整条联赛刻度（左＝第 1，右＝第 n），前四绿、降级区红，本队高亮；下方写两端与区间含义
function cpLadder(n, pos) {
  const rel = n >= 16 ? 3 : 0;
  return `<div class="cp-ladder">${Array.from({ length: n }, (_, i) => { const p = i + 1;
    return `<i class="${p <= 4 ? "z1" : p > n - rel ? "z3" : ""}${p === pos ? " it" : ""}" title="第 ${p} 名"></i>`; }).join("")}</div>
    <div class="cp-axis"><span class="z1">第 1 · 前四</span>${rel ? `<span class="z3">降级区 · 第 ${n}</span>` : `<span>第 ${n}</span>`}</div>`;
}
// 胜平负比例条，段里直接写场数
function cpWdl(w = 0, d = 0, l = 0) {
  const all = Math.max(1, w + d + l), seg = (k, v, t) => v ? `<i class="${k}" style="flex:${v / all}" title="${v} 场${t}">${v / all >= .14 ? `${v}${t}` : ""}</i>` : "";
  return `<div class="cp-wdl">${seg("W", w, "胜")}${seg("D", d, "平")}${seg("L", l, "负")}</div>`;
}
// 圆环：中间数字，下面一行小字说明是什么
const cpRing = (v, max, txt, color, cap) => `<div class="cp-ring" style="--v:${Math.max(0, Math.min(1, (v || 0) / max)) * 100}${color ? `;--rc:${color}` : ""}"><span class="num">${txt}</span>${cap ? `<small>${cap}</small>` : ""}</div>`;
// 近 10 场每场进/失球小柱；虚线＝联赛场均。上方一行图例
function cpCols(last, key, cls, ref) {
  const mx = Math.max(3, ...last.map((g) => g[key]));
  return `<div class="cp-cap"><span><i class="sw ${cls}"></i>近 ${last.length} 场</span>${ref != null ? `<span><i class="dash"></i>联赛均 ${cpFix(ref)}</span>` : ""}</div>
    <div class="cp-cols ${cls}">${last.map((g) => `<i style="height:${Math.max(6, g[key] / mx * 100)}%" class="${g[key] ? "" : "z"}" title="第 ${g.f.round} 轮 ${g.gf}-${g.ga}"></i>`).join("")}
    ${ref != null ? `<s style="bottom:${Math.min(100, ref / mx * 100)}%"></s>` : ""}</div>`;
}
// 刻度条：两端写最低/最高，实心点＝本队，竖线＝联赛平均
function cpScale(lo, hi, v, avg, fmt = (x) => Math.round(x)) {
  const pct = (x) => Math.max(0, Math.min(100, (x - lo) / Math.max(1e-6, hi - lo) * 100));
  return `<div class="cp-scale"><div class="cp-cap"><span><i class="sdot"></i>本队</span>${avg != null ? `<span><i class="sbar"></i>联赛均 ${fmt(avg)}</span>` : ""}</div><div class="tr"><i class="fill" style="width:${pct(v)}%"></i>${avg != null ? `<b class="avg" style="left:${pct(avg)}%" title="联赛平均 ${fmt(avg)}"></b>` : ""}<i class="dot" style="left:${pct(v)}%"></i></div>
    <div class="cp-axis"><span>最弱 ${fmt(lo)}</span><span>最强 ${fmt(hi)}</span></div></div>`;
}
// 阵容构成：门/后/中/前 堆叠条（by＝cpOne 按人数，否则按占比）
function cpMix(squad, by) {
  const g = { GK: 0, DF: 0, MF: 0, FW: 0 }; squad.forEach((p) => { const k = p.group || grp(p.position); if (g[k] != null) g[k] += by(p); });
  const all = Object.values(g).reduce((s, x) => s + x, 0) || 1;
  return `<div class="cp-mix">${Object.entries(g).map(([k, v]) => `<i class="${k}" style="flex:${v / all}" title="${k} ${Math.round(v / all * 100)}%"></i>`).join("")}</div><div class="cp-mixl">${Object.entries(g).map(([k, v]) => `<span class="${k}">${k} ${by === cpOne ? v : Math.round(v / all * 100) + "%"}</span>`).join("")}</div>`;
}
// 联赛平均与实力排名（两张概况共用）
function cpLeague() {
  const lg = S.table || [], games = lg.reduce((s, r) => s + (r.played || 0), 0);
  const strs = Object.values(S.teams || {}).map((x) => x.strength).filter(Boolean);
  return { goals: games ? lg.reduce((s, r) => s + (r.gf || 0), 0) / games : null, strs, sMin: Math.min(...strs), sMax: Math.max(...strs), sAvg: cpAvg(strs),
    strengthRank: (tid) => 1 + strs.filter((x) => x > (T(tid).strength || 0)).length };
}
// 普通进度条（预算/薪资空间等）：v / max，超出标红
const cpMeter = (v, max, color) => `<div class="cp-meter"><i style="width:${Math.max(0, Math.min(100, (v || 0) / (max || 1) * 100))}%;${color ? `background:${color}` : ""}"></i></div>`;
/* 球场照片（2026-11-14 用户：“接入一下这些球队的球场图片吧 放到概况里”）：身份卡顶部横幅，队徽压在照片下沿；
   横幅上不放署名（2026-11-14 用户：“图片下面的小字去掉”），出处只在大图里：Wikimedia 照片标作者与许可（多数 CC BY / BY-SA 要求署名），StadiumDB 补图标“许可待核”。点照片看大图与完整出处。 */
const cpPhotos = {};
const cpCredit = (ph) => ph.open ? `摄影 ${esc(ph.author || "佚名")} · ${esc(ph.license || "")}` : `图源 ${esc(ph.provider || "未知")} · 许可待核`;
function cpHero(tid, hist) {
  const ph = hist && hist.photo;
  if (!ph) return crest(tid, "xl");
  cpPhotos[tid] = ph;
  return `<div class="cp-hero" data-cpphoto="${tid}" title="${esc(ph.name)} · 点击看大图"><img src="/${esc(ph.img)}" alt="" onerror="this.parentNode.classList.add('nophoto')">
    <span class="cp-hero-st">${esc(ph.name)}</span>${crest(tid, "lg")}</div>`;
}
function cpPhoto(tid) {
  const ph = cpPhotos[tid]; if (!ph) return;
  sound("open");
  const el = document.createElement("div");
  el.className = "cp-lightbox";
  el.innerHTML = `<figure><img src="/${esc(ph.img)}" alt=""><figcaption><b>${crest(tid, "sm")} ${esc(ph.name)}</b><span>${esc(tname(tid))} 主场</span>
    <small>${cpCredit(ph)}${ph.date ? ` · 摄于 ${esc(ph.date)}` : ""}</small><small class="muted">${esc(ph.provider)}${ph.source ? ` · ${esc(ph.source)}` : ""}</small>
    <small class="muted">建筑参考照片，拍摄时间可能较早，不代表本季看台与赞助标识${ph.open ? "" : "；该图源未列开放许可，分发条件待核"}</small></figcaption></figure>`;
  el.onclick = () => { sound("close"); el.remove(); };
  document.body.appendChild(el);
}
addEventListener("click", (e) => { const el = e.target.closest && e.target.closest("[data-cpphoto]"); if (el) { e.stopPropagation(); cpPhoto(+el.dataset.cpphoto); } });
const cpRes = (g) => `<tr data-fx="${g.f.id}"><td class="cp-rd">${g.f.round}</td><td class="c cp-ha">${g.home ? "主" : "客"}</td><td class="name">${crest(g.opp, "sm")} ${esc(tname(g.opp))}</td><td class="n">${g.res ? `<span class="cp-sc ${g.res}">${g.gf}-${g.ga}</span>` : `<span class="muted">${cpDate(g.f.date)}</span>`}</td></tr>`;

async function openTeam(tid) {
  if (tid === me()) { sound("page"); return openSec("squad", 0, { silent: true }); }
  sound("page");
  let t, hist;
  let mk = null;
  try { [t, hist, mk] = await Promise.all([team(tid, true), clubInfo(tid), biz("market").catch(() => null)]); }
  catch (e) { return toast(`球队资料读取失败：${e.message}`); }
  const games = (t.fixtures || []).map((f) => cpView(f, tid));
  const played = games.filter((g) => g.res), upcoming = games.filter((g) => !g.res);
  const real = !!t.served, xi = t.squad.filter((p) => p.starter);
  const sum = (k) => t.squad.reduce((s, p) => s + (p[k] || 0), 0);
  const ages = t.squad.map((p) => p.age).filter((a) => a != null);
  // ref：星级参照（iml_market.star_ref＝3 星的 CA；2026-11-15 起全联赛统一刻度）；t.foreign＝其他联赛的球队（2026-11-15 用户“别的联赛的球队资料点不开”），排名/积分取它自己联赛的表行 t.row
  cpCtx = { tid, t, hist, real, games, played, upcoming, rr: t.foreign ? t.row || {} : row(tid) || {}, ref: mk && !mk.demo ? mk.star_ref : null,
    n: t.foreign ? t.teams_n || 20 : (S.table || []).length || t.teams_n || 20,
    xiAvg: real ? cpAvg(xi.map((p) => p.overall).filter(Boolean)) : null,
    value: t.squad.some((p) => p.value != null) ? sum("value") : null, wage: t.squad.some((p) => p.wage != null) ? sum("wage") : null,
    age: cpAvg(ages) };
  cpCupPick = -1;
  const rr = cpCtx.rr;
  openLayer(`${crest(tid, "sm")} ${esc(tname(tid))}`, `${esc(t.league_name || S.career.league_name || "")} · 第 ${rr.position || "—"} 名 · ${rr.points ?? 0} 分`,
    `${HALL_DEFS}<div class="pd-wrap cp" style="--club:${tcolor(tid)};--club-ink:${T(tid).ink || "#fff"}"><nav class="pd-nav">${CP_TABS.map((x, i) => `<button class="pd-tab" data-cpt="${i}">${x}</button>`).join("")}</nav><div class="pd-pane" id="cppane"></div></div>`);
  $$("[data-cpt]").forEach((b) => b.onclick = () => { if (+b.dataset.cpt !== cpTab) sound("cursor"); cpShow(+b.dataset.cpt); });
  cpShow(cpTab < CP_TABS.length ? cpTab : 0);
}

function cpShow(i, quiet) {
  cpTab = i;
  $$("[data-cpt]").forEach((b) => b.classList.toggle("on", +b.dataset.cpt === i));
  const pane = $("#cppane"); if (!pane || !cpCtx) return;
  pane.innerHTML = [cpOverview, cpSquad, cpFixtures, cpStats, cpHonours, cpTransfers][i](cpCtx);
  if (cpCtx.t.foreign) $$("[data-fx]", pane).forEach((el) => { el.removeAttribute("data-fx"); el.style.cursor = "default"; });   // 其他联赛只有比分，没有战报
  bindPage(pane); if (!quiet) animate(pane); else $$(".view > *", pane).forEach((x) => { x.style.animation = "none"; });
  cpBind(pane);
}

function cpBind(pane) {
  const c = cpCtx;
  $$("[data-cpg]", pane).forEach((el) => el.onclick = () => { cpGrp = el.dataset.cpg; sound("cursor"); cpShow(1, true); });
  $$("[data-cps]", pane).forEach((el) => el.onclick = () => { const k = el.dataset.cps; cpSort = { k, d: cpSort.k === k ? -cpSort.d : (k === "pos" || k === "age" ? 1 : -1) }; sound("cursor"); cpShow(1, true); });
  $$("[data-cpgo]", pane).forEach((el) => el.onclick = () => { sound("cursor"); cpShow(+el.dataset.cpgo); });
  $$("[data-cpp]", pane).forEach((el) => el.onclick = (e) => { e.stopPropagation(); openRivalPlayer(c.tid, el.dataset.cpp); });     // 他队球员资料
  $$("[data-cpcup]", pane).forEach((el) => el.onclick = () => {
    const i = +el.dataset.cpcup; cpCupPick = cpCupPick === i ? -1 : i; sound("cursor");
    $$("[data-cpcup]", pane).forEach((b) => b.classList.toggle("on", +b.dataset.cpcup === cpCupPick));
    const box = $(".hall-detail", pane); if (box) box.innerHTML = cpCupDetail(c);
  });
  $$("[data-cptr]", pane).forEach((el) => el.onclick = () => {
    hallRange = +el.dataset.cptr; sound("cursor");
    $$("[data-cptr]", pane).forEach((b) => b.classList.toggle("on", +b.dataset.cptr === hallRange)); cpDrawCharts(pane);
  });
  const nx = $(".cp-fx tr.next", pane); if (nx) { const box = nx.closest(".scroll"); box.scrollTop = Math.max(0, nx.offsetTop - box.clientHeight / 2); }
  requestAnimationFrame(() => cpDrawCharts(pane));
}

// 图按实际框大小画（像素坐标，手机两种尺寸都不变形）
function cpDrawCharts(pane) {
  const c = cpCtx; if (!c) return;
  const pb = $(".cp-posbox", pane);
  if (pb) pb.innerHTML = cpPosSvg(c, Math.max(220, pb.clientWidth - 8), Math.max(100, pb.clientHeight - 4));
  const gb = $(".cp-gbox", pane);
  if (gb) gb.innerHTML = cpGoalsSvg(c, Math.max(220, gb.clientWidth - 8), Math.max(50, gb.clientHeight - 4));
  const hb = $(".cp-hallbox", pane);
  if (hb && c.hist) hb.innerHTML = trendSvg({ real: { positions: c.hist.all_positions || c.hist.positions }, seasons: [] }, Math.max(200, hb.clientWidth - 12), Math.max(120, hb.clientHeight - 6));
}

/* ---------- 概况 ---------- */
// 两张概况共用的前五块：排名 / 积分 / 进球 / 失球 / 实力（参照都是联赛平均）；第六块（身价或人数）由调用方给
function cpCoreTiles(tid, rr, n, played, xiAvg) {
  const L = cpLeague(), gp = (rr.played || 0) || 1, last = played.slice(-10), cs = played.filter((g) => g.ga === 0).length;
  const tb = S.table || [], lead = tb[0], second = tb[1];
  const gap = !lead || !rr.position ? "" : rr.position === 1 ? (second ? `领先第二 ${(rr.points || 0) - (second.points || 0)} 分` : "") : `落后榜首 ${(lead.points || 0) - (rr.points || 0)} 分`;
  const rate = rr.played ? (rr.points || 0) / (3 * rr.played) * 100 : 0, str = T(tid).strength || 0;
  return [
    cpTile("联赛排名", rr.position ? `${rr.position}<span>/${n}</span>` : "—", gap, cpLadder(n, rr.position)),
    cpTile("积分", rr.points ?? 0, `${cpFix((rr.points || 0) / gp, 2)}/场`, `${cpRing(rate, 100, `${Math.round(rate)}%`, null, "得分率")}${cpWdl(rr.won, rr.drawn, rr.lost)}`),
    cpTile("进球", rr.gf ?? 0, `场均 ${cpFix((rr.gf || 0) / gp)}`, last.length ? cpCols(last, "gf", "gf", L.goals) : ""),
    cpTile("失球", rr.ga ?? 0, `场均 ${cpFix((rr.ga || 0) / gp)} · 零封 ${cs}`, last.length ? cpCols(last, "ga", "ga", L.goals) : ""),
    cpTile("球队实力", str || "—", `第${L.strengthRank(tid)}强${xiAvg != null ? ` · 首发 ${cpFix(xiAvg)}` : ""}`, L.strs.length ? cpScale(L.sMin, L.sMax, str, L.sAvg) : ""),
  ].join("");
}
// 他队资料页
function cpOverview(c) {
  const { tid, t, hist, rr, played, upcoming } = c;
  // 六块数据卡：前五块与我队概况共用 cpCoreTiles（参照联赛平均，2026-11-14 用户“别的球队的概况也显示我队”）
  const tiles = cpCoreTiles(tid, rr, c.n, played, c.xiAvg) + (c.value != null ? cpTile("阵容身价 · 估算", money(c.value, 0), `周薪 ${kfmt(c.wage)}`, cpMix(t.squad, (p) => p.value || 0))
    : cpTile("阵容人数", t.squad.length, "游戏自带名单", cpMix(t.squad, cpOne)));
  // 2026-11-14 用户：“把积分榜去掉吧 球队详情这里”——右栏只放核心球员
  const key = [...t.squad].sort((a, b) => (b.overall || 0) - (a.overall || 0) || (b.tier || 0) - (a.tier || 0)).slice(0, 8);   // 2026-11-14 用户：核心球员只显示头像
  const top = (t.scorers || [])[0];
  const res = (g) => `<tr data-fx="${g.f.id}"><td class="cp-rd">${g.f.round}</td><td class="c cp-ha">${g.home ? "主" : "客"}</td><td class="name">${crest(g.opp, "sm")} ${esc(tname(g.opp))}</td><td class="n">${g.res ? `<span class="cp-sc ${g.res}">${g.gf}-${g.ga}</span>` : `<span class="muted">${cpDate(g.f.date)}</span>`}</td></tr>`;
  return `<div class="view cp-ov">
    <div class="card cp-id${hist && hist.photo ? " has-photo" : ""}" style="--i:0">${cpHero(tid, hist)}<b class="cp-name">${esc(tname(tid))}</b><small class="muted">${esc(T(tid).latin || "")}</small>
      ${form(rr.form)}
      <div class="pd-list">
        ${hist && hist.coach ? `<div class="pd-kv cp-coach"><span>主帅</span><b>${coachFace(hist.coach)}${esc(hist.coach.name)}</b></div>` : ""}
        ${hist && hist.stadium && !hist.photo ? `<div class="pd-kv"><span>主场</span><b title="${esc(hist.stadium)}">${esc(hist.stadium)}</b></div>` : ""}
        ${hist && hist.founded ? `<div class="pd-kv"><span>建队</span><b>${hist.founded} 年</b></div>` : ""}
        ${hist && hist.total ? `<div class="pd-kv cp-link" data-cpgo="4"><span>主要奖杯</span><b><em class="cp-gold">${hist.total}</em> 座 ›</b></div>` : ""}
        ${c.age != null ? `<div class="pd-kv"><span>平均年龄</span><b>${cpFix(c.age)} 岁</b></div>` : ""}
      </div></div>
    <div class="cp-mid" style="--i:1">
      <div class="cp-tiles">${tiles}</div>
      <div class="card cp-keycard"><div class="ch">核心球员${top && top.goals ? `<span class="cp-topl">${svg("ball", 1.6)}队内射手 <b>${esc(top.name)}</b> <em>${top.goals} 球${top.assists ? ` · ${top.assists} 助` : ""}</em></span>` : ""}<span class="r cp-link" data-cpgo="1">阵容 ›</span></div>
        <div class="cb cp-keys cp-keys2">${key.map((p) => `<div class="cp-key cp-face" data-cpp="${esc(p.pid)}" title="${esc(p.name)} · ${esc(p.position || p.group || "")}${c.real && p.overall ? " · " + p.overall : ""}">${pface(p)}</div>`).join("")}</div></div>
    </div>
    <div class="cp-side" style="--i:2">
      ${played.length ? `<div class="card"><div class="ch">近期赛果<span class="r cp-link" data-cpgo="2">全部 ›</span></div><div class="cb scroll"><table class="cp-mini">${played.slice(upcoming.length ? -5 : -10).reverse().map(res).join("")}</table></div></div>` : ""}
      ${upcoming.length ? `<div class="card"><div class="ch">接下来<span class="r cp-link" data-cpgo="2">赛程 ›</span></div><div class="cb scroll"><table class="cp-mini">${upcoming.slice(0, played.length ? 5 : 10).map(res).join("")}</table></div></div>` : ""}
    </div></div>`;
}

/* ---------- 阵容 ---------- */
const CP_GO = { GK: 0, DF: 1, MF: 2, FW: 3 };
function cpSquad(c) {
  const { t, real } = c;
  const list = t.squad.filter((p) => cpGrp === "全部" || p.group === cpGrp);
  const key = { pos: (p) => (p.starter ? 0 : 10) + (CP_GO[p.group] ?? 9), ovr: (p) => p.overall || p.tier || 0, age: (p) => p.age ?? 99, pot: (p) => (p.potential || [])[1] || 0, value: (p) => p.value || 0, wage: (p) => p.wage || 0 }[cpSort.k] || (() => 0);
  list.sort((a, b) => (key(a) - key(b)) * cpSort.d || (b.overall || 0) - (a.overall || 0));
  const th = (k, label, cls = "") => `<th class="${cls} cp-sort${cpSort.k === k ? " on" : ""}" data-cps="${k}">${label}${cpSort.k === k ? (cpSort.d > 0 ? " ▲" : " ▼") : ""}</th>`;
  const est = list.some((p) => p.value != null);
  const rows = list.map((p) => {
    const tip = [p.filler ? "补位（库里没有该队这个位置的球员）" : "", p.card_type, p.version].filter(Boolean).join(" · ");
    const pot = p.potential ? (p.potential[0] === p.potential[1] ? p.potential[1] : `${p.potential[0]}-${p.potential[1]}`) : "—";
    return `<tr class="cp-prow${p.starter ? "" : " dim"}" data-cpp="${esc(p.pid)}"${tip ? ` title="${esc(tip)}"` : ""}><td>${pos(p.position, p.group)}</td><td class="name">${pface(p)}<b>${esc(p.name)}</b>${p.card_type ? `<i class="cp-ct">${esc(p.card_type)}</i>` : ""}</td>
      ${real ? `<td class="n">${p.age ?? "—"}</td><td>${c.ref != null ? starsHtml(starVal(p.ca, c.ref)) : ovr(p.overall)}</td><td class="n">${c.ref != null && p.ca_pot ? starsHtml(starVal(p.ca_pot[0], c.ref), starVal(p.ca_pot[1], c.ref), "pot") : pot}</td><td class="n">${p.value != null ? money(p.value) : "—"}</td><td class="n">${p.wage != null ? kfmt(p.wage) : "—"}</td>` : `<td>${stars(p.tier)}</td>`}
      <td class="c cp-st">${p.starter ? "首发" : "替补"}</td></tr>`;
  }).join("");
  const grpN = (g) => g === "全部" ? t.squad.length : t.squad.filter((p) => p.group === g).length;
  return `<div class="view cp-sq">
    <div class="cp-strip" style="--i:0">
      <div class="seg cp-seg">${["全部", "GK", "DF", "MF", "FW"].map((g) => `<button data-cpg="${g}" class="${cpGrp === g ? "on" : ""}">${g === "全部" ? "全部" : g}<i>${grpN(g)}</i></button>`).join("")}</div>
      <span><small>人数</small><b class="num">${t.squad.length}</b></span>
      ${c.age != null ? `<span><small>平均年龄</small><b class="num">${cpFix(c.age)}</b></span>` : ""}
      ${c.xiAvg != null ? `<span><small>首发均分</small><b class="num">${cpFix(c.xiAvg)}</b></span>` : ""}
      ${c.value != null ? `<span><small>身价 · 估算</small><b class="num">${money(c.value, 0)}</b></span><span><small>周薪合计</small><b class="num">${kfmt(c.wage)}</b></span>` : ""}
    </div>
    <div class="card" style="--i:1"><div class="cb scroll"><table class="cp-sqt"><thead><tr>${th("pos", "位置")}<th>球员</th>
      ${real ? `${th("age", "年龄", "n")}${th("ovr", "总评")}${th("pot", "潜力", "n")}${th("value", "身价", "n")}${th("wage", "周薪", "n")}` : th("ovr", "档位")}<th class="c">阵容</th></tr></thead><tbody>${rows}</tbody></table></div>
      <div class="pd-foot">${real ? `按该队本季实际出场的卡显示；总评为满级总评${est ? "；身价、周薪、潜力按转会市场同一模型估算" : ""}` : "该队用游戏自带名单：星级为能力档位，没有精确能力值"}</div></div></div>`;
}

/* ---------- 赛程 ---------- */
function cpFixtures(c) {
  const { games, played } = c;
  const nextId = (c.upcoming[0] || {}).f?.id;
  const rows = games.map((g) => `<tr class="${g.f.id === nextId ? "next" : ""}${g.res ? "" : " dim"}${g.opp === me() ? " me" : ""}"${g.res ? ` data-fx="${g.f.id}"` : ""}>
    <td class="cp-rd">${g.f.round}</td><td class="muted">${cpDate(g.f.date)}</td><td class="c cp-ha">${g.home ? "主" : "客"}</td>
    <td class="name" data-team="${g.opp}">${crest(g.opp, "sm")} ${esc(tname(g.opp))}</td>
    <td class="c">${g.res ? `<span class="cp-sc ${g.res}">${g.gf}-${g.ga}</span>` : g.f.id === nextId ? `<span class="cp-nx">下一场</span>` : "—"}</td></tr>`).join("");
  const tr = c.t.pos_trend || [], ps = tr.map((x) => x.pos).filter(Boolean);
  return `<div class="view cp-fxv">
    <div class="card" style="--i:0"><div class="ch">本季赛程<span class="r">${played.length} / ${games.length} 轮已赛</span></div><div class="cb scroll"><table class="cp-fx">${rows}</table></div></div>
    <div class="cp-charts" style="--i:1">
      <div class="card"><div class="ch">名次走势<span class="r">${ps.length ? `最高 第 ${Math.min(...ps)} 名 · 最低 第 ${Math.max(...ps)} 名` : "开赛后显示"}</span></div><div class="cb cp-posbox"></div></div>
      <div class="card"><div class="ch">每轮进失球<span class="r"><i class="lg-dot" style="background:var(--win)"></i>进 <i class="lg-dot" style="background:var(--loss)"></i>失</span></div><div class="cb cp-gbox"></div></div>
    </div></div>`;
}
function cpPosSvg(c, W, H) {
  const tr = (c.t.pos_trend || []).filter((x) => x.pos), N = c.n, R = c.games.length || 38;
  if (!tr.length) return `<div class="empty-note">开赛后按轮显示名次</div>`;
  const L = 22, Rm = 6, Tm = 6, B = 14;
  const x = (r) => L + (r - 1) / Math.max(1, R - 1) * (W - L - Rm), y = (p) => Tm + (p - 1) / Math.max(1, N - 1) * (H - Tm - B);
  const top = Math.min(4, N), rel = N >= 16 ? 3 : 0;
  let g = `<rect x="${L}" y="${Tm}" width="${W - L - Rm}" height="${y(top + .5) - Tm}" class="z-top"/>`;
  if (rel) g += `<rect x="${L}" y="${y(N - rel + .5)}" width="${W - L - Rm}" height="${H - B - y(N - rel + .5)}" class="z-rel"/>`;
  for (const p of [1, Math.round(N / 2), N]) g += `<text x="${L - 4}" y="${y(p) + 3}" class="tl">${p}</text><line x1="${L}" x2="${W - Rm}" y1="${y(p)}" y2="${y(p)}" class="vg"/>`;
  for (let r = 5; r <= R; r += 5) g += `<text x="${x(r)}" y="${H - 3}" class="xl">${r}</text>`;
  const pts = tr.map((p) => `${x(p.round).toFixed(1)},${y(p.pos).toFixed(1)}`).join(" ");
  const last = tr[tr.length - 1];
  return `<svg class="trend cp-pos" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">${g}<polyline points="${pts}" class="ln car"/>
    ${tr.map((p) => `<circle cx="${x(p.round).toFixed(1)}" cy="${y(p.pos).toFixed(1)}" r="${p === last ? 3.4 : 1.8}" class="car"><title>第 ${p.round} 轮后 第 ${p.pos} 名</title></circle>`).join("")}
    <text x="${Math.min(W - Rm - 2, x(last.round) + 6)}" y="${y(last.pos) - 5}" class="ct" text-anchor="${x(last.round) > W - 40 ? "end" : "start"}">第 ${last.pos} 名</text></svg>`;
}
function cpGoalsSvg(c, W, H) {
  const p = c.played; if (!p.length) return `<div class="empty-note">开赛后显示</div>`;
  const R = c.games.length || 38, mx = Math.max(3, ...p.map((g) => Math.max(g.gf, g.ga))), mid = H / 2, bw = Math.max(2, (W - 8) / R - 2);
  const x = (r) => 4 + (r - 1) * (W - 8) / R;
  return `<svg class="trend" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}"><line x1="0" x2="${W}" y1="${mid}" y2="${mid}" class="vg"/>
    ${p.map((g) => `<g><title>第 ${g.f.round} 轮 ${g.home ? "主" : "客"} vs ${esc(tname(g.opp))} ${g.gf}-${g.ga}</title>${g.gf ? `<rect x="${x(g.f.round).toFixed(1)}" y="${(mid - g.gf / mx * (mid - 2)).toFixed(1)}" width="${bw.toFixed(1)}" height="${(g.gf / mx * (mid - 2)).toFixed(1)}" class="gf"/>` : ""}${g.ga ? `<rect x="${x(g.f.round).toFixed(1)}" y="${mid}" width="${bw.toFixed(1)}" height="${(g.ga / mx * (mid - 2)).toFixed(1)}" class="ga"/>` : ""}</g>`).join("")}</svg>`;
}

/* ---------- 数据 ---------- */
function cpStats(c) {
  const { tid, played, games } = c;
  const line = (gs) => { const w = gs.filter((g) => g.res === "W").length, d = gs.filter((g) => g.res === "D").length, l = gs.length - w - d, gf = gs.reduce((s, g) => s + g.gf, 0), ga = gs.reduce((s, g) => s + g.ga, 0); return { n: gs.length, w, d, l, gf, ga, pts: w * 3 + d }; };
  const split = [["主场", line(played.filter((g) => g.home))], ["客场", line(played.filter((g) => !g.home))], ["总计", line(played)]];
  const streak = (ok) => { let best = 0, cur = 0; for (const g of played) { cur = ok(g) ? cur + 1 : 0; best = Math.max(best, cur); } return best; };
  const pick = (cmp) => played.reduce((b, g) => !b || cmp(g, b) ? g : b, null);
  const big = pick((g, b) => g.gf - g.ga > b.gf - b.ga || (g.gf - g.ga === b.gf - b.ga && g.gf > b.gf));
  const worst = pick((g, b) => g.ga - g.gf > b.ga - b.gf || (g.ga - g.gf === b.ga - b.gf && g.ga > b.ga));
  const most = pick((g, b) => g.gf + g.ga > b.gf + b.ga);
  const gm = (g) => g ? `<b data-fx="${g.f.id}" class="cp-link"><span class="cp-sc ${g.res}">${g.gf}-${g.ga}</span> ${g.home ? "主" : "客"} ${esc(tname(g.opp))}</b>` : "<b>—</b>";
  const kv = (k, v) => `<div class="pd-kv"><span>${k}</span>${v}</div>`;
  const rec = played.length ? [
    kv("最大胜利", big && big.res === "W" ? gm(big) : "<b>—</b>"), kv("最惨失利", worst && worst.res === "L" ? gm(worst) : "<b>—</b>"), kv("进球最多的一场", most && most.gf + most.ga ? gm(most) : "<b>—</b>"),
    kv("最长连胜", `<b>${streak((g) => g.res === "W")} 场</b>`), kv("最长不败", `<b>${streak((g) => g.res !== "L")} 场</b>`),
    kv("零封", `<b>${played.filter((g) => g.ga === 0).length} 场</b>`), kv("未能进球", `<b>${played.filter((g) => g.gf === 0).length} 场</b>`),
  ].join("") : `<div class="empty-note">开赛后统计</div>`;
  const h2h = games.filter((g) => g.opp === me());
  const sc = c.t.scorers || [];
  return `<div class="view cp-stv">
    <div class="cp-col" style="--i:0">
      <div class="card"><div class="ch">主客场战绩</div><div class="cb"><table class="cp-mini"><thead><tr><th></th><th class="n">赛</th><th class="n">胜</th><th class="n">平</th><th class="n">负</th><th class="n">进</th><th class="n">失</th><th class="n">分</th></tr></thead>
        <tbody>${split.map(([k, s]) => `<tr${k === "总计" ? ` class="cp-tot"` : ""}><td>${k}</td><td class="n">${s.n}</td><td class="n">${s.w}</td><td class="n">${s.d}</td><td class="n">${s.l}</td><td class="n">${s.gf}</td><td class="n">${s.ga}</td><td class="n"><b>${s.pts}</b></td></tr>`).join("")}</tbody></table></div></div>
      <div class="card"><div class="ch">与我队交手</div><div class="cb">${h2h.length ? `<table class="cp-mini">${h2h.map((g) => `<tr${g.res ? ` data-fx="${g.f.id}"` : ""}><td class="cp-rd">${g.f.round}</td><td class="muted">${cpDate(g.f.date)}</td><td>${g.home ? `${esc(tname(tid))} 主场` : `${esc(tname(me()))} 主场`}</td><td class="n">${g.res ? `<span class="cp-sc ${g.res === "W" ? "L" : g.res === "L" ? "W" : "D"}">${g.home ? `${g.gf}-${g.ga}` : `${g.ga}-${g.gf}`}</span>` : "未赛"}</td></tr>`).join("")}</table><div class="pd-foot">比分按主队在前；颜色是我队的胜负</div>` : `<div class="empty-note">本季不交手</div>`}</div></div>
    </div>
    <div class="card" style="--i:1"><div class="ch">赛季之最</div><div class="pd-list cp-rec">${rec}</div></div>
    <div class="card" style="--i:2"><div class="ch">队内射手<span class="r">进球 · 助攻</span></div><div class="cb scroll">${sc.length ? `<table class="cp-mini">${sc.map((p, i) => `<tr><td class="cp-rd">${i + 1}</td><td class="name">${pface(p)}<b>${esc(p.name)}</b></td><td class="n"><b class="num">${p.goals}</b></td><td class="n muted">${p.assists}</td></tr>`).join("")}</table>` : `<div class="empty-note">还没有进球记录</div>`}</div></div>
  </div>`;
}

/* ---------- 转会（M8-W4）：这支球队在联赛世界里的钱、本季与上季的转入转出、合同到期顺序。数据 /api/team/<id> 的 world（iml_world.club_info） ---------- */
function cpTransfers(c) {
  const w = c.t.world;
  if (!w) return `<div class="view"><div class="card"><div class="empty-note">联赛世界还没有建立（新建游戏后可用）</div></div></div>`;
  const yr = (u) => w.start_year + u, tier = ["", "豪门", "强队", "中游", "弱旅"][w.tier] || "";
  const tiles = [["转会预算", money(w.budget, 1), "var(--gold)"], ["阵容总值", money(w.squad_value, 0)], ["周薪合计", kfmt(w.payroll)], ["周薪上限", kfmt(w.wage_cap)],
    ["本季转入花费", money(w.spent, 1)], ["本季转出收入", money(w.received, 1)]];
  const KIND = { transfer: "转会", sign: "自由身", youth: "青训", release: "放走", retire: "退役" };
  const mv = w.moves.map((m) => `<div class="cp-mv ${m.dir}"><small>${esc(m.date ? m.date.slice(5).replace("-", "/") : `${yr(m.season - 1)}/${String(yr(m.season)).slice(2)} 季末`)}</small>
    <em>${m.dir === "in" ? "转入" : "转出"}</em><b>${esc(m.name)}</b><span>${m.other ? `${m.dir === "in" ? "来自" : "去"} ${esc(tname(m.other) || "")}` : KIND[m.kind] || ""}</span>
    <i>${m.fee ? money(m.fee, 1) : m.kind === "transfer" ? "" : KIND[m.kind] || ""}</i></div>`).join("");
  const G = { G: "门将", D: "后卫", M: "中场", F: "前锋" };
  const ct = w.contracts.filter((p) => p.card).slice(0, 40).map((p) => `<tr${p.until <= w.season ? ' class="cp-exp"' : ""}><td>${G[p.grp] || ""}</td><td class="name"><b>${esc(p.name)}</b></td>
    <td class="n">${p.age}</td><td class="n">${yr(p.until)}</td><td class="n">${kfmt(p.wage)}</td><td class="n"><span class="num" style="color:var(--gold)">${money(p.value, 1)}</span></td></tr>`).join("");
  return `<div class="view" style="grid-template-columns:minmax(0,1fr) minmax(0,1fr)">
    <div class="card" style="--i:0"><div class="ch">财务<span class="r">${tier} · ${w.n} 人${w.style_label ? ` · ${esc(w.style_label)} · 野心 ${"●".repeat(Math.max(1, Math.round((w.ambition || 0) * 5)))}${"○".repeat(5 - Math.max(1, Math.round((w.ambition || 0) * 5)))}` : ""}</span></div><div class="cb">${fmTiles(tiles)}</div>
      <div class="ch">转入与转出<span class="r">本季与上季</span></div><div class="cb scroll">${mv || '<div class="empty-note">还没有转会记录</div>'}</div></div>
    <div class="card" style="--i:1"><div class="ch">合同<span class="r">按到期先后 · 合同至＝该年 6 月</span></div><div class="cb scroll"><table><thead><tr><th>位置</th><th>球员</th><th class="n">年龄</th><th class="n">合同至</th><th class="n">周薪</th><th class="n">身价</th></tr></thead><tbody>${ct}</tbody></table></div></div></div>`;
}

/* ---------- 荣誉 ---------- */
function cpCupDetail(c) {
  const h = c.hist && c.hist.cabinet && c.hist.cabinet[cpCupPick];
  if (!h) return "";
  return `<b>${esc(h.name)}</b><em class="num">×${h.count}</em><span>${esc((h.seasons || []).join("　") || "年份待核")}</span>`;
}
function cpHonours(c) {
  const h = c.hist;
  if (!h) return `<div class="view"><div class="card"><div class="empty-note">这支球队没有收录现实历史资料（目前只有五大联赛球队有）</div></div></div>`;
  const cab = h.cabinet || [];
  const shelf = cab.length ? cab.map((x, i) => `<button class="tro${i === cpCupPick ? " on" : ""}" data-cpcup="${i}" title="${esc(x.name)}${x.last ? ` · 最近 ${esc(x.last)}` : ""}">${trophyArt(x.art || x.id, cupKind(x.id))}<b class="num">${x.count}</b><small>${esc(x.name)}</small></button>`).join("")
    : `<div class="hall-empty">${trophySvg("league")}<span>展柜还在等第一座主要奖杯</span></div>`;
  return `<div class="view v-hall">
    <div class="card hall" style="--i:0"><div class="ch">荣誉展厅<span class="r">${h.total || 0} 座主要奖杯${h.founded ? ` · ${h.founded} 年建队` : ""}${h.stadium ? ` · ${esc(h.stadium)}` : ""}</span></div>
      <div class="hall-room"><div class="hall-shelf">${shelf}</div></div>
      <div class="hall-detail">${cpCupDetail(c)}</div></div>
    <div class="card hall-trend" style="--i:1"><div class="ch">联赛名次走势<span class="r seg">${[[30, "近30季"], [0, "全部"]].map(([v, t]) => `<button data-cptr="${v}" class="${hallRange === v ? "on" : ""}">${t}</button>`).join("")}</span></div>
      <div class="cb cp-hallbox"></div>
      <div class="foot-note"><i class="lg-dot champ"></i>顶级联赛冠军</div></div></div>`;
}

/* ---- 我队 球队 · 概况（2026-11-14 用户：“那把我的球队的详情页也做好点吧 同样是类FM感”） ----
   “球队”分区的第一个标签（左上角队徽进入、任何地方点我队也到这里）。与他队资料页同一套数据卡，参照线换成“联赛平均”；
   多出我们自己才有的：预算与薪资空间（/api/biz/club）、士气/体能、董事会目标与信任、队内射手（卡上记录）、球员年龄/身价（/api/biz/squad）。 */
async function viewClub() {
  const tid = me();
  const [t, hist, club, sq] = await Promise.all([team(tid, true), clubInfo(tid), biz("club").catch(() => null), biz("squad").catch(() => null)]);
  const all = [...t.squad, ...t.reserve], rr = row(tid) || {}, n = (S.table || []).length || 20, gp = (rr.played || 0) || 1;
  const games = (S.schedule || t.fixtures || []).map((f) => cpView(f, tid)), played = games.filter((g) => g.res), upcoming = games.filter((g) => !g.res);
  const last = played.slice(-10), cs = played.filter((g) => g.ga === 0).length;
  const facts = (sq && sq.players) || {}, demo = sq && sq.demo ? `<i class="pd-demo">示例</i>` : "";
  const fv = (p, k) => (facts[String(p.pid)] || {})[k];
  const ages = all.map((p) => fv(p, "age")).filter((a) => a != null), value = all.reduce((s, p) => s + (fv(p, "value") || 0), 0);
  const xi = t.squad.filter((p) => p.starter && p.overall).map((p) => p.overall);
  const cb = club && !club.error ? club : null, bd = cb && cb.board;
  const tiles = cpCoreTiles(tid, rr, n, played, xi.length ? cpAvg(xi) : null) + (value ? cpTile(`阵容身价${demo}`, money(value, 0), `${all.length} 人 · 均龄 ${cpFix(cpAvg(ages))}`, cpMix(all, (p) => fv(p, "value") || 0))
    : cpTile("阵容人数", all.length, "一线队 + 预备队", cpMix(all, cpOne)));
  // 俱乐部状态：预算 / 周薪占上限 / 士气 / 体能
  const wagePct = cb && cb.wage_cap ? cb.weekly_wages / cb.wage_cap : null;
  const status = cb ? `<div class="card cp-club"><div class="ch">俱乐部状态${cb.demo ? `<i class="pd-demo">示例</i>` : ""}<span class="r cp-link" data-tab="finance:0">财务 ›</span></div><div class="cb">
      <div class="cp-kvbar"><span>转会预算</span><b class="num">${money(cb.budget)}</b></div>
      <div class="cp-kvbar"><span>周薪 / 上限</span><b class="num">${kfmt(cb.weekly_wages)}${cb.wage_cap ? ` <small>/ ${kfmt(cb.wage_cap)}</small>` : ""}</b>${wagePct != null ? cpMeter(cb.weekly_wages, cb.wage_cap, wagePct > .95 ? "var(--loss)" : wagePct > .85 ? "var(--draw)" : "var(--win)") : ""}</div>
      <div class="cp-kvbar"><span>本季收支</span><b class="num" style="color:${(cb.season_net || 0) >= 0 ? "var(--win)" : "var(--loss)"}">${(cb.season_net || 0) >= 0 ? "+" : ""}${money(cb.season_net)}</b></div>
      <div class="cp-rings"><div>${cpRing(cb.morale, 100, cb.morale ?? "—", gaugeColor(cb.morale || 0))}<small>士气</small></div><div>${cpRing(cb.fitness, 100, `${cb.fitness ?? "—"}`, gaugeColor(cb.fitness || 0))}<small>体能</small></div>
        ${bd ? `<div>${cpRing(bd.trust, 100, bd.trust ?? "—", gaugeColor(bd.trust || 0))}<small>董事会信任</small></div>` : ""}</div>@@BOARD@@</div></div>` : "";
  const OBJ = { met: ["达成中", "var(--win)"], done: ["已达成", "var(--win)"], chasing: ["追赶中", "var(--draw)"], behind: ["落后", "var(--loss)"], fail: ["未达成", "var(--loss)"] };
  // 董事会：目标 + 各项目标的状态点（悬停看说明），放在俱乐部状态卡底部
  const board = bd ? `<div class="cp-target cp-link" data-tab="home:3" title="董事会 ›"><small>董事会目标</small><b>${esc(bd.target || "—")}</b><em>${esc(bd.verdict || "")}</em>
      <span class="cp-objs">${(bd.objectives || []).map((o) => { const [lbl, col] = OBJ[o.state] || ["—", "var(--ink3)"]; return `<i style="background:${col}" title="${esc(o.text)} · ${lbl}${o.note ? " · " + esc(o.note) : ""}"></i>`; }).join("")}</span></div>` : "";
  const key = [...all].sort((a, b) => (b.overall || 0) - (a.overall || 0)).slice(0, 5);
  const scorers = [...all].filter((p) => p.goals || p.assists).sort((a, b) => (b.goals || 0) - (a.goals || 0) || (b.assists || 0) - (a.assists || 0)).slice(0, 5);
  const trend = (t.pos_trend || []).map((x) => x.pos).filter(Boolean);
  return `<div class="view cp cp-ov cp-mine">
    <div class="card cp-id${hist && hist.photo ? " has-photo" : ""}" style="--i:0">${cpHero(tid, hist)}<b class="cp-name">${esc(tname(tid))}</b><small class="muted">${esc(S.career.league_name || "")} · 第 ${S.career.season || 1} 季</small>
      ${form(rr.form)}
      <div class="pd-list">
        <div class="pd-kv"><span>主帅</span><b>你</b></div>
        ${hist && hist.stadium && !hist.photo ? `<div class="pd-kv"><span>主场</span><b title="${esc(hist.stadium)}">${esc(hist.stadium)}</b></div>` : ""}
        ${hist && hist.founded ? `<div class="pd-kv"><span>建队</span><b>${hist.founded} 年</b></div>` : ""}
        ${hist && hist.total ? `<div class="pd-kv cp-link" data-tab="squad:6"><span>主要奖杯</span><b><em class="cp-gold">${hist.total}</em> 座 ›</b></div>` : ""}
        ${trend.length ? `<div class="pd-kv"><span>本季最高</span><b>第 ${Math.min(...trend)} 名</b></div>` : ""}
      </div></div>
    <div class="cp-mid" style="--i:1">
      <div class="cp-tiles">${tiles}</div>
      <div class="cp-two${upcoming.length && played.length ? "" : " one"}">
        ${played.length ? `<div class="card"><div class="ch">近期赛果<span class="r cp-link" data-tab="season:1">全部 ›</span></div><div class="cb scroll"><table class="cp-mini">${played.slice(upcoming.length ? -5 : -10).reverse().map(cpRes).join("")}</table></div></div>` : ""}
        ${upcoming.length ? `<div class="card"><div class="ch">接下来<span class="r cp-link" data-tab="season:2">日程 ›</span></div><div class="cb scroll"><table class="cp-mini">${upcoming.slice(0, played.length ? 5 : 10).map(cpRes).join("")}</table></div></div>` : ""}
      </div></div>
    <div class="cp-side" style="--i:2">
      ${status.replace("@@BOARD@@", () => board)}
      <div class="card"><div class="ch">${scorers.length ? "队内射手" : "核心球员"}<span class="r cp-link" data-tab="squad:2">球员 ›</span></div><div class="cb cp-keys">
        ${(scorers.length ? scorers : key).map((p) => `<div class="cp-key" data-player="${esc(p.pid)}">${pface(p)}<b>${esc(p.name)}</b>${scorers.length ? `<em class="cp-ga">${p.goals || 0} 球 · ${p.assists || 0} 助</em>` : `${pos(p.position, p.group)}${ovr(p.overall)}`}</div>`).join("")}</div></div>
    </div></div>`;
}

/* ---- 他队球员资料（2026-11-14 用户：“做别的球队的球员详情 ... 能力值和技巧和技能的那些数据不能展示出来 反正就是类FM”） ----
   像 FM 的球探报告：只给身份、身体资料、可踢位置、球探星级（由总评/潜力换算成半星，不给数字）、本季进球助攻、身价/周薪估算与转会要价。
   不显示：具体能力值、能力雷达、技能、球员风格/AI 风格（后端也不返回这些，见 iml_ui._scout_profile）。 */
const cpStars = (v, lo = 60, hi = 100) => { const n = v == null ? 0 : Math.max(.5, Math.min(5, Math.round((v - lo) / (hi - lo) * 10) / 2));
  return `<span class="cp-st5" title="${n} / 5 星"><i style="width:${n / 5 * 100}%"></i></span>`; };
/* hint === undefined：从球队资料的阵容点进来（用已读好的 cpCtx，返回球队资料）。
   hint 是对象：从榜单 / 市场 / 联赛球员库点头像进来（2026-11-15 用户：“头像点不进去”）——用 /api/scout/<卡号> 现取，返回就是关掉这一层；
   hint = { goals, assists }（榜单里已有的本季数，没有的写 null）；tid 为 null＝自由球员。 */
async function openRivalPlayer(tid, pid, hint) {
  const ext = hint !== undefined;
  let c = cpCtx, p = null;
  if (!ext) { if (!c || c.tid !== tid) return; p = c.t.squad.find((x) => String(x.pid) === String(pid)); if (!p) return; sound("page"); }
  else {
    sound("page");
    const [scout, mk0] = await Promise.all([api(`/api/scout/${encodeURIComponent(pid)}`).catch(() => null), biz("market").catch(() => null)]);
    if (!scout || scout.error) return toast(scout && scout.error === "no-card" ? "这名球员游戏里没有卡，没有可看的资料" : "球员资料读取失败");
    p = scout; c = { tid, real: true, ref: mk0 && !mk0.demo ? mk0.star_ref : null, t: { scorers: [] } };
  }
  const mk = await biz("market").catch(() => null);
  const m = mk && !mk.demo && Array.isArray(mk.market) ? mk.market.find((x) => String(x.pid) === String(pid)) : null;
  const sc = ext ? (hint && (hint.goals != null || hint.assists != null) ? hint : null) : (c.t.scorers || []).find((x) => x.name === p.name) || null;
  const seasonVal = (v) => sc && sc[v] != null ? sc[v] : ext ? "—" : 0;
  const clubTag = tid != null ? `<span class="rp-club" data-cpback="1">${crest(tid, "sm")}${esc(tname(tid))}</span>` : `<span class="rp-club">自由球员</span>`;
  const real = c.real && p.overall != null;
  const pot = p.potential ? p.potential[1] : m ? m.potential : null;
  const kv = (k, v) => `<div class="pd-kv"><span>${k}</span><b>${v}</b></div>`;
  const apt = p.aptitude || (p.position ? { [p.position]: 2 } : {});
  const lvl = (k) => k === p.position ? 3 : apt[k] || 0;
  const natural = Object.keys(PD_SPOT).filter((k) => k !== p.position && apt[k] === 2), can = Object.keys(PD_SPOT).filter((k) => apt[k] === 1);
  const role = ext ? "—" : p.starter ? "主力" : "替补";
  const verdict = !real ? "资料有限" : p.overall >= 92 ? "世界级" : p.overall >= 87 ? "顶级球员" : p.overall >= 82 ? "主力级别" : p.overall >= 76 ? "可靠的轮换" : "阵容补充";
  const growth = real && pot != null ? (pot - p.overall >= 4 ? "还有明显成长空间" : pot > p.overall ? "仍有少许提升" : "已接近巅峰") : "";
  const body = `<div class="pd pd2 rp" style="--club:${tid != null ? tcolor(tid) : "var(--gold)"}">
    <div class="card pd-id" style="--i:0">
      ${real ? PD_CARD_BTN(p.pid) : ""}
      <div class="pd-media"><div class="pd-face"><img src="/img/player/${encodeURIComponent(p.pid)}.png" alt="" onerror="this.remove()"></div>${real ? PD_ART : ""}</div>
      <b class="pd-name">${esc(p.name)}</b>
      <div class="pd-tags">${pos(p.position, p.group)}${clubTag}</div>
      <div class="pd-list">${kv("年龄", p.age != null ? `${p.age} 岁` : "—")}${kv("惯用脚", p.foot || "—")}
        ${kv("身高体重", p.height ? `${p.height}cm · ${p.weight || "—"}kg` : "—")}${ext ? "" : kv("队内角色", role)}${p.card_type ? kv("卡种", esc(p.card_type)) : ""}</div>
    </div>
    <div class="card rp-scout" style="--i:1"><div class="ch">球探报告<span class="r">${real ? "按该队本季实际出场的卡" : "游戏自带名单 · 只有档位"}</span></div>
      <div class="cb">
        <div class="rp-row"><small>当前能力</small>${real ? (c.ref != null ? starsHtml(starVal(p.ca, c.ref)) : cpStars(p.overall)) : stars(p.tier)}<b>${verdict}</b></div>
        ${real ? `<div class="rp-row"><small>潜力</small>${c.ref != null ? starsHtml(starVal(p.ca_pot ? p.ca_pot[0] : null, c.ref), starVal(p.ca_pot ? p.ca_pot[1] : null, c.ref), "pot") : cpStars(pot)}<b>${growth}</b></div>` : ""}
        <div class="rp-pos"><div class="rp-vpitch"><i class="mid"></i><i class="circ"></i><i class="box t"></i><i class="box b"></i>
          ${Object.entries(PD_SPOT).map(([k, [x, y]]) => `<span class="pd-spot l${lvl(k)}" style="left:${y}%;top:${100 - x}%">${k}</span>`).join("")}</div>
          <div class="rp-poslist"><div><small>登记位置</small>${pos(p.position, p.group)}</div>${natural.length ? `<div><small>熟练</small>${natural.map((k) => pos(k)).join("")}</div>` : ""}${can.length ? `<div><small>可以胜任</small>${can.map((k) => pos(k)).join("")}</div>` : ""}
            ${p.aptitude ? "" : `<div class="muted fs-s">其他位置资料未知</div>`}</div></div>
      </div>
      <div class="pd-foot">球探只给星级评估，不提供具体能力值、技能与风格。</div></div>
    <div class="pd-side pd-side2" style="--i:2">
      <div class="card"><div class="ch">本季${tid != null ? ` · ${esc(tname(tid))}` : ""}</div><div class="pd-nums">${[["进球", seasonVal("goals")], ["助攻", seasonVal("assists")], ["角色", role]].map(([k, v]) => `<div><b class="num">${v}</b><small>${k}</small></div>`).join("")}</div></div>
      <div class="card"><div class="ch">身价与转会</div><div class="pd-money">
        <div class="pd-bigs"><div class="pd-big val"><small>身价 · 估算</small><b class="num">${p.value != null ? money(p.value) : m ? money(m.value) : "—"}</b></div>
          <div class="pd-big wage"><small>周薪 · 估算</small><b class="num">${p.wage != null ? kfmt(p.wage) : m ? kfmt(m.wage) : "—"}</b></div></div>
        <div class="rp-mk">${m ? `<span>转会要价 <b class="num">${money(m.price)}</b></span><button class="btn pri sm" data-mkgo="${esc(m.id)}">去转会市场</button>`
          : `<span class="muted">${real ? "目前不在转会市场名单里" : "该队使用游戏自带名单，无法求购"}</span>`}</div></div></div>
    </div></div>`;
  openLayer(`${esc(p.name)}`, `${tid != null ? esc(tname(tid)) : "自由球员"} · ${esc(p.position || "")}`, body);
  // 返回音效由按钮自带的 data-sound="back"（00-core 全局监听）播；这里再 sound("back") 会两声叠在一起（2026-11-15 用户：“返回音效太太太大声了”）
  const back = $(".layer .back"); if (back) back.onclick = () => { if (ext) closeLayer(); else openTeam(tid); };      // 外部入口：回到原来的页面
  $$("[data-cpback]").forEach((el) => el.onclick = () => { sound("back"); openTeam(tid); });
  // 2026-11-15 用户：“别的球队的球员，我们也可以点那个渲染卡面功能”——和我方球员详情同一个翻转（pdFlip → 宿主 /img/card/<卡号>.png，card_art 只按卡号与游戏资源合成，
  // 不看是不是我们的卡）。只在 real（该队实际出场的卡，pid 是卡号）时给；游戏自带名单的 pid 是原生球员号，不是卡，不给按钮。
  const lay = $(".layer"); if (lay) $$("[data-card]", lay).forEach((el) => el.onclick = () => pdFlip(lay, p));
}
/* ---- 青训出人的揭晓演出（2026-11-16，E321；用户：“青训出球员的形式就是抽卡”） ----
   通道 → 大门炸开 → 隧道尽头依次揭晓国家 / 主要位置 / 俱乐部 → 夜场里原卡面亮相（app/signing3d.js：three.js PBR + 辉光，
   贴图 / 球场全景 / 音效都是 CC0 素材，见 app/reveal/CREDIT.txt）。
   青训抽到的是卡库里的真实卡：显示这张卡原本的国家、俱乐部队徽和主要位置；能力值和潜力全程不显示（用户 2026-11-16 定）。
   ytReveal(y) 是唯一入口：y = { name, position, pid?, nation: { name, flag? }, club: { id?, name, code?, c? }, tier? }；返回的 Promise 在玩家点“收下”后完成。
   tier 0..5＝六档效果 T2 职业级 / T3 联赛优秀 / T4 世界级 / T5 超级巨星 / T6 足坛传奇 / T7 历史最伟大（signing3d.js 的 TIERS：颜色、彩带、烟花、光束、欢呼逐档加码），由出人规则给，页面上不出现数字。
   青训的出人规则（多久一次、花费、卡从哪来）还没做：现在只有青训页上的“揭晓回放 / 预览”会调它，服务端上线后在出人那一刻调同一个函数。
   没有 WebGL 时直接显示结果。 */
let ytLive = null;
function ytReveal(y) {
  if (ytLive) return ytLive.done;
  const tier = Math.max(0, Math.min(5, y.tier | 0)), nat = y.nation || {}, club = y.club || {}, el = document.createElement("div"); el.id = "sgn"; el.className = `sgn t${tier}`;
  el.innerHTML = `<div class="sgn-scene"></div><div class="sgn-white"></div>
    <div class="sgn-flat"><small>青训新星</small><b>${esc(y.name)}</b><span>${[y.position, nat.name, club.name].filter(Boolean).map(esc).join(" · ")}</span></div>
    <button class="btn pri sgn-go" data-sgn-ok>继续</button>
    <div class="sgn-skip">点按跳过</div>`;      // 用户 2026-11-16：名字写在 3D 台子的底栏上，画面中间不放文字和黑色遮罩，右下角只有“继续”；.sgn-flat 只在没有 WebGL 时显示
  document.body.appendChild(el); void el.offsetWidth; el.classList.add("on");
  const white = $(".sgn-white", el), live = ytLive = { el, show: null };
  let finish; live.done = new Promise((res) => { finish = res; });
  const shown = () => el.classList.add("done");
  const close = () => { if (ytLive !== live) return; ytLive = null; document.removeEventListener("keydown", onKey); if (live.show) live.show.dispose(); el.classList.remove("on"); setTimeout(() => el.remove(), 260); finish(); };
  const skip = () => { if (el.classList.contains("done")) return; if (live.show) live.show.skip(); else shown(); };
  const onKey = (e) => { if (e.key === "Escape" || e.key === "Enter" || e.key === " ") { e.preventDefault(); el.classList.contains("done") ? close() : skip(); } };
  document.addEventListener("keydown", onKey);
  el.addEventListener("click", (e) => { if (e.target.closest("[data-sgn-ok]")) { sound("ok"); close(); } else skip(); });
  (async () => {
    try {
      const { SigningReveal } = await import("/signing3d.js");
      if (ytLive !== live) return;
      const tid = me();
      live.show = new SigningReveal($(".sgn-scene", el), { name: y.name, position: y.position, tier,
        nation: { name: nat.name || "", flag: nat.flag || (nat.id ? `/reveal/flags/${nat.id}.png` : null) },      // nat.id＝eFootball 国家 id（profile-catalog countries）；旗帜由 tools/make_reveal_flags.py 按 id 生成
        club: { name: club.name || "", crest: club.id ? `/img/emblem/${club.id}.png` : null, code: club.code || "", color: club.c || "#555" },
        myCrest: `/img/emblem/${tid}.png`, myCode: tcode(tid), myColor: tcolor(tid),
        cardUrl: y.pid ? `/img/card/${encodeURIComponent(y.pid)}.png` : null, faceUrl: y.pid ? faceUrl(y.pid) : null,
        cardLive: y.pid ? { webm: `/img/card/${encodeURIComponent(y.pid)}.webm`, over: `/img/card/${encodeURIComponent(y.pid)}.over.png`, MPEG1: window.MPEG1 } : null,      // 动态卡面（同球员详情 pdLive）
        audio: audio(), reduced: REDUCED, onFlash: (v) => { white.style.opacity = v; }, onDone: shown });
      window.__ytShow = live.show;                        // 调试句柄：__ytShow.freeze = 秒 可定格
      await live.show.load();
      if (ytLive !== live) return live.show.dispose();
      live.show.play();
    } catch (e) {
      console.warn("youth reveal unavailable", e);       // 没有 WebGL：不播演出，直接给结果
      el.classList.add("flat"); shown();
    }
  })();
  return live.done;
}
window.__ytReveal = ytReveal;                             // 调试入口：控制台里用任意数据试播
// 预览（青训规则上线前实机上青训页没有学员）：从转会市场里拿真实的卡当样例，三个档位轮着播；不会进队。
const YT_NAT_ZH = { ENG: "英格兰", FRA: "法国", ESP: "西班牙", GER: "德国", ITA: "意大利", BRA: "巴西", ARG: "阿根廷", POR: "葡萄牙", NED: "荷兰", BEL: "比利时" };
let ytSampleI = 0;
// 固定测试卡（用户 2026-11-16 指定 106763760282015，德克兰·赖斯）：预览宿主里它的静态卡面 / 视频 / 透明层齐全，用来看真实动态卡面
const YT_TEST = { pid: 106763760282015, name: "Declan Rice", position: "CMF", nation: { id: 204, name: "英格兰" }, club: { id: 101, name: "阿森纳", code: "ARS", c: "#e8323c" } };
async function ytPreview() {
  const sc = await api(`/api/scout/${YT_TEST.pid}`).catch(() => null);
  if (sc && sc.name) return ytReveal({ name: sc.name, position: sc.position || YT_TEST.position, pid: YT_TEST.pid, tier: [5, 4, 3, 2, 1, 0][ytSampleI++ % 6], nation: YT_TEST.nation, club: YT_TEST.club });
  return ytPreviewMarket();
}
async function ytPreviewMarket() {
  const d = await biz("market").catch(() => null), pool = d && d.market ? d.market.filter((p) => p.pid && p.club && p.club.id) : [];
  const tier = [5, 4, 3, 2, 1, 0][ytSampleI++ % 6];
  if (!pool.length) return ytReveal({ name: "样例球员", position: "CMF", tier, nation: { name: "英格兰" }, club: { name: "样例俱乐部", code: "DEM", c: "#2d6cdf" } });
  const p = pool[(ytSampleI * 7) % pool.length];
  return ytReveal({ name: p.name, position: p.position, pid: p.pid, tier, nation: { name: YT_NAT_ZH[p.nat] || p.nat || "" }, club: { id: p.club.id, name: p.club.name, code: p.club.code, c: p.club.c } });
}
/* ================= 事件绑定（页面内） ================= */
function bindPage(root) {
  $$("[data-team]", root).forEach((el) => el.addEventListener("click", (e) => { e.stopPropagation(); openTeam(+el.dataset.team); }));
  $$("[data-player]", root).forEach((el) => el.addEventListener("click", (e) => { e.stopPropagation(); const d = el.dataset; openPlayer(d.player, d.pfree ? "free" : d.pteam, d.pg != null || d.pa != null ? { goals: d.pg != null ? +d.pg : null, assists: d.pa != null ? +d.pa : null } : null); }));
  $$("[data-fx]", root).forEach((el) => el.addEventListener("click", () => openReport(el.dataset.fx)));
  $$("[data-go]", root).forEach((el) => el.addEventListener("click", () => openSec(el.dataset.go)));
  $$("[data-pgroup]", root).forEach((el) => el.addEventListener("click", () => { pgroup = el.dataset.pgroup; draw(); }));
  $$("[data-round]", root).forEach((el) => el.addEventListener("click", () => { histRound = +el.dataset.round; sound("cursor"); draw(); }));
  $$("[data-rep]", root).forEach((el) => el.addEventListener("click", () => { repSel = el.dataset.rep; sound("cursor"); draw(); }));
  $$(".rp-stats", root).forEach(rpBind);                                       // E307 批次B：战报里的球员数据卡（切队 / 点人看热区）
  $$("[data-act=kickoff]", root).forEach((el) => el.addEventListener("click", () => kickoff()));
  $$("[data-act=day]", root).forEach((el) => el.addEventListener("click", () => advanceDay("day")));      // M5-D：只过一天
  $$("[data-act=offgo]", root).forEach((el) => el.addEventListener("click", () => advanceDay()));         // M5-D-c：休赛期继续（走到 6/30）
  $$("[data-act=review]", root).forEach((el) => el.addEventListener("click", () => { sound("page"); openSeasonReview(); }));
  fmDragBind(root);
  $$(".hm-rank tr.me", root).forEach((tr) => { const box = tr.closest(".cb"); if (box) { const d = tr.getBoundingClientRect().top - box.getBoundingClientRect().top; box.scrollTop = Math.max(0, box.scrollTop + d - (box.clientHeight - tr.offsetHeight) / 2); } });   // 排行榜打开时把我队滚到中间
  $$("[data-fm-open]", root).forEach((el) => el.addEventListener("click", () => { sound("page"); fmPicker(); }));
  // 阵容页右侧表（2026-11-18）：点“位置 / 能力”表头排序；预备队行的“换入”（不触发整行的球员详情）
  $$("[data-ln-sort]", root).forEach((el) => el.addEventListener("click", (e) => { e.stopPropagation(); if (lnSort === el.dataset.lnSort) return; lnSort = el.dataset.lnSort; sound("cursor"); quietDraw = true; draw(); }));
  $$("[data-ln-in]", root).forEach((el) => el.addEventListener("click", (e) => { e.stopPropagation(); sound("open"); mkSubstitute(el.dataset.lnIn); }));
  $$("[data-fm-free]", root).forEach((el) => el.addEventListener("click", () => { fmFree = !fmFree; sound("page"); quietDraw = true; draw(); }));
  $$("[data-fm-restore]", root).forEach((el) => el.addEventListener("click", () => { sound("cursor"); fmRestore(); }));
  $$("[data-cal]", root).forEach((el) => el.addEventListener("click", () => { if (!el.dataset.cal) return; calMonth = el.dataset.cal; sound("cursor"); draw(); }));
  bindHall(root);
  coachBind(root);                                                             // E352 第2批：我的教练页的竞猜 / 进修按钮
  // 经营层页面
  const on = (sel, fn) => $$(sel, root).forEach((el) => el.addEventListener("click", (e) => { e.stopPropagation(); fn(el); }));
  on("[data-tab]", (el) => navLink(el.dataset.tab));
  on("[data-todo]", (el) => toast(el.dataset.todo));
  on("[data-hms]", (el) => { hmSide = el.dataset.hms; sound("cursor"); hmSwap(); });
  on("[data-ibk]", (el) => { ibxKind = el.dataset.ibk; sound("cursor"); quietDraw = true; draw(); });
  on("[data-ibread]", () => { const its = BIZ.inbox ? BIZ.inbox.items : []; ibxMark(its.filter((x) => x.unread).map((x) => x.id)); its.forEach((x) => { x.unread = false; }); sound("ok"); if ($(".hm-in")) hmSwap(); else { quietDraw = true; draw(); } });
  on("[data-ibx]", (el) => { ibxSel = ibxId(el.dataset.ibx); if (cur.sec === "home" && cur.tab === 1) { sound("cursor"); quietDraw = true; draw(); } else { ibxKind = "all"; openSec("home", 1); } });
  on("[data-mkbid]", (el) => mkBid(+el.dataset.mkbid));
  on("[data-ct]", (el) => ctRenew(el.dataset.ct));
  on("[data-rel]", (el) => ctRelease(el.dataset.rel));
  on("[data-wagealloc]", () => { sound("page"); wageAllocDialog(); });          // E342：转会预算 ↔ 周薪上限
  on("[data-wd]", async (el) => { const r = await post("/api/market/withdraw", { bid: +el.dataset.wd }); if (mkFail(r)) return; await mkAfter("已撤回报价"); });
  on("[data-ctr]", async (el) => { const r = await post("/api/market/counter", { bid: +el.dataset.ctr }); if (mkFail(r)) return; sound("ok"); await mkAfter(""); mkTerms(+el.dataset.ctr); });   // M6-E1：接受还价＝转会费谈妥，直接进入和球员谈条款
  on("[data-terms]", (el) => { sound("page"); mkTerms(+el.dataset.terms); });
  on("[data-mkfree]", async (el) => { sound("page"); const r = await post("/api/market/free", { card: +el.dataset.mkfree }); if (mkFail(r)) return;   // M8-W4：和自由球员直接谈条款
    delete BIZ.market; delete BIZ.offers; await mkTerms(r.bid); });
  on("[data-mkwatch]", async (el) => { const r = await post("/api/market/watch", { card: +el.dataset.mkwatch }); if (mkFail(r)) return; delete BIZ.market; delete BIZ.offers; sound("cursor"); quietDraw = true; draw(); });
  on("[data-oact]", (el) => offerAct(el.dataset.oact, +el.dataset.oid));
  on("[data-lst]", async (el) => { if (el.dataset.lst === "new") return mkListPicker(); const d = await biz("market"); const own = d && d.own.find((x) => String(x.pid) === el.dataset.lst); if (own) mkListing(own, d); });
  on("[data-unlist]", async (el) => { const r = await post("/api/market/unlist", { card: +el.dataset.unlist }); if (mkFail(r)) return; await mkAfter("已撤牌"); });
  on("[data-sub]", (el) => mkSubstitute(el.dataset.sub));
  on("[data-yt]", async (el) => { const d = await biz("youth"), y = d && (d.academy || []).find((a) => String(a.pid) === el.dataset.yt); if (y && y.reveal) { sound("page"); ytReveal(ytArg(y.reveal)); } });      // E321：青训揭晓回放
  on("[data-ytplay]", () => { sound("page"); ytPlayPending(); });
  on("[data-ytdemo]", () => { sound("page"); ytPreview(); });
  // 2026-11-17 用户“可以做一个放弃青训球员的功能吧”：等待签约的新人在二级菜单里签约 / 免费放弃（ytWaitOpen）；已入队的学员＝走合同解约（同合同页的解约单）
  on("[data-ytwait]", () => { sound("page"); ytWaitOpen(); });
  on("[data-ytrelease]", (el) => { sound("page"); ctRelease(el.dataset.ytrelease); });
  on("[data-sellp]", (el) => mkSellFromPlayers(el.dataset.sellp));
  { const lgSel = $("[data-mklgsel]", root); if (lgSel) lgSel.onchange = () => { mkLg = +lgSel.value; sound("cursor"); quietDraw = true; draw(); }; }
  on("[data-mklg]", (el) => { mkLg = +el.dataset.mklg; sound("cursor"); quietDraw = true; draw(); });                // 2026-11-15：按联赛筛选（本联赛 / 西甲 / 意甲 / 法甲）
  on("[data-mkp]", (el) => { mkPos = el.dataset.mkp; sound("cursor"); quietDraw = true; draw(); });               // 筛选：安静重画（不重播入场动画）
  on("[data-mko]", (el) => { mkOpt[el.dataset.mko] = !mkOpt[el.dataset.mko]; sound("cursor"); quietDraw = true; draw(); });
  on("[data-mksort]", (el) => { mkSortBy(el.dataset.mksort); sound("cursor"); quietDraw = true; draw(); });        // 2026-11-15：表头升降序
  on("[data-mk]", (el) => { if (mkSel !== +el.dataset.mk) { sound("cursor"); mkSelect(+el.dataset.mk); } });     // 选行：只换详情卡
  on("[data-mkmore]", () => { sound("cursor"); mkMore(); });
  on("[data-mkgo]", (el) => { mkSel = +el.dataset.mkgo; mkResetFilters(); openSec("transfer", 0); });
  // M6-F1 市场筛选 / 对比 / 阵容深度
  on("[data-mkadv]", () => { mkMoreOpen = !mkMoreOpen; sound("cursor"); quietDraw = true; draw(); });
  on("[data-mkpos]", (el) => { const x = el.dataset.mkpos, one = mkF.pos && mkF.pos.length === 1 && mkF.pos[0] === x;
    Object.assign(mkF, one ? { pos: null, posName: "", beat: 0 } : { pos: [x], posName: POS_ZH[x] || x, beat: 0 }); sound("cursor"); quietDraw = true; draw(); });
  on("[data-mkdrop]", (el) => { mkDrop(el.dataset.mkdrop); sound("cursor"); quietDraw = true; draw(); });
  on("[data-mkclear]", () => { mkResetFilters(); sound("cursor"); quietDraw = true; draw(); });
  on("[data-mkwatchf]", () => { mkF.watch = !mkF.watch; sound("cursor"); quietDraw = true; draw(); });
  on("[data-mkcmp]", (el) => { sound("page"); mkCompare(+el.dataset.mkcmp); });
  on("[data-chg]", () => { repChgOpen = !repChgOpen; sound("cursor"); quietDraw = true; draw(); });                  // M7-G4 本轮变化展开 / 收起
  on("[data-rep-menu]", (el) => repMenu(el));
  on("[data-wllg]", (el) => { wlLg = +el.dataset.wllg; wlSel = null; sound("cursor"); quietDraw = true; draw(); });   // 2026-11-15：联赛球员库切换联赛
  on("[data-wl]", (el) => { wlSel = +el.dataset.wl; sound("cursor"); quietDraw = true; draw(); });
  on("[data-fas]", (el) => { faSort = el.dataset.fas; sound("cursor"); quietDraw = true; draw(); });                  // M8-W4 自由球员排序                  // M8-W0 联赛球员库
  on("[data-wls]", (el) => { wlSort = el.dataset.wls; sound("cursor"); quietDraw = true; draw(); });
  on("[data-brief]",() => { sound("page"); openBrief(); });
  on("[data-lu-assist]",(el) => { sound("page"); luAssist(el.dataset.luAssist || undefined); });                  // M6-F2 阵容助手
  on("[data-dpu]", (el) => dpPick(el.dataset.dpu));
  on("[data-dpmk]", (el) => dpMarket(el.dataset.dpmk));
  $$("[data-mkf]", root).forEach((el) => el.addEventListener("change", () => { mkF[el.dataset.mkf] = el.value.trim(); quietDraw = true; draw(); }));     // 数字框失焦 / 回车后才筛
  $$("[data-mkcan]", root).forEach((el) => el.addEventListener("change", () => { mkF.can = el.checked; quietDraw = true; draw(); }));
  const q = $("#mk-q", root); if (q) { let tm = 0; q.addEventListener("input", () => { clearTimeout(tm); tm = setTimeout(() => { mkF.q = q.value; mkRefilter(); }, 220); }); }   // 搜索：只换表格与详情，不重画整页（保住输入焦点）
  const planBody = () => ({ days: wk.filter((x) => x.kind !== "match" && !x.fixed).map((x) => x.kind === "intense" ? "high" : x.kind), focus: focusK });
  const realTraining = () => trainReal;
  on("[data-tpl]", (el) => { sound("cursor"); trTemplate(el.dataset.tpl); });                                   // M7-G1
  on("[data-tauto]", () => { sound("cursor"); trAuto(); });
  on("[data-trestore]", () => { sound("cursor"); trRestore(); });
  on("[data-day]", (el) => { if (trainReal) return trDayMenu(+el.dataset.day, el); const x = wk[+el.dataset.day]; x.kind = CYCLE[(CYCLE.indexOf(x.kind) + 1) % CYCLE.length]; sound("cursor"); if (realTraining()) trainSave("/api/training/plan", planBody()); quietDraw = true; draw(); });
  on("[data-focus]", (el) => { if (realTraining()) { if (!el.classList.contains("on")) { sound("cursor"); trSavePlan({ focus: el.dataset.focus }); } return; } if (focusK === el.dataset.focus) return; focusK = el.dataset.focus; sound("cursor"); quietDraw = true; draw(); });
  on("[data-ind]", async (el) => {
    const d = await biz("training"); if (!d || d.demo) return;
    if (d.goals) return trGoalMenu(el.dataset.ind, el);                       // M7-G2：菜单选目标（旧宿主没有 goals 才循环）
    const p = d.players.find((x) => String(x.pid) === el.dataset.ind); if (!p) return;
    const opts = [null, ...(p.position === "GK" ? IND_GK : IND_FIELD)], at = p.individual ? opts.indexOf(p.cat) : 0;
    const nextCat = opts[(Math.max(0, at) + 1) % opts.length];
    sound("cursor"); el.disabled = true;
    trainSave("/api/training/individual", { card: p.pid, category: nextCat }).then((ok) => { if (ok) { quietDraw = true; draw(); } });
  });
  on("[data-ifo]", (el) => { const i = +el.dataset.ifo, curF = el.textContent; ifocus[i] = FOCI[(FOCI.indexOf(curF) + 1) % FOCI.length]; el.textContent = ifocus[i]; sound("cursor"); });
  const tb = $("#tablebox", root), mr = tb && $("tr.me", tb);
  if (mr) tb.scrollTop = Math.max(0, mr.offsetTop - tb.clientHeight / 2);
}

/* ================= 外壳 ================= */
function tabBadge(sec, i) {
  const ib = BIZ.inbox, mk = BIZ.market || BIZ.offers, sq = BIZ.squad;      // E355：“继续”后主页只重读轻量 offers，报价角标同样来自它
  let n = 0;
  if (sec === "home" && i === 1 && ib) n = ib.items.filter((m) => m.unread).length;
  if (sec === "transfer" && i === 2 && mk) n = mk.offers.incoming.filter((o) => o.state === "pending").length;
  if (sec === "squad" && i === 2 && sq) n = Object.values(sq.players).filter((p) => p.injury).length;      // 伤病并进“球员”（UI 评估第二档）：角标跟到球员标签
  return n ? `<span class="b">${n}</span>` : "";
}
// 子页开关上的角标：伤病数挂在“球员 · 伤病”上
function subBadge(sec, tab, i) {
  const sq = BIZ.squad;
  const n = sec === "squad" && tab === 2 && i === 1 && sq ? Object.values(sq.players).filter((p) => p.injury).length : 0;
  return n ? `<span class="b">${n}</span>` : "";
}
// 顶栏塞不下就依次收：先去掉可选的“冬窗/近况”，还不够再收联赛栏的“第 x / y 轮”，保证最右边的“下一场”按钮完整（真机字体比预览宽）
// E360（2026-11-18 用户：“侧栏顶栏…限制我们的空间”）：二级页签并进顶栏，所以“挤”先表现为页签行放不下（要横向滑动）。
// 依次收数据块，页签仍放不下才让它横向滑动；队徽与“下一场”按钮永远完整。
// 用户（同日看预览后）：联赛与排名合成“联赛标志＋名次”，资金只写金额——这两块已经很小、始终显示；能收的只剩 k1 去转会窗/近况
function fitTop() {
  const t = $(".top"); if (!t) return;
  const steps = ["k1"];
  t.classList.remove(...steps);
  const sub = $("#subnav", t);
  // 不能只看 scrollWidth（体验评审 U01：根文档宽 740 时按钮右边界仍到 751）：直接量最右侧按钮的真实边界
  const over = () => { const g = t.querySelector(".go"), lim = Math.min(t.getBoundingClientRect().right - (parseFloat(getComputedStyle(t).paddingRight) || 0), innerWidth);
    return (sub && sub.offsetParent !== null && sub.scrollWidth > sub.clientWidth + 1) || t.scrollWidth > t.clientWidth + 1 || (g && g.getBoundingClientRect().right > lim + 0.5); };
  for (const c of steps) { if (!over()) break; t.classList.add(c); }
  fitTabsHint();
}
// 页签行横向滑动时右边缘渐隐，提示右边还有页签（滑到底就不渐隐）
// E365（2026-11-18 用户：“能不能做成可以左右滑动的…特别窄的屏幕会点不到一些界面”）：手指本来就能滑；补上鼠标滚轮/拖动（PC 预览、模拟器），
// 左边也渐隐（提示左边还有页签）
function fitTabsHint() {
  const s = $("#subnav"); if (!s) return;
  s.classList.toggle("more", s.scrollWidth - s.clientWidth - s.scrollLeft > 2);
  s.classList.toggle("less", s.scrollLeft > 2);
  if (s.dataset.hint) return;
  s.dataset.hint = "1"; s.addEventListener("scroll", fitTabsHint, { passive: true });
  s.addEventListener("wheel", (e) => {                      // 竖向滚轮 → 横向滑动（放得下就不拦）
    if (s.scrollWidth <= s.clientWidth + 1) return;
    const d = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY; if (!d) return;
    e.preventDefault(); s.scrollLeft += d * (e.deltaMode === 1 ? 32 : 1);
  }, { passive: false });
  let drag = null;                                          // 鼠标按住拖动；拖过 5px 就吞掉松手那一下点击，免得误切页签
  s.addEventListener("pointerdown", (e) => { if (e.pointerType !== "mouse" || e.button !== 0 || s.scrollWidth <= s.clientWidth + 1) return; drag = { x: e.clientX, l: s.scrollLeft, moved: false }; });
  addEventListener("pointermove", (e) => { if (!drag) return; const dx = e.clientX - drag.x; if (!drag.moved && Math.abs(dx) < 5) return; drag.moved = true; s.classList.add("dragging"); s.scrollLeft = drag.l - dx; });
  addEventListener("pointerup", () => { if (!drag) return; const moved = drag.moved; drag = null; s.classList.remove("dragging");
    if (!moved) return; const eat = (ev) => { ev.stopPropagation(); ev.preventDefault(); };   // 只吞紧跟着的这一次点击（在别处松手就没有点击，下一拍撤掉）
    s.addEventListener("click", eat, { capture: true, once: true }); setTimeout(() => s.removeEventListener("click", eat, { capture: true }), 0); });
}
addEventListener("resize", () => fitTop());
// 球员头像预取：后台把自己阵容的头像排进头像队列的最低优先级（宿主有内存+磁盘缓存，之后各页面秒出）；屏幕上的头像永远先加载。
// 2026-11-14：不再预取整个转会市场（新档时几百张没缓存的头像会占住宿主唯一的 Python 线程，页面数据跟着卡）——市场头像滚到才加载。
const faceSeen = new Set();
function prefetchFaces(pids) {
  const q = [...new Set(pids.filter(Boolean).map(String))].filter((p) => !faceSeen.has(p));
  q.forEach((p) => faceSeen.add(p));
  FACE.low.push(...q); facePump();
}
function prefetchSquadFaces() {
  team(me()).then((t) => prefetchFaces([...t.squad.filter((p) => p.starter), ...t.squad.filter((p) => !p.starter), ...t.reserve.slice(0, 20)].map((p) => p.pid))).catch(() => {});
}
// M6-E1（评审 §8.3）：顶栏写“可用”（余额减去已承诺给报价 / 谈判中的转会费），悬停看三个数
const budgetTip = (c) => { const r = c.wage_alloc ? c.wage_alloc.reserved : 0;          // E342：划给周薪的预留也写进提示
  return c.committed || r ? `财务 · 余额 ${money(c.budget, 1)}${c.committed ? ` · 已承诺 ${money(c.committed, 1)}` : ""}${r ? ` · 划给周薪 ${money(r, 1)}` : ""} · 可用 ${money(c.available, 1)}` : "财务"; };
// 顶栏转会窗块（E360 用户：“太占空间了”）：短写“夏窗 1 天后 / 夏窗剩 7 天”，全句进悬停提示
const winTip = (w) => `${w.kind === "winter" ? "冬窗" : "夏窗"}${w.open ? `${w.days} 天后关闭` : `${w.days} 天后开启`}`;
const winStat = (w) => `<div>${w.kind === "winter" ? "冬窗" : "夏窗"}${w.open ? "剩" : ""}</div><span class="num" style="color:var(--blue)">${w.days}</span><div>${w.open ? "天" : "天后"}</div>`;
async function renderShell() {
  // 性能（2026-11-14）：外壳只等顶栏要的俱乐部和通知；最重的市场与球队数据放到后台读（读完补上标签角标），不再拖慢第一屏
  const [club, inbox] = await Promise.all([biz("club"), biz("inbox")]);
  Promise.all([biz("market"), biz("squad")]).then(() => refreshBadges()).catch(() => {});
  const c = S.career, r = row(me()) || {}, n = S.next;
  document.documentElement.style.setProperty("--club", c.club_color || "#2c3038");
  document.documentElement.style.setProperty("--club-ink", c.club_ink || "#fff");
  const nextTxt = n ? `${n.home === me() ? "主场" : "客场"} · ${esc(tname(n.home === me() ? n.away : n.home))}` : c.finished ? "赛季已结束" : "暂无比赛";
  const unread = inbox ? inbox.items.filter((m) => m.unread).length : 0;
  const win = club && club.window;
  // 顶栏（同原型）：俱乐部斜切色块 / 轮次 / 排名 / 资金 / 转会窗 / 通知 / 下一场；经营数据取不到时资金与转会窗换成积分与近况
  const mid = club
    ? `<div class="stat money jump" data-jump="finance:0" role="button" tabindex="0" title="${club.committed || (club.wage_alloc && club.wage_alloc.reserved) ? "可用资金" : "转会预算"} · ${budgetTip(club)}">${svg("coin")}<span class="num" data-k="top-budget" data-to="${club.available ?? club.budget}">${money(club.available ?? club.budget)}</span></div>
       <div class="stat opt jump" data-jump="season:2" role="button" tabindex="0" title="${winTip(win)} · 查看日程表">${winStat(win)}</div>`
    : `<div class="stat jump" data-jump="season:0" role="button" tabindex="0" title="积分榜"><div>积分</div><span class="num" data-k="top-pts" data-to="${r.points || 0}">${r.points || 0}</span></div><div class="stat opt"><div>近况</div>${form(r.form)}</div>`;
  $("#app").innerHTML = `<div class="app">
    <header class="top">
      <button class="brand" title="${esc(tname(me()))} · 球队：阵容、球员、合同" aria-label="${esc(tname(me()))} · 球队：阵容、球员、合同">${crest(me())}</button>
      <nav class="subnav" id="subnav"></nav><div class="tools" id="tools"></div><div class="fill"></div>
      <div class="stat lgbar jump" data-jump="season:0" role="button" tabindex="0" title="${esc(c.league_name)} · 第 ${c.current_round} / ${c.rounds_total} 轮 · 排名 ${r.position || "—"}（积分榜）" aria-label="${esc(c.league_name)} 排名 ${r.position || "—"}">${lgLogo() || svg("cal")}<span class="num" data-k="top-rank" data-to="${r.position ?? ""}">${r.position || "—"}</span></div>
      ${mid}
      ${inbox ? `<button class="bell" id="bell" title="通知中心" data-sound="open">${svg("bell")}${unread ? `<i>${unread}</i>` : ""}</button>` : ""}
      <button class="simbtn" id="simbtn" title="不亲自上场，直接模拟这场比赛" ${euroToday() || (n && isMatchDay()) ? "" : "disabled"}>${svg("bolt", 1.8)}<span>模拟</span></button>
      <button class="go${euroToday() ? ` eu ${euCls()}` : ""}" data-act="kickoff" ${n || c.finished || euroToday() ? "" : "disabled"}>${goHtml()}</button>
    </header>
    <nav class="rail"><div class="ind" id="rind"></div>
      ${Object.entries(SECTIONS).filter(([k]) => k !== "squad").map(([k, s]) => `<button class="ri" data-sec="${k}">${svg(k, 1.7)}${s.t}</button>`).join("")}
      <div class="sp"></div><button class="ri ri-menu" id="tosettings" title="设置">${svg("gear", 1.7)}设置</button></nav>
    <main class="main"><div class="page" id="page"></div>
      <aside class="drawer" id="drawer"><div class="ch" style="padding:10px">通知中心<button class="r" id="dall">全部 ›</button></div><div class="cb scroll inbox">${inbox ? inbox.items.map((m) => msgHtml(m, `data-ibx="${m.id}" style="cursor:pointer"`)).join("") : ""}</div></aside></main></div>`;
  $$(".ri[data-sec]").forEach((b) => b.onclick = () => openSec(b.dataset.sec));
  // 顶栏数据直达：联赛 → 赛程结果，排名 / 积分 → 积分榜，转会预算 → 财务
  $$(".top .jump").forEach((el) => { const go = () => { sound("page"); navLink(el.dataset.jump); };
    el.onclick = go; el.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(); } }; });
  $(".brand").onclick = () => openSec("squad");
  $("#tosettings").onclick = () => { sound("open"); openSettings(); };
  fitTop(); if (document.fonts && document.fonts.ready) document.fonts.ready.then(fitTop);
  prefetchSquadFaces();
  $(".go").onclick = () => (euroToday() ? kickoff() : !S.next && S.career.finished ? (offWalk() ? advanceDay() : openSeasonReview()) : kickoff());   // M5-D-c：休赛期先走到 6/30；E341 欧战比赛日和联赛一样直接开球（kickoff 内转欧战）
  $("#simbtn").onclick = () => { if (!$("#simbtn").disabled) { sound("page"); euroToday() ? openEuroSim() : openSim(); } };
  if ($("#bell")) $("#bell").onclick = (e) => { e.stopPropagation(); const d = $("#drawer"); d.classList.toggle("open"); if (!d.classList.contains("open")) sound("close"); };
  $("#dall").onclick = () => { $("#drawer").classList.remove("open"); openSec("home", 1); };
  $$("#drawer [data-ibx]").forEach((el) => el.onclick = () => { ibxSel = ibxId(el.dataset.ibx); ibxKind = "all"; $("#drawer").classList.remove("open"); openSec("home", 1); });
  $$(".top [data-to]").forEach(countUp);
  openSec(cur.sec, cur.tab, { silent: true, redraw: true });
}
document.addEventListener("click", (e) => { const d = $("#drawer"); if (d && d.classList.contains("open") && !e.target.closest("#drawer, #bell")) { d.classList.remove("open"); sound("close"); } });

// 2026-11-13：去掉“退出”按钮。独立大师联赛进入后只能重启游戏回主游戏（切回会让下次从卡3进联赛出新手教程）；
// 面板用手机返回键收起。closePanel 宿主接口仍在，界面不再调用。

/* ================= 没有赛季：选联赛 / 球队开新赛季 ================= */
const pick = { leagues: null, comp: null, team: null, busy: false, error: "", mode: "new", draft: "real", tiers: {} };
// E369：新建游戏可选“真实世界”（原玩法）或“全球梦幻选秀”（九个联赛所有球队各抽 26 人，宿主 iml_fantasy）。档次说明读 /api/fantasy/tier/<队>。
const FD_FLOOR = (pa) => (pa >= 170 ? "超级巨星" : pa >= 155 ? "世界级" : "联赛优秀");
function pickTier(tid) {
  if (pick.tiers[tid] !== undefined) return pick.tiers[tid];
  pick.tiers[tid] = null;
  api(`/api/fantasy/tier/${tid}`).then((t) => { pick.tiers[tid] = t && !t.error ? t : false; if (screen === "pick" && pick.team === tid) drawPick(); }).catch(() => { pick.tiers[tid] = false; });
  return null;
}
function pickDraftNote(tm) {
  if (pick.draft !== "fantasy") return "";
  const t = tm ? pickTier(tm.id) : null;
  const floor = t ? t.floor.map(([pa, n]) => `${FD_FLOOR(pa)}及以上 ×${n}`).join("、") : "";
  return `<div class="pk-fd"><b>全球梦幻选秀</b><span>九个联赛的所有球队同规则各抽 26 人（门将 3 / 后卫 8 / 中场 9 / 前锋 6），年龄 17–23 岁；只抽这一次，不能重抽。${t ? ` 本队档次 <em class="fd-tier t${t.tier}">${esc(t.name)}</em>，保底：${esc(floor)}。` : tm ? " 正在读取本队档次…" : " 选一支球队查看档次与保底。"}弱队抽到顶级潜力的机会明显更小。</span></div>`;
}
async function renderPick() {
  document.documentElement.style.setProperty("--club", "#2c3038");
  if (pick.leagues === null) {
    $("#app").innerHTML = `<div class="loading-screen">正在载入联赛…</div>`;
    try { pick.leagues = (await api("/api/season/options")).leagues || []; } catch (e) { pick.leagues = []; }
    if (pick.leagues.length && pick.comp === null) pick.comp = (pick.leagues.find((l) => l.comp === 113) || pick.leagues[0]).comp;
  }
  drawPick();
}
function drawPick() {
  const L = pick.leagues || [];
  if (!L.length) {
    $("#app").innerHTML = `<div class="pick"><header><b>独立大师联赛</b><span>还没有赛季</span></header><div class="empty-note">联赛列表暂时不可用</div><footer></footer></div>`;
    return;
  }
  const lg = L.find((l) => l.comp === pick.comp) || L[0], tm = lg.teams.find((x) => x.id === pick.team);
  // 2026-11-13 重做：队徽完整显示（旧规则 .tm span 把队徽外框也拉伸裁掉了）、联赛标志、实力条（相对本联赛最强队）、选中用球队色
  const top = Math.max(1, ...lg.teams.map((x) => x.strength)), low = Math.min(...lg.teams.map((x) => x.strength));
  const pct = (v) => Math.round(25 + 75 * (v - low) / Math.max(1, top - low));
  const code = (x) => esc((x.short || x.latin || "?").slice(0, 3).toUpperCase());
  const emb = (x, cls = "") => `<span class="pk-crest ${cls}"><img src="/img/emblem/${x.id}.png" alt="" onerror="this.parentNode.classList.add('fb')"><i>${code(x)}</i></span>`;
  const logo = (l) => l.logo ? `<img class="pk-lgo" src="/img/comp/L${l.logo}.png" alt="" onerror="this.remove()">` : `<i class="pk-lgo blank"></i>`;
  $("#app").innerHTML = `<div class="pick pk2${pick.mode === "new" && pick.draft === "fantasy" ? " pk-fdm" : ""}"><header><div class="mn-brand sm"><b>73</b><span>${WORDMARK}</span></div><b class="pk-t">${pick.mode === "new" ? "新建游戏" : "新赛季"}</b><span>选择联赛与执教球队</span>${pick.mode === "new" ? `<span class="pk-mode" role="radiogroup">${[["real", "真实世界"], ["fantasy", "全球梦幻选秀"]].map(([k, n]) => `<button class="${pick.draft === k ? "on" : ""}" data-draft="${k}" role="radio" aria-checked="${pick.draft === k}">${n}</button>`).join("")}</span>` : ""}<button class="btn" id="pback" data-sound="back">‹ 主菜单</button></header>
    ${pick.mode === "new" ? pickDraftNote(tm) : ""}
    <div class="body"><div class="lgs scroll">${L.map((l) => `<button class="lg${l.comp === lg.comp ? " on" : ""}" data-comp="${l.comp}">${logo(l)}<span>${esc(l.name)}</span><i>${l.teams.length}</i></button>`).join("")}</div>
      <div class="tms scroll">${lg.teams.map((x, i) => `<button class="tm${x.id === pick.team ? " on" : ""}" data-tid="${x.id}" style="--i:${Math.min(i, 24)}">${emb(x)}<span class="tn"><b>${esc(tzh(x))}</b><span class="pk-bar"><i style="width:${pct(x.strength)}%"></i></span></span><em class="num" title="实力">${x.strength}</em></button>`).join("")}</div></div>
    <footer>${pick.error ? `<span class="dn">${esc(pick.error)}</span>` : tm ? `<span class="pk-sel">${emb(tm, "sm")}<span><b>${esc(tzh(tm))}</b><small>${logo(lg)}${esc(lg.name)} · 实力 ${tm.strength} · 联赛第 ${lg.teams.indexOf(tm) + 1}</small></span></span>` : `<span class="pk-hint">点一支球队</span>`}
      <button class="btn pri" id="pstart" data-sound="ok" ${tm && !pick.busy ? "" : "disabled"}>${pick.busy ? (pick.draft === "fantasy" && pick.mode === "new" ? "正在为全世界选秀…" : "正在创建…") : pick.draft === "fantasy" && pick.mode === "new" ? "开始选秀 ›" : "开始赛季 ›"}</button></footer></div>`;
  $$("[data-draft]").forEach((b) => b.onclick = () => { if (pick.busy) return; pick.draft = b.dataset.draft; pick.error = ""; sound("cursor"); drawPick(); });
  if (tm) { const c = (S && S.teams && S.teams[String(tm.id)] || {}).c; if (c) document.documentElement.style.setProperty("--club", c); }
  $$(".lg").forEach((b) => b.onclick = () => { pick.comp = +b.dataset.comp; pick.team = null; pick.error = ""; sound("cursor"); drawPick(); });
  $$(".tm[data-tid]").forEach((b) => b.onclick = () => { pick.team = +b.dataset.tid; pick.error = ""; sound("cursor"); drawPick(); });
  $("#pstart").onclick = startSeason;
  $("#pback").onclick = toMenu;
}
const PICK_FAIL = { "season-active": "已经有一个赛季在进行", "roster-data-unavailable": "球员名单资源尚未准备好，请更新游戏后重试", "native-roster-incomplete": "本队可用原生球员不足23人，暂时无法执教", "no-ml-profile": "还没有大师联赛存档", busy: "正在进入比赛，稍后再试", "unknown-team": "这支球队暂时不能执教", "archive-failed": "没能归档当前生涯，存档没有改动，请重试", "fantasy-failed": "全球选秀没能完成，存档没有改动，请重试", "bad-mode": "未知的开档模式" };
async function startSeason() {
  if (pick.busy || pick.team == null) return;
  pick.busy = true; drawPick();
  try {
    // 新建游戏：POST /api/game/new（宿主 iml_host.new_game：归档当前生涯后开第 1 季）；旧宿主没有这个动作时退回 newSeason
    const fantasy = pick.mode === "new" && pick.draft === "fantasy";
    let r = await post("/api/game/new", fantasy ? { team: pick.team, comp: pick.comp, mode: "fantasy" } : { team: pick.team, comp: pick.comp });
    if (fantasy && r && r.reason === "unknown-action") throw new Error("当前游戏版本还不支持全球梦幻选秀，请更新后重试");
    if (fantasy && r && r.ok && r.mode !== "fantasy") throw new Error("当前游戏版本还不支持全球梦幻选秀：已按真实世界开档");
    if (r && r.reason === "unknown-action") {
      if ((pick.leagues || []).some((l) => l.comp === pick.comp && l.requires_competition))
        throw new Error("当前游戏版本尚未接入所选联赛，请更新后重试");
      const h = host();
      if (!(h && h.newSeason)) throw new Error("（预览）这里由宿主创建赛季");
      r = JSON.parse(h.newSeason(pick.team));
    }
    if (!r || !r.ok) throw new Error(PICK_FAIL[r && r.reason] || (r && r.error) || "没能开始赛季，请重试");
    pick.leagues = null; pick.team = null; cur = { sec: "home", tab: 0 };
    for (const k of Object.keys(BIZ)) delete BIZ[k];
    screen = "game";
    sound("ok");
    await refresh(true);
    if (fantasy && typeof fdOpen === "function") await fdOpen();       // E369：进生涯前揭晓我方 26 人
  } catch (e) { pick.error = e.message; }
  finally { pick.busy = false; if (screen === "pick") drawPick(); }
}

/* ================= 全球梦幻选秀：揭晓我方 26 人（E369，2026-11-18） =================
   规格 outputs/reference/INDEPENDENT_MASTER_LEAGUE_GLOBAL_FANTASY_DRAFT_2026-11-18.md §7。
   阵容在新建生涯时已由宿主一次定好（iml_fantasy：九个联赛所有球队同规则）；这里只读 GET /api/fantasy，翻牌不抽签。
   分 4 批（门将 3 / 后卫 8 / 中场 9 / 前锋 6），批内按档次由低到高翻开（好牌留到最后）。逐张翻（点牌或“下一张”）、揭晓本批、跳过全部。
   进度只记一个数（已翻开几张，POST /api/fantasy/revealed，只增不减）：关掉、重进、重复点都接着同一份结果。
   卡面显示：名字、位置、生涯年龄、当前能力与球探潜力（星级；精确潜力不出现）。超级巨星档以上单张翻开时播青训同款 3D 揭晓（ytReveal）。
   保底换来的人标“已达成保底”，不冒充自然抽中。 */
let FD = null;
const FD_TIER = ["职业级", "联赛优秀", "世界级", "超级巨星", "足坛传奇", "历史最伟大"];
const fdStar = (ca) => Math.max(0.5, Math.min(5, Math.round((3 + (ca - 148) / 14) * 2) / 2));      // 绝对刻度：3 星＝CA148，一星 14 CA（同 iml_ability.STAR_MID/STAR_STEP）
async function fdOpen(force) {
  let d;
  try { d = await api("/api/fantasy"); } catch (e) { return false; }
  if (!d || d.mode !== "fantasy" || !(d.cards || []).length) return false;
  if (!force && d.done >= d.cards.length) return false;
  FD = { d, done: Math.min(d.done | 0, d.cards.length), batch: 0, busy: false, saved: d.done | 0 };
  FD.batch = fdBatchOf(FD.done);
  fdDraw();
  return true;
}
function fdBatches() {           // [{grp, name, from, to}] 在 cards 里的区间
  let i = 0;
  return FD.d.batches.map((b) => { const from = i; i += FD.d.cards.filter((c) => c.grp === b.grp).length; return { ...b, from, to: i }; });
}
function fdBatchOf(n) { const B = fdBatches(); const k = B.findIndex((b) => n < b.to); return k < 0 ? B.length - 1 : k; }
function fdCard(c, i) {
  const open = i < FD.done, t = Math.max(0, Math.min(5, c.tier | 0));
  if (!open) return `<button class="fd-c back t${t}" data-fdi="${i}" style="--i:${i}"><span class="fd-bk"><b>73</b><i>${esc(FD.d.batches.find((b) => b.grp === c.grp).name)}</i></span></button>`;
  const lo = fdStar(c.pot[0]), hi = fdStar(c.pot[1]);
  return `<div class="fd-c open t${t}${c.floor ? " fl" : ""}" style="--i:${i}">
    <div class="fd-art"><i class="fd-ini">${esc(initials(c.name))}</i>${c.pid ? `<img src="/img/card/${encodeURIComponent(c.pid)}.png" alt="" onerror="this.replaceWith(Object.assign(document.createElement('img'),{src:'${faceUrl(c.pid)}',className:'fd-face',onerror(){this.remove()}}))">` : ""}</div>
    <div class="fd-info"><b>${esc(c.name)}</b><span>${pos(c.position || "", "")} <em>${c.age} 岁</em></span>
      <div class="fd-st"><span><i>能力</i>${starsHtml(fdStar(c.ca))}</span><span><i>潜力</i>${starsHtml(lo, hi, "pot")}</span></div>
      <small class="fd-tn">${esc(FD_TIER[t])}${c.floor ? ` · <u>已达成保底</u>` : ""}</small></div></div>`;
}
function fdDraw() {
  const d = FD.d, B = fdBatches(), b = B[FD.batch], all = FD.done >= d.cards.length;
  let el = $("#fd");
  if (!el) { el = document.createElement("div"); el.id = "fd"; document.body.appendChild(el); }
  const floor = (d.rules.floor || []).map(([pa, n]) => `${pa >= 170 ? "超级巨星" : pa >= 155 ? "世界级" : "联赛优秀"}及以上 ×${n}`).join("、");
  el.innerHTML = `<div class="fd-top"><div><b>全球梦幻选秀</b><span>${crest(d.team, "sm")}${esc(tname(d.team))} · 档次 <em class="fd-tier t${d.tier}">${esc(d.tier_name)}</em> · ${d.rules.squad} 人 · 年龄 ${d.rules.age[0]}–${d.rules.age[1]} 岁${floor ? ` · 保底：${esc(floor)}` : ""}</span></div>
      <span class="fd-n num">${FD.done}/${d.cards.length}</span></div>
    <nav class="fd-tabs">${B.map((x, k) => `<button class="${k === FD.batch ? "on" : ""}${FD.done >= x.to ? " ok" : ""}" data-fdb="${k}" ${FD.done < x.from && k !== FD.batch ? "disabled" : ""}>${esc(x.name)} <i>${Math.max(0, Math.min(x.to, FD.done) - x.from)}/${x.to - x.from}</i></button>`).join("")}</nav>
    <div class="fd-grid scroll">${d.cards.slice(b.from, b.to).map((c, j) => fdCard(c, b.from + j)).join("")}</div>
    <footer class="fd-ft"><span class="muted">${all ? "全部揭晓！其他球队的阵容可在世界 / 球队 / 球探页查看" : "点牌翻开，好牌在每批最后"}</span>
      <span class="fd-bt">${all ? `<button class="btn pri" data-fdgo data-sound="ok">进入生涯 ›</button>`
        : `<button class="btn" data-fdskip>跳过全部</button><button class="btn" data-fdbatch ${FD.done >= b.to ? "disabled" : ""}>揭晓本批</button><button class="btn pri" data-fdnext>${FD.done >= b.to ? "下一批 ›" : "下一张"}</button>`}</span></footer>`;
  el.classList.add("on");
  $$("[data-fdi]", el).forEach((x) => x.onclick = () => fdFlip(+x.dataset.fdi));
  $$("[data-fdb]", el).forEach((x) => x.onclick = () => { FD.batch = +x.dataset.fdb; sound("cursor"); fdDraw(); });
  const q = (s) => $(s, el);
  if (q("[data-fdnext]")) q("[data-fdnext]").onclick = () => FD.done >= b.to ? (FD.batch = Math.min(B.length - 1, FD.batch + 1), sound("page"), fdDraw()) : fdFlip(FD.done);
  if (q("[data-fdbatch]")) q("[data-fdbatch]").onclick = () => fdTo(b.to, false);
  if (q("[data-fdskip]")) q("[data-fdskip]").onclick = () => fdTo(d.cards.length, false);
  if (q("[data-fdgo]")) q("[data-fdgo]").onclick = fdClose;
}
async function fdFlip(i) {
  if (FD.busy || i !== FD.done) return i > FD.done ? fdFlip(FD.done) : null;     // 只能按顺序翻：点后面的牌也是翻下一张
  const c = FD.d.cards[i];
  if ((c.tier | 0) >= 3 && typeof ytReveal === "function") {                     // 超级巨星及以上：3D 揭晓（同青训）
    FD.busy = true;
    // 国籍与卡上的原俱乐部同青训揭晓；卡上没有俱乐部（国家队卡、传奇卡）时不写我们自己的队徽（用户 2026-11-18），给空俱乐部：3D 台子画 reveal/crest_generic.png 通用队徽
    const club = c.club && c.club.id ? { ...c.club, code: c.club.code || tcode(c.club.id), c: tcolor(c.club.id) } : { name: "", code: "", c: "#555" };
    try { await ytReveal({ name: c.name, position: c.position, pid: c.pid, tier: c.tier, nation: c.nation || {}, club }); }
    catch (e) { /* 演出失败不影响结果 */ }
    FD.busy = false;
  } else sound(c.tier >= 2 ? "ok" : "cursor");
  return fdTo(i + 1, true);
}
async function fdTo(n, one) {
  FD.done = Math.max(FD.done, Math.min(n, FD.d.cards.length));
  if (!one) sound("ok");
  const B = fdBatches();
  if (FD.done >= B[FD.batch].to && FD.done < FD.d.cards.length && !one) FD.batch = fdBatchOf(FD.done);
  fdDraw();
  fdSave();
}
let fdSaving = null;
async function fdSave() {        // 进度写回宿主（失败不要紧：下次进来从已保存的位置接着翻，结果不变）
  if (fdSaving || FD.done <= FD.saved) return;
  const n = FD.done;
  fdSaving = post("/api/fantasy/revealed", { done: n }).then((r) => { if (r && r.ok) FD.saved = Math.max(FD.saved, r.done | 0); }).catch(() => {}).finally(() => { fdSaving = null; if (FD && FD.done > FD.saved) fdSave(); });
}
function fdClose() {
  const el = $("#fd");
  if (el) { el.classList.remove("on"); setTimeout(() => el.remove(), 220); }
  FD = null;
}
window.__fdOpen = fdOpen;                 // 调试 / 回看入口：__fdOpen(true)
/* ================= 开球：夜景地球飞入，点光点俯冲；同时调宿主开赛 ================= */
let stadiums = null, kick = null;
// 主队没有球场坐标时，地球落在这个联赛所在国家（按联赛名关键字），而不是固定的非洲某点
const LEAGUE_SPOTS = [[/English|Premier|Championship/i, 52.6, -1.6], [/Scottish/i, 56.2, -4.2], [/Italian|Serie/i, 42.6, 12.6], [/Spanish|LaLiga|La Liga/i, 40.3, -3.7],
  [/Ligue/i, 46.6, 2.4], [/Eredivisie|Dutch/i, 52.2, 5.4], [/Portugal/i, 39.6, -8.0], [/Brasil|Brazil/i, -15.8, -47.9], [/Argentin/i, -34.6, -58.4],
  [/J1|J2|MEIJI|Japan/i, 35.7, 139.7], [/Chile/i, -33.4, -70.6], [/Swiss/i, 46.9, 8.2], [/S[üu]per Lig|Turk/i, 39.9, 32.9], [/Danish/i, 55.9, 10.2],
  [/Belgian/i, 50.7, 4.5], [/Colombia/i, 4.6, -74.1], [/SEALION|Thai/i, 13.75, 100.5], [/American|MLS/i, 39.5, -98.3], [/Korea/i, 37.0, 127.5],
  [/Malaysia/i, 3.1, 101.7], [/Morocc/i, 32.0, -6.5], [/German|Bundesliga/i, 51.1, 10.4]];
function leagueSpot(name) { const m = LEAGUE_SPOTS.find(([re]) => re.test(name || "")); return m ? { lat: m[1], lon: m[2] } : { lat: 48, lon: 8 }; }
// 逐日推进（2026-11-13）：顶栏右上角平时是“继续”，一天一天往下一场比赛日走；到了比赛日才变成“下一场 · 主/客场 + 对手队徽”，点它进赛前。
// 原生赛程没有“今天”，所以今天的日期只存在前端（localStorage，按赛季存），并夹在“上一场比赛日 ~ 下一场比赛日”之间：
// 踢完一场自动落在那场的比赛日，不会出现“今天晚于/早于赛程”的错位；清了存储最多回到上一场比赛日。日子本身目前只是日历前进，周度的训练/伤病结算仍然按轮。
const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
const dayKey = () => `ml-day:${S.career.user_team}:${S.career.league_key || S.career.league_name}:${S.career.season ?? ""}`;
// M5-D（2026-11-14）：“今天”改由宿主保存（GET /api/calendar，iml_calendar）。用户选“推进到下一事件”：继续＝一直过到下一个要处理的事
// （比赛日、转会窗开/关、联赛结束、6/30）；2026-11-14 起页面的“继续”一律只过一天（mode day），“过一天”按钮已去掉。宿主没有这个接口（旧包）时退回下面原来的前端逐日逻辑。
let CAL = null;
async function loadCal() { try { const c = await api("/api/calendar"); CAL = c && c.date ? c : null; } catch (e) { CAL = null; } return CAL; }
function dayInfo() {
  if (CAL && S && S.next && CAL.next_match) {
    const today = parseD(CAL.date), nd = parseD(CAL.next_match.date);
    return { today, nd, left: Math.max(0, Math.round((nd - today) / 864e5)), matchDay: !!CAL.match_day, server: true };
  }
  const sch = S && S.schedule || [], nx = sch.find((x) => !x.result);
  if (!nx || !S.next) return null;                                            // 没有排期/赛季结束：保持旧行为（直接“下一场”）
  const nd = parseD(nx.date), played = sch.filter((x) => x.result).map((x) => parseD(x.date)), last = played.length ? new Date(Math.max(...played)) : addDays(nd, -6);
  let today = null; try { const v = localStorage.getItem(dayKey()); if (v) today = parseD(v); } catch (e) { /* 无存储就每次从上一场比赛日起 */ }
  if (!today || isNaN(today)) today = last;
  if (today < last) today = last; if (today > nd) today = nd;
  const left = Math.round((nd - today) / 864e5);
  return { today, nd, left, matchDay: left <= 0 };
}
const isMatchDay = () => { const d = dayInfo(); return !d || d.matchDay; };
// M5-D-c：联赛打完到 6 月 30 日是休赛期——“继续”照常一天天往后走（停在 6/30），到了 6/30 右上角才变“进入新赛季”。旧宿主（无日历）照旧直接“赛季总结”。
const offWalk = () => !!(CAL && S && !S.next && S.career.finished && CAL.phase === "offseason" && !CAL.at_ceiling);
const seasonEnd = () => !!(CAL && S && !S.next && S.career.finished && CAL.at_ceiling && !CAL.europe);   // E336：欧战决赛还没踢，不算赛季结束
// E336 欧战（批次 1 只有模拟）：今天是我队的欧冠/欧联比赛日，顶栏右上角变成“欧冠 · 对手队徽”，点它弹模拟确认窗；联赛比赛照旧
const euroToday = () => !!(CAL && CAL.europe && CAL.europe.today);
const euCls = (e = CAL && CAL.europe) => (e && e.comp === "uel" ? "eu-uel" : "eu-ucl");      // 2026-11-18 用户：欧联的下一场也是欧冠（蓝）样式——按赛事上色：欧冠蓝 / 欧联橙黑
const euLogo = (e) => (typeof EU_LOGO === "object" && e && EU_LOGO[e.comp]) || "";
// E341：主页“下一场”取联赛和欧战里更早的那场（同一天欧战在前，日历本来就是欧战先踢）
const euroFirst = () => !!(CAL && CAL.europe && (!S.next || !CAL.next_match || parseD(CAL.europe.date) <= parseD(CAL.next_match.date)));
const dateTxt = (d) => `${d.getMonth() + 1}月${d.getDate()}日 周${WEEK[(d.getDay() + 6) % 7]}`;
const GO_PLAY = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 4l12 8-12 8z"/></svg>', GO_FWD = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 5l9 7-9 7zM12 5l9 7-9 7z"/></svg>';
const GO_CUP = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">${ICON.season}</svg>`;
function goHtml() {
  const n = S.next, c = S.career;
  if (euroToday()) { const e = CAL.europe; return `${crest(e.opponent)}<div>${esc(e.label)}<small>${e.neutral ? "中立场" : e.home ? "主场" : "客场"}</small></div>${GO_PLAY}`; }
  if (!n && c.finished && offWalk()) {                                       // 休赛期：继续往 6/30 走，副标题写今天与下一个停点
    const nxt = (CAL.upcoming || []).find((e) => e.stop);
    return `<div>继续<small>${dateTxt(parseD(CAL.date))} · ${nxt ? esc(nxt.text) : "休赛期"}</small></div>${GO_FWD}`;
  }
  if (!n && c.finished && seasonEnd()) return `<div>进入新赛季<small>6月30日 · 明天第 ${(c.season || 1) + 1} 赛季</small></div>${GO_CUP}`;
  if (!n && c.finished) return `<div>赛季总结<small>第 ${c.season || 1} 赛季</small></div>${GO_CUP}`;      // 赛季打完：右上角变成“赛季总结”，点开后可进入新赛季（2026-11-14）
  if (!n) return `<div>下一场<small>暂无比赛</small></div>${GO_PLAY}`;
  const di = dayInfo();
  if (di && !di.matchDay) {
    const nxt = CAL && (CAL.upcoming || []).find((e) => e.stop && e.kind !== "match" && parseD(e.date) < di.nd);   // 比赛前还有要停下的事：写出来
    return `<div>继续<small>${dateTxt(di.today)} · ${nxt ? esc(nxt.text) : `还有 ${di.left} 天比赛`}</small></div>${GO_FWD}`;
  }
  const home = n.home === me();
  return `${crest(home ? n.away : n.home)}<div>下一场<small>${home ? "主场" : "客场"}</small></div>${GO_PLAY}`;
}
let calBusy = false;
async function advanceDay(mode = "day") {          // 2026-11-14 用户：“继续…不要一次性就跳到下一场比赛 一天一天”——所有“继续”都只过一天
  const off = offWalk(), d = off ? { server: true } : dayInfo(); if (!d || d.matchDay || calBusy) return;
  if (!d.server) {                                                        // 旧宿主：前端逐日
    const nt = addDays(d.today, 1); try { localStorage.setItem(dayKey(), ymd(nt)); } catch (e) { /* 存不了就只在本次有效 */ }
    sound("cursor"); return refreshDay();
  }
  calBusy = true; sound("cursor");
  const r = await post("/api/calendar/advance", { mode }).catch(() => null);
  calBusy = false;
  if (!r || r.error || !r.date) return toast((r && r.error) || "推进失败");
  CAL = r;
  const stop = r.stop, skipped = (r.passed || []).filter((p) => !stop || p.text !== stop.text);
  // 停下的原因：比赛日不提示（按钮自己会变“下一场”）；别的事件给一条提示，途中只记录不停的事（如月初）一并带上
  if (stop && stop.kind !== "match") toast(`${dateTxt(parseD(r.date))} · ${stop.text}`);
  else if (r.moved > 1 && skipped.length) {                               // M5-D-d：途中事件多了（月度财务、伤愈）：只写前两条，其余看日志/通知
    const ts = skipped.filter((p) => p.kind !== "month").map((p) => p.text);
    if (ts.length) toast(`过了 ${r.moved} 天 · ${ts.slice(0, 2).join("、")}${ts.length > 2 ? ` 等 ${ts.length} 件事` : ""}`);
  }
  if (r.moved > 0 || (r.passed || []).length) topSync();
  refreshDay();
}
// M5-D-b：转会窗按日期开关、俱乐部按日期答复报价——过了日子之后经营数据会变。清掉经营缓存（当前页 draw 时重取），
// 顶栏只重画转会窗天数、预算与通知角标（不整壳重建，“继续”保持轻快）。
function topSync() {
  for (const k of ["club", "market", "offers", "inbox", "finance", "squad", "lineup", "depth", "brief", "changes", "youth", "coach"]) delete BIZ[k];
  Promise.all([biz("club"), biz("inbox")]).then(([club, inbox]) => {
    const win = club && club.window, w = $('.top [data-jump="season:2"]'), m = $('.top [data-k="top-budget"]'), dl = $("#drawer .inbox");
    if (dl && inbox) {                                                     // 铃铛抽屉里的通知也换成新的（点击同 renderShell）
      dl.innerHTML = inbox.items.map((x) => msgHtml(x, `data-ibx="${x.id}" style="cursor:pointer"`)).join("");
      $$("[data-ibx]", dl).forEach((el) => el.onclick = () => { ibxSel = ibxId(el.dataset.ibx); ibxKind = "all"; $("#drawer").classList.remove("open"); openSec("home", 1); });
    }
    if (w && win) { w.innerHTML = winStat(win); w.title = `${winTip(win)} · 查看日程表`; }
    if (m && club) {                                                       // M6-E1：顶栏是“可用”，悬停看余额 / 已承诺 / 可用
      const v = club.available ?? club.budget; m.textContent = money(v); m.dataset.to = v;
      // E360（用户：“可用资金的话，就只显示钱”）：顶栏只写金额，“可用资金 / 转会预算”写进悬停提示
      const st = m.closest(".stat"); if (st) st.title = `${club.committed || (club.wage_alloc && club.wage_alloc.reserved) ? "可用资金" : "转会预算"} · ${budgetTip(club)}`;
    }
    refreshBadges(); fitTop();
  }).catch(() => {});
}
// 模拟比赛（2026-11-13 用户：“希望可以出一个模拟比赛的功能，不用我们踢的，直接模拟，要求数据合理一点”）：
// 宿主按双方首发的 CA、球队状态（我方状态箭头与体能、对手近 5 场战绩）和主客场推演整场比分与进球 / 助攻（2026-11-15 起不受对手难度影响，难度只管手动比赛），
// 再走和实际比赛同一条赛季结算（积分榜、出场进球统计、体能伤病成长照常变化）。主页的胜平负概率也来自这同一个模型。
const SIM_ERR = { "match-running": "有一场比赛正在进行", "squad-incomplete": "首发不足 11 人，先去阵容页补齐", "no-season": "赛季已结束", busy: "正在进入比赛，稍后再试", "no-ml-profile": "还没有大师联赛存档" };
// 点“模拟”只弹一个确认窗（用户 2026-11-13：“不要做二级菜单，弹窗问玩家是否要模拟就行了”），确认后直接模拟并打开战报。
function openSim() {
  const f = S && S.next; if (!f || $("#simdlg")) return;
  const el = document.createElement("div"); el.id = "simdlg"; el.className = "dlg-back";
  el.innerHTML = `<div class="dlg" role="dialog" aria-modal="true"><b class="dlg-t">是否模拟这场比赛？</b>
    <div class="dlg-b"><button id="dlg-no">取消</button><button id="dlg-yes" class="pri">模拟</button></div></div>`;
  document.body.appendChild(el);
  const close = () => { document.removeEventListener("keydown", onKey); el.remove(); };
  const onKey = (e) => { if (e.key === "Escape" && !$("#dlg-yes").disabled) close(); };
  document.addEventListener("keydown", onKey);
  el.addEventListener("click", (e) => { if (e.target === el && !$("#dlg-yes").disabled) { sound("back"); close(); } });
  $("#dlg-no").onclick = () => { sound("back"); close(); };
  $("#dlg-yes").onclick = async () => {
    const y = $("#dlg-yes"), n = $("#dlg-no"); if (y.disabled) return; y.disabled = n.disabled = true; y.textContent = "模拟中…";
    const r = await post("/api/sim", {});
    if (r && r.reason === "result-unknown") { close(); await refresh(true); return toast(r.error || "数据暂时不可用"); }
    if (!r || r.error || !r.ok) { y.disabled = n.disabled = false; y.textContent = "模拟"; return toast(SIM_ERR[r && r.reason] || (r && r.error) || "模拟失败"); }   // 只有宿主明确回 ok 才算模拟成功
    sound("ok"); close(); $$(".layer").forEach((l) => l.remove()); screen = "game"; await refresh(true);
    const m = S && S.career ? lastMine() : null; if (m && (!r.fixture || m.round === r.fixture)) openReport(m.id);   // 只开这一轮的战报，不会误开上一场
  };
}
// E336：欧战比赛日的模拟确认窗。宿主 POST /api/europe/sim 按 CA 模型踢完这场（双回合次回合打平当场加时/点球），同晚其他比赛一并结算。
const EURO_ERR = { "not-today": "还没到欧战比赛日", "no-match": "没有要踢的欧战比赛", "match-running": "有一场比赛正在进行", "squad-incomplete": "首发不足 11 人，先去阵容页补齐", busy: "正在进入比赛，稍后再试" };
async function euTeams() {                       // 欧战对手多半不在本联赛：队名/颜色在 /api/europe 里（没开过欧战页时 S.teams 里没有，会显示 #编号）
  if (!S || !CAL || !CAL.europe || (S.teams && S.teams[CAL.europe.opponent])) return;
  try { const d = await api("/api/europe"); for (const [k, v] of Object.entries((d && d.teams) || {})) if (!S.teams[k]) S.teams[k] = v; } catch (err) { /* 名字缺了就显示编号，不挡比赛 */ }
}
async function openEuroSim() {
  const e = CAL && CAL.europe; if (!e || $("#simdlg")) return;
  await euTeams(); if ($("#simdlg")) return;
  const el = document.createElement("div"); el.id = "simdlg"; el.className = "dlg-back";
  el.innerHTML = `<div class="dlg" role="dialog" aria-modal="true"><b class="dlg-t">是否模拟这场比赛？</b>
    <div class="eu-dlg-note">${esc(e.text)}。两回合打平：次回合加时、点球由系统决出。</div>
    <div class="dlg-b"><button id="dlg-no">取消</button><button id="dlg-yes" class="pri">模拟</button></div></div>`;
  document.body.appendChild(el);
  const close = () => { document.removeEventListener("keydown", onKey); el.remove(); };
  const onKey = (ev) => { if (ev.key === "Escape" && !$("#dlg-yes").disabled) close(); };
  document.addEventListener("keydown", onKey);
  el.addEventListener("click", (ev) => { if (ev.target === el && !$("#dlg-yes").disabled) { sound("back"); close(); } });
  $("#dlg-no").onclick = () => { sound("back"); close(); };
  $("#dlg-yes").onclick = async () => {
    const y = $("#dlg-yes"), n = $("#dlg-no"); if (y.disabled) return; y.disabled = n.disabled = true; y.textContent = "模拟中…";
    const r = await post("/api/europe/sim", {}).catch(() => null);
    if (!r || r.error || !r.ok) { y.disabled = n.disabled = false; y.textContent = "模拟"; return toast(EURO_ERR[r && r.reason] || (r && r.error) || "模拟失败"); }
    sound("ok"); close(); $$(".layer").forEach((l) => l.remove());
    euSel = null; euMode = null; screen = "game"; await refresh(true); await loadCal(); topSync();
    await openEuroReport(r.id ? "eu:" + r.id : null);                       // E341：和联赛一样，模拟完直接打开这场的战报
  };
}
// E341：欧战战报＝联赛的战报页（宿主 /api/fixture/eu:<场次> 给出同结构的比赛，另带赛事名与两回合总比分）。没有场次号就取最近一场；都没有退回欧战页。
async function euTeamsAll() {
  if (!S) return;
  try { const d = await api("/api/europe"); for (const [k, v] of Object.entries((d && d.teams) || {})) if (!S.teams[k]) S.teams[k] = v; return d; } catch (err) { return null; }
}
async function openEuroReport(id) {
  const d = await euTeamsAll();
  const fid = id || (d && d.last);
  if (!fid) { navLink("season:6"); return; }
  delete fxCache[fid];
  await openReport(fid);
}
function refreshDay() {
  const sb = $("#simbtn"); if (sb) sb.disabled = !(euroToday() || (S.next && isMatchDay()));
  const g = $(".go"); if (g) { g.innerHTML = goHtml(); g.classList.toggle("eu", euroToday()); g.classList.remove("eu-ucl", "eu-uel"); if (euroToday()) g.classList.add(euCls()); g.classList.remove("tick"); void g.offsetWidth; g.classList.add("tick"); fitTop(); }
  quietDraw = true; draw();
}
// cup：欧战比赛日“亲自踢”（E336 批次 2）——和联赛开球同一套过场与同一个宿主开赛作业；宿主按“欧战比赛日到了”把原生对手换成欧战对手，
// 结算进欧战而不是联赛。传入 CAL.europe；球队按主客场/中立场摆好（中立场的决赛我方按主队走）。
async function kickoff(cup) {
  if (!(cup && cup.y17) && window.__y7kick) { window.__y7kick = false; post("/api/rc29/y17/unkick", {}); }
  if (!cup && euroToday()) cup = CAL.europe;                                  // E341：欧战比赛日和联赛一样，“开始比赛”直接进开球过场（模拟在顶栏的模拟键）
  if (cup) await euTeams();
  const f = cup ? { home: cup.home || cup.neutral ? me() : cup.opponent, away: cup.home || cup.neutral ? cup.opponent : me(), round: 0 } : S && S.next;
  if (!f || kick) return;
  if (!cup && !isMatchDay()) return advanceDay();
  sound("ok");
  if (!stadiums) { try { stadiums = await (await fetch("/data/stadiums.json")).json(); } catch (e) { stadiums = {}; } }
  const st = cup && cup.neutral ? null : stadiums[String(f.home)], el = $("#kickoff"), k = kick = { earth: null, going: false };
  const where = st ? { lat: st.lat, lon: st.lon } : cup ? { lat: 48, lon: 8 } : leagueSpot(S.career.league_key || S.career.league_name);   // no stadium on file: the league's country（欧战：欧洲中部）
  const side = (tid, where) => `<div class="kt ${where}">${where === "home" ? `<div><b>${esc(tname(tid))}</b></div>${crest(tid)}` : `${crest(tid)}<div><b>${esc(tname(tid))}</b></div>`}</div>`;
  el.innerHTML = `<div class="ko2-scene"></div><div class="ko2-scrim"></div><div class="ko2-flash"></div>
    <div class="ko2-top">${cup ? `${cup.comp && euLogo(cup) ? `<i class="eulg ${euCls(cup)}">${euLogo(cup)}</i>` : ""}<b>${esc(cup.label)}</b><span>${cup.neutral ? "中立场" : cup.home ? "主场" : "客场"}</span>` : `${lgLogo()}<b>${esc(S.career.league_name)}</b><span>Round ${f.round} / ${S.career.rounds_total}</span>`}</div>
    <div class="ko2-teams">${side(f.home, "home")}<div class="vsmark">VS</div>${side(f.away, "away")}</div>
    <div class="ko2-pin${st ? "" : " nov"}"><i class="ko2-lead"></i><button class="ko2-hit" data-go-match data-sound="ok" aria-label="进入比赛"></button></div>
    <div class="ko2-venue">${st ? `<b>${esc(st.name)}</b><span>${esc(st.city || "")}${st.en ? ` · ${esc(st.en)}` : ""}${st.cap ? ` · ${(+st.cap).toLocaleString()}` : ""}</span>` : ""}</div>
    <div class="ko2-note" id="ko-note"></div>
    <div class="ko2-bar"><button class="btn" id="ko-cancel" data-sound="back">取消</button></div>
    <div class="ko3-board">${crest(f.home)}<b>${esc(tname(f.home))}</b><i>VS</i><b>${esc(tname(f.away))}</b>${crest(f.away)}</div>
    <div class="ko3-cap" id="ko-cap"></div><div class="ko3-line"><i id="ko-line"></i></div>
    <div class="ko3-xi" id="ko-xi"></div>
    <div class="ko2-black"></div><div class="ko3-white"></div>`;
  el.className = "kickoff"; el.hidden = false; void el.offsetWidth; el.classList.add("on");
  $("#ko-cancel").onclick = () => { if (cup && cup.y17) { window.__y7kick = false; post("/api/rc29/y17/unkick", {}); } kickClose(k); };
  $$("[data-go-match]", el).forEach((b) => b.onclick = () => kickGo(k));
  const stage = () => { el.classList.add("lock"); [[180, "tm-in"], [520, "vs-in"], [900, "venue-in"]].forEach(([ms, c]) => setTimeout(() => { if (kick === k) el.classList.add(c); }, REDUCED ? 0 : ms)); };
  try {
    const { KickoffEarth } = await import("/kickoff3d.js");
    if (kick !== k) return;
    const pinEl = $(".ko2-pin", el), lead = $(".ko2-lead", el), venue = $(".ko2-venue", el);
    k.earth = new KickoffEarth($(".ko2-scene", el), Object.assign(where, {
      color: getComputedStyle(document.documentElement).getPropertyValue("--club").trim(), onLock: stage,
      onPin: (x, y, on) => { if (!pinEl) return; pinEl.style.transform = `translate(${x}px, ${y}px)`; pinEl.style.opacity = on; lead.style.height = Math.max(0, venue.offsetTop - y - 4) + "px"; } }));
    await k.earth.load(); if (kick !== k) return;
    await k.earth.play(REDUCED ? 1 : 2400);
  } catch (e) {
    console.warn("kickoff earth unavailable", e);       // 没有 WebGL 也能开赛：只是没有地球背景
    ["lock", "tm-in", "vs-in", "venue-in"].forEach((c) => el.classList.add(c));
  }
}
// 宿主约定：startMatch() 开始；进到原生赛前画面后宿主调 MlLeague.matchReady()，失败调 MlLeague.matchFailed("原因")。
// 宿主在等用户进 AI Division 主页时最长约 210 秒，这里的保护时间放到 240 秒，避免宿主还在等时界面先判失败。
// 2026-11-13：开赛过场跟着真实开赛阶段走，不再“俯冲→黑屏→转圈”。阶段来自宿主作业（GET /api/start/status → iml_host.status().stage）；
// 取不到（预览、旧网关）时按实机测得的时长模拟。画面上只讲比赛日的故事（热身 → 更衣室 → 入场 → 开球），不出现技术阶段名。
// 进度是连续的：每段内按该段的典型时长慢慢往前爬（最多爬到下一段前 85%），地球跟着进度连续下降、缓慢环绕，没有停顿；
// 宿主报 matchReady（原生赛前画面已出）时才完成俯冲、白闪、切走。
const KO_STEPS = [["球员正在热身", ["start", "page", "open", "hop"], 3000], ["主教练在更衣室讲话", ["switch"], 5500],
  ["球员入场", ["back", "reenter", "form"], 7500], ["准备开球", ["proceed"], 4000]];   // [字幕, 宿主阶段, 该段典型时长 ms（实机测得）]
const KO_SIM = [0, 3000, 8500, 16000];          // 预览：各段开始的毫秒
function koStep(k, i) {
  if (!k || kick !== k || !k.going || i <= k.step) return;
  k.step = i; k.stepT0 = performance.now();
  const cap = $("#ko-cap");
  if (cap) {
    $$("span", cap).forEach((s) => { s.classList.add("out"); setTimeout(() => s.remove(), 700); });
    const s = document.createElement("span"); s.textContent = KO_STEPS[i][0]; cap.appendChild(s);
    void s.offsetWidth; s.classList.add("in");
  }
  if (i === 1) koLineup(k);
}
function koProgress(k) {                          // 0..1, continuous: completed steps + a creep inside the current one
  if (k.step < 0) return 0;
  const n = KO_STEPS.length, dur = KO_STEPS[k.step][2], inStep = Math.min(0.85, (performance.now() - k.stepT0) / dur * 0.85);
  return Math.min(1, (k.step + (k.finishing ? 1 : inStep)) / n);
}
function koLoop(k) {                              // drives the progress line and the globe every frame
  const line = $("#ko-line");
  const frame = () => {
    if (kick !== k || !k.going) return;
    const p = koProgress(k);
    if (line) line.style.transform = `scaleX(${p.toFixed(4)})`;
    if (k.earth && !k.finishing) k.earth.follow(0.12 + p * 0.74);
    k.raf = requestAnimationFrame(frame);
  };
  k.raf = requestAnimationFrame(frame);
}
async function koLineup(k) {
  let t; try { t = await team(me()); } catch (e) { return; }
  if (kick !== k || !k.going) return;
  const xi = t.squad.filter((p) => p.starter).slice(0, 11);
  const box = $("#ko-xi"); if (!box) return;
  box.innerHTML = xi.map((p, i) => `<div class="ko3-p" style="--d:${i}"><i class="pf"><img src="/img/player/${encodeURIComponent(p.pid)}.png" alt="" onerror="this.remove()"></i><span>${esc(short(p.name))}</span></div>`).join("");
  void box.offsetWidth; box.classList.add("in");
}
function koWatch(k) {
  const t0 = performance.now(), names = KO_STEPS.map((s) => s[1]);
  let real = null;                                // null = not known yet, false = simulate, true = host stages
  const tick = async () => {
    if (kick !== k || !k.going) return;
    if (real !== false) {
      try {
        const st = await api("/api/start/status");
        if (st && st.kind === "start" && st.stage) { real = true; const i = names.findIndex((n) => n.includes(st.stage)); if (i >= 0) koStep(k, i); }
        else if (real === null) real = false;
      } catch (e) { if (real === null) real = false; }
    }
    if (real === false) { const ms = performance.now() - t0; KO_SIM.forEach((at, i) => { if (ms >= at) koStep(k, i); }); }
    k.watch = setTimeout(tick, 400);
  };
  tick();
}
function kickGo(k) {
  if (k.going) return; k.going = true; k.step = -1;
  const el = $("#kickoff"); el.classList.add("ko-go"); $("#ko-note").textContent = "";
  koStep(k, 0); koWatch(k); koLoop(k);
  k.guard = setTimeout(() => matchFailed(k, "开赛超时，请重试"), 240000);
  const h = host();
  if (h && h.startMatch) { try { h.startMatch(); } catch (e) { matchFailed(k, e.message); } }
  else k.fake = setTimeout(() => window.MlLeague.matchReady(), 21000);   // 预览：约 21 s 后当作原生赛前画面已出现
}
function koFinish(k) {                               // the native pre-match screen is up: finish the dive, flash, hand over
  const el = $("#kickoff");
  koStep(k, KO_STEPS.length - 1); k.finishing = true;
  const line = $("#ko-line"); if (line) line.style.transform = "scaleX(1)";
  el.classList.add("finish");
  const close = () => kickClose(k);
  if (k.earth && !REDUCED) { k.earth.approach(1, 1100).then(() => setTimeout(close, 300)); } else close();
}
function matchFailed(k, msg) {
  if (!k || kick !== k || !k.going) return;
  clearTimeout(k.guard); clearTimeout(k.fake); clearTimeout(k.watch); cancelAnimationFrame(k.raf); k.going = false; k.finishing = false;
  const el = $("#kickoff"); el.classList.remove("ko-go", "black", "loading", "finish");
  const cap = $("#ko-cap"); if (cap) cap.innerHTML = "";
  const line = $("#ko-line"); if (line) line.style.transform = "scaleX(0)";
  const box = $("#ko-xi"); if (box) { box.classList.remove("in"); box.innerHTML = ""; }
  $("#ko-note").textContent = msg || "";
  if (k.earth) k.earth.undive(REDUCED ? 1 : 700);
}
function kickClose(k = kick) {
  if (!k || kick !== k) return; kick = null;
  clearTimeout(k.guard); clearTimeout(k.fake); clearTimeout(k.watch); cancelAnimationFrame(k.raf);
  const el = $("#kickoff"); el.classList.remove("on");
  setTimeout(() => { if (k.earth) k.earth.dispose(); if (!kick) { el.hidden = true; el.innerHTML = ""; el.className = "kickoff"; } }, REDUCED ? 0 : 260);
}
window.MlLeague = {
  simDone,
  matchReady() { const k = kick; if (!k || !k.going) return; clearTimeout(k.guard); clearTimeout(k.watch); koFinish(k); },
  matchFailed(msg) { matchFailed(kick, msg); },
  refresh() { return refresh(true); },
  // 性能（2026-11-14）：宿主把面板藏起来（开赛后整场比赛都是藏着的）时调用 setHidden(true)：停掉定时刷新、暂停所有 CSS 动画；再显示时恢复并刷新一次
  setHidden(h) {
    hostHidden = !!h;
    document.documentElement.classList.toggle("host-hidden", hostHidden);
    if (!hostHidden && screen === "game") refresh();
  },
  // 比赛结算后回到 AI Division：宿主把面板拉回来并调用这里（round = 刚踢的轮次），直接显示这场的战报。
  async postMatch(round) {
    if (kick) kickClose(kick);
    document.querySelectorAll(".intro").forEach((el) => el.remove());   // 赛后直接回经营界面，不放开场动画、不经过主菜单
    if (round >= 5000 && window.y7AfterMatch) { await refresh(true).catch(() => {}); screen = "y17"; return window.y7AfterMatch(round); }
    screen = "game";
    await refresh(true);
    if (!S || !S.career) return;
    if (round >= 1000) {                                                // E336 批次 2：踢完的是欧战比赛（宿主给 1000+序号）：回欧战页，不开联赛战报
      await loadCal(); topSync(); euSel = null; euMode = null;
      await openEuroReport(null);                                       // E341：回到主页并打开这场欧战的战报（和联赛一样）
      return;
    }
    const f = lastMine();
    if (f && (!round || f.round === round)) openReport(f.id);
  },
};

/* ================= 存档 / 读档 / 导出导入（E367，2026-11-18 用户：“我现在想做一个存档系统”→“按你想的来吧 可以导出”） ================= */
// 宿主 iml_saves：5 个手动槽 + 自动存档（生涯有进度就写）+ 读档前备份（读错了可以读回来）。
// 导出 / 导入走 AndroidMlLeague.exportSave / importSave（系统文件选择器），结果回调 MlLeague.saveTransferDone。
const sv = { list: null, current: null, busy: false, confirm: null, error: "" };
const SV_LABEL = { auto: "自动存档", backup: "读档前备份" };
const SV_FAIL = {
  "no-season": "还没有进行中的生涯", "match-armed": "比赛已经准备开始，踢完这场再存 / 读档", "empty-slot": "这个存档位是空的",
  newer: "这个存档来自更新的游戏版本，请先更新游戏", "bad-file": "存档文件已损坏或不是大师联赛存档", "too-large": "存档文件太大",
  "migration-failed": "存档没能升级到当前版本，当前生涯没有改动", "bad-slot": "这个存档位不能这样操作", busy: "正在进入比赛，稍后再试",
  "no-ml-profile": "还没有大师联赛存档", "no-file": "没有收到文件", "unknown-action": "当前版本还不支持存档，请更新到最新版本",
};
const svErr = (r) => SV_FAIL[r && r.reason] || (r && /[一-龥]/.test(r.error || "") ? r.error : "") || "操作没有完成，请重试";
function svWhen(t) {
  if (!t) return "";
  const d = new Date(t * 1000), p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}
function svLine(m) {
  if (!m) return "";
  return [m.league_name, `第 ${m.season || 1} 季`, m.rounds ? `第 ${m.round} / ${m.rounds} 轮` : "", m.date || ""].filter(Boolean).map(esc).join(" · ");
}
function svClub(m) {
  const tid = m && m.team;
  return `<div class="sv-club"><span class="cw"><img src="/img/emblem/${tid}.png" alt="" onerror="this.parentNode.classList.add('fb')"><i>${esc(String((m && m.team_name) || "?").slice(0, 3))}</i></span>
    <div><b>${esc((m && m.team_name) || (tid ? tname(tid) : "—"))}</b><small>${svLine(m)}</small></div></div>`;
}
function svRecord(m) {
  if (!m || m.points == null) return "";
  return `<div class="sv-rec"><span><small>排名</small><b class="num">${m.rank || "—"}</b></span><span><small>积分</small><b class="num">${m.points}</b></span><span><small>战绩</small><b class="num">${m.won}-${m.drawn}-${m.lost}</b></span></div>`;
}
async function openSaves() {
  sound("page"); screen = "saves"; sv.confirm = null; sv.error = ""; sv.list = null;
  drawSaves();
  await svReload();
}
async function svReload() {
  const r = await post("/api/saves/list", {});
  if (screen !== "saves") return;
  if (!r || r.error) { sv.list = []; sv.error = svErr(r); } else { sv.list = r.slots || []; sv.current = r.current || null; sv.error = ""; }
  drawSaves();
}
function svCard(x) {
  const h = host(), manual = x.kind === "manual", cur = !!sv.current;
  const title = manual ? `存档 ${x.slot}` : SV_LABEL[x.slot] || x.slot;
  const acts = [];
  if (manual && cur) acts.push(`<button class="btn" data-sv="save" data-slot="${x.slot}">${x.empty ? "保存到这里" : "覆盖保存"}</button>`);
  if (!x.empty && !x.damaged) acts.push(`<button class="btn pri" data-sv="load" data-slot="${x.slot}">读取</button>`);
  if (!x.empty && !x.damaged && h && h.exportSave) acts.push(`<button class="btn" data-sv="export" data-slot="${x.slot}">导出</button>`);
  if (manual && h && h.importSave) acts.push(`<button class="btn" data-sv="import" data-slot="${x.slot}">导入</button>`);
  if (!x.empty && x.slot !== "backup") acts.push(`<button class="btn ghost" data-sv="delete" data-slot="${x.slot}">删除</button>`);
  const body = x.empty ? `<div class="sv-empty">${manual ? "空存档位" : x.slot === "auto" ? "生涯推进后会自动保存在这里" : "读档前会把当时的生涯备份在这里"}</div>`
    : x.damaged ? `<div class="sv-empty dn">存档文件已损坏（${esc(SV_FAIL[x.reason] || x.reason || "")}）</div>`
    : `${svClub(x.summary)}${svRecord(x.summary)}`;
  return `<div class="sv-card${x.empty ? " empty" : ""}${manual ? "" : " sys"}"><div class="sv-hd"><b>${esc(title)}</b><small>${esc(svWhen(x.time))}</small></div>${body}<div class="sv-acts">${acts.join("")}</div></div>`;
}
function svConfirmText(c) {
  const x = (sv.list || []).find((s) => s.slot === c.slot) || {}, name = x.kind === "manual" ? `存档 ${c.slot}` : SV_LABEL[c.slot] || c.slot;
  if (c.act === "save") return { t: `覆盖 ${name}？`, p: `${name}里原来的生涯会被当前生涯替换。`, ok: "覆盖保存" };
  if (c.act === "load") return { t: `读取 ${name}？`, p: `当前生涯会被替换成这个存档。读档前会自动把当前生涯存到“读档前备份”，读错了可以读回来。`, ok: "读取存档" };
  if (c.act === "delete") return { t: `删除 ${name}？`, p: "删除后不能恢复。", ok: "删除" };
  if (c.act === "import") return { t: `导入到 ${name}？`, p: x.empty ? "选择一个 .imlsave 存档文件，导入后在这里读取。" : `${name}里原来的存档会被导入的文件替换。`, ok: "选择文件" };
  return { t: "", p: "", ok: "确定" };
}
function drawSaves() {
  if (screen !== "saves") return;
  const L = sv.list;
  const c = sv.confirm, ct = c ? svConfirmText(c) : null;
  $("#app").innerHTML = `<div class="pick saves"><header><div class="mn-brand sm"><b>73</b><span>${WORDMARK}</span></div><b class="pk-t">存档</b><span>保存、读取、导出你的生涯</span><button class="btn" id="svback" data-sound="back">‹ 主菜单</button></header>
    <div class="sv-now">${sv.current ? `<small class="mn-cap">当前生涯</small>${svClub(sv.current)}` : `<small class="mn-cap">当前没有进行中的生涯</small>`}</div>
    <div class="sv-grid scroll">${L === null ? `<div class="loading-screen">正在读取存档…</div>` : L.length ? L.map(svCard).join("") : ""}</div>
    <footer>${sv.error ? `<span class="dn">${esc(sv.error)}</span>` : `<span class="pk-hint">${sv.busy ? "正在处理…" : "读档、覆盖前都会再确认一次"}</span>`}</footer>
    ${ct ? `<div class="mn-modal"><div class="mn-dlg"><b>${esc(ct.t)}</b><p>${esc(ct.p)}</p>
      <div class="mn-acts"><button class="btn" data-svc="no" data-sound="back">取消</button><button class="btn pri" data-svc="yes" data-sound="ok">${esc(ct.ok)}</button></div></div></div>` : ""}
  </div>`;
  $("#svback").onclick = toMenu;
  $$("[data-sv]").forEach((b) => b.onclick = () => svAsk(b.dataset.sv, b.dataset.slot));
  $$("[data-svc]").forEach((b) => b.onclick = () => { const cc = sv.confirm; sv.confirm = null; if (b.dataset.svc === "yes" && cc) return svDo(cc.act, cc.slot); sound("back"); drawSaves(); });
}
function svAsk(act, slot) {
  if (sv.busy) return;
  const x = (sv.list || []).find((s) => s.slot === slot) || {};
  if (act === "export" || (act === "save" && x.empty)) return svDo(act, slot);
  sound("open"); sv.confirm = { act, slot }; drawSaves();
}
async function svDo(act, slot) {
  if (sv.busy) return;
  const h = host();
  if (act === "export" || act === "import") {
    const fn = act === "export" ? h && h.exportSave : h && h.importSave;
    if (!fn) { toast("（预览）导出 / 导入由游戏里的系统文件选择器完成"); return drawSaves(); }
    sv.busy = true; drawSaves();
    let started = false;
    try { started = !!fn.call(h, slot); } catch (e) { started = false; }
    if (!started) { sv.busy = false; toast("系统文件选择器打不开，请稍后再试"); drawSaves(); }
    return;                                         // 结果由宿主回调 saveTransferDone
  }
  sv.busy = true; drawSaves();
  const r = await post(`/api/saves/${act}`, { slot });
  sv.busy = false;
  if (!r || r.error || r.ok === false) { sound("back"); toast(svErr(r)); return svReload(); }
  sound("ok");
  if (act === "load") {
    toast("存档已读取");
    for (const k of Object.keys(BIZ)) delete BIZ[k];
    cur = { sec: "home", tab: 0 }; screen = "menu";
    await refresh(true);
    return renderMenu();
  }
  toast(act === "save" ? "已保存" : "已删除");
  svReload();
}
function saveTransferDone(kind, raw) {
  sv.busy = false;
  let r = null;
  try { r = typeof raw === "string" ? JSON.parse(raw) : raw; } catch (e) { r = null; }
  if (r && r.cancelled) { if (screen === "saves") drawSaves(); return; }
  if (!r || r.error || r.ok === false) toast(svErr(r));
  else { sound("ok"); toast(kind === "export" ? "存档已导出" : "存档已导入，可以在存档位里读取"); }
  if (screen === "saves") svReload();
}
window.MlLeague.saveTransferDone = saveTransferDone;
/* ================= 开场动画与主菜单（2026-11-13 用户：“先给一个简短又高级的开场动画 73efootball，然后进入主菜单：退出 / 新建游戏 / 继续游戏”） ================= */
// 画面：intro（开场）→ menu（主菜单）→ game（经营界面）| pick（新建游戏选队）。轮询刷新只重画当前画面。
let screen = "intro", menuSel = 0, menuConfirm = false;
const WORDMARK = "EFOOTBALL";
function playIntro() {
  return new Promise((done) => {
    const el = document.createElement("div");
    el.className = "intro";
    el.innerHTML = `<svg class="in-lines" viewBox="0 0 400 240" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
        <rect x="18" y="18" width="364" height="204"/><path d="M200 18v204"/><circle cx="200" cy="120" r="34"/><circle cx="200" cy="120" r="1.5"/>
        <rect x="18" y="72" width="50" height="96"/><rect x="332" y="72" width="50" height="96"/><rect x="18" y="98" width="18" height="44"/><rect x="364" y="98" width="18" height="44"/></svg>
      <div class="in-glow"></div>
      <div class="in-box"><div class="in-mark"><b class="in-73"><span class="r">7</span><span class="w">3</span></b><span class="in-wm">${WORDMARK.split("").map((c, i) => `<i style="--d:${i}">${c}</i>`).join("")}</span></div>
        <div class="in-rule"></div><div class="in-sub">MASTER LEAGUE</div></div>
      <i class="in-sweep"></i>`;
    document.body.appendChild(el);
    const ld = $(".loading-screen"); if (ld) ld.textContent = "";      // 开场时不露出底下的“正在载入…”
    let over = false;
    const end = () => { if (over) return; over = true; el.classList.add("out"); setTimeout(() => { el.remove(); done(); }, REDUCED ? 0 : 450); };
    el.addEventListener("pointerdown", end);                      // 点一下跳过
    setTimeout(end, REDUCED ? 400 : 2700);
  });
}
const MENU = () => {
  const c = S && S.career;
  return [
    { k: "continue", t: "继续游戏", s: c ? `${tname(me())} · ${c.league_name} · 第 ${c.current_round} / ${c.rounds_total} 轮` : "还没有存档", ic: "play", off: !c },
    { k: "new", t: "新建游戏", s: "选择联赛与执教球队，开始新的生涯", ic: "plus" },
    { k: "saves", t: "存档", s: "保存、读取、导出导入生涯存档", ic: "doc" },
    { k: "y17", t: "Champions League 2017", s: "Real matches in My League · table, scorers, news, Ballon d’Or", ic: "cups" },
    { k: "exit", t: "退出", s: "要回到普通游戏，请重新进入游戏", ic: "exit" },
  ];
};
let ownSq = null;
async function ownLoad() { try { ownSq = await api("/api/rc29/own"); } catch (e) { ownSq = null; } if (screen === "menu") renderMenu(); }
const ownRow = () => ownSq && !ownSq.error ? `<div class="own-row"><div><b>Play with</b><small>${ownSq.on ? "Your own squad (like My League) - your main team's 23 cards" : "The club's real players"}</small></div><span class="own-seg"><button class="${ownSq.on ? "" : "on"}" data-own="0">Club squad</button><button class="${ownSq.on ? "on" : ""}" data-own="1">My squad</button></span></div>` : "";
async function ownSet(on) { const r = await post("/api/rc29/own", { on }); if (r && r.error) { toast(r.reason || r.error); } else { ownSq = r; sound("ok"); toast(on ? "Your own squad will play the Master League matches" : "The club's players are back"); } renderMenu(); }
function saveCard() {
  const c = S && S.career;
  if (!S) return `<div class="mn-empty">${svg("doc", 1.5)}<b>数据暂时不可用</b><small>稍后再打开大师联赛</small></div>`;
  if (!c) return `<div class="mn-empty">${svg("ball", 1.5)}<b>还没有存档</b><small>新建游戏，选择一支球队开始你的第一个赛季</small></div>`;
  const r = row(me()) || {}, n = S.next, opp = n ? (n.home === me() ? n.away : n.home) : null;
  return `<div class="mn-sv"><small class="mn-cap">当前存档</small>
      <div class="mn-club">${crest(me(), "xl")}<div><b>${esc(tname(me()))}</b><span>${lgLogo()}${esc(c.league_name)} · 第 ${c.season || 1} 季</span></div></div>
      <div class="mn-stats"><div><small>轮次</small><span class="num">${c.current_round}<i>/${c.rounds_total}</i></span></div>
        <div><small>排名</small><span class="num">${r.position || "—"}</span></div><div><small>积分</small><span class="num">${r.points ?? 0}</span></div>
        <div><small>战绩</small><span class="num sm">${r.won ?? 0}-${r.drawn ?? 0}-${r.lost ?? 0}</span></div></div>
      <div class="mn-next">${n ? `<small>下一场</small>${crest(opp, "sm")}<b>${esc(tname(opp))}</b><em>${n.home === me() ? "主场" : "客场"}</em>` : `<small>${c.finished ? "赛季已结束" : "暂无比赛"}</small>`}</div></div>`;
}
function renderMenu() {
  screen = "menu";
  const c = S && S.career;
  document.documentElement.style.setProperty("--club", (c && c.club_color) || "#2c3038");
  document.documentElement.style.setProperty("--club-ink", (c && c.club_ink) || "#fff");
  const items = MENU();
  if (items[menuSel] && items[menuSel].off) menuSel = items.findIndex((x) => !x.off);
  $("#app").innerHTML = `<div class="menu">
    <svg class="mn-pitch" viewBox="0 0 400 240" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><rect x="18" y="18" width="364" height="204"/><path d="M200 18v204"/><circle cx="200" cy="120" r="34"/><rect x="18" y="72" width="50" height="96"/><rect x="332" y="72" width="50" height="96"/></svg>
    <div class="mn-left">
      <div class="mn-brand"><b><span class="r">7</span>3</b><span>${WORDMARK}</span></div>
      <h1>大师联赛</h1><div class="mn-en">MASTER LEAGUE</div>
      <nav class="mn-list">${items.map((x, i) => `<button class="mn-it${i === menuSel ? " on" : ""}" data-menu="${x.k}" data-i="${i}" ${x.off ? "disabled" : ""}><em>0${i + 1}</em><span class="ic">${svg(x.ic, 1.8)}</span><div><b>${x.t}</b><small>${esc(x.s)}</small></div><i class="arr">›</i></button>`).join("")}</nav>
    </div>
    <aside class="mn-save">${saveCard()}${ownRow()}</aside>
    <button class="mn-lang" id="mn-lang" translate="no" aria-label="Language">${svg("globe", 1.8)}<span>${esc(langInfo(LANG).name)}</span></button>
    ${menuLang ? `<div class="mn-modal" id="mn-lang-modal" translate="no"><div class="mn-dlg"><b>语言 / Language</b>
      <div class="mn-langs">${LANGS.map((l) => `<button class="mn-lg${l.code === LANG ? " on" : ""}" data-lg="${l.code}">${esc(l.name)}</button>`).join("")}</div></div></div>` : ""}
    ${menuConfirm ? `<div class="mn-modal"><div class="mn-dlg"><b>开始新的生涯？</b>
      <p>当前生涯（${esc(tname(me()))} · 第 ${c.season || 1} 季第 ${c.current_round} 轮）会被归档，赛季、训练、伤病、成长、球探、财务、转会和荣誉记录从头开始。</p>
      <p class="mn-note">全部从头开始：球员能力回到卡面数值，合同重新签订，联赛年龄按卡面重新计算。</p>
      <div class="mn-acts"><button class="btn" data-mc="no" data-sound="back">取消</button><button class="btn pri" data-mc="yes" data-sound="ok">确定新建</button></div></div></div>` : ""}
    ${exitBlock ? `<div class="mn-modal"><div class="mn-dlg"><b>请重新进入游戏</b>
      <p>大师联赛里不能直接退出回到普通游戏。</p>
      <p class="mn-note">想回到普通游戏，请完全关闭游戏后重新启动，重启后会自动回到原来的主存档。</p>
      <div class="mn-acts"><button class="btn pri" data-mx="ok" data-sound="ok">知道了</button></div></div></div>` : ""}
  </div>`;
  $("#mn-lang").onclick = () => { sound("open"); menuLang = true; renderMenu(); };
  $$("[data-own]").forEach((b) => b.onclick = () => { if (b.classList.contains("on")) return; ownSet(b.dataset.own === "1"); });
  if (ownSq === null) { ownSq = false; ownLoad(); }
  if (menuLang) {
    const close = () => { menuLang = false; sound("back"); renderMenu(); };
    $("#mn-lang-modal").onclick = (e) => { if (e.target.id === "mn-lang-modal") close(); };            // 点空白处关闭
    $$(".mn-lg").forEach((b) => b.onclick = () => { if (b.dataset.lg === LANG) return close(); sound("ok"); setLang(b.dataset.lg); });
  }
  $$("[data-mx]").forEach((b) => b.onclick = () => { exitBlock = false; renderMenu(); });
  $$(".mn-it").forEach((b) => {
    b.onmouseenter = () => { if (!b.disabled && menuSel !== +b.dataset.i) { menuSel = +b.dataset.i; $$(".mn-it").forEach((x) => x.classList.toggle("on", x === b)); } };
    b.onclick = () => menuGo(b.dataset.menu);
  });
  $$("[data-mc]").forEach((b) => b.onclick = () => { menuConfirm = false; if (b.dataset.mc === "yes") return openNewGame(); sound("back"); renderMenu(); });
}
function menuGo(k) {
  // E369：梦幻选秀没翻完就离开过的生涯，继续游戏时接着揭晓同一份阵容（fdOpen 在不是选秀档 / 已翻完时什么也不做）
  if (k === "continue") { if (!(S && S.career)) return; sound("page"); screen = "game"; cur = { sec: "home", tab: 0 }; return refresh(true).then(() => typeof fdOpen === "function" && fdOpen()); }
  if (k === "new") { sound("ok"); if (S && S.career) { menuConfirm = true; return renderMenu(); } return openNewGame(); }
  if (k === "saves") return openSaves();
  if (k === "y17") return window.openY17 && window.openY17();      // RC29.17: stand-alone Y17 Champions League (y17.js)
  if (k === "exit") return tryExit();
}
// 2026-11-15 用户：“禁用这个退出功能 当玩家想退出的时候叫他重进游戏就对了”——退出一律不收起面板，只弹“请重新进入游戏”。
// （2026-11-13 起是“进过大师联赛才拦”，没进过可以收起；现在不再区分。）
let exitBlock = false, menuLang = false;      // menuLang：主页右上角“语言”弹层（2026-11-17 用户：主页也要能切换语言）
function tryExit() { sound("open"); exitBlock = true; renderMenu(); }
function openNewGame() {
  sound("page");
  screen = "pick"; pick.mode = "new"; pick.team = null; pick.error = "";
  renderPick();
}
function toMenu() { sound("back"); menuConfirm = false; exitBlock = false; screen = "menu"; renderMenu(); }
// 主菜单的键盘 / 手柄方向键：上下选择，回车确认，Esc 关掉确认框
document.addEventListener("keydown", (e) => {
  if (screen !== "menu") return;
  if (exitBlock) { if (e.key === "Escape" || e.key === "Enter") { e.preventDefault(); exitBlock = false; renderMenu(); } return; }
  if (menuConfirm) { if (e.key === "Escape") { menuConfirm = false; renderMenu(); } return; }
  const items = MENU(), step = e.key === "ArrowDown" ? 1 : e.key === "ArrowUp" ? -1 : 0;
  if (step) {
    e.preventDefault();
    let i = menuSel;
    for (let n = 0; n < items.length; n++) { i = (i + step + items.length) % items.length; if (!items[i].off) break; }
    menuSel = i; sound("cursor"); $$(".mn-it").forEach((b) => b.classList.toggle("on", +b.dataset.i === menuSel));
  } else if (e.key === "Enter") { e.preventDefault(); menuGo(items[menuSel].k); }
});

/* ================= 刷新：比赛结束回到界面时数据会变；只有内容变了才重画 ================= */
async function refresh(force) {
  let s;
  try { s = await api("/api/state"); } catch (e) { if (!S) $("#app").innerHTML = `<div class="loading-screen">数据暂时不可用：${esc(e.message)}</div>`; return; }
  const j = JSON.stringify(s);
  if (!force && j === lastJson) return;
  const first = !S; lastJson = j; S = s; H = null;
  if (S && S.career) await loadCal();          // M5-D：宿主保存的“今天”（踢完一场会落到那场的比赛日）
  for (const k of Object.keys(teamCache)) delete teamCache[k];
  for (const k of Object.keys(fxCache)) delete fxCache[k];
  for (const k of Object.keys(BIZ)) delete BIZ[k];
  wk = null;
  try {
    if (screen === "intro" || screen === "pick" || screen === "saves" || screen === "y17") return;       // 开场动画结束后由启动流程进主菜单；选队页、存档页不被轮询打断
    if (screen === "menu" || !S.career) return renderMenu();
    // await：renderShell 是异步的，不等它画完，postMatch 打开的战报层会被随后重建的界面冲掉；渲染异常也才进得了下面的 catch
    if (first || force || !$(".app")) await renderShell();
    else if (!$(".layer") && !kick) await renderShell();     // 有子页面或开球层时先不打扰，下次轮询再画
    else lastJson = "";
  } catch (e) {       // 渲染出错不能让页面永远停在“正在载入”：显示原因，并让下次轮询重试
    lastJson = "";
    if (!$(".app")) $("#app").innerHTML = `<div class="loading-screen">界面出错：${esc(e && e.message)}</div>`;
  }
}
document.addEventListener("visibilitychange", () => { if (!document.hidden && !hostHidden) refresh(); });
// 性能（2026-11-14）：比赛结束后宿主会主动调 MlLeague.refresh / postMatch，切回界面时也会刷新；轮询只是兜底，从 15 秒放宽到 45 秒（每次都占宿主 Python 线程）
setInterval(() => { if (!document.hidden && !hostHidden && !kick) refresh(); }, 45000);
// 启动：开场动画和读取状态同时进行，两者都完成后进主菜单
(async () => {
  await I18N.ready;                       // 英文模式：先读语言包再画第一屏（中文模式这里是已完成的 Promise）
  const intro = playIntro();
  await refresh(true);
  await intro;
  if (screen === "intro") renderMenu();
})();
// ---- RC29.3: match report for the other leagues' fixtures (scorers, assists and simulated ratings from the host)
document.addEventListener("click", async (event) => {
  const t = event.target.closest("[data-lgfx]");
  if (!t || $("#rc-rep")) return;
  const [lg, rd, h, a] = t.dataset.lgfx.split(":");
  let d = null;
  try { d = await api(`/api/rc29/fixture/${lg}/${rd}/${h}/${a}`); } catch (e) { d = null; }
  if (!d || d.error) return;
  sound("page");
  const pill = (r) => `<b class="mr-pill ${r >= 7.5 ? "hi" : r >= 6.5 ? "mid" : "lo"}">${r.toFixed(1)}</b>`;
  const side = (k) => (d[k].ratings || []).map((p) => `<div class="mr-row${p.motm ? " motm" : ""}"><span class="mr-n">${pface(p, "mr-pf")}${esc(shortName(p.name))}${p.g ? `<i class="mr-g">${"●".repeat(Math.min(p.g, 4))}</i>` : ""}${p.a ? `<i class="mr-a">A${p.a > 1 ? p.a : ""}</i>` : ""}</span>${pill(p.r)}</div>`).join("");
  const gl = (team) => (d.goals || []).filter((g) => g.team === team).map((g) => `<div class="mr-goal"><b>${esc(shortName(g.name))}</b>${g.assist ? `<small>${esc(shortName(g.assist))}</small>` : ""}</div>`).join("");
  const el = document.createElement("div"); el.id = "rc-rep"; el.className = "mr-back";
  el.innerHTML = `<div class="mr-box" role="dialog" aria-modal="true" translate="no">
    <button class="mr-x" id="rc-rep-x" aria-label="Close">✕</button>
    <div class="mr-meta">${esc(d.league)} · Round ${d.round}<span>Simulated</span></div>
    <div class="mr-head"><div class="mr-team">${crest(d.home.team, "lg")}<b>${esc(tname(d.home.team))}</b><div class="mr-gl">${gl(d.home.team)}</div></div>
      <div class="mr-score"><b>${d.home.goals}</b><i>:</i><b>${d.away.goals}</b>${d.motm ? `<div class="mr-motm">${pface(d.motm, "mr-pf big")}<span><small>Player of the match</small><b>${esc(shortName(d.motm.name))}</b></span>${pill(d.motm.r)}</div>` : ""}</div>
      <div class="mr-team">${crest(d.away.team, "lg")}<b>${esc(tname(d.away.team))}</b><div class="mr-gl">${gl(d.away.team)}</div></div></div>
    <div class="mr-cols"><div class="mr-col">${side("home")}</div><div class="mr-col">${side("away")}</div></div></div>`;
  document.body.appendChild(el);
  el.addEventListener("click", (ev) => { if (ev.target === el || ev.target.closest("#rc-rep-x")) { sound("back"); el.remove(); } });
});


// ---- RC29.3: no ages anywhere in the Master League (user request) - hide every "Age" column, field and sort chip after each render
const RC_AGE = /^(年龄|平均年龄|卡面年龄|联赛年龄|均龄|Age|Avg age|Average age|Card age|League age)\s*[⇅↕↑↓▲▼⬍]*$/i;
function rcHideAge(root) {
  root = root || document.body;
  root.querySelectorAll("table").forEach((tb) => {
    const ths = [...tb.querySelectorAll("thead th")];
    const idx = ths.findIndex((th) => RC_AGE.test(th.textContent.trim()));
    if (idx < 0) return;
    ths[idx].style.display = "none";
    tb.querySelectorAll("tbody tr").forEach((tr) => { const td = tr.children[idx]; if (td && !td.hasAttribute("colspan")) td.style.display = "none"; });
  });
  root.querySelectorAll(".pd-kv, .kv, .yw-kv span, .cp-kv span, button.chip, .df-row").forEach((el) => {
    const lab = el.querySelector("span, small, b"); const t = (lab ? lab.textContent : el.textContent).trim();
    if (RC_AGE.test(t)) el.style.display = "none";
  });
}
try {
  let rcAgeT = 0;
  new MutationObserver(() => { clearTimeout(rcAgeT); rcAgeT = setTimeout(() => rcHideAge(), 30); }).observe(document.documentElement, { childList: true, subtree: true });
} catch (e) { /* older WebView: ages stay visible */ }


// ---- RC29.3: Ballon d'Or & European Golden Shoe (host: /api/rc29/awards, frozen at each season end)
// Nominees are revealed on 8 August, the ceremony is on 22 September of the following season - like the real award.
const BDO_BALL = (sz = 120) => `<svg class="bdo-ball" width="${sz}" height="${Math.round(sz * 1.25)}" viewBox="0 0 120 150" aria-hidden="true"><defs>
  <radialGradient id="bdoG" cx="36%" cy="30%" r="75%"><stop offset="0" stop-color="#fffbe6"/><stop offset=".18" stop-color="#ffe58a"/><stop offset=".5" stop-color="#e0ad2e"/><stop offset=".8" stop-color="#9a6a0c"/><stop offset="1" stop-color="#4d3204"/></radialGradient>
  <linearGradient id="bdoB" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#7a520a"/><stop offset=".35" stop-color="#f6d675"/><stop offset=".6" stop-color="#c9921d"/><stop offset="1" stop-color="#5e3e06"/></linearGradient>
  <linearGradient id="bdoK" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a2a2e"/><stop offset="1" stop-color="#0c0c0e"/></linearGradient>
  <radialGradient id="bdoGl" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#ffd76a" stop-opacity=".45"/><stop offset="1" stop-color="#ffd76a" stop-opacity="0"/></radialGradient></defs>
  <ellipse cx="60" cy="54" rx="58" ry="56" fill="url(#bdoGl)"/>
  <path d="M38 132h44l4 14H34z" fill="url(#bdoK)"/><rect x="34" y="144" width="52" height="4" rx="1" fill="#000" opacity=".6"/>
  <path d="M44 118h32l6 14H38z" fill="url(#bdoB)"/><path d="M50 104h20l-2 14H52z" fill="url(#bdoB)"/>
  <circle cx="60" cy="56" r="44" fill="url(#bdoG)"/>
  <g fill="none" stroke="#6b4606" stroke-opacity=".5" stroke-width="1.4" stroke-linejoin="round">
    <path d="M60 33l15 10-6 17H51l-6-17z" fill="#8a5d0a" fill-opacity=".22"/>
    <path d="M60 33c0-8-2-14-6-20M75 43c9-3 15-2 22 3M69 60c5 7 7 14 6 22M51 60c-5 7-7 14-6 22M45 43c-9-3-15-2-22 3"/>
    <path d="M23 46c-6 8-8 18-6 28M97 46c6 8 8 18 6 28M45 82c5 8 9 13 15 17M75 82c-5 8-9 13-15 17"/></g>
  <ellipse cx="44" cy="36" rx="14" ry="9" fill="#fff" opacity=".42" transform="rotate(-28 44 36)"/></svg>`;
const BDO_SEEN = (k) => { try { return localStorage.getItem("bdo:" + k) === "1"; } catch (e) { return true; } };
const BDO_MARK = (k) => { try { localStorage.setItem("bdo:" + k, "1"); } catch (e) { /* ignore */ } };
let bdoLast = null;
async function bdoLoad() {
  try { const d = await api("/api/rc29/awards"); bdoLast = d && !d.error ? d : null; } catch (e) { bdoLast = null; }
  if (bdoLast && bdoLast.teams && typeof S !== "undefined" && S) for (const [k, v] of Object.entries(bdoLast.teams)) if (v && !S.teams[k]) S.teams[k] = v;
  return bdoLast;
}
const BDO_MEDAL = ["", "gold", "silver", "bronze"];
function bdoRow(r, rank, showPts) {
  const tro = (r.trophies || []).map((t) => `<em>${esc(t)}</em>`).join("");
  return `<div class="bdo-row${showPts && rank <= 3 ? " m-" + BDO_MEDAL[rank] : ""}"><span class="bdo-rk">${rank != null ? rank : ""}</span>${pface(r, "bdo-pf")}<span class="bdo-nm"><b translate="no">${esc(r.name)}</b><small>${r.team != null ? crest(r.team, "sm") : ""}${esc(r.club || "")}</small></span>`
    + `<span class="bdo-st"><i>${r.goals} G</i><i>${r.assists} A</i>${r.ucl_goals ? `<i class="ucl">UCL ${r.ucl_goals} G</i>` : ""}${tro}</span>${showPts ? `<b class="bdo-pts">${r.votes != null ? r.votes : ""}<small>pts</small></b>` : ""}</div>`;
}
function bdoPodium(top) {
  const card = (r, i) => !r ? "" : `<div class="bdo-pod p${i + 1}"><div class="bdo-pod-rk">${i + 1}</div>${pface(r, "bdo-pf lg")}<b translate="no">${esc(r.name)}</b><small>${r.team != null ? crest(r.team, "sm") : ""}${esc(r.club)}</small>`
    + `<div class="bdo-pod-st"><span><b>${r.goals}</b>Goals</span><span><b>${r.assists}</b>Assists</span><span><b>${r.ucl_goals || 0}</b>UCL G</span></div>`
    + `${(r.trophies || []).length ? `<div class="bdo-pod-tr">${r.trophies.map((t) => `<em>${esc(t)}</em>`).join("")}</div>` : ""}<div class="bdo-pod-v">${r.votes || ""} pts</div></div>`;
  return `<div class="bdo-podium">${card(top[1], 1)}${card(top[0], 0)}${card(top[2], 2)}</div>`;
}
function bdoBoot(a) {
  return `<div class="bdo-card bdo-boot"><div class="bdo-h">${BDO_SHOE}<span><b>European Golden Shoe</b><small>${esc(a.label)} · goals × 2 (top-five league factor)</small></span></div>`
    + (a.golden_boot || []).map((r) => `<div class="bdo-row"><span class="bdo-rk">${r.rank}</span>${r.team != null ? crest(r.team, "sm") : ""}<span class="bdo-nm"><b translate="no">${esc(r.name)}</b><small>${esc(r.club)}</small></span><span class="bdo-st"><i>${r.goals} goals</i></span><b class="bdo-pts">${r.points}</b></div>`).join("") + `</div>`;
}
const BDO_SHOE = `<svg width="44" height="44" viewBox="0 0 48 48" aria-hidden="true"><defs><linearGradient id="bdoShoe" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff2b0"/><stop offset=".5" stop-color="#e2b23a"/><stop offset="1" stop-color="#7a5510"/></linearGradient></defs><path d="M6 30c6 0 10-3 13-9l3-6 6 2c-1 4 1 6 5 7l9 3c3 1 4 3 4 6v3H6z" fill="url(#bdoShoe)"/><path d="M6 39h40v3H6z" fill="#8a6414"/><g stroke="#7a5510" stroke-width="1.3"><path d="M22 20l4 2M21 23l4 2M19 26l4 2"/></g></svg>`;
async function viewAwards() {
  const d = await bdoLoad();
  const a = d && d.latest;
  if (!a) return `<div class="view v-bdo one"><div class="bdo-card bdo-empty">${BDO_BALL(100)}<b>Ballon d'Or</b><span>The first award is decided at the end of this season.<br><small>Nominees: 8 August · Ceremony: 22 September of next season</small></span></div></div>`;
  const ceremony = a.phase === "ceremony", list = a.ballon_dor || [];
  const rest = (ceremony ? list.slice(3) : list).map((r) => bdoRow(r, ceremony ? r.rank : null, ceremony)).join("");
  const hist = (d.history || []).map((h) => { const w = (h.ballon_dor || [])[0]; return w ? `<div class="bdo-hist">${pface(w, "bdo-pf")}<span><b>${esc(h.label)}</b> <span translate="no">${esc(w.name)}</span> <small>${esc(w.club)}</small></span></div>` : ""; }).join("");
  const head = `<div class="bdo-hero">${BDO_BALL(78)}<div><small>${ceremony ? "Ballon d'Or · Final ranking" : "Ballon d'Or · The 30 nominees"}</small><b>${esc(a.label)}</b><span>${ceremony ? `Winner: <b translate="no">${esc((list[0] || {}).name || "")}</b>` : `Ceremony on ${esc(a.ceremony_date)}`}</span></div>`
    + `<div class="bdo-acts"><button id="bdo-show">${ceremony ? "Replay ceremony" : "Show nominees"}</button></div></div>`;
  return `<div class="view v-bdo"><div class="bdo-col">${head}${ceremony ? bdoPodium(list) : ""}<div class="bdo-card bdo-list">${rest}</div></div><div class="bdo-col">${bdoBoot(a)}${hist ? `<div class="bdo-card"><div class="bdo-h"><span><b>Past winners</b></span></div>${hist}</div>` : ""}</div></div>`;
}
function bdoModal(a, mode) {
  if ($("#bdo-pop")) return;
  const el = document.createElement("div"); el.id = "bdo-pop"; el.className = "dlg-back bdo-back";
  if (mode === "nominees") {
    const tiles = (a.ballon_dor || []).map((r, i) => `<div class="bdo-tile" style="animation-delay:${i * 60}ms">${pface(r, "bdo-pf")}<span><b translate="no">${esc(shortName(r.name))}</b><small>${r.team != null ? crest(r.team, "sm") : ""}${esc(r.club)}</small></span></div>`).join("");
    el.innerHTML = `<div class="bdo-dlg" role="dialog" aria-modal="true">${BDO_BALL(88)}<small class="bdo-kick">Ballon d'Or ${esc(a.label)}</small><h2>The 30 nominees</h2><p>The winner will be revealed at the ceremony on ${esc(a.ceremony_date)}.</p><div class="bdo-grid">${tiles}</div><div class="dlg-b"><button class="pri" id="bdo-x">Close</button></div></div>`;
  } else {
    const rows = [...(a.ballon_dor || [])].reverse();
    el.innerHTML = `<div class="bdo-dlg bdo-cer" role="dialog" aria-modal="true"><small class="bdo-kick">Ballon d'Or ${esc(a.label)} · Ceremony</small><div class="bdo-stage"><div class="bdo-wait">${BDO_BALL(150)}<span>And the Ballon d'Or goes to…</span></div></div><div class="bdo-rank"></div><div class="dlg-b"><button id="bdo-skip">Skip</button><button class="pri" id="bdo-x">Close</button></div></div>`;
    const box = el.querySelector(".bdo-rank"), stage = el.querySelector(".bdo-stage");
    let i = 0, timer = null;
    const step = () => {
      if (i >= rows.length) return;
      const r = rows[i++];
      if (r.rank === 1) {
        stage.innerHTML = `<div class="bdo-winner">${BDO_BALL(150)}${pface(r, "bdo-pf xl")}<div>${r.team != null ? crest(r.team) : ""}<b translate="no">${esc(r.name)}</b><small>${esc(r.club)} · ${r.goals} goals · ${r.assists} assists${r.ucl_goals ? ` · ${r.ucl_goals} UCL goals` : ""}</small>${(r.trophies || []).length ? `<span>${r.trophies.map(esc).join(" · ")}</span>` : ""}</div></div>`;
        sound && sound("ok");
      }
      box.insertAdjacentHTML("afterbegin", bdoRow(r, r.rank, true));
      timer = setTimeout(step, r.rank <= 4 ? 1400 : r.rank <= 10 ? 650 : 220);
    };
    timer = setTimeout(step, 900);
    el.querySelector("#bdo-skip").onclick = () => { clearTimeout(timer); while (i < rows.length) { const r = rows[i++]; box.insertAdjacentHTML("afterbegin", bdoRow(r, r.rank, true)); } const w = rows[rows.length - 1]; if (w) stage.innerHTML = `<div class="bdo-winner">${BDO_BALL(150)}${pface(w, "bdo-pf xl")}<div>${w.team != null ? crest(w.team) : ""}<b translate="no">${esc(w.name)}</b><small>${esc(w.club)}</small></div></div>`; };
  }
  document.body.appendChild(el);
  el.addEventListener("click", (ev) => { if (ev.target === el || ev.target.id === "bdo-x") { el.remove(); } });
}
document.addEventListener("click", async (ev) => {
  if (!ev.target.closest("#bdo-show")) return;
  const d = bdoLast || await bdoLoad(); const a = d && d.latest; if (!a) return;
  bdoModal(a, a.phase === "ceremony" ? "ceremony" : "nominees");
});
// pop the announcement once, the first time the career date passes each milestone
async function bdoCheck() {
  const d = await bdoLoad(); const a = d && d.latest; if (!a) return;
  const k = `${a.season}:${a.phase}`;
  if ((a.phase === "nominees" || a.phase === "ceremony") && !BDO_SEEN(k)) { BDO_MARK(k); bdoModal(a, a.phase); }
}
setInterval(() => { if (typeof S !== "undefined" && S && S.career && !$("#bdo-pop")) bdoCheck(); }, 8000);

// ---- RC29.4: stand-alone cups (host /api/rc29/cups) - UCL 2017 with RC26's 2017 squads, AFC Champions League Elite
let cupSub = {}, cupData = {}, cupBusy = false, cupSquad = {}, cupStageSeen = {};
const cupCrest = (d, tid, cls = "sm") => { const t = (d.teams || {})[tid] || {}; return crestId(t.crest, t.short || "?", t.c, cls); };
const cupName = (d, tid) => ((d.teams || {})[tid] || {}).name || `#${tid}`;
const cnVis = (d, x, big) => x.pid ? pface(x, big ? "bdo-pf lg" : "bdo-pf") : cupCrest(d, x.team, big ? "lg" : "");
const cnQuote = (x) => x.q ? `<blockquote class="cn-q">“${esc(x.q)}”<cite>— ${esc(x.by)}</cite></blockquote>` : "";
const cnCard = (d, x, i) => `<article class="cn-it tone-${x.tone}${i === 0 ? " lead" : ""}"><div class="cn-vis">${cnVis(d, x, i === 0)}</div><div class="cn-tx"><div class="cn-meta"><span class="cn-tag">${esc(x.tag)}</span><span>${esc(x.when)}</span><span class="cn-src">${esc(x.src)}</span></div><h3>${esc(x.h)}</h3>${x.q ? cnQuote(x) : `<p>${esc(x.b)}</p>`}</div></article>`;
const cnRow = (d, x, top) => `<li class="cn-row tone-${x.tone}${top ? " cn-first" : ""}"><span class="cn-rv">${cnVis(d, x, false)}</span><span class="cn-rt"><small><b class="cn-tag">${esc(x.tag)}</b>${esc(x.when)}</small><b>${esc(x.h)}</b>${top && (x.q || x.b) ? `<em>${esc(x.q ? `“${x.q}” — ${x.by}` : x.b)}</em>` : ""}</span></li>`;
async function viewCupU17() { return viewCup("ucl17"); }
async function viewCupAfc() { return viewCup("afc"); }
async function viewCup(id) {
  let d = null;
  try { d = await api(`/api/rc29/cups/${id}`); } catch (e) { d = null; }
  if (!d || d.error) return `<div class="view"><div class="card"><div class="empty-note">Cup unavailable<br><small>${esc((d && d.error) || "")}</small></div></div></div>`;
  if (!d.started && !d.table) return cupPicker(id);
  cupData[id] = d;
  const phase = d.stage === "done" ? "done" : d.stage === "league" ? "league" : "ko";
  if (cupStageSeen[id] !== undefined && cupStageSeen[id] !== phase) cupSub[id] = null;   // a new stage: jump to its tab
  cupStageSeen[id] = phase;
  const sub = cupSub[id] || (phase === "done" ? "mvp" : phase);
  const me = d.team, mine = (m) => m.h === me || m.a === me;
  const sc = (m) => (m.hg == null ? "vs" : `${m.hg + ((m.et || [0, 0])[0])} - ${m.ag + ((m.et || [0, 0])[1])}`);
  const scl = (arr) => (arr || []).map(([n, k]) => `<span>${esc(n)}${k > 1 ? ` <b>×${k}</b>` : ""}</span>`).join("");
  const tieOf = {}; for (const k of d.ko || []) for (const t of k.ties) for (const l of t.legs) tieOf[l.id] = t;
  const outCls = (m, side) => { const t = tieOf[m.id]; if (!t || !t.winner || t.legs[t.legs.length - 1].id !== m.id) return ""; return m[side] !== t.winner ? " elim" : " adv"; };
  const aggTxt = (m) => { const t = tieOf[m.id]; if (!t || !t.agg || t.legs.length < 2 || t.legs[t.legs.length - 1].id !== m.id) return t && t.winner && t.legs[t.legs.length - 1].id === m.id && (t.et || t.pens) ? `<div class="cup-agg2">${t.pens ? `${t.pens[0]}-${t.pens[1]} pens` : "after extra time"}</div>` : ""; const a = m.h === t.a ? t.agg[0] : t.agg[1], b = m.h === t.a ? t.agg[1] : t.agg[0]; return `<div class="cup-agg2">Agg <b>${a} - ${b}</b>${t.et && !t.pens ? " · aet" : ""}${t.pens ? ` · ${m.h === t.a ? t.pens[0] : t.pens[1]}-${m.h === t.a ? t.pens[1] : t.pens[0]} pens` : ""}</div>`; };
  const mrow = (m) => `<div class="cup-fx${mine(m) ? " mine" : ""}${m.hg != null ? " done" : ""}"${m.hg != null ? ` data-cupm="${id}:${m.id}"` : ""}><div class="mrow"><span class="ctm${outCls(m, "h")}">${esc(cupName(d, m.h))}</span>${cupCrest(d, m.h)}<span class="sc">${sc(m)}</span>${cupCrest(d, m.a)}<span class="ctm${outCls(m, "a")}">${esc(cupName(d, m.a))}</span></div>${aggTxt(m)}${m.sc && (m.sc.h.length || m.sc.a.length) ? `<div class="cup-gs"><div class="gh">${scl(m.sc.h)}</div><i>⚽</i><div class="ga">${scl(m.sc.a)}</div></div>` : ""}</div>`;
  // header
  const head = `<div class="cup-hero cup-${id}"><div class="cup-badge">${svg("cups", 1.6)}</div><div class="cup-t"><small>${esc(d.stage_name)}</small><b>${esc(d.name)}</b><span>Your club: ${cupCrest(d, me)} <b>${esc(cupName(d, me))}</b>${d.champion ? ` · Champion: ${cupCrest(d, d.champion)} <b>${esc(cupName(d, d.champion))}</b>` : ""}</span></div>`
    + `<div class="cup-acts">${d.stage !== "done" ? `<button class="pri" data-cup="next" data-v="${id}">Play next matchday</button><button data-cup="finish" data-v="${id}">Simulate to the end</button>` : ""}<button data-cup="reset" data-v="${id}">New cup</button></div></div>`;
  const tabs = [["news", "News"], ["league", "League phase"], ["ko", "Knockout"], ["stats", "Scorers & assists"], ["mvp", "MVP"], ["squads", "Squads"]].map(([k, t]) => `<button class="${sub === k ? "on" : ""}" data-cup="sub" data-v="${id}:${k}">${t}</button>`).join("");
  let body = "";
  if (sub === "league") {
    const cut1 = d.direct, cut2 = d.direct + d.po, played = d.table.some((r) => r.p);
    const zone = (p) => (p <= cut1 ? "z-direct" : p <= cut2 ? "z-po" : "z-out");
    const nForm = Math.min(5, d.rounds.length), dots = (f) => `<span class="cup-form">${Array.from({ length: nForm }, (_, i) => { const x = f.slice(-nForm)[i]; return x ? `<i class="f-${x}">${x}</i>` : `<i class="f-n"></i>`; }).join("")}</span>`;
    const rows = d.table.map((r) => `<tr class="${zone(r.pos)}${r.team === me ? " me" : ""}${r.pos === cut1 || (d.po && r.pos === cut2) ? " cut" : ""}"><td class="cup-rk"><b>${r.pos}</b></td><td class="name"><span class="tn">${cupCrest(d, r.team)}<span>${esc(cupName(d, r.team))}</span></span></td><td class="n">${r.p}</td><td class="n">${r.w}</td><td class="n">${r.d}</td><td class="n">${r.l}</td><td class="n cup-gd${r.gd > 0 ? " up" : r.gd < 0 ? " dn" : ""}">${r.gd > 0 ? "+" : ""}${r.gd}</td><td class="n cup-fm">${dots(r.form || [])}</td><td class="n cup-pts"><b>${r.pts}</b></td></tr>`).join("");
    const key = `<div class="cup-key">${d.po ? `<span class="z-direct"><i></i>Quarter-finals</span><span class="z-po"><i></i>Knockout play-off</span>` : `<span class="z-direct"><i></i>Round of 16</span><span class="z-out"><i></i>Eliminated</span>`}${played ? "" : `<span class="cup-key-n">Before kick-off the table is listed A–Z</span>`}</div>`;
    const blocks = d.rounds.map((r) => ({ key: "L" + r.round, t: `Matchday ${r.round}`, ms: r.matches }));
    for (const k of d.ko || []) {
      const n = Math.max(...k.ties.map((t) => t.legs.length));
      for (let i = 0; i < n; i++) blocks.push({ key: `${k.stage}${i}`, t: `${k.name}${n > 1 ? (i ? " · 2nd leg" : " · 1st leg") : ""}`, ms: k.ties.map((t) => t.legs[i]).filter(Boolean), ko: true });
    }
    let cur = blocks.findIndex((x) => x.ms.some((m) => m.hg == null));
    const lastPlayed = blocks.map((x, i) => x.ms.some((m) => m.hg != null) ? i : -1).filter((i) => i >= 0).pop();
    cur = lastPlayed != null ? lastPlayed : Math.max(0, cur);
    const goMd = () => { const c = document.querySelector(".cup-mds .cb"), t = c && c.querySelector(".cup-md[data-cur]"); if (c && t) c.scrollTop += t.getBoundingClientRect().top - c.getBoundingClientRect().top - 2; };
    setTimeout(goMd, 60); setTimeout(goMd, 350);
    const nextIdx = blocks.findIndex((x) => x.ms.some((m) => m.hg == null));
    const rds = blocks.map((x, i) => `<div class="cup-md${x.ko ? " ko" : ""}"${i === cur ? " data-cur" : ""}><div class="cup-mdt">${esc(x.t)}${i === nextIdx && d.stage !== "done" ? `<em>Next</em>` : ""}</div>${x.ms.map(mrow).join("")}</div>`).join("");
    const nw = d.news || [], lead = nw[0];
    const room = `<div class="card cup-room"><div class="ch">Newsroom<button class="r cn-more" data-cup="sub" data-v="${id}:news">All ${nw.length} stories →</button></div><div class="cb">${lead ? `<div class="cn-strip" data-cup="sub" data-v="${id}:news">${nw.slice(0, 4).map((x, i) => `<article class="cn-tile tone-${x.tone}${i === 0 ? " cn-first" : ""}"><span class="cn-rv">${cnVis(d, x, false)}</span><span class="cn-rt"><small><b class="cn-tag">${esc(x.tag)}</b>${esc(x.when)}</small><b>${esc(x.h)}</b>${x.q || x.b ? `<em>${esc(x.q ? `“${x.q}” — ${x.by}` : x.b)}</em>` : ""}</span></article>`).join("")}</div>` : `<div class="empty-note">The press pack arrives with the first matchday</div>`}</div></div>`;
    body = `<div class="card cup-tbl"><div class="ch">League phase table</div><div class="cb scroll"><table><thead><tr><th>#</th><th>Club</th><th class="n">P</th><th class="n">W</th><th class="n">D</th><th class="n">L</th><th class="n">GD</th><th class="n">Form</th><th class="n">Pts</th></tr></thead><tbody>${rows}</tbody></table>${key}</div></div><div class="card cup-mds"><div class="ch">Matchdays</div><div class="cb scroll">${rds}</div></div>${room}`;
  } else if (sub === "squads") {
    const sq = d.squads || {}, pick = cupSquad[id] && sq[cupSquad[id]] ? cupSquad[id] : String(me);
    const chips = Object.keys(sq).sort((a, b) => cupName(d, a).localeCompare(cupName(d, b))).map((t) => `<button class="cup-sq-chip${t === pick ? " on" : ""}" data-cup="squad" data-v="${id}:${t}">${cupCrest(d, t)}<span>${esc(cupName(d, t))}</span></button>`).join("");
    const ORD = { GK: 0, CB: 1, LB: 2, RB: 2, DMF: 3, CMF: 4, LMF: 5, RMF: 5, AMF: 6, LWF: 7, RWF: 7, SS: 8, CF: 9 };
    const ps = (sq[pick] || []).slice().sort((a, b) => (b.xi - a.xi) || (ORD[a.pos] ?? 5) - (ORD[b.pos] ?? 5));
    const cardOf = (r) => `<div class="btc${r.xi ? " xi" : ""}"${id === "ucl17" ? "" : ` data-plain="1"`}><div class="btc-top"><b>${esc(r.pos)}</b>${cupCrest(d, pick)}</div><div class="btc-face">${r.pid ? `<img data-face="${esc(r.pid)}" alt="">` : ""}</div><div class="btc-name" translate="no">${esc(r.name)}</div>${r.xi ? `<div class="btc-xi">Starting XI</div>` : ""}</div>`;
    body = `<div class="card cup-sq"><div class="ch">${esc(cupName(d, pick))} · squad${id === "ucl17" ? `<span class="r">Big Time series · Del Piero edition</span>` : ""}</div><div class="cb"><div class="cup-sq-chips">${chips}</div><div class="btc-grid">${ps.map(cardOf).join("")}</div></div></div>`;
  } else if (sub === "news") {
    const n = d.news || [];
    body = n.length ? `<div class="card cup-news"><div class="ch">Cup news<span class="r">${n.length} stories</span></div><div class="cb scroll cn-grid">${n.map((x, i) => cnCard(d, x, i)).join("")}</div></div>` : `<div class="card"><div class="empty-note">No news yet</div></div>`;
  } else if (sub === "ko") {
    const tie = (t) => `<div class="cup-tie${t.a === me || t.b === me ? " mine" : ""}">${t.legs.map(mrow).join("")}${t.agg ? `<div class="cup-agg">${t.legs.length > 1 ? `Aggregate <b>${t.agg[0]} - ${t.agg[1]}</b>` : ""}${t.et ? " · after extra time" : ""}${t.pens ? ` · penalties ${t.pens[0]}-${t.pens[1]}` : ""} · ${cupCrest(d, t.winner)} <b>${esc(cupName(d, t.winner))}</b> ${t.stage === "final" ? "win the cup" : "go through"}</div>` : ""}</div>`;
    body = d.ko.length ? d.ko.map((k) => `<div class="card"><div class="ch">${esc(k.name)}${k.stage === "final" ? `<span class="r">${esc(d.final_venue)}</span>` : ""}</div><div class="cb scroll cup-ties">${k.ties.map(tie).join("")}</div></div>`).join("") : `<div class="card"><div class="empty-note">The knockout draw follows the league phase</div></div>`;
  } else if (sub === "stats") {
    const list = (rows, unit) => rows.length ? rows.map((r) => `<tr class="${r.team === me ? "me" : ""}"><td class="rk">${r.rank}</td><td class="name rc-nm"><span class="tn">${cupCrest(d, r.team)}${pface(r)}<span class="rc-pl"><b translate="no">${esc(r.name)}</b><small>${esc(cupName(d, r.team))}</small></span></span></td><td class="n"><b>${r.n}</b></td></tr>`).join("") : `<tr><td class="muted">No ${unit} yet</td></tr>`;
    body = `<div class="card"><div class="ch">Top scorers</div><div class="cb scroll"><table><tbody>${list(d.scorers, "goals")}</tbody></table></div></div><div class="card"><div class="ch">Top assists</div><div class="cb scroll"><table><tbody>${list(d.assists, "assists")}</tbody></table></div></div>`;
  } else {
    const m = d.mvp || [];
    body = m.length ? `<div class="card cup-mvp">${[m[1], m[0], m[2]].map((r, i) => r ? `<div class="bdo-pod p${[2, 1, 3][i]}"><div class="bdo-pod-rk">${[2, 1, 3][i]}</div>${pface(r, "bdo-pf lg")}<b translate="no">${esc(r.name)}</b><small>${cupCrest(d, r.team)}${esc(cupName(d, r.team))}</small><div class="bdo-pod-st"><span><b>${r.goals}</b>Goals</span><span><b>${r.assists}</b>Assists</span></div><div class="bdo-pod-v">MVP ${[2, 1, 3][i] === 1 ? "of the tournament" : "#" + [2, 1, 3][i]}</div></div>` : "").join("")}</div>`
      : `<div class="card"><div class="empty-note">The MVP top 3 is announced after the final</div></div>`;
  }
  const top = (d.news || [])[0], tick = false && top ? `<button class="cup-tick tone-${top.tone}" data-cup="sub" data-v="${id}:news"><span class="cn-tag">${esc(top.tag)}</span><b>${esc(top.h)}</b><small>${esc(top.src)} · ${esc(top.when)}</small><i>All news →</i></button>` : "";
  return `<div class="view v-cup v-${id} vs-${sub}">${head}<div class="cup-tabs">${tabs}</div>${tick}<div class="cup-body cup-${sub}">${body}</div></div>`;
}
async function cupPicker(id) {
  let all = null; try { all = await api("/api/rc29/cups"); } catch (e) { all = null; }
  const c = all && (all.cups || []).find((x) => x.id === id);
  if (!c) return `<div class="view"><div class="card"><div class="empty-note">Cup unavailable</div></div></div>`;
  const d = { teams: Object.fromEntries(c.teams.map((t) => [t.id, t])) };
  const fmt = id === "ucl17" ? "12 clubs · league phase of 4 matches (2 home, 2 away) · 1st–4th straight to the quarter-finals, 5th–12th two-legged play-off · two-legged quarter- and semi-finals · one final in Cardiff"
    : "24 clubs · league stage of 8 matches (4 home, 4 away) · top 16 to a two-legged round of 16 · quarter-finals, semi-finals and final as single matches in Jeddah";
  const tiles = c.teams.map((t) => `<button class="cup-pick" data-cup="start" data-v="${id}:${t.id}">${crestId(t.crest, t.short, t.c, "")}<b>${esc(t.name)}</b><small>${"★".repeat(Math.max(1, Math.min(5, Math.round((t.rating - 40) / 12))))}</small></button>`).join("");
  return `<div class="view v-cup"><div class="cup-hero cup-${id}"><div class="cup-badge">${svg("cups", 1.6)}</div><div class="cup-t"><small>Choose your club</small><b>${esc(c.name)}</b><span>${esc(fmt)}</span></div></div><div class="cup-picks">${tiles}</div></div>`;
}
document.addEventListener("click", async (ev) => {
  const t = ev.target.closest("[data-cup]");
  if (!t || cupBusy) return;
  ev.stopPropagation(); ev.preventDefault();
  const k = t.dataset.cup, v = t.dataset.v;
  if (k === "sub") { const [id, sub] = v.split(":"); cupSub[id] = sub; sound("cursor"); return draw(); }
  if (k === "squad") { const [id, t] = v.split(":"); cupSquad[id] = t; sound("cursor"); return draw(); }
  cupBusy = true;
  try {
    if (k === "start") { const [id, team] = v.split(":"); await post(`/api/rc29/cups/${id}/start`, { team: +team }); cupSub[id] = "league"; }
    else if (k === "next") await post(`/api/rc29/cups/${v}/next`, {});
    else if (k === "finish") { await post(`/api/rc29/cups/${v}/finish`, {}); cupSub[v] = "mvp"; }
    else if (k === "reset") { await post(`/api/rc29/cups/${v}/reset`, {}); cupSub[v] = null; }
    sound("ok");
  } catch (e) { /* the page shows the stored state */ }
  cupBusy = false; draw();
}, true);
document.addEventListener("click", async (ev) => {
  const t = ev.target.closest("[data-cupm]");
  if (!t || $("#rc-rep")) return;
  const [id, mid] = t.dataset.cupm.split(":");
  let d = null; try { d = await api(`/api/rc29/cups/${id}/match/${mid}`); } catch (e) { d = null; }
  if (!d || d.error) return;
  sound("page");
  const side = (k) => (d[k].ratings || []).map((p) => `<div class="rc-rt${d.motm && p.pid === d.motm.pid ? " motm" : ""}"><span>${esc(p.name)}${p.g ? ` <i>${"⚽".repeat(Math.min(p.g, 4))}</i>` : ""}${p.a ? ` <i class="ast">A${p.a > 1 ? "×" + p.a : ""}</i>` : ""}</span><b style="background:${p.r >= 7.5 ? "var(--win)" : p.r >= 6.5 ? "#b88a1e" : "#9a4b2f"}">${p.r.toFixed(1)}</b></div>`).join("");
  const goals = (d.goals || []).map((g) => `<div class="rc-g">${cupCrest(d, g.team)}<span>⚽ ${esc(g.name)}${g.assist ? ` <small>(${esc(g.assist)})</small>` : ""}</span></div>`).join("") || `<div class="muted">No goals</div>`;
  const el = document.createElement("div"); el.id = "rc-rep"; el.className = "dlg-back";
  el.innerHTML = `<div class="dlg rc-rep" role="dialog" aria-modal="true" translate="no"><div class="rc-hd">${cupCrest(d, d.home.team, "")}<b class="rc-sc">${d.home.goals} : ${d.away.goals}</b>${cupCrest(d, d.away.team, "")}</div>
    <div class="rc-sub">${esc(cupName(d, d.home.team))} vs ${esc(cupName(d, d.away.team))} · ${esc(d.cup)}${d.et ? " · after extra time" : ""}</div>
    ${d.motm ? `<div class="rc-motm">Man of the match <b>${esc(d.motm.name)}</b> <span>${d.motm.r.toFixed(1)}</span></div>` : ""}
    <div class="rc-cols"><div><div class="rc-t">Goals</div>${goals}</div><div><div class="rc-t">${esc(cupName(d, d.home.team))}</div>${side("home")}</div><div><div class="rc-t">${esc(cupName(d, d.away.team))}</div>${side("away")}</div></div>
    <div class="dlg-b"><button id="rc-rep-x" class="pri">Close</button></div></div>`;
  document.body.appendChild(el);
  el.addEventListener("click", (e2) => { if (e2.target === el || e2.target.id === "rc-rep-x") { sound("back"); el.remove(); } });
});

// ---- RC29.6: Master League editor (RC26 "Edit Transfer" for the V32 world): move players between CPU clubs of any league, edit ability
let edState = { cid: null, team: null, q: "", hits: null, pick: null, db: false, cards: null, role: null };
async function viewEditor() {
  let d = null; try { d = await api("/api/rc29/editor"); } catch (e) { d = null; }
  if (!d || d.error || !d.leagues) return `<div class="view"><div class="card"><div class="empty-note">Editor unavailable<br><small>${esc((d && (d.reason || d.error)) || "")}</small></div></div></div>`;
  const L = d.leagues.find((x) => x.cid === edState.cid) || d.leagues[0]; edState.cid = L.cid;
  const C = L.clubs.find((c) => c.team === edState.team) || L.clubs.find((c) => !c.mine) || L.clubs[0]; edState.team = C.team;
  let sq = null; try { sq = await api(`/api/rc29/editor/club/${L.cid}/${C.team}`); } catch (e) { sq = null; }
  const ltabs = d.leagues.map((x) => `<button class="${x.cid === L.cid ? "on" : ""}" data-ed="lg" data-v="${x.cid}">${esc(x.name)}</button>`).join("");
  const clubs = L.clubs.map((c) => `<button class="ed-club${c.team === C.team ? " on" : ""}${c.mine ? " mine" : ""}" data-ed="club" data-v="${c.team}">${crest(c.team, "sm")}<span><b>${esc(c.name)}</b><small>${c.n} players · level ${c.level}${c.strength && c.strength !== 100 ? ` · <b class="ed-pct">${c.strength}%</b>` : ""}</small></span>${c.mine ? `<em>You</em>` : ""}</button>`).join("");
  const G = { G: "Goalkeepers", D: "Defenders", M: "Midfielders", F: "Forwards" };
  let lastG = null;
  const rows = ((sq && sq.players) || []).map((p) => { const head = p.grp !== lastG ? `<tr class="ed-grp"><td colspan="6">${G[p.grp] || ""}</td></tr>` : ""; lastG = p.grp;
    return head + `<tr><td class="ed-pos"><b>${esc(p.pos || "")}</b>${sq.locked ? "" : `<input class="ed-no" type="number" min="1" max="99" value="${p.shirt || ""}" data-ed-no="${p.pid}" title="Shirt number">`}</td><td class="name"><span class="tn">${pface({ pid: p.card }, "bdo-pf")}<span class="rc-pl"><b translate="no">${esc(p.name)}</b><small>${esc(p.nat || "")}${p.value != null ? ` · €${p.value}M` : ""}</small></span></span></td>
      <td class="n">${sq.locked ? `<b>${p.ca}</b>` : `<span class="ed-ca"><button data-ed="ca-" data-v="${p.pid}:${p.ca}">−</button><input type="number" min="60" max="199" value="${p.ca}" data-ed-ca="${p.pid}"><button data-ed="ca+" data-v="${p.pid}:${p.ca}">+</button></span>`}</td>
      <td class="n muted">${p.pa ?? ""}</td><td class="n ed-role">${p.share && (p.share.g || p.share.a) ? `<b class="${p.share.manual ? "man" : ""}">${p.share.g}% · ${p.share.a}%</b>` : `<small>auto</small>`}${sq.locked ? "" : `<button class="ed-rb" data-ed="role" data-v="${esc(p.name)}" data-g="${p.share ? p.share.g : 0}" data-a="${p.share ? p.share.a : 0}">✎</button>`}</td><td class="n">${sq.locked ? "" : `<button class="ed-move" data-ed="move" data-v="${p.pid}">Move ›</button>`}</td></tr>`; }).join("");
  const hits = edState.hits ? (edState.hits.length ? edState.hits.map((p) => `<div class="ed-hit"><span class="tn">${crest(p.club, "sm")}<span class="rc-pl"><b translate="no">${esc(p.name)}</b><small>${esc(p.club_name)} · ${esc(p.league)} · ${esc(p.pos || "")} · CA ${p.ca}</small></span></span><span><button data-ed="goto" data-v="${p.cid}:${p.club}">Club</button><button class="pri" data-ed="move" data-v="${p.pid}" data-cid="${p.cid}">Move ›</button></span></div>`).join("") : `<div class="empty-note">No player found</div>`) : `<div class="empty-note">Type a name to search every league</div>`;
  const cards = edState.cards ? (edState.cards.length ? edState.cards.map((c) => `<div class="ed-hit"><span class="tn">${pface({ pid: c.card }, "bdo-pf")}<span class="rc-pl"><b translate="no">${esc(c.name)}</b><small>Card ${c.card}${c.pos ? " · " + c.pos : ""}</small></span></span><span><button class="pri" data-ed="add" data-v="${c.card}" data-pos="${esc(c.pos || "")}" data-name="${esc(c.name)}">Add to ${esc(C.name)}</button></span></div>`).join("") : `<div class="empty-note">No card found</div>`) : `<div class="empty-note">A real-life transfer the Master League does not have yet: find the card and add it to the club on the left. He plays, scores and assists like everybody else; set his Role (✎) if he should be a main scorer.</div>`;
  let modal = "";
  if (edState.roles) {
    const R = edState.roles, opt = (sel) => `<option value="">—</option>` + R.players.map((p) => `<option value="${esc(p.id)}"${String(sel) === String(p.id) ? " selected" : ""}>${p.xi ? "" : "(bench) "}${esc(p.shirt)} · ${esc(p.name)}</option>`).join("");
    modal = `<div class="dlg-back ed-dlg"><div class="dlg ed-rdlg"><div class="ch">Captain &amp; set pieces · ${esc(C.name)}</div><div class="cb"><p class="muted">Used in your matches against this club (the match squad gets the captain and the set-piece takers).</p>
      <div class="ed-rgrid"><label>Captain<select data-edr="c">${opt(R.captain)}</select></label>${R.labels.map((l, i) => `<label>${esc(l)}<select data-edr="${i}">${opt(R.kickers[i])}</select></label>`).join("")}</div>
      <div class="ed-acts"><button data-ed="cancel">Cancel</button><button class="pri" data-ed="roles-save">Save</button></div></div></div></div>`;
  } else if (edState.role) {
    const r = edState.role;
    modal = `<div class="dlg-back ed-dlg"><div class="dlg"><div class="ch">Scoring role · ${esc(r.name)}</div><div class="cb"><p class="muted">Share of his team's goals and assists in every competition (league, Europe). A 30% scorer at a top club gets about 25–30 league goals. Auto = by ability and position.</p>
      <div class="ed-roleform"><label>Goals %<input type="number" id="ed-rg" min="0" max="45" value="${r.g}"></label><label>Assists %<input type="number" id="ed-ra" min="0" max="35" value="${r.a}"></label></div>
      <div class="ed-acts"><button data-ed="role-auto">Auto</button><button data-ed="cancel">Cancel</button><button class="pri" data-ed="role-save">Save</button></div></div></div></div>`;
  } else if (edState.pick) {
    const pk = edState.pick, opts = d.leagues.map((x) => `<optgroup label="${esc(x.name)}">${x.clubs.filter((c) => !c.mine).map((c) => `<option value="${x.cid}:${c.team}">${esc(c.name)}</option>`).join("")}</optgroup>`).join("");
    modal = `<div class="dlg-back ed-dlg"><div class="dlg"><div class="ch">Move ${esc(pk.name)}</div><div class="cb"><p class="muted">From <b>${esc(pk.from)}</b> — choose the new club (no fee, takes effect immediately; results, scorers and news follow).</p><select id="ed-to">${opts}</select><div class="ed-acts"><button data-ed="cancel">Cancel</button><button class="pri" data-ed="domove">Confirm transfer</button></div></div></div></div>`;
  }
  return `<div class="view v-ed"><div class="card ed-left"><div class="ch">Leagues</div><div class="ed-ltabs">${ltabs}</div><div class="cb scroll">${clubs}</div></div>
    <div class="card ed-mid"><div class="ch">${crest(C.team, "sm")} ${esc(C.name)}${sq && sq.locked ? `<span class="r">Your club · edit through the market</span>` : `<span class="r">CA = current ability · PA = potential</span>`}</div>${sq && !sq.locked ? `<div class="ed-tools"><label class="ed-str">Club strength <input type="range" min="60" max="150" step="5" value="${sq.strength || 100}" data-ed-str="${C.team}"><b id="ed-strv">${sq.strength || 100}%</b></label>
      <span class="ed-addid"><input id="ed-aid" placeholder="Player card ID" inputmode="numeric"><input id="ed-ash" placeholder="No." inputmode="numeric" maxlength="2"><select id="ed-apos">${["", "GK", "CB", "LB", "RB", "DMF", "CMF", "LMF", "RMF", "AMF", "LWF", "RWF", "SS", "CF"].map((x) => `<option value="${x}">${x || "Pos (card)"}</option>`).join("")}</select><input id="ed-aca" placeholder="CA" inputmode="numeric" maxlength="3"><button class="pri" data-ed="addid">Add</button></span><button class="ed-rolesbtn" data-ed="roles" data-v="${C.team}">Captain &amp; set pieces</button></div>` : ""}<div class="cb scroll"><table class="ed-tbl"><thead><tr><th>Pos · No.</th><th>Player</th><th class="n">CA</th><th class="n">PA</th><th class="n" title="Share of the team's goals · assists">Role</th><th></th></tr></thead><tbody>${rows}</tbody></table></div></div>
    ${modal}</div>`;
}
async function edCa(pid, ca) { const r = await post("/api/rc29/editor/ca", { pid, cid: edState.cid, ca }).catch(() => null); if (r && r.error) toast && toast(r.reason || r.error); sound("ok"); draw(); }
document.addEventListener("click", async (ev) => {
  const t = ev.target.closest("[data-ed]"); if (!t || !t.closest(".v-ed")) return;
  ev.stopPropagation(); ev.preventDefault();
  const k = t.dataset.ed, v = t.dataset.v || "";
  if (k === "lg") { edState.cid = +v; edState.team = null; sound("cursor"); return draw(); }
  if (k === "club") { edState.team = +v; sound("cursor"); return draw(); }
  if (k === "goto") { const [c, tm] = v.split(":"); edState.cid = +c; edState.team = +tm; return draw(); }
  if (k === "ca-" || k === "ca+") { const [pid, ca] = v.split(":"); return edCa(pid, +ca + (k === "ca+" ? 1 : -1)); }
  if (k === "move") { const row = t.closest("tr, .ed-hit"); const name = row ? (row.querySelector(".rc-pl b") || {}).textContent : ""; edState.pick = { pid: v, cid: t.dataset.cid ? +t.dataset.cid : edState.cid, name, from: t.dataset.cid ? ((row.querySelector(".rc-pl small") || {}).textContent || "").split(" · ")[0] : ($(".ed-mid .ch") || {}).textContent || "" }; return draw(); }
  if (k === "cancel") { edState.pick = null; edState.role = null; edState.roles = null; return draw(); }
  if (k === "roles") { const r = await api(`/api/rc29/editor/roles/${v}`).catch(() => null); if (!r || r.error) { try { toast((r && r.reason) || "Not available"); } catch (e) {} return; } edState.roles = r; sound("open"); return draw(); }
  if (k === "roles-save") { const R = edState.roles, cap = ($('[data-edr="c"]') || {}).value || null, ks = R.labels.map((_, i) => ($(`[data-edr="${i}"]`) || {}).value || null);
    const r = await post("/api/rc29/editor/roles", { team: R.team, captain: cap, kickers: ks }).catch(() => null); edState.roles = null;
    if (r && r.error) { try { toast(r.reason || r.error); } catch (e) {} } else { sound("ok"); try { toast("Captain and set pieces saved"); } catch (e) {} } return draw(); }
  if (k === "addid") { const card = ($("#ed-aid").value || "").trim(); if (!/^\d{3,18}$/.test(card)) { try { toast("Enter a valid card ID"); } catch (e) {} return; }
    const r = await post("/api/rc29/editor/add", { cid: edState.cid, team: edState.team, card: +card, shirt: +($("#ed-ash").value || 0), pos: $("#ed-apos").value || "", ca: +($("#ed-aca").value || 0) || 150 }).catch(() => null);
    if (r && r.error) { try { toast(r.reason || r.error); } catch (e) {} } else { sound("ok"); try { toast("Player added"); } catch (e) {} } return draw(); }
  if (k === "mode") { edState.db = v === "1"; edState.hits = null; edState.cards = null; edState.q = ""; return draw(); }
  if (k === "role") { edState.role = { name: v, g: +t.dataset.g || 0, a: +t.dataset.a || 0 }; return draw(); }
  if (k === "role-save" || k === "role-auto") { const r = edState.role; edState.role = null;
    await post("/api/rc29/editor/role", k === "role-auto" ? { name: r.name, auto: true } : { name: r.name, g: +$("#ed-rg").value || 0, a: +$("#ed-ra").value || 0 }).catch(() => null); sound("ok"); return draw(); }
  if (k === "add") { const r = await post("/api/rc29/editor/add", { cid: edState.cid, team: edState.team, card: +v, pos: t.dataset.pos || "", name: t.dataset.name || "" }).catch(() => null);
    if (r && r.error) { try { toast(r.reason || r.error); } catch (e) {} } else sound("ok"); return draw(); }
  if (k === "domove") { const [cid, team] = ($("#ed-to").value || "").split(":"); const pk = edState.pick; edState.pick = null;
    const r = await post("/api/rc29/editor/move", { pid: pk.pid, from_cid: pk.cid, to_cid: +cid, to_team: +team }).catch(() => null);
    if (r && r.ok) { sound("ok"); edState.cid = +cid; edState.team = +team; edState.hits = null; } return draw(); }
}, true);
document.addEventListener("change", async (ev) => { const n = ev.target.closest("[data-ed-no]"); if (!n || !n.closest(".v-ed")) return; const r = await post("/api/rc29/editor/shirt", { cid: edState.cid, pid: n.dataset.edNo, shirt: +n.value }).catch(() => null); if (r && r.error) { try { toast(r.reason || r.error); } catch (e) {} draw(); } else sound("ok"); }, true);
document.addEventListener("change", async (ev) => { const r = ev.target.closest("[data-ed-str]"); if (r && r.closest(".v-ed")) { await post("/api/rc29/editor/strength", { team: +r.dataset.edStr, pct: +r.value }).catch(() => null); sound("ok"); } }, true);
document.addEventListener("input", (ev) => { const r = ev.target.closest("[data-ed-str]"); if (r) { const b = $("#ed-strv"); if (b) b.textContent = r.value + "%"; } }, true);
document.addEventListener("change", (ev) => { const i = ev.target.closest("[data-ed-ca]"); if (i && i.closest(".v-ed")) edCa(i.dataset.edCa, +i.value); }, true);
let edTimer = null;
document.addEventListener("input", (ev) => { const i = ev.target.closest("[data-ed-q]"); if (!i) return; edState.q = i.value; clearTimeout(edTimer);
  edTimer = setTimeout(async () => { if (edState.q.trim().length < 2) { edState.hits = null; edState.cards = null; } else if (edState.db) { const r = await api(`/api/rc29/editor/cards/${encodeURIComponent(edState.q.trim())}`).catch(() => null); edState.cards = (r && r.cards) || []; } else { const r = await api(`/api/rc29/editor/search/${encodeURIComponent(edState.q.trim())}`).catch(() => null); edState.hits = (r && r.players) || []; } await draw(); const q = $(".ed-q"); if (q) { q.focus(); q.setSelectionRange(q.value.length, q.value.length); } }, 350); }, true);
// ==== RC29.17 Y17 BEGIN ====
/* RC29.17 - Y17 Champions League: a stand-alone league inside the Master League app (own data /api/rc29/y17, own saves).
   Uses ml.js helpers ($, $$, esc, svg, pface, crestId, sound, toast, api, post). Screens: lobby -> pick -> game; saves. */
(() => {
  const Y = { d: null, tab: "home", md: null, stat: "g", club: null, art: null, busy: false, pick: null, saves: null, confirm: null, modal: null, ceremony: 0 };
  const TABS = [["home", "Home"], ["table", "Table"], ["fixtures", "Fixtures"], ["stats", "Stats"], ["awards", "Awards"], ["news", "News"], ["squads", "Squads"]];
  const ICON = {
    home: '<path d="M3 11l9-7 9 7v9H14v-6h-4v6H3z"/>', table: '<path d="M4 5h16M4 10h16M4 15h16M4 20h16"/>', fixtures: '<rect x="3.5" y="5" width="17" height="15" rx="2"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
    stats: '<path d="M5 20V10M12 20V4M19 20v-7"/>', awards: '<path d="M7 4h10v4a5 5 0 01-10 0z"/><path d="M7 6H4v1a3 3 0 003 3M17 6h3v1a3 3 0 01-3 3M12 13v4M8 21h8l-1-4H9z"/>',
    news: '<rect x="3.5" y="4.5" width="17" height="15" rx="2"/><path d="M7 9h10M7 13h10M7 17h6"/>', squads: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c.5-4 3-6 6-6s5.5 2 6 6"/><circle cx="17" cy="9" r="2.4"/><path d="M15.5 14.2c2.6.3 4.6 2.2 5 5.8"/>',
    back: '<path d="M15 5l-7 7 7 7"/>', play: '<path d="M8 5l11 7-11 7z"/>', ff: '<path d="M4 6l8 6-8 6zM12 6l8 6-8 6z"/>', save: '<path d="M5 4h11l3 3v13H5z"/><path d="M8 4v5h7V4M8 20v-6h8v6"/>',
  };
  const STARBALL = `<svg class="y7-emb" viewBox="0 0 120 120" aria-hidden="true"><defs><radialGradient id="y7g" cx="40%" cy="35%" r="70%"><stop offset="0" stop-color="#ffffff"/><stop offset=".55" stop-color="#cfd6ea"/><stop offset="1" stop-color="#6f7899"/></radialGradient></defs>${Array.from({ length: 8 }, (_, i) => { const a = i / 8 * Math.PI * 2 - Math.PI / 2, x = 60 + Math.cos(a) * 46, y = 60 + Math.sin(a) * 46; return `<path transform="translate(${x.toFixed(1)} ${y.toFixed(1)})" d="M0-7l2 4.8 5.2.4-4 3.4 1.3 5.1L0 3.9-4.5 6.7l1.3-5.1-4-3.4 5.2-.4z" fill="url(#y7g)"/>`; }).join("")}<circle cx="60" cy="60" r="27" fill="none" stroke="url(#y7g)" stroke-width="2"/><path d="M60 41l6 8.5-3.5 10h-5L54 49.5zM44.5 57l9.5-.5 3 9.5-5.5 6.5-8.5-3.5zM75.5 57l-9.5-.5-3 9.5 5.5 6.5 8.5-3.5z" fill="url(#y7g)" opacity=".9"/></svg>`;
  const ic = (k, w = 1.8) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round">${ICON[k]}</svg>`;
  const T = (id) => (Y.d && Y.d.teams && Y.d.teams[String(id)]) || {};
  const cr = (id, cls = "sm") => { const t = T(id); return crestId(t.crest, t.short || "?", t.c, cls); };
  const nm = (id) => T(id).name || `#${id}`;
  const nk = (id) => T(id).nick || nm(id);
  const shortN = (n) => { const p = String(n || "").split(" "); return p.length < 2 || /^(Jr|Júnior)$/.test(p[p.length - 1]) ? n : `${p[0][0]}. ${p.slice(1).join(" ")}`; };
  const face = (pid, cls = "") => pface({ pid }, cls);
  const btc = (p, extra = "") => `<div class="btc y7-btc${p.xi ? " xi" : ""}">${p.pid ? `<img class="y7-cardart" src="/img/card/${encodeURIComponent(p.pid)}.png" alt="" loading="lazy" onload="this.parentNode.classList.add('art')" onerror="this.remove()">` : ""}<div class="btc-top"><b>${esc(p.pos || "")}</b>${cr(p.team || Y.club)}</div><div class="btc-face">${p.pid ? `<img data-face="${esc(p.pid)}" alt="">` : ""}</div><div class="btc-name" translate="no">${esc(p.name)}</div>${extra}</div>`;
  const ord = (n) => `${n}${n % 100 >= 11 && n % 100 <= 13 ? "th" : ({ 1: "st", 2: "nd", 3: "rd" }[n % 10] || "th")}`;
  const call = async (path, body) => { const r = body === undefined ? await api(path).catch((e) => ({ error: e.message })) : await post(path, body); return r || { error: "no-response" }; };

  // ------------------------------------------------------------------ entry
  async function openY17() {
    sound("page"); screen = "y17"; Y.tab = "home"; Y.md = null; Y.art = null; Y.modal = null;
    $("#app").innerHTML = `<div class="y7 y7-load"><div class="y7-spin"></div><b>Champions League 2017</b></div>`;
    if (!window.__y7kick) post("/api/rc29/y17/unkick", {});
    Y.d = await call("/api/rc29/y17");
    if (Y.d && Y.d.error) { $("#app").innerHTML = `<div class="y7 y7-load"><b>Champions League 2017</b><small>${esc(Y.d.reason || Y.d.error)}</small><button class="y7-btn" id="y7x">‹ Master League</button></div>`; $("#y7x").onclick = toMenu; return; }
    lobby();
  }
  window.openY17 = openY17;

  // ------------------------------------------------------------------ lobby
  function lobby() {
    if (screen !== "y17") return;
    Y.view = "lobby";
    const c = Y.d && Y.d.career, me = c && Y.d.table && Y.d.table.find((x) => x.team === c.team);
    const live = !!(Y.d && Y.d.link_active);
    const hist = (Y.d && Y.d.history) || [];
    const items = [
      { k: "continue", t: "Continue", s: c ? `${nm(c.team)} · Season ${c.season} · ${c.done ? "season finished" : `matchday ${Math.min(c.round + 1, c.rounds)} of ${c.rounds}`}` : "No league yet", off: !c },
      { k: "new", t: "New season", s: "Choose one of the twelve clubs of 2017", off: false },
      { k: "saves", t: "Saves", s: "Five slots for this league", off: false },
      { k: "back", t: "Master League", s: "Back to the Master League menu", off: false },
    ];
    $("#app").innerHTML = `<div class="y7 y7-lobby">
      <div class="y7-glow"></div>
      <div class="y7-lb-left">
        <div class="y7-mark">${STARBALL}<span><em>The 2016/17 giants</em><b>Champions League</b><i>2017</i></span></div>
        <nav class="y7-menu">${items.map((x, i) => `<button class="y7-mi" data-y7m="${x.k}" ${x.off ? "disabled" : ""}><em>0${i + 1}</em><div><b>${x.t}</b><small>${esc(x.s)}</small></div><i>›</i></button>`).join("")}</nav>
      </div>
      <aside class="y7-lb-card">${c && me ? `<small class="y7-cap">${live ? "Live from My League" : "Your league"}</small>
          <div class="y7-lb-club">${cr(c.team, "xl")}<div><b>${esc(nm(c.team))}</b><span>Season ${c.season} · ${c.done ? "Finished" : `Matchday ${c.round + 1} of ${c.rounds}`}</span></div></div>
          <div class="y7-lb-stats"><div><small>Position</small><b class="num">${me.pos}</b></div><div><small>Points</small><b class="num">${me.pts}</b></div><div><small>W-D-L</small><b class="num">${me.w}-${me.d}-${me.l}</b></div><div><small>Titles</small><b class="num">${hist.filter((h) => h.champion === c.team).length}</b></div></div>
          ${hist.length ? `<div class="y7-lb-hist">${hist.slice(-3).reverse().map((h) => `<span>${h.season}. ${cr(h.champion)} <b>${esc(nk(h.champion))}</b>${h.ballon ? `<em>Ballon d'Or ${esc(shortN(h.ballon.name))}</em>` : ""}</span>`).join("")}</div>` : ""}`
        : `<div class="y7-how"><small class="y7-cap">How it works</small><ol><li><b>New season</b>: pick your club of 2017</li><li>Press <b>Play</b> on a matchday: you play it yourself, like a Master League match, with your own squad</li><li>33 matchdays, every pair meets three times</li></ol><p>Your real result and scorers go into the table, the Golden Boot race, the news, the interviews and the Ballon d'Or night.</p></div>`}</aside>
    </div>`;
    $$("[data-y7m]").forEach((b) => b.onclick = () => {
      const k = b.dataset.y7m;
      if (k === "continue") { sound("page"); return game(); }
      if (k === "new") return openPick(false);
      if (k === "saves") return openSaves();
      if (k === "back") return toMenu();
    });
  }

  // ------------------------------------------------------------------ pick a club
  function openPick(nextSeason) {
    sound("page"); Y.view = "pick"; Y.pick = { team: nextSeason && Y.d.career ? Y.d.career.team : null, next: !!nextSeason, confirm: false };
    drawPick();
  }
  function drawPick() {
    const p = Y.pick, teams = Object.values(Y.d.teams);
    const rating = {}; (Y.d.pick || []).forEach((x) => { rating[x.id] = x.rating; });
    const order = [1222, 1220, 5317, 2365, 1987, 1986, 131, 1219, 1221, 1985, 2621, 132];
    const stars = { 1222: "Messi · Neymar · Suárez", 1220: "Ronaldo · Modrić · Bale", 5317: "Lewandowski · Müller · Neuer", 2365: "Dybala · Buffon · Chiellini", 1987: "Salah · Mané · Firmino",
      1986: "Cavani · Mbappé · Verratti", 131: "De Bruyne · Agüero · Silva", 1219: "Griezmann · Oblak · Godín", 1221: "Hazard · Kanté · Costa", 1985: "Kane · Alli · Eriksen", 2621: "Totti · Džeko · De Rossi", 132: "Pogba · Rooney · De Gea" };
    const tier = (id) => order.indexOf(id) < 2 ? "Title favourite" : order.indexOf(id) < 5 ? "Contender" : order.indexOf(id) < 8 ? "Outsider" : "Dark horse";
    const sel = p.team;
    $("#app").innerHTML = `<div class="y7 y7-pick"><header class="y7-ph"><button class="y7-btn ghost" id="y7pb">‹ Back</button><b>${p.next ? "Next season - choose your club" : "New league - choose your club"}</b><span>${p.next ? "History, titles and Ballon d'Or count are kept" : "A completely separate league: nothing changes in the Master League"}</span></header>
      <div class="y7-pgrid">${order.map((id, i) => { const t = T(id); return `<button class="y7-pc${sel === id ? " on" : ""}" data-y7t="${id}" style="--c:${t.c};--i:${i}">${cr(id, "lg")}<div><b>${esc(t.name)}</b><small>${esc(stars[id] || "")}</small><span class="y7-pbar"><i style="width:${Math.max(20, Math.min(100, ((rating[id] || 80) - 45) * 1.15))}%"></i></span></div><em>${tier(id)}</em></button>`; }).join("")}</div>
      <footer class="y7-pf">${sel ? `<span class="y7-psel">${cr(sel, "sm")}<b>${esc(nm(sel))}</b><small>Manager: ${esc(T(sel).boss || "")} · ${esc(T(sel).ground || "")}</small></span>` : `<span class="y7-hint">Tap a club</span>`}
        <button class="y7-btn pri" id="y7go" ${sel && !Y.busy ? "" : "disabled"}>${Y.busy ? "Creating…" : p.next ? "Start next season ›" : "Start the league ›"}</button></footer>
      ${p.confirm ? `<div class="y7-modal"><div class="y7-dlg"><b>Start a new league?</b><p>Your current Y17 league (${esc(nm(Y.d.career.team))}, season ${Y.d.career.season}) will be replaced. Save it in a slot first if you want to keep it.</p><div class="y7-acts"><button class="y7-btn" data-y7c="no">Cancel</button><button class="y7-btn pri" data-y7c="yes">Start new</button></div></div></div>` : ""}
    </div>`;
    $("#y7pb").onclick = () => { sound("back"); Y.d.career ? (p.next ? game() : lobby()) : lobby(); };
    $$("[data-y7t]").forEach((b) => b.onclick = () => { p.team = +b.dataset.y7t; sound("cursor"); drawPick(); });
    $("#y7go").onclick = () => { if (!p.next && Y.d.career && !p.confirm) { p.confirm = true; sound("open"); return drawPick(); } start(); };
    $$("[data-y7c]").forEach((b) => b.onclick = () => { p.confirm = false; if (b.dataset.y7c === "yes") return start(); sound("back"); drawPick(); });
  }
  async function start() {
    const p = Y.pick; if (!p.team || Y.busy) return;
    Y.busy = true; drawPick();
    const r = await call(p.next ? "/api/rc29/y17/season" : "/api/rc29/y17/new", { team: p.team });
    Y.busy = false;
    if (!r || r.error) { toast((r && (r.reason || r.error)) || "Could not start"); return drawPick(); }
    sound("ok"); Y.d = r; Y.tab = "home"; Y.md = null; Y.art = null; game();
  }

  // ------------------------------------------------------------------ saves
  async function openSaves() {
    sound("page"); Y.view = "saves"; Y.saves = null; Y.confirm = null; drawSaves();
    Y.saves = await call("/api/rc29/y17/saves"); drawSaves();
  }
  function drawSaves() {
    const s = Y.saves, cur = s && s.current, c = Y.confirm;
    const card = (x) => {
      const m = x.summary;
      return `<div class="y7-sv${x.empty ? " empty" : ""}"><div class="y7-svh"><b>Slot ${x.slot}</b><small>${x.time ? new Date(x.time * 1000).toLocaleString() : ""}</small></div>
        ${x.empty ? `<div class="y7-sve">Empty slot</div>` : `<div class="y7-svc">${cr(m.team, "lg")}<div><b>${esc(m.team_name)}</b><small>Season ${m.season} · MD ${m.round}/33 · ${ord(m.rank)} · ${m.points} pts${m.titles ? ` · ${m.titles} title${m.titles > 1 ? "s" : ""}` : ""}</small></div></div>`}
        <div class="y7-acts">${cur ? `<button class="y7-btn" data-y7s="save" data-v="${x.slot}">${x.empty ? "Save here" : "Overwrite"}</button>` : ""}${x.empty ? "" : `<button class="y7-btn pri" data-y7s="load" data-v="${x.slot}">Load</button><button class="y7-btn ghost" data-y7s="delete" data-v="${x.slot}">Delete</button>`}</div></div>`;
    };
    $("#app").innerHTML = `<div class="y7 y7-saves"><header class="y7-ph"><button class="y7-btn ghost" id="y7sb">‹ Back</button><b>Y17 saves</b><span>${cur ? `Current: ${esc(cur.team_name)} · Season ${cur.season} · MD ${cur.round}/33` : "No league in progress"}</span></header>
      <div class="y7-svg">${s ? s.slots.map(card).join("") : `<div class="y7-load"><div class="y7-spin"></div></div>`}</div>
      ${c ? `<div class="y7-modal"><div class="y7-dlg"><b>${c.act === "load" ? `Load slot ${c.slot}?` : c.act === "delete" ? `Delete slot ${c.slot}?` : `Overwrite slot ${c.slot}?`}</b><p>${c.act === "load" ? "Your current Y17 league is replaced (a backup is kept)." : c.act === "delete" ? "This cannot be undone." : "The league saved there is replaced by your current one."}</p><div class="y7-acts"><button class="y7-btn" data-y7k="no">Cancel</button><button class="y7-btn pri" data-y7k="yes">Confirm</button></div></div></div>` : ""}</div>`;
    $("#y7sb").onclick = () => { sound("back"); lobby(); };
    $$("[data-y7s]").forEach((b) => b.onclick = () => {
      const act = b.dataset.y7s, slot = b.dataset.v, x = s.slots.find((q) => q.slot === slot);
      if (act === "save" && x.empty) return doSave(act, slot);
      Y.confirm = { act, slot }; sound("open"); drawSaves();
    });
    $$("[data-y7k]").forEach((b) => b.onclick = () => { const cc = Y.confirm; Y.confirm = null; if (b.dataset.y7k === "yes") return doSave(cc.act, cc.slot); sound("back"); drawSaves(); });
  }
  async function doSave(act, slot) {
    const r = await call(`/api/rc29/y17/saves/${act}`, { slot });
    if (!r || r.error) { sound("back"); toast((r && r.error) || "Failed"); return openSaves(); }
    sound("ok");
    if (act === "load") { Y.d = r; toast("League loaded"); Y.tab = "home"; return game(); }
    toast(act === "save" ? "Saved" : "Deleted"); Y.saves = r; drawSaves();
  }

  // ------------------------------------------------------------------ game shell
  function game() {
    if (screen !== "y17" || !Y.d || !Y.d.career) return lobby();
    Y.view = "game";
    const c = Y.d.career, me = Y.d.table.find((x) => x.team === c.team) || {}, t = T(c.team);
    document.documentElement.style.setProperty("--y7c", t.c || "#1b2a52");
    $("#app").innerHTML = `<div class="y7 y7-app">
      <header class="y7-top">
        <button class="y7-brand" id="y7menu" title="Menu">${cr(c.team, "lg")}</button>
        <div class="y7-tt"><b>${esc(nm(c.team))}</b><small>Champions League 2017 · Season ${c.season}</small></div>
        <div class="y7-chips"><span><small>MD</small><b class="num">${Math.min(c.round, 33)}<i>/33</i></b></span><span><small>Pos</small><b class="num">${me.pos || "—"}</b></span><span><small>Pts</small><b class="num">${me.pts ?? 0}</b></span><span class="y7-form">${(me.form || []).map((f) => `<i class="f${f}">${f}</i>`).join("")}</span></div>
        <div class="y7-fill"></div>
        ${c.done ? `<button class="y7-btn" id="y7cer">${ic("awards")}<span>Awards night</span></button>` : Y.d.next ? (c.linked ? `<div class="y7-nextchip">${cr(Y.d.next.h)}<span><small>Matchday ${Y.d.next.round} · play it in My League</small><b>${esc(nk(Y.d.next.h))} v ${esc(nk(Y.d.next.a))}</b></span>${cr(Y.d.next.a)}</div>`
          : `<button class="y7-btn ghost y7-simbtn" id="y7sim1" title="Simulate this matchday">${ic("ff")}<span>Sim</span></button><button class="y7-btn pri y7-play" id="y7play">${ic("play")}<span>Play · MD ${Y.d.next.round}</span></button>`) : ""}
      </header>
      <nav class="y7-rail">${TABS.map(([k, n]) => `<button class="${Y.tab === k ? "on" : ""}" data-y7tab="${k}">${ic(k)}<span>${n}</span></button>`).join("")}<div class="y7-sp"></div><button data-y7tab="__menu">${ic("back")}<span>Menu</span></button></nav>
      <main class="y7-main scroll" id="y7page"></main>
      <div id="y7modal"></div>
    </div>`;
    $$("[data-y7tab]").forEach((b) => b.onclick = () => { const k = b.dataset.y7tab; if (k === "__menu") { sound("back"); return lobby(); } Y.tab = k; sound("cursor"); $$("[data-y7tab]").forEach((x) => x.classList.toggle("on", x === b)); page(); });
    $("#y7menu").onclick = () => { sound("back"); lobby(); };
    if ($("#y7next")) $("#y7next").onclick = () => openPlay();
    if ($("#y7play")) $("#y7play").onclick = () => y7Play();
    if ($("#y7sim1")) $("#y7sim1").onclick = () => { Y.modal = { kind: "play", hg: "", ag: "" }; sound("open"); drawModal(); };
    if ($("#y7sim")) $("#y7sim").onclick = () => { Y.modal = { kind: "simall" }; drawModal(); };
    if ($("#y7ns")) $("#y7ns").onclick = () => openPick(true);
    if ($("#y7cer")) $("#y7cer").onclick = () => ceremony(0);
    page();
    if (c.done && Y.d.awards && !Y.d.awards.shown) ceremony(0);
  }
  function page() {
    const el = $("#y7page"); if (!el) return;
    const f = { home: pHome, table: pTable, fixtures: pFix, stats: pStats, awards: pAwards, news: pNews, squads: pSquads }[Y.tab] || pHome;
    el.innerHTML = f(); el.scrollTop = 0; bind(el);
  }

  // ------------------------------------------------------------------ playing
  function openPlay() {
    const n = Y.d.next; if (!n) return;
    Y.modal = { kind: "play", hg: "", ag: "" }; sound("open"); drawModal();
  }
  async function playNext(mine) {
    if (Y.busy) return; Y.busy = true; drawModal();
    const before = Y.d.table.find((x) => x.team === Y.d.career.team);
    const r = await call("/api/rc29/y17/next", mine || {});
    Y.busy = false;
    if (!r || r.error) { toast((r && (r.reason || r.error)) || "Failed"); Y.modal = null; return drawModal(); }
    Y.d = r; sound("ok");
    const rd = r.career.round - 1, m = r.rounds[rd].find((x) => x.h === r.career.team || x.a === r.career.team);
    Y.md = rd; Y.modal = null;
    game();
    if (m) openMatch(rd + 1, m.i, before);
  }
  async function simAll() {
    if (Y.busy) return; Y.busy = true; drawModal();
    const r = await call("/api/rc29/y17/sim", {});
    Y.busy = false; Y.modal = null;
    if (!r || r.error) { toast("Failed"); return drawModal(); }
    Y.d = r; sound("ok"); Y.tab = "table"; game();
  }

  // ------------------------------------------------------------------ Play: your matchday through the Master League match flow
  async function y7Play() {
    if (!S || !S.career) { toast("Start a Master League career first: Champions League matches use its match flow"); return; }
    if (!ownSq || ownSq.error) { try { ownSq = await api("/api/rc29/own"); } catch (e) { ownSq = null; } }
    if (!ownSq || !ownSq.on) { Y.modal = { kind: "own" }; sound("open"); return drawModal(); }
    const r = await post("/api/rc29/y17/kick", {});
    if (!r || r.error) { toast((r && r.reason) || "The match could not be prepared"); return; }
    // the kick-off screen draws crests as /img/emblem/<id>: show both clubs under their CREST ids (Y17 team ids are other emblems)
    const keyOf = (id) => String(T(id).crest || id), saved = S.career.user_team, kept = {};
    for (const id of [r.team, r.opponent]) { const k = keyOf(id), t = T(id); kept[k] = S.teams[k]; S.teams[k] = Object.assign({}, S.teams[k] || {}, { latin: t.name, zh: t.name, short: t.short, c: t.c }); }
    S.career.user_team = +keyOf(r.team); window.__y7kick = true;
    try { await kickoff({ home: r.home, neutral: false, opponent: +keyOf(r.opponent), label: r.label, y17: true }); }
    finally { S.career.user_team = saved; for (const k of Object.keys(kept)) { if (kept[k]) S.teams[k] = kept[k]; } }
  }
  window.y7AfterMatch = async (round) => {
    window.__y7kick = false;
    screen = "y17"; Y.d = await call("/api/rc29/y17");
    Y.tab = "home"; game();
    const rd = round - 5000, m = Y.d.rounds && Y.d.rounds[rd - 1] && Y.d.rounds[rd - 1].find((x) => x.h === Y.d.career.team || x.a === Y.d.career.team);
    if (m) openMatch(rd, m.i);
  };

  // ------------------------------------------------------------------ pages
  function teamRow(x, compact) {
    const me = x.team === Y.d.career.team, z = x.pos === 1 ? "z1" : x.pos <= 4 ? "z4" : x.pos >= 11 ? "zb" : "";
    return `<tr class="${me ? "me" : ""} ${z}"><td class="rk"><i>${x.pos}</i></td><td class="nm"><span class="tn">${cr(x.team)}<b>${esc(compact ? nk(x.team) : nm(x.team))}</b></span></td><td class="n">${x.p}</td>${compact ? "" : `<td class="n">${x.w}</td><td class="n">${x.d}</td><td class="n">${x.l}</td><td class="n">${x.gf}:${x.ga}</td>`}<td class="n">${x.gd > 0 ? "+" : ""}${x.gd}</td><td class="n pts">${x.pts}</td>${compact ? "" : `<td class="fm">${x.form.map((f) => `<i class="f${f}">${f}</i>`).join("")}</td>`}</tr>`;
  }
  function pHome() {
    const d = Y.d, c = d.career, n = d.next;
    const nextCard = n ? `<section class="y7-card y7-next"><div class="y7-ch">${n.derby ? `<em class="y7-derby">${esc(n.derby)}</em>` : "Next match"}<span>Matchday ${n.round} · ${esc(T(n.h).ground || "")}</span></div>
        <div class="y7-vs"><div>${cr(n.h, "xl")}<b>${esc(nk(n.h))}</b><small>${ord((d.table.find((x) => x.team === n.h) || {}).pos || 0)}</small></div><i>VS</i><div>${cr(n.a, "xl")}<b>${esc(nk(n.a))}</b><small>${ord((d.table.find((x) => x.team === n.a) || {}).pos || 0)}</small></div></div>
        ${c.linked ? `<div class="y7-playnote">${ic("play")}<span>This season follows <b>My League</b>: play the match there.</span></div>` : `<button class="y7-btn pri wide y7-play" data-y7a="play">${ic("play")} Play matchday ${n.round}</button>`}</section>`
      : `<section class="y7-card y7-next done"><div class="y7-ch">Season ${c.season} complete</div><div class="y7-champ">${cr(d.awards ? d.awards.champion : d.table[0].team, "xl")}<b>${esc(nm(d.awards ? d.awards.champion : d.table[0].team))}</b><small>Champions · ${d.table[0].pts} pts</small></div><button class="y7-btn pri wide" data-y7a="cer">${ic("awards")} Awards night</button></section>`;
    const top = d.table.slice(0, 5), mine = d.table.find((x) => x.team === c.team);
    const mini = `<section class="y7-card y7-hometbl"><div class="y7-ch">Table<span>${c.round} / ${c.rounds} matchdays</span><button class="y7-more" data-y7go="table">Full ›</button></div><table class="y7-tbl"><thead><tr><th>#</th><th>Club</th><th class="n">P</th><th class="n">W</th><th class="n">D</th><th class="n">L</th><th class="n">GD</th><th class="n">Pts</th></tr></thead><tbody>${d.table.map((x) => { const me = x.team === c.team, z = x.pos === 1 ? "z1" : x.pos <= 4 ? "z4" : ""; return `<tr class="${me ? "me" : ""} ${z}"><td class="rk"><i>${x.pos}</i></td><td class="nm"><span class="tn">${cr(x.team)}<b>${esc(nk(x.team))}</b></span></td><td class="n">${x.p}</td><td class="n">${x.w}</td><td class="n">${x.d}</td><td class="n">${x.l}</td><td class="n">${x.gd > 0 ? "+" : ""}${x.gd}</td><td class="n pts">${x.pts}</td></tr>`; }).join("")}</tbody></table></section>`;
    const duel = duelCard();
    const race = d.scorers.length ? `<section class="y7-card"><div class="y7-ch">Golden Boot race<button class="y7-more" data-y7go="stats">All ›</button></div>${d.scorers.slice(0, 10).map((p, i) => `<div class="y7-rr${i === 0 ? " lead" : ""}"><i>${p.rank}</i>${face(p.pid, "lg")}<span><b translate="no">${esc(p.name)}</b><small>${cr(p.team)} ${esc(nk(p.team))}</small></span><span class="y7-bar"><i style="width:${Math.round(p.n / d.scorers[0].n * 100)}%"></i></span><b class="num">${p.n}</b></div>`).join("")}</section>`
      : `<section class="y7-card"><div class="y7-ch">Golden Boot race</div><div class="y7-empty">The race starts on matchday 1</div></section>`;
    const fire = d.form.filter((x) => x.v > 0.15).slice(0, 4);
    const form = fire.length ? `<section class="y7-card"><div class="y7-ch">Form guide</div>${fire.map((x) => `<div class="y7-fr">${face(x.pid)}<b translate="no">${esc(shortN(x.name))}</b>${cr(x.team)}<span class="y7-heat" style="--h:${Math.round(Math.min(1, x.v / 0.6) * 100)}%"><i></i></span><em>🔥</em></div>`).join("")}${(d.cold || []).filter((x) => x.v < -0.15).slice(0, 2).map((x) => `<div class="y7-fr cold">${face(x.pid)}<b translate="no">${esc(shortN(x.name))}</b>${cr(x.team)}<span class="y7-heat" style="--h:${Math.round(Math.min(1, -x.v / 0.5) * 100)}%"><i></i></span><em>❄</em></div>`).join("")}</section>` : "";
    const news = d.news.slice(0, 4).map((x, i) => newsItem(x, i)).join("");
    return `<div class="y7-home"><div class="y7-col">${nextCard}${mini}</div><div class="y7-col">${duel}${ballonMini()}</div><div class="y7-col">${race}</div></div>`;
  }
  function duelCard() {
    const d = Y.d.duel || {}, m = d.messi, r = d.ronaldo;
    if (!m || !r) return "";
    const row = (k, a, b) => { const t = Math.max(1, a + b), w = a > b ? " l" : b > a ? " r" : "";
      return `<div class="dx-row${w}"><b class="num">${a}</b><span class="dx-bar"><i class="l" style="width:${(a / t * 100).toFixed(1)}%"></i><em>${k}</em></span><b class="num">${b}</b></div>`; };
    const tot = Math.max(1, (m.bscore || 0) + (r.bscore || 0)), pm = Math.round((m.bscore || 0) / tot * 100);
    const who = (x, nmx) => `<div class="dx-p">${face(x.pid, "y7-xl")}<b>${nmx}</b>${cr(x.team)}</div>`;
    return `<section class="y7-card dx">
      <div class="y7-ch"><em class="y7-derby">Messi v Ronaldo</em><span>The eternal duel</span></div>
      <div class="dx-top">${who(m, "Messi")}<div class="dx-mid"><i class="dx-vs">VS</i></div>${who(r, "Ronaldo")}</div>
      ${row("Goals", m.g, r.g)}${row("Assists", m.a, r.a)}${row("Man of the match", m.motm, r.motm)}${row("Hat-tricks", m.hat || 0, r.hat || 0)}${row("G+A", m.g + m.a, r.g + r.a)}${row("Ballon d'Or", m.ballons || 0, r.ballons || 0)}
      <div class="dx-odds"><b>${pm}%</b><span><i style="width:${pm}%"></i></span><b>${100 - pm}%</b></div><small class="dx-ol">Ballon d'Or race</small>
    </section>`;
  }
  function ballonMini() {
    const b = (Y.d.ballon || []).slice(0, 5);
    if (!b.length) return "";
    return `<section class="y7-card"><div class="y7-ch">Ballon d'Or race<button class="y7-more" data-y7go="awards">All ›</button></div>${b.map((p, i) => `<div class="y7-bm${i === 0 ? " lead" : ""}"><i>${i + 1}</i>${face(p.pid, "lg")}<span><b translate="no">${esc(p.name)}</b><small>${(p.why || []).map(esc).join(" · ") || `${p.g} G · ${p.a} A`}</small></span>${cr(p.team)}</div>`).join("")}</section>`;
  }
  function pTable() {
    const d = Y.d;
    return `<section class="y7-card"><div class="y7-ch">Champions League 2017 · Season ${d.career.season}<span>${d.career.round} / ${d.career.rounds} matchdays · 1st = champion</span></div>
      <table class="y7-tbl"><thead><tr><th>#</th><th>Club</th><th class="n">P</th><th class="n">W</th><th class="n">D</th><th class="n">L</th><th class="n">Goals</th><th class="n">GD</th><th class="n">Pts</th><th>Form</th></tr></thead><tbody>${d.table.map((x) => teamRow(x)).join("")}</tbody></table>
      <div class="y7-key"><i class="z1"></i>Champion <i class="z4"></i>Top four</div></section>`;
  }
  function pFix() {
    const d = Y.d, played = d.career.round;
    if (Y.md == null) Y.md = Math.max(0, Math.min(32, played - 1));
    const chips = d.rounds.map((_, i) => `<button class="${i === Y.md ? "on" : ""}${i < played ? " dn" : ""}${i === played && !d.career.done ? " nx" : ""}" data-y7md="${i}">${i + 1}</button>`).join("");
    const rd = d.rounds[Y.md] || [];
    const sc = (arr) => (arr || []).map((g) => `<span translate="no">${esc(g[0])} ${g[1]}'${g[2] === "pen" ? " (p)" : ""}</span>`).join("");
    const rows = rd.map((m) => { const mine = m.h === d.career.team || m.a === d.career.team, done = m.hg != null;
      return `<div class="y7-fx${mine ? " mine" : ""}${done ? " done" : ""}"${done ? ` data-y7mt="${Y.md + 1}:${m.i}"` : ""}><div class="y7-fxr"><b class="h">${esc(nk(m.h))}</b>${cr(m.h)}<span class="sc">${done ? `${m.hg}<i>-</i>${m.ag}` : "vs"}</span>${cr(m.a)}<b class="a">${esc(nk(m.a))}</b></div>${done && m.sc && (m.sc[0].length || m.sc[1].length) ? `<div class="y7-gs"><div class="gh">${sc(m.sc[0])}</div><i>⚽</i><div class="ga">${sc(m.sc[1])}</div></div>` : ""}${m.you ? `<em class="y7-you">your result</em>` : ""}</div>`; }).join("");
    return `<section class="y7-card"><div class="y7-ch">Matchday ${Y.md + 1}<span>${Y.md < 11 ? "First round" : Y.md < 22 ? "Second round" : "Third round"} · tap a result for the report</span></div><div class="y7-mds">${chips}</div><div class="y7-fxl">${rows}</div></section>`;
  }
  function pStats() {
    const d = Y.d, k = Y.stat;
    const lists = { g: ["Goals", d.scorers], a: ["Assists", d.assists], ga: ["Goals + assists", d.ga], motm: ["Man of the match", d.motm] };
    const [label, rows] = lists[k] || lists.g;
    return `<section class="y7-card"><div class="y7-ch">Player stats<span class="y7-seg">${Object.entries(lists).map(([kk, v]) => `<button class="${kk === k ? "on" : ""}" data-y7st="${kk}">${v[0]}</button>`).join("")}</span></div>
      ${rows.length ? `<table class="y7-tbl y7-ps"><thead><tr><th>#</th><th>Player</th><th>Club</th><th class="n">${label}</th></tr></thead><tbody>${rows.map((p) => `<tr class="${p.team === d.career.team ? "me" : ""}"><td class="rk"><i>${p.rank}</i></td><td class="nm"><span class="tn">${face(p.pid, "lg")}<span><b translate="no">${esc(p.name)}</b><small>${esc(p.pos || "")}</small></span></span></td><td><span class="tn">${cr(p.team)}<small>${esc(nk(p.team))}</small></span></td><td class="n pts">${p.n}</td></tr>`).join("")}</tbody></table>` : `<div class="y7-empty">No matches played yet</div>`}</section>`;
  }
  function pAwards() {
    const d = Y.d, aw = d.awards;
    const ball = (d.ballon || []).length ? `<section class="y7-card"><div class="y7-ch">${aw ? "Ballon d'Or · final ranking" : "Ballon d'Or · power ranking"}<span>Goals, assists, decisive goals, El Clásico, big games, carrying the team, the title</span></div>${(aw ? aw.ballon : d.ballon).map((p, i) => `<div class="y7-br${i < 3 ? " top t" + (i + 1) : ""}"><i>${i + 1}</i>${face(p.pid, "lg")}<span><b translate="no">${esc(p.name)}</b><small>${cr(p.team)} ${esc(nk(p.team))} · ${p.g} G · ${p.a} A · ${p.motm} MOTM${(p.why || []).length ? " · " + p.why.map(esc).join(" · ") : ""}</small></span><span class="y7-bar"><i style="width:${Math.round(p.score / (aw ? aw.ballon : d.ballon)[0].score * 100)}%"></i></span></div>`).join("")}</section>` : `<section class="y7-card"><div class="y7-ch">Ballon d'Or</div><div class="y7-empty">The power ranking appears after matchday 1</div></section>`;
    let end = "";
    if (aw) {
      const b = aw.boot[0], pm = aw.playmaker[0], gl = aw.glove;
      end = `<section class="y7-card y7-trs"><div class="y7-ch">Season ${d.career.season} honours<button class="y7-more" data-y7a="cer">Replay ceremony ›</button></div><div class="y7-trg">
        <div class="y7-tr gold">${cr(aw.champion, "xl")}<small>Champions</small><b>${esc(nm(aw.champion))}</b><em>${aw.points} pts</em></div>
        ${b ? `<div class="y7-tr">${btc({ pid: b.pid, name: b.name, pos: "Golden Boot", team: b.team })}<b>${b.n} goals</b></div>` : ""}
        ${pm ? `<div class="y7-tr">${btc({ pid: pm.pid, name: pm.name, pos: "Playmaker", team: pm.team })}<b>${pm.n} assists</b></div>` : ""}
        ${gl && gl.pid ? `<div class="y7-tr">${btc({ pid: gl.pid, name: gl.name, pos: "Golden Glove", team: gl.team })}<b>${gl.cs} clean sheets</b></div>` : ""}
        ${aw.breakout ? `<div class="y7-tr">${btc({ pid: aw.breakout.pid, name: aw.breakout.name, pos: "Breakout", team: aw.breakout.team })}<b>${aw.breakout.g} G · ${aw.breakout.a} A</b></div>` : ""}
        </div></section>${totsCard(aw.tots)}`;
    }
    const hist = d.history.length ? `<section class="y7-card"><div class="y7-ch">Roll of honour</div><table class="y7-tbl"><thead><tr><th>Season</th><th>Champion</th><th>Golden Boot</th><th>Ballon d'Or</th><th class="n">You</th></tr></thead><tbody>${d.history.slice().reverse().map((h) => `<tr><td class="rk"><i>${h.season}</i></td><td><span class="tn">${cr(h.champion)}<b>${esc(nk(h.champion))}</b></span></td><td>${h.boot ? `<span class="tn">${face(h.boot.pid)}<b translate="no">${esc(shortN(h.boot.name))}</b><small>${h.boot.n}</small></span>` : ""}</td><td>${h.ballon ? `<span class="tn">${face(h.ballon.pid)}<b translate="no">${esc(shortN(h.ballon.name))}</b></span>` : ""}</td><td class="n">${ord(h.you)}</td></tr>`).join("")}</tbody></table></section>` : "";
    return `<div class="y7-aw">${end}${ball}${hist}</div>`;
  }
  function totsCard(xi) {
    if (!xi || !xi.length) return "";
    const lines = ["F", "M", "D", "GK"].map((g) => xi.filter((p) => p.line === g));
    return `<section class="y7-card"><div class="y7-ch">Team of the season</div><div class="y7-pitch">${lines.map((l) => `<div class="y7-pl">${l.map((p) => `<div class="y7-tp">${face(p.pid, "lg")}<b translate="no">${esc(shortN(p.name))}</b>${cr(p.team)}</div>`).join("")}</div>`).join("")}</div></section>`;
  }
  function newsItem(x, i) {
    const vis = x.pid ? face(x.pid, "lg") : x.teams ? `<span class="y7-nv2">${cr(x.teams[0])}${cr(x.teams[1])}</span>` : cr(x.team, "lg");
    return `<button class="y7-ni k-${x.kind}${Y.art === x.id ? " on" : ""}" data-y7n="${esc(x.id)}">${vis}<span><em>${esc(x.tag || "")} · MD ${x.round}</em><b>${esc(x.title)}</b>${x.score ? `<small class="num">${x.score[0]}-${x.score[1]}</small>` : ""}</span></button>`;
  }
  function article(x) {
    if (!x) return `<div class="y7-empty">Choose a story</div>`;
    const voices = (x.voices || (x.quote ? [x.quote] : [])).map((v) => `<blockquote class="y7-q">${v.pid ? face(v.pid, "lg") : cr(v.team, "lg")}<div><p>“${esc(v.text)}”</p><cite translate="no">${esc(v.who)}${v.role ? ` · ${esc(v.role)}` : ""}</cite></div></blockquote>`).join("");
    const paras = (x.paras || []).filter(Boolean).map((p) => /^\d+' - /.test(p) ? `<p class="y7-tl"><b>${esc(p.split(" - ")[0])}</b>${esc(p.slice(p.indexOf(" - ") + 3))}</p>` : `<p>${esc(p)}</p>`).join("");
    const head = x.teams && x.score ? `<div class="y7-ah">${cr(x.teams[0], "lg")}<b class="num">${x.score[0]} - ${x.score[1]}</b>${cr(x.teams[1], "lg")}</div>` : x.pid ? `<div class="y7-ahp">${btc({ pid: x.pid, name: "", pos: x.tag || "", team: x.team })}</div>` : "";
    return `<article class="y7-art k-${x.kind}"><em class="y7-atag">${esc(x.tag || "")} · Matchday ${x.round}</em><h2>${esc(x.title)}</h2>${head}${x.lead ? `<p class="y7-lead">${esc(x.lead)}</p>` : ""}${paras}${voices}${x.ref ? `<button class="y7-btn" data-y7mt="${x.ref[0]}:${x.ref[1]}">Match report ›</button>` : ""}</article>`;
  }
  function pNews() {
    const d = Y.d; if (!d.news.length) return `<section class="y7-card"><div class="y7-empty">No news yet - play a matchday</div></section>`;
    if (!Y.art || !d.news.find((x) => x.id === Y.art)) Y.art = d.news[0].id;
    return `<div class="y7-news"><section class="y7-card y7-nlist scroll">${d.news.map(newsItem).join("")}</section><section class="y7-card y7-nart scroll">${article(d.news.find((x) => x.id === Y.art))}</section></div>`;
  }
  function pSquads() {
    const d = Y.d; if (!Y.club) Y.club = d.career.team;
    const sq = d.squads[String(Y.club)] || [], t = T(Y.club);
    const chips = Object.keys(d.squads).map((id) => `<button class="${+id === Y.club ? "on" : ""}" data-y7cl="${id}">${cr(+id)}<span>${esc(nk(+id))}</span></button>`).join("");
    const G = { GK: 0, CB: 1, LB: 1, RB: 1, DMF: 2, CMF: 2, LMF: 2, RMF: 2, AMF: 2, LWF: 3, RWF: 3, SS: 3, CF: 3 };
    const list = sq.slice().sort((a, b) => (b.xi - a.xi) || (G[a.pos] - G[b.pos]));
    return `<section class="y7-card"><div class="y7-ch">${cr(Y.club)} ${esc(t.name)}<span>Manager: ${esc(t.boss || "")} · ${sq.length} players · gold frame = starting XI</span></div><div class="y7-clubs">${chips}</div>
      <div class="btc-grid y7-sq">${list.map((p) => btc({ ...p, team: Y.club }, `${p.g || p.a ? `<div class="y7-ga">${p.g ? `<i>⚽ ${p.g}</i>` : ""}${p.a ? `<i>🅰 ${p.a}</i>` : ""}</div>` : ""}${p.f > 0.25 ? `<div class="y7-hot">🔥</div>` : ""}`)).join("")}</div></section>`;
  }

  // ------------------------------------------------------------------ match report
  async function openMatch(r, i) {
    Y.modal = { kind: "match", load: true }; drawModal();
    const m = await call(`/api/rc29/y17/match/${r}/${i}`);
    if (!Y.modal || Y.modal.kind !== "match") return;
    Y.modal = { kind: "match", m }; drawModal();
  }
  function matchHtml(m) {
    if (!m || m.error) return `<div class="y7-empty">Report unavailable</div>`;
    const rep = m.report || {}, tl = m.goals.map((g) => `<li class="${g.side ? "a" : "h"}"><b>${g.min}'</b>${face(g.pid)}<span><strong translate="no">${esc(g.name)}</strong>${g.kind === "pen" ? " (pen)" : g.kind === "fk" ? " (free kick)" : g.kind === "header" ? " (header)" : ""}${g.assist ? `<small>assist ${esc(g.assist)}</small>` : ""}</span></li>`).join("");
    const voices = (rep.voices || []).map((v) => `<blockquote class="y7-q">${v.pid ? face(v.pid, "lg") : cr(v.team, "lg")}<div><p>“${esc(v.text)}”</p><cite translate="no">${esc(v.who)} · ${esc(v.role || "")}</cite></div></blockquote>`).join("");
    const lu = (k) => (m.lineups[k] || []).map((p) => `<span>${face(p.pid)}<b translate="no">${esc(shortN(p.name))}</b><em>${esc(p.pos)}</em></span>`).join("");
    return `<div class="y7-mr"><div class="y7-mrh"><small>${m.derby ? `<em class="y7-derby">${esc(m.derby)}</em> · ` : ""}Matchday ${m.round} · ${esc(m.venue || "")}</small>
        <div class="y7-mrs"><div>${cr(m.h, "xl")}<b>${esc(nk(m.h))}</b></div><b class="num">${m.hg}<i>-</i>${m.ag}</b><div>${cr(m.a, "xl")}<b>${esc(nk(m.a))}</b></div></div></div>
      <div class="y7-mrb"><div class="y7-mrl">${tl ? `<ul class="y7-tlist">${tl}</ul>` : `<div class="y7-empty">No goals</div>`}${m.motm ? `<div class="y7-motm">${btc({ pid: m.motm.pid, name: m.motm.name, pos: "Man of the match", team: m.motm.team })}</div>` : ""}</div>
        <div class="y7-mrr">${(rep.paras || []).slice(0, 1).map((p) => `<p class="y7-lead">${esc(p)}</p>`).join("")}${(rep.timeline || []).map((p) => `<p class="y7-tl"><b>${esc(p.split(" - ")[0])}</b>${esc(p.slice(p.indexOf(" - ") + 3))}</p>`).join("")}${(rep.paras || []).slice(1).map((p) => `<p>${esc(p)}</p>`).join("")}${voices}
          <div class="y7-lus"><div><b>${esc(nk(m.h))}</b>${lu("h")}</div><div><b>${esc(nk(m.a))}</b>${lu("a")}</div></div></div></div></div>`;
  }

  // ------------------------------------------------------------------ awards ceremony
  function ceremony(step) {
    const aw = Y.d.awards; if (!aw) return;
    Y.modal = { kind: "cer", step }; sound(step ? "ok" : "open"); drawModal();
  }
  function cerHtml(step) {
    const aw = Y.d.awards, b = aw.ballon || [];
    if (step === 0) return `<div class="y7-cer s0"><small>Season ${Y.d.career.season} · Awards night</small><div class="y7-cer-champ">${cr(aw.champion, "xl")}<h2>${esc(nm(aw.champion))}</h2><p>Champions League winners · ${aw.points} points</p></div><button class="y7-btn pri" data-y7cer="1">The Golden Boot ›</button></div>`;
    if (step === 1) { const g = aw.boot[0]; return `<div class="y7-cer"><small>Golden Boot</small><div class="y7-cer-one">${btc({ pid: g.pid, name: g.name, pos: "Golden Boot", team: g.team })}<div><h2 translate="no">${esc(g.name)}</h2><p>${g.n} league goals${aw.boot[1] ? ` · ahead of ${esc(aw.boot[1].name)} (${aw.boot[1].n})` : ""}</p></div></div><button class="y7-btn pri" data-y7cer="2">Ballon d'Or: 3rd place ›</button></div>`; }
    if (step >= 2 && step <= 4) {
      const shown = b.slice(0, 3).map((p, i) => ({ p, i })).filter(({ i }) => i >= 4 - step);
      const pod = [1, 0, 2].map((i) => { const s = shown.find((x) => x.i === i); return `<div class="y7-pod p${i + 1}${s ? " in" : ""}">${s ? btc({ pid: s.p.pid, name: s.p.name, pos: ["1st", "2nd", "3rd"][i], team: s.p.team }) : `<div class="y7-q-card">?</div>`}<span>${s ? `${s.p.g} G · ${s.p.a} A` : ""}</span><i>${i + 1}</i></div>`; }).join("");
      const lbl = ["", "", "And in third place…", "Runner-up…", "The Ballon d'Or goes to…"][step];
      return `<div class="y7-cer"><small>Ballon d'Or 2017</small><h3>${lbl}</h3><div class="y7-podium">${pod}</div>${step < 4 ? `<button class="y7-btn pri" data-y7cer="${step + 1}">${step === 2 ? "2nd place ›" : "And the winner is… ›"}</button>` : `<h2 class="y7-win" translate="no">${esc(b[0].name)}</h2><button class="y7-btn pri" data-y7cer="done">Close</button>`}</div>`;
    }
    return "";
  }

  // ------------------------------------------------------------------ modal host
  function drawModal() {
    const host = $("#y7modal"); if (!host) return;
    const M = Y.modal;
    if (!M) { host.innerHTML = ""; return; }
    let body = "";
    if (M.kind === "play") {
      const n = Y.d.next;
      body = `<div class="y7-dlg y7-play"><b>Matchday ${n.round}: ${esc(nk(n.h))} v ${esc(nk(n.a))}</b><p>Simulate it, or enter the score if you played this match yourself (for example in My League Y17).</p>
        <div class="y7-enter">${cr(n.h, "lg")}<input id="y7hg" type="number" min="0" max="15" inputmode="numeric" placeholder="-"><i>:</i><input id="y7ag" type="number" min="0" max="15" inputmode="numeric" placeholder="-">${cr(n.a, "lg")}</div>
        <div class="y7-acts"><button class="y7-btn ghost" data-y7p="cancel">Cancel</button><button class="y7-btn" data-y7p="enter" ${Y.busy ? "disabled" : ""}>Use my score</button><button class="y7-btn pri" data-y7p="sim" ${Y.busy ? "disabled" : ""}>${Y.busy ? "Playing…" : "Simulate ›"}</button></div></div>`;
    } else if (M.kind === "own") {
      body = `<div class="y7-dlg"><b>Play with your own squad?</b><p>Champions League 2017 matches are played like My League: with the 23 cards of your main team, against the real 2017 club. This also switches the Master League to "My squad" (you can switch back on the Master League menu).</p><div class="y7-acts"><button class="y7-btn ghost" data-y7p="cancel">Cancel</button><button class="y7-btn pri" data-y7p="own-on">Use my squad and play</button></div></div>`;
    } else if (M.kind === "simall") {
      body = `<div class="y7-dlg"><b>Play to the end of the season?</b><p>Every remaining matchday is simulated, your matches too.</p><div class="y7-acts"><button class="y7-btn ghost" data-y7p="cancel">Cancel</button><button class="y7-btn pri" data-y7p="simall" ${Y.busy ? "disabled" : ""}>${Y.busy ? "Playing…" : "Play to the end"}</button></div></div>`;
    } else if (M.kind === "match") {
      body = `<div class="y7-dlg y7-big"><button class="y7-x" data-y7p="cancel">✕</button>${M.load ? `<div class="y7-load"><div class="y7-spin"></div></div>` : matchHtml(M.m)}</div>`;
    } else if (M.kind === "cer") {
      body = `<div class="y7-dlg y7-big y7-cerbox"><button class="y7-x" data-y7p="cer-close">✕</button>${cerHtml(M.step)}</div>`;
    }
    host.innerHTML = `<div class="y7-modal">${body}</div>`;
    const close = () => { Y.modal = null; sound("back"); drawModal(); };
    $$("[data-y7p]", host).forEach((b) => b.onclick = () => {
      const k = b.dataset.y7p;
      if (k === "cancel") return close();
      if (k === "cer-close") { post("/api/rc29/y17/seen", {}); if (Y.d.awards) Y.d.awards.shown = true; return close(); }
      if (k === "sim") return playNext(null);
      if (k === "own-on") { Y.modal = null; drawModal(); return (async () => { const r = await post("/api/rc29/own", { on: true }); if (!r || r.error) { toast((r && r.reason) || "Could not switch the squad"); return; } ownSq = r; y7Play(); })(); }
      if (k === "simall") return simAll();
      if (k === "enter") { const h = $("#y7hg").value, a = $("#y7ag").value; if (h === "" || a === "") { toast("Enter both scores"); return; } return playNext({ hg: +h, ag: +a }); }
    });
    $$("[data-y7cer]", host).forEach((b) => b.onclick = () => { const v = b.dataset.y7cer; if (v === "done") { post("/api/rc29/y17/seen", {}); Y.d.awards.shown = true; Y.modal = null; sound("ok"); drawModal(); return; } ceremony(+v); });
    $(".y7-modal", host).onclick = (e) => { if (e.target.classList.contains("y7-modal") && M.kind !== "cer" && !Y.busy) close(); };
    bind(host);
  }

  // ------------------------------------------------------------------ page events
  function bind(root) {
    $$("[data-y7go]", root).forEach((b) => b.onclick = () => { Y.tab = b.dataset.y7go; sound("cursor"); $$("[data-y7tab]").forEach((x) => x.classList.toggle("on", x.dataset.y7tab === Y.tab)); page(); });
    $$("[data-y7a]", root).forEach((b) => b.onclick = () => (b.dataset.y7a === "play" ? y7Play() : ceremony(0)));
    $$("[data-y7md]", root).forEach((b) => b.onclick = () => { Y.md = +b.dataset.y7md; sound("cursor"); page(); const on = $(".y7-mds .on"); if (on) on.scrollIntoView({ inline: "center", block: "nearest" }); });
    $$("[data-y7mt]", root).forEach((b) => b.onclick = () => { const [r, i] = b.dataset.y7mt.split(":"); sound("open"); openMatch(+r, +i); });
    $$("[data-y7st]", root).forEach((b) => b.onclick = () => { Y.stat = b.dataset.y7st; sound("cursor"); page(); });
    $$("[data-y7cl]", root).forEach((b) => b.onclick = () => { Y.club = +b.dataset.y7cl; sound("cursor"); page(); });
    $$("[data-y7n]", root).forEach((b) => b.onclick = () => {
      Y.art = b.dataset.y7n; sound("cursor");
      if (Y.tab !== "news") { Y.tab = "news"; $$("[data-y7tab]").forEach((x) => x.classList.toggle("on", x.dataset.y7tab === "news")); return page(); }
      $$(".y7-ni").forEach((x) => x.classList.toggle("on", x === b)); const a = $(".y7-nart"); if (a) { a.innerHTML = article(Y.d.news.find((x) => x.id === Y.art)); a.scrollTop = 0; bind(a); }
    });
    if (Y.tab === "fixtures") { const on = $(".y7-mds .on", root); if (on) setTimeout(() => on.scrollIntoView({ inline: "center", block: "nearest" }), 0); }
  }
})();
// ==== RC29.17 Y17 END ====
})();
