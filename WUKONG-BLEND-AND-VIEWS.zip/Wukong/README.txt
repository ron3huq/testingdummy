Wukong Blender preview package.
Includes the existing dense-uniform .blend and eight rendered angles.
These are Blender previews, not Android/GPU screenshots.
No APK overlay files are included in this separate download.
