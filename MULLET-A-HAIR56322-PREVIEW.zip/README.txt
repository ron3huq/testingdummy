Mullet A: original hair from card89136418985302 / native head56322.
Preview only; no Android card target has been assigned.
Retained face/neck vertex positions and the target rig are unchanged. Old hair removed, donor hair fitted uniformly. Incorrect dark mouth material on rear neck polygons restored to original skin. Native face replacement is pending user confirmation of destination card ID.
