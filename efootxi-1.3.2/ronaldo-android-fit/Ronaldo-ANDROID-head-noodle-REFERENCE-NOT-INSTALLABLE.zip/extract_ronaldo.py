from pathlib import Path
import sys,json,re,hashlib,struct
sys.path.insert(0,'/workspace/testingdummy/tools');from make_extra_pak import Toc
r=Path(__file__).parent;t=Toc(str(r/'pc3700_mobile_and.utoc'));out=r/'extracted';out.mkdir(exist_ok=True);report=[]
for name,i in t.files.items():
 if re.search(r'/SK_4522(?:[^0-9]|$)',name):
  b=t.read(i);assert len(b)==t.ol[i][1];(out/Path(name).name).write_bytes(b)
  pos=struct.unpack_from('<I',b,24)[0];end=pos+struct.unpack_from('<I',b,28)[0];names=[]
  while pos<end:
   h=int.from_bytes(b[pos:pos+2],'big');pos+=2;wide=h>>15;n=h&32767
   names.append(b[pos:pos+n*(2 if wide else 1)].decode('utf-16-le' if wide else 'utf8'));pos+=n*(2 if wide else 1)
  paths=[x for x in names if x.startswith('/')];bones=[x for x in names if x.startswith(('sk_','skf_','d_','dsk_','hair_'))]
  report.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'dependencies':paths,'bone_name_candidates':bones,'names':names})
(r/'head-assets.json').write_text(json.dumps(report,indent=2))
for v in report:print(json.dumps({k:x for k,x in v.items() if k!='names'},indent=2))
