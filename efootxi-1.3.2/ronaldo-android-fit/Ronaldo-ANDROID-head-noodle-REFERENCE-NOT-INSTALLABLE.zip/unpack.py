from pathlib import Path
import ctypes as C,ctypes.util,hashlib,json
r=Path(__file__).parent;lib=C.CDLL(ctypes.util.find_library('archive'))
def d(n,a,t):f=getattr(lib,n);f.argtypes=a;f.restype=t;return f
new=d('archive_read_new',[],C.c_void_p);filters=d('archive_read_support_filter_all',[C.c_void_p],C.c_int);formats=d('archive_read_support_format_all',[C.c_void_p],C.c_int);op=d('archive_read_open_filenames',[C.c_void_p,C.POINTER(C.c_char_p),C.c_size_t],C.c_int);nh=d('archive_read_next_header',[C.c_void_p,C.POINTER(C.c_void_p)],C.c_int);pn=d('archive_entry_pathname',[C.c_void_p],C.c_char_p);sz=d('archive_entry_size',[C.c_void_p],C.c_int64);rd=d('archive_read_data',[C.c_void_p,C.c_void_p,C.c_size_t],C.c_ssize_t);fr=d('archive_read_free',[C.c_void_p],C.c_int);err=d('archive_error_string',[C.c_void_p],C.c_char_p)
parts=[str(r/'parts'/f'pc3700_mobile_and.part{i}.rar').encode() for i in range(1,9)]
a=(C.c_char_p*9)(*parts,None);h=new();filters(h);formats(h);assert op(h,a,65536)==0,err(h)
e=C.c_void_p();report=[]
while True:
 rc=nh(h,C.byref(e))
 if rc==1:break
 assert rc==0,err(h)
 name=pn(e).decode().replace('\\','/');size=sz(e);print(name,size,flush=True);assert size<512*1024*1024
 out=r/name;assert out.resolve().is_relative_to(r.resolve());out.parent.mkdir(parents=True,exist_ok=True)
 buf=C.create_string_buffer(1024*1024);digest=hashlib.sha256();total=0
 with out.open('wb') as f:
  while True:
   n=rd(h,buf,len(buf));assert n>=0,err(h)
   if n==0:break
   data=buf.raw[:n];f.write(data);digest.update(data);total+=n
 assert total==size
 report.append({'path':name,'bytes':size,'sha256':digest.hexdigest()})
fr(h);(r/'unpack-validation.json').write_text(json.dumps(report,indent=2));print(report)
