import bpy,bmesh,math,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).parent;bpy.ops.wm.open_mainfile(filepath=str(R/'HULK_AVENGERS_V2.blend'))
cs=[bpy.data.objects['HULK_EYE_'+str(side)].location.copy()for side in [-1,1]]
for name in ['face_high_0_fox_skin_mat','hair_high_0_fox_skin_mat']:
 o=bpy.data.objects[name];bpy.context.view_layer.objects.active=o
 for mod in list(o.modifiers):bpy.ops.object.modifier_apply(modifier=mod.name)
 bm=bmesh.new();bm.from_mesh(o.data);remove=[]
 for f in bm.faces:
  p=f.calc_center_median()
  if any(((p.x-c.x)/.019)**2+((p.z-c.z)/.0057)**2<1 and p.y<c.y+.014 for c in cs):remove.append(f)
 bmesh.ops.delete(bm,geom=remove,context='FACES');bm.to_mesh(o.data);bm.free();print(name,'REMOVED',len(remove))
bpy.ops.wm.save_as_mainfile(filepath=str(R/'HULK_AVENGERS_V2.blend'))
s=bpy.context.scene;s.cycles.samples=24;a=0;s.camera.location=(0,-.72,1.72);s.camera.rotation_euler=(Vector((0,-.07,1.662))-s.camera.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(R/'eye_check.png');bpy.ops.render.render(write_still=True)
