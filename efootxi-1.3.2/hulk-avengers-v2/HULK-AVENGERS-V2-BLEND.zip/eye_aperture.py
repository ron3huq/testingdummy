import bpy,bmesh,math,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).parent;bpy.ops.wm.open_mainfile(filepath=str(R/'HULK_AVENGERS_V2.blend'))
o=bpy.data.objects['HULK_FACE_SCULPT'];bm=bmesh.new();bm.from_mesh(o.data);cs=[bpy.data.objects['HULK_EYE_'+str(s)].location.copy()for s in [-1,1]];remove=[]
for f in bm.faces:
 p=f.calc_center_median()
 for c in cs:
  if ((p.x-c.x)/.018)**2+((p.z-c.z)/.0049)**2<1 and p.y<c.y+.010:
   remove.append(f);break
bmesh.ops.delete(bm,geom=remove,context='FACES');bm.to_mesh(o.data);bm.free();print('EYE_APERTURE_FACES',len(remove));bpy.ops.wm.save_as_mainfile(filepath=str(R/'HULK_AVENGERS_V2.blend'))
s=bpy.context.scene;s.cycles.samples=48;a=0;s.camera.location=(0,-.72,1.72);s.camera.rotation_euler=(Vector((0,-.07,1.662))-s.camera.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(R/'eye_check.png');bpy.ops.render.render(write_still=True)
