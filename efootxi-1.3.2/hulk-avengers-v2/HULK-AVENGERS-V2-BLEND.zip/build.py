import bpy,math,random,json,bmesh
from mathutils import Vector
from pathlib import Path
R=Path(__file__).parent
bpy.ops.wm.open_mainfile(filepath='/workspace/analysis/ronaldo-v2-editfix/Ronaldo_V2_TAB_STABLE.blend')
random.seed(17)
for o in list(bpy.data.objects):
 if o.type!='MESH' or o.name not in ['face_high_0_fox_skin_mat','face_high_2_fox_skin_mat','hair_high_0_fox_skin_mat']:
  bpy.data.objects.remove(o,do_unlink=True)
def ga(x,z,cx,cz,rx,rz):return math.exp(-((x-cx)/rx)**2-((z-cz)/rz)**2)
def deform(v):
 x,y,z=v;z+=.012;ax=abs(x);front=1/(1+math.exp(min(50,(y+.108)*110)))
 jaw=math.exp(-((z-1.601)/.042)**2);cheek=math.exp(-((z-1.681)/.037)**2);neck=1/(1+math.exp((z-1.571)*70))
 # Rounded zygomatic mass and U-shaped jaw, rather than the previous square slab.
 nx=x*(1.22+.20*jaw+.18*cheek+.42*neck)
 nz=1.69+(z-1.69)*.96
 ny=-.075+(y+.075)*(1.05+.10*jaw+.21*neck)
 # Low brow with distinct inner corrugator bulges, deep sockets and heavy upper lids.
 ny-=front*(.016*ga(ax,z,.025,1.736,.030,.016)+.005*ga(x,z,0,1.742,.012,.027))
 nz-=front*(.007*ga(ax,z,.016,1.731,.022,.016)+.002*ga(x,z,-.026,1.73,.026,.017))
 ny+=front*.004*ga(ax,z,.032,1.710,.019,.012)
 # Broad, short nose with bulbous alae; reduce the long pointed human tip.
 nose=ga(x,z,0,1.686,.025,.024)*front
 nx+=math.copysign(.010*ga(ax,z,.013,1.685,.017,.014)*front,x)
 ny+=.009*nose
 nz-=.004*ga(x,z,0,1.701,.018,.027)*front
 # Cheek and muzzle weight, nasolabial pads, broad lips and rounded lower chin.
 ny-=front*(.008*ga(ax,z,.050,1.689,.025,.029)+.008*ga(x,z,0,1.661,.045,.018)+.005*ga(x,z,0,1.600,.047,.025))
 nx+=x*.22*ga(x,z,0,1.657,.040,.020)*front
 # Slightly open, downturned snarl. Mouth rim vertices move with each lip.
 mouth=math.exp(-(x/.031)**6)*math.exp(-((z-1.654)/.017)**4)*front
 nz+=(.0010 if z>=1.651 else -.0018)*mouth
 nz-=.003*ga(ax,z,.030,1.653,.017,.018)*front
 ny-=.003*ga(x,z,0,1.661,.035,.009)*front
 return Vector((nx,ny,nz-.012))
# Colourise packed diffuse in linear space, preserving source pores / brows / lip variation.
skin=bpy.data.materials.new('HULK olive green skin with micro pores');skin.use_nodes=True
n=skin.node_tree.nodes;l=skin.node_tree.links;bs=n.get('Principled BSDF');bs.inputs['Roughness'].default_value=.66;bs.inputs['Subsurface Weight'].default_value=.035;bs.inputs['Specular IOR Level'].default_value=.25
src=next(n.image for n in bpy.data.objects['face_high_2_fox_skin_mat'].data.materials[0].node_tree.nodes if n.type=='TEX_IMAGE' and n.image and 'warm' in n.image.name)
import numpy as np
pix=np.array(src.pixels[:],dtype=np.float32).reshape(-1,4);lum=pix[:,:3]@np.array([.3,.59,.11]);pix[:,:3]=lum[:,None]*np.array([.67,.70,.47])[None,:]
im=bpy.data.images.new('Hulk_skin_PACKED',width=src.size[0],height=src.size[1]);im.pixels.foreach_set(pix.ravel());im.pack();tex=n.new('ShaderNodeTexImage');tex.image=im;variation=n.new('ShaderNodeTexNoise');variation.inputs['Scale'].default_value=65;variation.inputs['Detail'].default_value=4
ramp=n.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].color=(.40,.39,.30,1);ramp.color_ramp.elements[1].color=(1,.97,.88,1);l.new(variation.outputs['Fac'],ramp.inputs[0])
mix=n.new('ShaderNodeMixRGB');mix.blend_type='MULTIPLY';mix.inputs[0].default_value=.45;l.new(tex.outputs['Color'],mix.inputs[1]);l.new(ramp.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],bs.inputs['Base Color'])
noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=1800;noise.inputs['Detail'].default_value=3
bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.32;bump.inputs['Distance'].default_value=.00022;l.new(noise.outputs['Fac'],bump.inputs['Height']);l.new(bump.outputs['Normal'],bs.inputs['Normal'])
skins=[]
for o in list(bpy.data.objects):
 if o.type!='MESH':continue
 for v in o.data.vertices:v.co=deform(v.co)
 o.data.materials.clear();o.data.materials.append(skin)
 for p in o.data.polygons:p.use_smooth=True;p.material_index=0
 o.data.normals_split_custom_set_from_vertices([Vector((0,0,0)) for v in o.data.vertices])
 for mod in list(o.modifiers):o.modifiers.remove(mod)
 mod=o.modifiers.new('Sculpt surface refinement','SUBSURF');mod.levels=2;mod.render_levels=2
 skins.append(o)
face=bpy.data.objects['face_high_2_fox_skin_mat'];face.name='HULK_FACE_SCULPT'
# Sculpt forehead furrows into a dense editable mesh.
bpy.context.view_layer.objects.active=face;face.select_set(True);bpy.ops.object.modifier_apply(modifier=face.modifiers[0].name)
# Carve irregular forehead, eye-corner and nasolabial creases into the subdivided surface.
for v in face.data.vertices:
 x,y,z=v.co;ax=abs(x)
 front=1/(1+math.exp(min(50,(y+.13)*150)))
 # Deep branching vertical frown folds; shallower curved forehead furrows.
 depth=0.
 for side in [-1,1]:
  for k in range(2):
   path=side*(.0055+k*.010+(z-1.737)*(.14+.07*k)+.0014*math.sin((z-1.73)*230+k))
   depth+=.0015*math.exp(-((x-path)/.0013)**2)*math.exp(-((z-1.750)/.022)**4)
 for k in range(2):
  path=1.767+k*.009+.005*(x/.075)**2+.0015*math.sin(x*90+k)
  depth+=.0007*math.exp(-((z-path)/.0011)**2)*math.exp(-(x/.072)**6)
 # Sweeping nasolabial folds lead from alae toward the mouth corners.
 path=.022+max(0,1.688-z)*.95
 depth+=.0015*math.exp(-((ax-path)/.0020)**2)*math.exp(-((z-1.671)/.023)**4)
 # Eye corner creases fan outward rather than straight parallel cuts.
 for k in [-1,0,1]:
  path=1.708+k*.003+(ax-.048)*(-.25+k*.30)
  depth+=.0008*math.exp(-((z-path)/.0010)**2)*math.exp(-((ax-.058)/.014)**4)
 v.co.y+=depth*front
def mat(name,color,rough=.5):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*color,1);b.inputs['Roughness'].default_value=rough;return m
# Short irregular curls in overlapping clumps: swept tubes, not upright hair cards.
hairmat=mat('Avengers dark brown hair',(.0025,.0016,.0011),.8)
hairmat.node_tree.nodes.get('Principled BSDF').inputs['Specular IOR Level'].default_value=.03
scalp=bpy.data.objects['hair_high_0_fox_skin_mat'];deps=bpy.context.evaluated_depsgraph_get();ev=scalp.evaluated_get(deps);em=ev.to_mesh();em.calc_loop_triangles()
triangles=[];areas=[];capvs=[];capfs=[]
for tri in em.loop_triangles:
 coords=[em.vertices[i].co.copy()for i in tri.vertices];c=sum(coords,Vector())/3
 frontness=1/(1+math.exp((c.y+.09)*90))
 hairline=1.688+.070*frontness
 hairline-=.008*math.exp(-(c.x/.023)**2)*frontness
 hairline+=.002*math.sin(c.x*170+c.y*75)
 if c.z<hairline:continue
 normal=tri.normal.copy();triangles.append((coords,normal));areas.append(tri.area)
 off=len(capvs);capvs.extend([p+normal*.0008 for p in coords]);capfs.append((off,off+1,off+2))
cap=bpy.data.meshes.new('Continuous dark hair roots');cap.from_pydata(capvs,[],capfs);cap.materials.append(hairmat);capob=bpy.data.objects.new('HULK_HAIR_ROOTS',cap);bpy.context.collection.objects.link(capob)
for p in cap.polygons:p.use_smooth=True
vs=[];fs=[]
for coords,normal in random.choices(triangles,weights=areas,k=1600):
 a=random.random();b=random.random()
 if a+b>1:a=1-a;b=1-b
 root=coords[0]*(1-a-b)+coords[1]*a+coords[2]*b
 top=max(0,min(1,(root.z-1.73)/.055));length=random.uniform(.010,.019)+top*random.uniform(.009,.020)
 tangent=normal.cross(Vector((0,0,1)))
 if tangent.length<.1:tangent=Vector((1,0,0))
 tangent.normalize();bit=normal.cross(tangent).normalized()
 sweep=(Vector((random.uniform(-.8,.8),random.uniform(-.8,.8),.05))*.8+bit*.3)
 phase=random.uniform(0,math.tau);curl=random.uniform(.002,.005)
 for strand in range(8):
  p=root+tangent*random.uniform(-.0025,.0025)+bit*random.uniform(-.0025,.0025)
  width=random.uniform(.00022,.00040);ll=length*random.uniform(.75,1.15);off=len(vs)
  for j in range(8):
   t=j/7;center=p+normal*ll*(t-.40*t*t)+sweep*ll*t*t+tangent*curl*(math.sin(phase+t*4.5)-math.sin(phase))*t+bit*curl*math.sin(t*4)*t
   radius=width*(1-t)**.65+.000015
   frontlock=1/(1+math.exp((root.y+.122)*200));center+=Vector((0,-.010,-.018))*frontlock*t*t*math.exp(-(root.x/.068)**4)
   for k in range(4):vs.append(center+radius*(tangent*math.cos(k*math.tau/4)+bit*math.sin(k*math.tau/4)))
   if j:
    for k in range(4):fs.append((off+(j-1)*4+k,off+(j-1)*4+(k+1)%4,off+j*4+(k+1)%4,off+j*4+k))
me=bpy.data.meshes.new('Curled overlapping individual hair fibres');me.from_pydata(vs,[],fs);me.materials.append(hairmat);ob=bpy.data.objects.new('HULK_SHORT_CURLS',me);bpy.context.collection.objects.link(ob)
for p in me.polygons:p.use_smooth=True
ev.to_mesh_clear()
def sphere(name,loc,scale,ma):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=40,ring_count=24,location=loc);o=bpy.context.object;o.name=name;o.scale=scale;o.data.materials.append(ma)
 for p in o.data.polygons:p.use_smooth=True
 return o
white=mat('Warm sclera',(.32,.30,.22),.28);iris=mat('Hazel green iris',(.075,.085,.019),.25);pupil=mat('Pupil',(.001,.002,.001),.2)
for side in [-1,1]:
 c=deform((side*.029,-.1400,1.7020));sphere('HULK_EYE_'+str(side),c,(.018,.012,.010),white)
 sphere('IRIS_'+str(side),c+Vector((0,-.0118,0)),(.0064,.0013,.0064),iris)
 sphere('PUPIL_'+str(side),c+Vector((0,-.0130,0)),(.0026,.0005,.0034),pupil)
# Close small source holes at the neck and scalp, retaining a bust base.
for o in skins:
 if o==face:continue
 bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.00012);bmesh.ops.holes_fill(bm,edges=[e for e in bm.edges if e.is_boundary],sides=20);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free()
 for p in o.data.polygons:p.use_smooth=True
# Shorten the neck continuously, carrying all head parts together.
for o in bpy.data.objects:
 if o.type!='MESH':continue
 matrix=o.matrix_world.copy();inv=matrix.inverted()
 for v in o.data.vertices:
  p=matrix@v.co;t=max(0,min(1,(p.z-1.43)/.14));p.z-=.025*t*t*(3-2*t);v.co=inv@p
# Presentation scene.
s=bpy.context.scene;s.world.color=(.045,.045,.045)
for o in bpy.context.selected_objects:o.select_set(False)
bpy.ops.object.camera_add();cam=bpy.context.object;cam.name='Portrait camera';s.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=.39
for name,loc,power,size,col in [('Key',(-.35,-.50,2.10),20,.45,(1,.94,.84)),('Fill',(.4,-.25,1.8),7,.45,(.8,.87,1)),('Rim',(.2,.2,1.95),16,.35,(.85,.94,1))]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.data.color=col;o.rotation_euler=(Vector((0,-.07,1.65))-o.location).to_track_quat('-Z','Y').to_euler()
s.render.engine='CYCLES';s.cycles.samples=48;s.cycles.use_denoising=False;s.render.resolution_x=800;s.render.resolution_y=900;s.render.resolution_percentage=100
s.view_settings.view_transform='AgX';s['asset_status']='Hulk sculpt study; not FaceBuilder; not game converted or tested';s['reference']='User Hulk front three-quarter stills'
for area in bpy.context.screen.areas:
 if area.type=='VIEW_3D':area.spaces.active.shading.type='MATERIAL';area.spaces.active.overlay.show_extras=False
for name,angle in [('front',0),('three_quarter',35),('profile',90),('back',180)]:
 a=math.radians(angle);cam.location=(.65*math.sin(a),-.07-.65*math.cos(a),1.72);cam.rotation_euler=(Vector((0,-.07,1.662))-cam.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(R/(name+'.png'))
 if name=='three_quarter':bpy.ops.wm.save_as_mainfile(filepath=str(R/'HULK_AVENGERS_V2.blend'))
 bpy.ops.render.render(write_still=True)
(R/'validation.json').write_text(json.dumps({'facebuilder_used':False,'game_tested':False,'packed_skin':im.packed_file is not None,'hair_triangles':len(fs),'face_vertices':len(face.data.vertices),'eyes':2,'ronaldo_original_modified':False},indent=2))
