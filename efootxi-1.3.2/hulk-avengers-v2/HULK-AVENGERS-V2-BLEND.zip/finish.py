import bpy,math,numpy as np
from pathlib import Path
from mathutils import Vector
R=Path(__file__).parent;bpy.ops.wm.open_mainfile(filepath=str(R/'HULK_AVENGERS_V2.blend'))
centers={}
for side in [-1,1]:
 o=bpy.data.objects['HULK_EYE_'+str(side)];centers[side]=sum([o.matrix_world@v.co for v in o.data.vertices],Vector())/len(o.data.vertices)
for o in list(bpy.data.objects):
 if o.name.startswith(('HULK_EYE_','IRIS_','PUPIL_')):bpy.data.objects.remove(o,do_unlink=True)
def mat(name,c,rough):
 m=bpy.data.materials.new(name);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*c,1);b.inputs['Roughness'].default_value=rough;return m
sclera=mat('Sclera muted ivory',(.31,.30,.23),.27);iris=mat('Radial hazel iris',(.085,.071,.028),.28);pupil=mat('Pupil integrated on globe',(.001,.001,.0005),.2)
n=iris.node_tree.nodes;l=iris.node_tree.links;no=n.new('ShaderNodeTexNoise');no.inputs['Scale'].default_value=32;ra=n.new('ShaderNodeValToRGB');ra.color_ramp.elements[0].color=(.025,.018,.007,1);ra.color_ramp.elements[1].color=(.16,.15,.055,1);l.new(no.outputs['Fac'],ra.inputs[0]);l.new(ra.outputs[0],n.get('Principled BSDF').inputs['Base Color'])
for side,c in centers.items():
 c.y+=.0012;bpy.ops.mesh.primitive_uv_sphere_add(segments=96,ring_count=64,location=c);o=bpy.context.object;o.name='HULK_EYE_'+str(side);o.scale=(.018,.012,.010)
 for m in [sclera,iris,pupil]:o.data.materials.append(m)
 for p in o.data.polygons:
  center=sum([o.data.vertices[i].co for i in p.vertices],Vector())/len(p.vertices);radius=math.hypot(center.x*.018,center.z*.010);p.material_index=2 if center.y<0 and radius<.0023 else 1 if center.y<0 and radius<.0054 else 0;p.use_smooth=True
# Slightly greener muted olive rather than the pale khaki of the first test.
im=bpy.data.images['Hulk_skin_PACKED'];px=np.array(im.pixels[:],dtype=np.float32).reshape(-1,4);px[:,:3]*=np.array([.925,1.029,.94]);im.pixels.foreach_set(px.ravel());im.pack()
face=bpy.data.objects['HULK_FACE_SCULPT']
for v in face.data.vertices:
 x,y,z=v.co
 if y<-.15:v.co.y-=.0025*math.exp(-(x/.018)**2-((z-1.652)/.010)**2)
# Viewer opens on the three-quarter portrait, with packed textures.
s=bpy.context.scene;s.cycles.use_denoising=False
for name,ang in [('front',0),('three_quarter',35),('profile',90),('back',180)]:
 a=math.radians(ang);s.camera.location=(.65*math.sin(a),-.07-.65*math.cos(a),1.72);s.camera.rotation_euler=(Vector((0,-.07,1.662))-s.camera.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(R/(name+'.png'));s.cycles.samples=128 if name=='three_quarter' else 64
 if name=='three_quarter':bpy.ops.wm.save_as_mainfile(filepath=str(R/'HULK_AVENGERS_V2.blend'))
 bpy.ops.render.render(write_still=True)
