import bpy,math,json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
r=Path(__file__).parent;bpy.ops.wm.open_mainfile(filepath=str(r/'SpiderMan_v5_STRAIGHT_NECK.blend'));o=bpy.data.objects['RECONSTRUCTED_REAR_NECK_PATCH'];b=BVHTree.FromObject(o,bpy.context.evaluated_depsgraph_get());checks=[]
for z in [1.47,1.49,1.51,1.53,1.55,1.57,1.59]:
 for a in [math.pi/2,math.pi,3*math.pi/2]:
  d=Vector((math.sin(a),-math.cos(a),0));p,n,i,dist=b.ray_cast(Vector((0,-.052,z)),d);assert p is not None,(z,a);checks.append([z,a])
assert bpy.context.scene['neck_shortening_mm']==20
verts=o.data.vertices;back=[max(verts[i*65+j].co.y for j in range(65))for i in range(49)];assert all(b<=a+.00001 for a,b in zip(back,back[1:])), 'Posterior bulge regression'
(r/'neck-validation.json').write_text(json.dumps({'rear_and_side_horizontal_rays_hit':len(checks),'neck_shortening_mm':20,'neck_reconstructed':True,'facebuilder_used':False,'game_tested':False},indent=2));print('NECK_SURFACE_PASS',len(checks))
