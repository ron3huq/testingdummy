import bpy,math,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).parent;bpy.ops.wm.open_mainfile(filepath='/workspace/analysis/ronaldo-2017-refine-v2/Ronaldo_2017_FACE_NECK_v2.blend')
c=bpy.data.objects['00_EDIT_CONTROLS'];c['Neck_shortening_mm']=7.;c['Adam_apple_mm']=3.5;bpy.context.scene.frame_set(1)
# Slight additional darkening across the unified image, including the whole neck.
im=next(i for i in bpy.data.images if i.name.startswith('face_neck_warm_dark'));px=list(im.pixels[:])
for k in range(0,len(px),4):
 for j in range(3):px[k+j]*=.97
new=bpy.data.images.new('UNIFIED_SKIN_V3_DARKER',im.size[0],im.size[1],alpha=True);new.pixels[:]=px;new.pack()
for m in bpy.data.materials:
 if m.use_nodes:
  for n in m.node_tree.nodes:
   if n.type=='TEX_IMAGE'and n.image==im:n.image=new
# Adjustable concentrated/furrowed expression requested from the new reference.
c['Intense_expression']=.8;c.id_properties_ui('Intense_expression').update(min=0.,max=1.,description='0 neutral structure; 1 concentrated brow/eyes; game animation not overridden')
for ob in bpy.data.objects:
 if ob.type!='MESH'or not ob.data.shape_keys or not ob.name.startswith('face_high_'):continue
 key=ob.shape_key_add(name='INTENSE_FOCUSED_EXPRESSION')
 for v,base in zip(key.data,ob.data.shape_keys.key_blocks['Basis'].data):
  x,y,z=base.co;front=1/(1+math.exp((y+.12)*180));brow=math.exp(-((abs(x)-.017)/.018)**2-((z-1.737)/.012)**2)*front
  upper=math.exp(-((abs(x)-.028)/.015)**2-((z-1.723)/.004)**2)*front
  lower=math.exp(-((abs(x)-.028)/.015)**2-((z-1.712)/.0035)**2)*front
  v.co.z+=-.0014*brow-.0007*upper+.00025*lower;v.co.y-=.0007*brow
 dr=key.driver_add('value').driver;dr.expression='a';vv=dr.variables.new();vv.name='a';vv.type='SINGLE_PROP';vv.targets[0].id=c;vv.targets[0].data_path='["Intense_expression"]'
bpy.context.scene.frame_set(1)
for ob in bpy.data.objects:
 if ob.type!='MESH'or not ob.data.shape_keys or ob.name not in ['face_high_0_fox_skin_mat','face_high_2_fox_skin_mat']:continue
 key=ob.shape_key_add(name='DEFINED_LARYNGEAL_RIDGE')
 for v,base in zip(key.data,ob.data.shape_keys.key_blocks['Basis'].data):
  x,y,z=base.co;v.co.y-=.0010*math.exp(-(x/.012)**2-((z-1.543)/.012)**2)/(1+math.exp((y+.065)*180))
 key.value=1.
s=bpy.context.scene;s['revision']='v2_BASE_ONLY_focus_darker_defined_larynx';s.cycles.samples=20;cam=s.camera
report={'eyes_added':0,'base':'exact v2, no v3 eyeballs or v3 neck settings','neck_total_shortening_mm':7,'adam_apple_mm':3.5,'extra_skin_rgb_scale':.97,'phone_tested':False,'native_eye_motion_verified':False,'lip_candidate':'same local upper-lip weight edits as v2; device unverified','intense_expression_default':.8,'in_game_expression_lock':False}
for name,a in [('front',0),('three_quarter',35),('profile',90),('back_neck',145)]:
 a=math.radians(a);cam.location=(.65*math.sin(a),-.075-.65*math.cos(a),1.735);cam.rotation_euler=(Vector((0,-.075,1.68))-cam.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(R/(name+'.png'))
 if name=='front':bpy.ops.wm.save_as_mainfile(filepath=str(R/'Ronaldo_V2_BASE_FOCUS_LARYNX.blend'))
 bpy.ops.render.render(write_still=True)
(R/'validation.json').write_text(json.dumps(report,indent=2))
