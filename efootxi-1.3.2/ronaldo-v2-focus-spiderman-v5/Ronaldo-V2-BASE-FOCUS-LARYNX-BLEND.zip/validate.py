import bpy,json,math
from pathlib import Path
R=Path(__file__).parent;bpy.ops.wm.open_mainfile(filepath=str(R/'Ronaldo_V2_BASE_FOCUS_LARYNX.blend'));new={o.name:o for o in bpy.data.objects if o.type=='MESH'};assert len(new)==10 and not any('RESTORED_EYE' in n for n in new)
with bpy.data.libraries.load('/workspace/analysis/ronaldo-2017-refine-v2/Ronaldo_2017_FACE_NECK_v2.blend',link=False)as(a,b):b.objects=[n for n in a.objects if n in new]
checks=[]
for old in b.objects:
 o=new[old.name.rsplit('.',1)[0]];assert [tuple(p.vertices)for p in old.data.polygons]==[tuple(p.vertices)for p in o.data.polygons]
 for aa,bb in zip(old.data.uv_layers,o.data.uv_layers):assert all((x.uv-y.uv).length<1e-8 for x,y in zip(aa.data,bb.data))
 def w(ob):return [{ob.vertex_groups[g.group].name:g.weight for g in v.groups}for v in ob.data.vertices]
 assert w(old)==w(o);assert all((aa.co-bb.co).length<1e-8 for aa,bb in zip(old.data.shape_keys.key_blocks['Basis'].data,o.data.shape_keys.key_blocks['Basis'].data));checks.append(o.name);bpy.data.objects.remove(old,do_unlink=True)
c=bpy.data.objects['00_EDIT_CONTROLS'];c.id_properties_ui('Adam_apple_mm').update(min=0.,max=5.);assert c['Neck_shortening_mm']==7
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Ronaldo_V2_BASE_FOCUS_LARYNX.blend'))
r=json.loads((R/'validation.json').read_text());r['verified_exact_v2_basis_topology_uv_weights']=checks;r['no_v3_eye_meshes']=True;r['original_v2_neck_setting_preserved']=True;(R/'validation.json').write_text(json.dumps(r,indent=2));print('EXACT_V2_BASE_PASS',len(checks))
