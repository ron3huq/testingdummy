import bpy,bmesh,math
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=Path(__file__).parent;bpy.ops.wm.open_mainfile(filepath=str(R/'Ronaldo_V2_BASE_FOCUS_LARYNX.blend'));skins=[bpy.data.objects[n]for n in ['face_high_0_fox_skin_mat','face_high_2_fox_skin_mat','hair_high_0_fox_skin_mat']];bpy.context.scene.frame_set(1)
mesh0=bpy.data.objects['face_high_0_fox_skin_mat'];mesh2=bpy.data.objects['face_high_2_fox_skin_mat']
cloud=[];faces=[]
for o in skins:
 ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh();off=len(cloud);cloud.extend(v.co.copy()for v in m.vertices);faces.extend([off+i for i in p.vertices]for p in m.polygons);ev.to_mesh_clear()
me=bpy.data.meshes.new('TEMP_normal_reference');me.from_pydata(cloud,[],faces);bm=bmesh.new();bm.from_mesh(me);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.00025);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.normal_update();bm.to_mesh(me);bm.free();me.calc_loop_triangles();bv=BVHTree.FromPolygons([v.co for v in me.vertices],[p.vertices for p in me.polygons]);
# Nearest reference surface normal shared by overlapping sections; blend at boundaries.
for o in skins:
 ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());em=ev.to_mesh();normals=[]
 for v in em.vertices:
  p,n,i,d=bv.find_nearest(v.co)
  # Use smoothed reference vertex normals instead of flat polygon normal.
  poly=me.polygons[i];near=sorted(poly.vertices,key=lambda j:(me.vertices[j].co-p).length)[:3];nn=Vector((0,0,0));total=0
  for j in near:
   w=1/max(.00005,(me.vertices[j].co-p).length);nn+=me.vertices[j].normal*w;total+=w
  nn.normalize();normals.append(nn)
 ev.to_mesh_clear();o.data.normals_split_custom_set_from_vertices(normals)
bpy.data.meshes.remove(me)

bpy.ops.wm.save_as_mainfile(filepath=str(R/'Ronaldo_V2_BASE_FOCUS_LARYNX.blend'))
s=bpy.context.scene;cam=s.camera;a=math.radians(50);cam.location=(.5*math.sin(a),-.075-.5*math.cos(a),1.61);cam.rotation_euler=(Vector((0,-.085,1.565))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=.19;s.render.filepath=str(R/'neck_detail.png');s.cycles.samples=24;bpy.ops.render.render(write_still=True)
