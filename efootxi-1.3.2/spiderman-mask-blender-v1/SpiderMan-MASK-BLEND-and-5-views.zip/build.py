import bpy, math, os
from mathutils import Vector
from pathlib import Path
R=Path(__file__).parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def mat(name,color,rough=.5,metal=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal;return m
red=mat('Crimson woven mask',(.22,.003,.008),.7);black=mat('Raised charcoal rubber',(.009,.012,.015),.32);white=mat('Silver white optical lenses',(.65,.73,.76),.3,.28)
for m,scale,strength in [(red,1900,.18),(white,3500,.1)]:
 n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF');tex=n.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=scale;tex.inputs['Detail'].default_value=2;b=n.new('ShaderNodeBump');b.inputs['Strength'].default_value=strength;b.inputs['Distance'].default_value=.00025;l.new(tex.outputs['Fac'],b.inputs['Height']);l.new(b.outputs['Normal'],p.inputs['Normal'])
# Cross sections in metres: neck, jaw, cheekbones, forehead and crown.
profiles=[(0,.048,.045),(.055,.047,.046),(.09,.051,.049),(.112,.047,.054),(.13,.057,.067),(.16,.071,.077),(.195,.082,.080),(.235,.085,.081),(.27,.083,.080),(.3,.073,.073),(.325,.055,.057),(.34,.028,.032),(.345,.001,.001)]
def radii(z):
 for i in range(len(profiles)-1):
  a,b=profiles[i:i+2]
  if z<=b[0]:
   t=max(0,(z-a[0])/(b[0]-a[0]));pr=profiles[max(0,i-1)];nx=profiles[min(len(profiles)-1,i+2)]
   def interp(j):
    m0=(b[j]-pr[j])/(b[0]-pr[0])*(b[0]-a[0]);m1=(nx[j]-a[j])/(nx[0]-a[0])*(b[0]-a[0]);return (2*t**3-3*t*t+1)*a[j]+(t**3-2*t*t+t)*m0+(-2*t**3+3*t*t)*b[j]+(t**3-t*t)*m1
   return interp(1),interp(2)
 return .001,.001
# Covered nose and brow are sculpted into a continuous mask, with no lips/nose holes.
def point(a,z,offset=0):
 rx,ry=radii(z);x=rx*math.sin(a);c=math.cos(a);y=-ry*c
 if c>0:
  nose=.009*math.exp(-(x/.017)**2-((z-.205)/.024)**2)
  brow=.002*math.exp(-((abs(x)-.038)/.027)**2-((z-.252)/.017)**2)
  y-=(nose+brow)*c**4
 return (x+offset*math.sin(a),y-offset*c,z)
def front(x,z,offset=0):
 rx,_=radii(z);a=math.asin(max(-.998,min(.998,x/rx)));return point(a,z,offset)
def mesh(name,verts,faces,material):
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();ob=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(ob);me.materials.append(material)
 for p in me.polygons:p.use_smooth=True
 return ob
N=128;M=160;verts=[point(2*math.pi*j/N,.345*i/M)for i in range(M+1)for j in range(N)];faces=[(i*N+j,i*N+(j+1)%N,(i+1)*N+(j+1)%N,(i+1)*N+j)for i in range(M)for j in range(N)];head=mesh('MASK_continuous_closed_face_no_human_skin',verts,faces,red)
# Eye silhouettes are independent curved 3D optical assemblies.
def bez(p0,p1,p2,p3,t):return tuple((1-t)**3*p0[i]+3*(1-t)**2*t*p1[i]+3*(1-t)*t*t*p2[i]+t**3*p3[i] for i in range(2))
p0=(.009,.224);p1=(.077,.263)
outline=[bez(p0,(.031,.252),(.063,.252),p1,i/48)for i in range(48)]+[bez(p1,(.077,.215),(.046,.184),p0,i/48)for i in range(48)]
for side in [-1,1]:
 center=(.043,.229);v=[front(side*center[0],center[1],.0052)];rings=12;L=len(outline)
 for k in range(1,rings+1):
  t=k/rings
  for x,z in outline:v.append(front(side*(center[0]+(x-center[0])*t),center[1]+(z-center[1])*t,.0037+.0015*(1-t*t)))
 f=[(0,1+j,1+(j+1)%L)for j in range(L)]
 for k in range(rings-1):
  a=1+k*L;b=a+L;f.extend((a+j,b+j,b+(j+1)%L,a+(j+1)%L)for j in range(L))
 lens=mesh(('L'if side<0 else'R')+'_convex_white_lens',v,f,white)
 # Wide frame ring, rather than a painted eye on skin.
 v=[]
 for scale,dep in [(1.15,.003),(1,.005)]:
  for x,z in outline:v.append(front(side*(center[0]+(x-center[0])*scale),center[1]+(z-center[1])*scale,dep))
 frame=mesh(('L'if side<0 else'R')+'_thick_black_eye_frame',v,[(j,(j+1)%L,L+(j+1)%L,L+j)for j in range(L)],black)
 sol=frame.modifiers.new('Rubber frame thickness','SOLIDIFY');sol.thickness=.001
# Actual raised web curves, not a bitmap over a human face.
def curve(name,pts,width=.00052):
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.bevel_depth=width;cu.bevel_resolution=2;s=cu.splines.new('POLY');s.points.add(len(pts)-1)
 for p,co in zip(s.points,pts):p.co=(*co,1)
 ob=bpy.data.objects.new(name,cu);bpy.context.collection.objects.link(ob);cu.materials.append(black)
# Radial face web centred on bridge of the nose; cropped to the mask silhouette.
zc=.225
for j in range(20):
 ang=2*math.pi*j/20;pts=[]
 for k in range(1,160):
  r=.0016*k;x=math.sin(ang)*r;z=zc+math.cos(ang)*r
  if z<.004 or z>.341:break
  rx,_=radii(z)
  if abs(x)>.98*rx:break
  pts.append(front(x,z,.00065))
 if len(pts)>1:curve('Web_radial_%02d'%j,pts)
for k in range(1,12):
 pts=[]
 for j in range(401):
  a=2*math.pi*j/400;r=.018*k*(1-.018*math.sin(10*a)**2);x=math.sin(a)*r;z=zc+math.cos(a)*r
  valid=.004<z<.341 and abs(x)<.98*radii(z)[0]
  if valid:pts.append(front(x,z,.0007))
  elif len(pts)>1:curve('Web_face_arc',pts);pts=[]
  else:pts=[]
 if len(pts)>1:curve('Web_face_arc',pts)
for j in range(11):
 a=math.pi/2+j*math.pi/10;curve('Web_rear_vertical',[point(a,.006+i*.332/120,.00065)for i in range(121)])
for z in [.025,.05,.078,.105,.135,.17,.205,.24,.275,.305,.325]:curve('Web_rear_ring',[point(math.pi/2+i*math.pi/100,z+.0015*math.cos(i*math.pi/10),.0007)for i in range(101)])
# Neutral studio presentation.
floor=mat('Studio',(.035,.045,.06),.8)
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.002));bpy.context.object.data.materials.append(floor);bpy.context.object.name='STUDIO_floor'
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=40;scene.cycles.use_denoising=False;scene.render.resolution_x=760;scene.render.resolution_y=900;scene.render.resolution_percentage=100;scene.world.color=(.15,.15,.15)
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
for name,loc,power,size in [('Key',(-.4,-.5,.6),25,.5),('Fill',(.4,-.35,.3),12,.4),('Rim',(.2,.35,.5),32,.35)]:
 d=bpy.data.lights.new(name,'AREA');d.energy=power*.15;d.shape='DISK';d.size=size;o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);o.location=loc;aim(o,(0,0,.2))
d=bpy.data.cameras.new('Inspection_camera');cam=bpy.data.objects.new('Inspection_camera',d);scene.collection.objects.link(cam);scene.camera=cam;d.type='ORTHO';d.ortho_scale=.40
scene['status']='BLENDER_DESIGN_PROTOTYPE_NOT_ANDROID_COOKED_OR_DEVICE_VERIFIED';scene['reference']='User supplied two Spider-Man references; prioritise second image. Original procedural approximation, not an extracted film asset.'
for area in bpy.context.screen.areas:
 if area.type=='VIEW_3D':area.spaces.active.region_3d.view_location=(0,0,.18);area.spaces.active.region_3d.view_distance=.55
for name,angle in [('front',0),('three_quarter',40),('left',90),('right',-90),('back',180)]:
 a=math.radians(angle);cam.location=(.8*math.sin(a),-.8*math.cos(a),.22);aim(cam,(0,0,.18));scene.render.filepath=str(R/(name+'.png'))
 if name=='front':bpy.ops.wm.save_as_mainfile(filepath=str(R/'SpiderMan_MASK_EDIT.blend'))
 bpy.ops.render.render(write_still=True)
print('DONE')
