import bpy,json,math
from pathlib import Path
r=Path(__file__).parent
bpy.ops.wm.open_mainfile(filepath=str(r/'SpiderMan_MASK_EDIT.blend'))
meshes=[o for o in bpy.data.objects if o.type=='MESH' and not o.name.startswith('STUDIO')]
assert all(all(math.isfinite(c)for v in o.data.vertices for c in v.co)for o in meshes)
assert all(len(o.data.vertices)>0 and len(o.data.polygons)>0 for o in meshes)
assert len([o for o in meshes if 'lens' in o.name])==2
assert len([o for o in meshes if 'frame' in o.name])==2
report={'status':'BLENDER_4_3_2_OPEN_AND_GEOMETRY_CHECK_PASS','meshes':{o.name:{'vertices':len(o.data.vertices),'polygons':len(o.data.polygons)}for o in meshes},'web_curve_objects':len([o for o in bpy.data.objects if o.type=='CURVE']),'external_textures_required':False,'film_exact_likeness_verified':False,'android_cooked':False,'android_device_tested':False,'rigged_to_game':False}
(r/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
