import bpy,math,json
from pathlib import Path
from mathutils import Vector
R=Path(__file__).parent;bpy.ops.wm.open_mainfile(filepath='/workspace/analysis/ronaldo-2017-refine-v2/Ronaldo_2017_FACE_NECK_v2.blend')
c=bpy.data.objects['00_EDIT_CONTROLS'];c['Neck_shortening_mm']=8.;c['Adam_apple_mm']=2.;bpy.context.scene.frame_set(1)
# Slight additional darkening across the unified image, including the whole neck.
im=next(i for i in bpy.data.images if i.name.startswith('face_neck_warm_dark'));px=list(im.pixels[:])
for k in range(0,len(px),4):
 for j in range(3):px[k+j]*=.97
new=bpy.data.images.new('UNIFIED_SKIN_V3_DARKER',im.size[0],im.size[1],alpha=True);new.pixels[:]=px;new.pack()
for m in bpy.data.materials:
 if m.use_nodes:
  for n in m.node_tree.nodes:
   if n.type=='TEX_IMAGE'and n.image==im:n.image=new
# The source archive lacks common eyeball geometry. Add explicit separate globes.
# Eye material uses the supplied PC common eye image, with a warm iris tint only.
eyeim=bpy.data.images.load(str(R/'eye_warm_iris.png'));eyeim.pack();eyeim.alpha_mode='NONE'
mat=bpy.data.materials.new('RESTORED_COMMON_EYES');mat.use_nodes=True;n=mat.node_tree.nodes;t=n.new('ShaderNodeTexImage');t.image=eyeim;p=n.get('Principled BSDF');p.inputs['Roughness'].default_value=.25;mat.node_tree.links.new(t.outputs['Color'],p.inputs['Base Color'])
for sign,name in [(-1,'R'),(1,'L')]:
 bpy.ops.mesh.primitive_uv_sphere_add(segments=48,ring_count=24,radius=.0118,location=(sign*.027,-.1385,1.716- .008));o=bpy.context.object;o.name='RESTORED_EYE_'+name;o.data.materials.append(mat)
 # Object-space planar optical UV: iris remains centred toward the front.
 uv=o.data.uv_layers.active
 for loop in o.data.loops:
  v=o.data.vertices[loop.vertex_index].co;uv.data[loop.index].uv=(.5+v.x/.0236,.5+v.z/.0236)
 for f in o.data.polygons:f.use_smooth=True
 o.vertex_groups.new(name='skf_eye_'+name.lower()).add(list(range(len(o.data.vertices))),1.,'REPLACE')
 o['status']='Restored separate eyeball preview; not yet Android rig-verified'
# Adjustable concentrated/furrowed expression requested from the new reference.
c['Intense_expression']=.8;c.id_properties_ui('Intense_expression').update(min=0.,max=1.,description='0 neutral structure; 1 concentrated brow/eyes; game animation not overridden')
for ob in bpy.data.objects:
 if ob.type!='MESH'or not ob.data.shape_keys or not ob.name.startswith('face_high_'):continue
 key=ob.shape_key_add(name='INTENSE_FOCUSED_EXPRESSION')
 for v,base in zip(key.data,ob.data.shape_keys.key_blocks['Basis'].data):
  x,y,z=base.co;front=1/(1+math.exp((y+.12)*180));brow=math.exp(-((abs(x)-.017)/.018)**2-((z-1.737)/.012)**2)*front
  upper=math.exp(-((abs(x)-.028)/.015)**2-((z-1.723)/.004)**2)*front
  lower=math.exp(-((abs(x)-.028)/.015)**2-((z-1.712)/.0035)**2)*front
  v.co.z+=-.0014*brow-.0007*upper+.00025*lower;v.co.y-=.0007*brow
 dr=key.driver_add('value').driver;dr.expression='a';vv=dr.variables.new();vv.name='a';vv.type='SINGLE_PROP';vv.targets[0].id=c;vv.targets[0].data_path='["Intense_expression"]'
bpy.context.scene.frame_set(1)
s=bpy.context.scene;s['revision']='v3_restore_common_eyes_neck8mm_adam2mm_darker';s.cycles.samples=20;cam=s.camera
report={'eyes_added':2,'eye_source':'PC common eye_sclera image supplied earlier; newly created separate globe geometry','neck_total_shortening_mm':8,'adam_apple_mm':2,'extra_skin_rgb_scale':.97,'phone_tested':False,'native_eye_motion_verified':False,'lip_candidate':'same local upper-lip weight edits as v2; device unverified','intense_expression_default':.8,'in_game_expression_lock':False}
for name,a in [('front',0),('three_quarter',35),('profile',90),('back_neck',145)]:
 a=math.radians(a);cam.location=(.65*math.sin(a),-.075-.65*math.cos(a),1.735);cam.rotation_euler=(Vector((0,-.075,1.68))-cam.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(R/(name+'.png'))
 if name=='front':bpy.ops.wm.save_as_mainfile(filepath=str(R/'Ronaldo_2017_v3_EYES_NECK.blend'))
 bpy.ops.render.render(write_still=True)
(R/'validation.json').write_text(json.dumps(report,indent=2))
