import bpy,json,math
from pathlib import Path
R=Path(__file__).parent;bpy.ops.wm.open_mainfile(filepath=str(R/'Ronaldo_2017_v3_EYES_NECK.blend'));c=bpy.data.objects['00_EDIT_CONTROLS'];eyes=[o for o in bpy.data.objects if o.name.startswith('RESTORED_EYE_')];assert len(eyes)==2
for o in eyes:
 dr=o.driver_add('location',2).driver;dr.expression='1.716-n/1000';v=dr.variables.new();v.name='n';v.type='SINGLE_PROP';v.targets[0].id=c;v.targets[0].data_path='["Neck_shortening_mm"]'
 assert len(o.data.uv_layers)>0
 assert o.data.materials[0].use_nodes
bpy.context.scene.frame_set(1)
assert c['Intense_expression']==.8 and c['Neck_shortening_mm']==8 and c['Adam_apple_mm']==2
for o in bpy.data.objects:
 if o.type=='MESH':assert all(math.isfinite(x)for v in o.data.vertices for x in v.co)
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Ronaldo_2017_v3_EYES_NECK.blend'))
r=json.loads((R/'validation.json').read_text());r['checks']={'reopened_blender':True,'two_eyeballs_with_uv_materials':True,'eye_position_follows_neck_controller':True,'finite_geometry':True,'expression_default':.8};(R/'validation.json').write_text(json.dumps(r,indent=2));print('RONALDO_V3_PASS')
