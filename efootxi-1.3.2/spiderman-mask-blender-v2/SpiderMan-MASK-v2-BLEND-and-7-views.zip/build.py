import bpy, math, os
from mathutils import Vector
from pathlib import Path
R=Path(__file__).parent
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def mat(name,color,rough=.5,metal=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=metal;return m
red=mat('Crimson woven mask',(.22,.003,.008),.7);black=mat('Raised charcoal rubber',(.009,.012,.015),.32);white=mat('Silver white optical lenses',(.65,.73,.76),.3,.28)
for m,scale,strength in [(red,1900,.18),(white,3500,.1)]:
 n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF');tex=n.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=scale;tex.inputs['Detail'].default_value=2;b=n.new('ShaderNodeBump');b.inputs['Strength'].default_value=strength;b.inputs['Distance'].default_value=.00025;l.new(tex.outputs['Fac'],b.inputs['Height']);l.new(b.outputs['Normal'],p.inputs['Normal'])
# Cross sections in metres: neck, jaw, cheekbones, forehead and crown.
profiles=[(0,.068,.047,.029),(.025,.052,.042,.027),(.055,.044,.041,.026),(.074,.042,.047,.012),(.085,.043,.052,-.005),(.102,.060,.061,-.001),(.128,.067,.069,.004),(.155,.075,.077,.011),(.19,.077,.081,.016),(.225,.076,.081,.02),(.255,.070,.076,.023),(.279,.056,.062,.025),(.296,.031,.039,.026),(.303,.001,.002,.026)]
def radii(z):
 for i in range(len(profiles)-1):
  a,b=profiles[i:i+2]
  if z<=b[0]:
   t=max(0,(z-a[0])/(b[0]-a[0]));pr=profiles[max(0,i-1)];nx=profiles[min(len(profiles)-1,i+2)]
   def interp(j):
    m0=(b[j]-pr[j])/(b[0]-pr[0])*(b[0]-a[0]);m1=(nx[j]-a[j])/(nx[0]-a[0])*(b[0]-a[0]);return (2*t**3-3*t*t+1)*a[j]+(t**3-2*t*t+t)*m0+(-2*t**3+3*t*t)*b[j]+(t**3-t*t)*m1
   return interp(1),interp(2),interp(3)
 return .001,.001,.026
# Covered nose and brow are sculpted into a continuous mask, with no lips/nose holes.
def point(a,z,offset=0):
 rx,ry,cy=radii(z);sn=math.sin(a);c=math.cos(a);x=rx*sn
 # Flatten the facial plane and square jaw; retain rounded occipital cranium.
 y=cy-ry*(max(c,0)**.48 if c>0 else c)
 if c>0:
  nose=.010*math.exp(-(x/.015)**2-((z-.184)/.022)**2)
  chin=.006*math.exp(-(x/.030)**4-((z-.096)/.014)**2)
  brow=.002*math.exp(-((abs(x)-.037)/.026)**2-((z-.226)/.018)**2)
  cheek=.003*math.exp(-((abs(x)-.053)/.015)**2-((z-.161)/.025)**2)
  y-=(nose+chin+brow+cheek)*c**3
 # Jaw corners sit above the centre chin; neck is behind the mandibular plane.
 zz=z+.009*abs(sn)**3*math.exp(-((z-.098)/.025)**2)
 return (x+offset*sn,y-offset*c,zz)
def front(x,z,offset=0):
 rx,_,_=radii(z);a=math.asin(max(-.998,min(.998,x/rx)));return point(a,z,offset)
def mesh(name,verts,faces,material):
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();ob=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(ob);me.materials.append(material)
 for p in me.polygons:p.use_smooth=True
 return ob
N=128;M=160;verts=[point(2*math.pi*j/N,.303*i/M)for i in range(M+1)for j in range(N)];faces=[(i*N+j,i*N+(j+1)%N,(i+1)*N+(j+1)%N,(i+1)*N+j)for i in range(M)for j in range(N)];head=mesh('MASK_continuous_closed_face_no_human_skin',verts,faces,red)
# Eye silhouettes are independent curved 3D optical assemblies.
def bez(p0,p1,p2,p3,t):return tuple((1-t)**3*p0[i]+3*(1-t)**2*t*p1[i]+3*(1-t)*t*t*p2[i]+t**3*p3[i] for i in range(2))
p0=(.011,.191);p1=(.068,.244)
outline=[bez(p0,(.028,.211),(.054,.229),p1,i/48)for i in range(48)]+[bez(p1,(.073,.192),(.043,.158),p0,i/48)for i in range(48)]
for side in [-1,1]:
 center=(.043,.202);v=[front(side*center[0],center[1],.0052)];rings=12;L=len(outline)
 for k in range(1,rings+1):
  t=k/rings
  for x,z in outline:v.append(front(side*(center[0]+(x-center[0])*t),center[1]+(z-center[1])*t,.0037+.0015*(1-t*t)))
 f=[(0,1+j,1+(j+1)%L)for j in range(L)]
 for k in range(rings-1):
  a=1+k*L;b=a+L;f.extend((a+j,b+j,b+(j+1)%L,a+(j+1)%L)for j in range(L))
 lens=mesh(('L'if side<0 else'R')+'_convex_white_lens',v,f,white)
 # Wide frame ring, rather than a painted eye on skin.
 v=[]
 for scale,dep in [(1.13,.0035),(1,.0055)]:
  for x,z in outline:v.append(front(side*(center[0]+(x-center[0])*scale),center[1]+(z-center[1])*scale,dep))
 frame=mesh(('L'if side<0 else'R')+'_thick_black_eye_frame',v,[(j,(j+1)%L,L+(j+1)%L,L+j)for j in range(L)],black)
 sol=frame.modifiers.new('Rubber frame thickness','SOLIDIFY');sol.thickness=.001
# Actual raised web curves, not a bitmap over a human face.
def curve(name,pts,width=.00052):
 cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.bevel_depth=width;cu.bevel_resolution=2;s=cu.splines.new('POLY');s.points.add(len(pts)-1)
 for p,co in zip(s.points,pts):p.co=(*co,1)
 ob=bpy.data.objects.new(name,cu);bpy.context.collection.objects.link(ob);cu.materials.append(black)
# Continuous wraparound lattice: no dangling cut-off face spokes.
for j in range(9):
 a=-math.pi/2+j*math.pi/8;pts=[]
 for i in range(161):
  z=.002+i*.298/160
  pinch=.16+.84*(1-math.exp(-((z-.193)/.046)**2))
  aa=math.asin(math.sin(a)*pinch)
  pts.append(point(aa,z,.00085))
 curve('WEB_front_meridian_%02d'%j,pts,.0007)
for j in range(1,8):
 a=math.pi/2+j*math.pi/8;curve('WEB_back_meridian_%02d'%j,[point(a,.002+i*.298/150,.00085)for i in range(151)],.0007)
for k,z in enumerate([.014,.036,.058,.080,.103,.126,.148,.169,.189,.210,.233,.255,.276,.291]):
 pts=[]
 for j in range(257):
  a=2*math.pi*j/256;zz=z+.002*math.sin(a*8)**2
  pts.append(point(a,zz,.0009))
 curve('WEB_continuous_ring_%02d'%k,pts,.0007)
# Packed hexagonal textile, UV mapped over the mask (not a human skin image).
img=bpy.data.images.load(str(R/'mask_hex.png'));img.pack();nodes=red.node_tree.nodes;links=red.node_tree.links;bs=nodes.get('Principled BSDF');tex=nodes.new('ShaderNodeTexImage');tex.image=img;links.new(tex.outputs['Color'],bs.inputs['Base Color'])
uv=head.data.uv_layers.new(name='MaskTextileUV')
for loop in head.data.loops:
 vi=loop.vertex_index;uv.data[loop.index].uv=((vi%N)/N,(vi//N)/M)
# Close the crown; keep collar opening for a game-body attachment later.
import bmesh
bm=bmesh.new();bm.from_mesh(head.data);bm.verts.ensure_lookup_table();bm.faces.new([bm.verts[M*N+j]for j in range(N)]);bm.to_mesh(head.data);bm.free()
# Neutral studio presentation.
floor=mat('Studio',(.035,.045,.06),.8)
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.002));bpy.context.object.data.materials.append(floor);bpy.context.object.name='STUDIO_floor'
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False;scene.render.resolution_x=760;scene.render.resolution_y=900;scene.render.resolution_percentage=100;scene.world.color=(.15,.15,.15)
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
for name,loc,power,size in [('Key',(-.4,-.5,.6),25,.5),('Fill',(.4,-.35,.3),12,.4),('Rim',(.2,.35,.5),32,.35)]:
 d=bpy.data.lights.new(name,'AREA');d.energy=power*.15;d.shape='DISK';d.size=size;o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);o.location=loc;aim(o,(0,0,.2))
d=bpy.data.cameras.new('Inspection_camera');cam=bpy.data.objects.new('Inspection_camera',d);scene.collection.objects.link(cam);scene.camera=cam;d.type='ORTHO';d.ortho_scale=.355
scene['status']='BLENDER_DESIGN_PROTOTYPE_NOT_ANDROID_COOKED_OR_DEVICE_VERIFIED';scene['reference']='Revised against user multi-angle references: squared jaw, pronounced chin, offset neck, flat facial plane and continuous web lattice. Original procedural approximation, not an extracted film asset.'
for area in bpy.context.screen.areas:
 if area.type=='VIEW_3D':area.spaces.active.region_3d.view_location=(0,0,.18);area.spaces.active.region_3d.view_distance=.55
for name,angle in [('front',0),('three_quarter',40),('left',90),('right',-90),('back',180)]:
 a=math.radians(angle);cam.location=(.8*math.sin(a),-.8*math.cos(a),.183);aim(cam,(0,0,.153));scene.render.filepath=str(R/(name+'.png'))
 if name=='front':bpy.ops.wm.save_as_mainfile(filepath=str(R/'SpiderMan_MASK_v2_EDIT.blend'))
 bpy.ops.render.render(write_still=True)
print('DONE')
clay=mat('Clay anatomy inspection',(.24,.26,.28),.8)
scene.view_layers[0].material_override=clay;scene.cycles.samples=20;scene.render.resolution_percentage=75
for name,angle in [('clay_front',0),('clay_profile',90)]:
 a=math.radians(angle);cam.location=(.8*math.sin(a),-.8*math.cos(a),.183);aim(cam,(0,0,.153));scene.render.filepath=str(R/(name+'.png'));bpy.ops.render.render(write_still=True)
