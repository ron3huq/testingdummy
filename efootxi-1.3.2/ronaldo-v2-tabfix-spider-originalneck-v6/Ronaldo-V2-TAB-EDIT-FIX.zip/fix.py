import bpy,json,math
from pathlib import Path
R=Path(__file__).parent;src='/workspace/analysis/ronaldo-2017-refine-v2/Ronaldo_2017_FACE_NECK_v2.blend';bpy.ops.wm.open_mainfile(filepath=src);bpy.context.scene.frame_set(1);bpy.context.view_layer.update();meshes=[o for o in bpy.data.objects if o.type=='MESH'];snapshot={};checks=[]
# Capture final evaluated v2 coordinates BEFORE removing keys, never use Basis.
for o in meshes:
 ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh();assert len(m.vertices)==len(o.data.vertices);snapshot[o.name]=[v.co.copy()for v in m.vertices];ev.to_mesh_clear()
# Keep a second file with all original controllers and improved edit display.
for o in meshes:
 if o.data.shape_keys:
  o.use_shape_key_edit_mode=True;o.show_only_shape_key=False;o.active_shape_key_index=1
for a in bpy.context.screen.areas:
 if a.type=='VIEW_3D':
  a.spaces.active.shading.type='MATERIAL';a.spaces.active.overlay.show_extras=False;a.spaces.active.overlay.show_relationship_lines=False
face=bpy.data.objects['face_high_2_fox_skin_mat'];bpy.ops.object.select_all(action='DESELECT');face.select_set(True);bpy.context.view_layer.objects.active=face
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Ronaldo_V2_CONTROLS_EDIT_DISPLAY.blend'))
# Stable TAB file: final v2 shape becomes base, same vertex/face order, UV/materials/weights.
for o in meshes:
 if o.data.shape_keys:o.shape_key_clear()
 for v,p in zip(o.data.vertices,snapshot[o.name]):v.co=p
 o.data.update();checks.append({'name':o.name,'vertices':len(o.data.vertices),'polygons':len(o.data.polygons),'max_error_mm':max((v.co-p).length for v,p in zip(o.data.vertices,snapshot[o.name]))*1000})
# The controls no longer apply to this baked copy; avoid misleading sliders.
c=bpy.data.objects.get('00_EDIT_CONTROLS')
if c:bpy.data.objects.remove(c,do_unlink=True)
bpy.context.view_layer.update()
# Verify actual edit-mode positions remain exactly the evaluated v2 coordinates.
import bmesh
bpy.ops.object.mode_set(mode='EDIT');bm=bmesh.from_edit_mesh(face.data);bm.verts.ensure_lookup_table();assert max((v.co-snapshot[face.name][i]).length for i,v in enumerate(bm.verts))<1e-7;bpy.ops.object.mode_set(mode='OBJECT')
bpy.context.scene['revision']='ORIGINAL_V2_SHAPE_FROZEN_FOR_IDENTICAL_OBJECT_AND_EDIT_MODE';bpy.ops.wm.save_as_mainfile(filepath=str(R/'Ronaldo_V2_TAB_STABLE.blend'))
(R/'validation.json').write_text(json.dumps({'source':src,'basis_replaced_with_final_evaluated_v2':True,'exact_v2_visual_coordinates':checks,'edit_mode_face_positions_match':True,'topology_uv_materials_weights_not_rebuilt':True,'v3_v4_changes_used':False,'game_install':False},indent=2))
print('V2_TAB_STABLE_PASS')
