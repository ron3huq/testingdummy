import bpy,math,json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=Path(__file__).parent;bpy.ops.wm.open_mainfile(filepath=str(R/'SpiderMan_v6_ORIGINAL_2006_NECK.blend'));objects=[o for o in bpy.data.objects if o.type=='MESH'and o.name.startswith('ORIGINAL_2006_')];assert len(objects)==1
vv=[];ff=[]
for o in objects:
 off=len(vv);vv.extend(v.co for v in o.data.vertices);ff.extend([off+i for i in p.vertices]for p in o.data.polygons)
b=BVHTree.FromPolygons(vv,ff);checks=[]
for z in [1.49,1.51,1.53,1.55,1.57,1.59]:
 p,n,i,d=b.ray_cast(Vector((0,-.055,z)),Vector((0,1,0)));assert p is not None,('missing back',z);checks.append(z)
assert not any('RECONSTRUCTED' in o.name for o in bpy.data.objects);assert bpy.context.scene['neck_shortening_mm']==20
(R/'neck-validation.json').write_text(json.dumps({'source_objects':[o.name for o in objects],'no_synthetic_neck':True,'posterior_rays_hit_at_heights':checks,'shortening_mm':20,'hidden_upper_overlap_fitted':True,'phone_tested':False},indent=2));print('ORIGINAL_SOURCE_NECK_REAR_PASS',len(checks))
