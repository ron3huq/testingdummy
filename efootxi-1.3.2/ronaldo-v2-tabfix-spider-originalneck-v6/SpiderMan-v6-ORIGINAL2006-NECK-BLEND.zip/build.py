import bpy,bmesh,sys,math,json
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R=Path(__file__).parent;ROOT=Path('/workspace/analysis/ronaldo-2006-viewer')
sys.path.insert(0,'/workspace/analysis/my-league/ronaldo-pc-conversion/pes-fmdl-blender/pes-fmdl');from FmdlFile import FmdlFile
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
def mat(n,c,r=.55):
 m=bpy.data.materials.new(n);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=r;return m
red=mat('MASK_crimson_fabric',(.24,.005,.014),.65);black=mat('MASK_graphite_web_and_rims',(.008,.009,.011),.52);white=mat('MASK_silver_optical_lenses',(.68,.71,.72),.35)
def mesh(n,v,f,m):
 me=bpy.data.meshes.new(n);me.from_pydata(v,[],f);me.update();ob=bpy.data.objects.new(n,me);bpy.context.collection.objects.link(ob);me.materials.append(m)
 for p in me.polygons:p.use_smooth=True
 return ob
models={}
for n in ['face_high','hair_high']:
 f=FmdlFile();f.readFile(str(ROOT/'source-extracted'/(n+'.fmdl')));models[n]=f
cv=lambda v:(v.position.x,-v.position.z,v.position.y)
# Original Ronaldo 2006 source skin parts, not a synthetic neck/collar.
neckmat=mat('RONALDO_2006_SOURCE_SKIN',(.5,.26,.17));im=bpy.data.images.load(str(ROOT/'converted/face_bsm_alp.png'));im.pack();im.alpha_mode='NONE';tex=neckmat.node_tree.nodes.new('ShaderNodeTexImage');tex.image=im;neckmat.node_tree.links.new(tex.outputs['Color'],neckmat.node_tree.nodes.get('Principled BSDF').inputs['Base Color'])
source_necks=[]
for model,index,label in [('face_high',0,'NECK'),('face_high',2,'THROAT'),('hair_high',0,'REAR_SCALP_NECK'),('face_high',5,'COLLAR_BASE')]:
 m=models[model].meshes[index];ids={id(v):i for i,v in enumerate(m.vertices)};ob=mesh('ORIGINAL_2006_'+label,list(map(cv,m.vertices)),[[ids[id(v)]for v in reversed(t.vertices)]for t in m.faces],neckmat);uv=ob.data.uv_layers.new(name='UV0')
 for l in ob.data.loops:v=m.vertices[l.vertex_index];uv.data[l.index].uv=(v.uv[0].u,1-v.uv[0].v)
 for i,v in enumerate(m.vertices):
  for bone,w in v.boneMapping.items():
   g=ob.vertex_groups.get(bone.name)or ob.vertex_groups.new(name=bone.name);g.add([i],w,'REPLACE')
 # Intersect source triangles rather than removing whole faces: preserve posterior skin.
 bm=bmesh.new();bm.from_mesh(ob.data);bmesh.ops.bisect_plane(bm,geom=list(bm.verts)+list(bm.edges)+list(bm.faces),plane_co=(0,0,1.633),plane_no=(0,0,1),clear_outer=True,dist=.000001);bmesh.ops.delete(bm,geom=[v for v in bm.verts if not v.link_faces],context='VERTS');bm.to_mesh(ob.data);bm.free();source_necks.append(ob)
# The source collar base normally uses the body AO material; retain its source
# geometry/weights and project skin UV from the original skin neck, not dummy UV.
from mathutils.geometry import barycentric_transform
bpy.context.view_layer.update();skin=source_necks[0];bb=BVHTree.FromObject(skin,bpy.context.evaluated_depsgraph_get());base=source_necks[3]
for loop in base.data.loops:
 co=base.data.vertices[loop.vertex_index].co;hit,n,pi,dist=bb.find_nearest(co);poly=skin.data.polygons[pi];ls=list(poly.loop_indices)[:3];points=[skin.data.vertices[skin.data.loops[k].vertex_index].co for k in ls];uvs=[Vector((*skin.data.uv_layers[0].data[k].uv,0))for k in ls];uv=barycentric_transform(hit,*points,*uvs);base.data.uv_layers[0].data[loop.index].uv=(uv.x,uv.y)
# Only tuck the upper front overlap inside the mask; preserve visible source neck.
for ob in source_necks:
 for v in ob.data.vertices:
  t=max(0,min(1,(v.co.z-1.603)/.007));front=max(0,min(1,(-v.co.y-.085)/.025));v.co.y+=.028*t*front;v.co.x*=1-.05*t*front
# Build the covered shell from real head anatomy. No parametric egg profile.
cloud=[]
for mm in [models['face_high'].meshes[0],models['face_high'].meshes[2],models['hair_high'].meshes[0]]:
 for v in mm.vertices:
  x,y,z=cv(v)
  if z<1.603:continue
  x=max(-.077,min(.077,x));y=max(y,-.175) # covered ears and smoothed nose, not protruding bare ears/nose
  y+=.010*math.exp(-((z-1.753)/.050)**2)*max(0,min(1,(y+.075)/.06))
  x*=1-.035*math.exp(-((z-1.635)/.025)**2)
  if y<-.12:y+=.0035*math.exp(-((z-1.635)/.022)**2)
  cloud.append((x,y,z))
for i in range(1,10):
 lat=i*math.pi/20
 for j in range(48):
  a=j*2*math.pi/48;cloud.append((.075*math.cos(lat)*math.sin(a),-.061-.092*math.cos(lat)*math.cos(a),1.732+.091*math.sin(lat)))
bm=bmesh.new()
for p in cloud:bm.verts.new(p)
bmesh.ops.convex_hull(bm,input=list(bm.verts),use_existing_faces=False)
# Remove loose source vertices left inside the convex envelope.
bmesh.ops.delete(bm,geom=[v for v in bm.verts if not v.link_faces],context='VERTS')
me=bpy.data.meshes.new('Anatomical_mask_shell');bm.to_mesh(me);bm.free();shell=bpy.data.objects.new('SPIDERMAN_ANATOMICAL_HEAD',me);bpy.context.collection.objects.link(shell);me.materials.append(red);bpy.context.view_layer.objects.active=shell;shell.select_set(True)
sub=shell.modifiers.new('Smooth anatomical envelope','SUBSURF');sub.levels=2;bpy.ops.object.modifier_apply(modifier=sub.name)
for p in shell.data.polygons:p.use_smooth=True
bpy.context.view_layer.update();bvh=BVHTree.FromObject(shell,bpy.context.evaluated_depsgraph_get())
# Fit only the hidden upper skin overlap to the inside of the existing mask.
for ob in source_necks:
 for v in ob.data.vertices:
  t=max(0,min(1,(v.co.z-1.603)/.007))
  if not t:continue
  hit,n,i,d=bvh.find_nearest(v.co)
  if (v.co-hit).dot(n)>0:v.co=v.co.lerp(hit-n*.001,t)
def front(x,z,off=.001):
 p,n,_,_=bvh.ray_cast(Vector((x,-.5,z)),Vector((0,1,0)))
 if p is None:raise RuntimeError('Eye extends off anatomical head '+str((x,z)))
 return p+n*off
center=Vector((0,-.066,1.714))
def surf(r,a,off=.0008):
 d=Vector((math.sin(r)*math.sin(a),-math.cos(r),math.sin(r)*math.cos(a)));p,n,_,_=bvh.ray_cast(center,d)
 if p is None:raise RuntimeError('Anatomical shell ray miss')
 return p+n*off
# Continuous radial film-style web, centred between the eyes.
def curve(n,pts,w=.00055):
 c=bpy.data.curves.new(n,'CURVE');c.dimensions='3D';c.bevel_depth=w;c.bevel_resolution=2;s=c.splines.new('POLY');s.points.add(len(pts)-1)
 for p,v in zip(s.points,pts):p.co=(*v,1)
 o=bpy.data.objects.new(n,c);bpy.context.collection.objects.link(o);c.materials.append(black)
for j in range(16):curve('WEB_radial_%02d'%j,[surf(.006+i*(math.pi-.012)/160,j*math.pi/8)for i in range(161)])
for k,r in enumerate([.24,.45,.68,.92,1.18,1.45,1.73,2.0,2.27,2.51,2.75]):curve('WEB_ring_%02d'%k,[surf(r-.018*math.sin(8*a)**2,a)for a in [i*2*math.pi/256 for i in range(257)]])
def bez(p0,p1,p2,p3,t):return tuple((1-t)**3*p0[i]+3*(1-t)**2*t*p1[i]+3*(1-t)*t*t*p2[i]+t**3*p3[i]for i in range(2))
p0=(.012,1.714);p1=(.064,1.756)
outline=[bez(p0,(.028,1.731),(.052,1.747),p1,i/48)for i in range(48)]+[bez(p1,(.067,1.706),(.042,1.688),p0,i/48)for i in range(48)]
for sign in [-1,1]:
 c=(.041,1.722);L=len(outline);v=[front(sign*c[0],c[1],.0045)]
 for k in range(1,13):
  t=k/12
  for x,z in outline:v.append(front(sign*(c[0]+(x-c[0])*t),c[1]+(z-c[1])*t,.003+.0015*(1-t*t)))
 f=[(0,1+j,1+(j+1)%L)for j in range(L)]
 for k in range(11):
  a=1+k*L;b=a+L;f.extend((a+j,b+j,b+(j+1)%L,a+(j+1)%L)for j in range(L))
 mesh(('LEFT'if sign<0 else'RIGHT')+'_LENS',v,f,white)
 v=[]
 for sc,off in [(1.13,.002),(1,.004)]:
  for x,z in outline:v.append(front(sign*(c[0]+(x-c[0])*sc),c[1]+(z-c[1])*sc,off))
 ob=mesh(('LEFT'if sign<0 else'RIGHT')+'_FRAME',v,[(j,(j+1)%L,L+(j+1)%L,L+j)for j in range(L)],black);mod=ob.modifiers.new('Frame thickness','SOLIDIFY');mod.thickness=.0008
# Shorten the complete assembly by 20 mm with a continuous neck blend.
for ob in list(bpy.data.objects):
 if ob.type=='MESH':
  for v in ob.data.vertices:
   t=max(0,min(1,(v.co.z-1.40)/.19));t=t*t*(3-2*t);v.co.z-=.02*t
 elif ob.type=='CURVE':
  for sp in ob.data.splines:
   for v in sp.points:
    t=max(0,min(1,(v.co.z-1.40)/.19));t=t*t*(3-2*t);v.co.z-=.02*t
# Repair source boundary holes using only original source vertices, not a loft.
bpy.ops.object.select_all(action='DESELECT')
for ob in source_necks:ob.select_set(True);bpy.context.view_layer.objects.active=ob
bpy.ops.object.join();skin=bpy.context.object;skin.name='ORIGINAL_2006_NECK_REPAIRED';source_necks=[skin]
oldverts=[v.co.copy()for v in skin.data.vertices];oldpolys=[tuple(p.vertices)for p in skin.data.polygons];olduv=[[skin.data.uv_layers[0].data[l].uv.copy()for l in p.loop_indices]for p in skin.data.polygons];oldb=BVHTree.FromPolygons(oldverts,oldpolys)
bm=bmesh.new();bm.from_mesh(skin.data);layer=bm.faces.layers.int.new('original_source_face')
for f in bm.faces:f[layer]=1
bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.00005);result=bmesh.ops.holes_fill(bm,edges=[e for e in bm.edges if e.is_boundary],sides=0);bmesh.ops.triangulate(bm,faces=list(bm.faces));bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.faces.ensure_lookup_table();newfaces=[i for i,f in enumerate(bm.faces)if f[layer]==0];bm.to_mesh(skin.data);bm.free()
for pi in newfaces:
 for li in skin.data.polygons[pi].loop_indices:
  co=skin.data.vertices[skin.data.loops[li].vertex_index].co;hit,normal,i,dist=oldb.find_nearest(co);inds=oldpolys[i][:3];pts=[oldverts[j]for j in inds];uu=[Vector((*u,0))for u in olduv[i][:3]];uv=barycentric_transform(hit,*pts,*uu);skin.data.uv_layers[0].data[li].uv=(uv.x,uv.y)
for p in skin.data.polygons:p.use_smooth=True
skin['source_boundary_faces_added']=len(newfaces)
# Shared normals across the original source skin sections, without changing positions/UV.
cloud=[];faces=[]
for o in source_necks:
 ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());m=ev.to_mesh();off=len(cloud);cloud.extend(v.co.copy()for v in m.vertices);faces.extend([off+i for i in p.vertices]for p in m.polygons);ev.to_mesh_clear()
me=bpy.data.meshes.new('TEMP_normal_reference');me.from_pydata(cloud,[],faces);bm=bmesh.new();bm.from_mesh(me);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.00025);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.normal_update();bm.to_mesh(me);bm.free();me.calc_loop_triangles();bv=BVHTree.FromPolygons([v.co for v in me.vertices],[p.vertices for p in me.polygons]);
# Nearest reference surface normal shared by overlapping sections; blend at boundaries.
for o in source_necks:
 ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get());em=ev.to_mesh();normals=[]
 for v in em.vertices:
  p,n,i,d=bv.find_nearest(v.co)
  # Use smoothed reference vertex normals instead of flat polygon normal.
  poly=me.polygons[i];near=sorted(poly.vertices,key=lambda j:(me.vertices[j].co-p).length)[:3];nn=Vector((0,0,0));total=0
  for j in near:
   w=1/max(.00005,(me.vertices[j].co-p).length);nn+=me.vertices[j].normal*w;total+=w
  nn.normalize();normals.append(nn)
 ev.to_mesh_clear();o.data.normals_split_custom_set_from_vertices(normals)
bpy.data.meshes.remove(me)
# Micro textile bump on mask only. Neck texture remains original.
n=red.node_tree.nodes;l=red.node_tree.links;t=n.new('ShaderNodeTexNoise');t.inputs['Scale'].default_value=2500;b=n.new('ShaderNodeBump');b.inputs['Strength'].default_value=.13;b.inputs['Distance'].default_value=.0002;l.new(t.outputs['Fac'],b.inputs['Height']);l.new(b.outputs['Normal'],n.get('Principled BSDF').inputs['Normal'])
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=16;scene.cycles.use_denoising=False;scene.render.resolution_x=720;scene.render.resolution_y=900;scene.world.color=(.1,.1,.1)
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
for n,loc,power in [('Key',(-.35,-.5,2.05),4),('Fill',(.4,-.4,1.8),2),('Rim',(.2,.2,2.0),5)]:
 d=bpy.data.lights.new(n,'AREA');d.energy=power;d.size=.4;o=bpy.data.objects.new(n,d);scene.collection.objects.link(o);o.location=loc;aim(o,(0,-.06,1.7))
d=bpy.data.cameras.new('Camera');cam=bpy.data.objects.new('Camera',d);scene.collection.objects.link(cam);scene.camera=cam;d.type='ORTHO';d.ortho_scale=.38
scene['status']='ANATOMICAL_HEAD_WITH_ORIGINAL_2006_NECK_NOT_DEVICE_VERIFIED';scene['neck_shortening_mm']=20;scene['facebuilder_used']=False;scene['neck_source']='Original Ronaldo2006 neck/throat/rear-scalp source triangles; geometric intersection under mask; UV/weights retained; no generated cylinder'
# Raw mesh export for native asset building; curve geometry included after evaluation.
records=[]
for o in list(scene.objects):
 if o.type not in ['MESH','CURVE']:continue
 dep=bpy.context.evaluated_depsgraph_get();ev=o.evaluated_get(dep);mm=ev.to_mesh();mm.calc_loop_triangles();records.append({'name':o.name,'vertices':[list(v.co)for v in mm.vertices],'triangles':[list(t.vertices)for t in mm.loop_triangles]});ev.to_mesh_clear()
(R/'geometry.json').write_text(json.dumps(records))
for name,ang in [('front',0),('three_quarter',40),('left',90),('right',-90),('back',180)]:
 a=math.radians(ang);cam.location=(.8*math.sin(a),-.06-.8*math.cos(a),1.72);aim(cam,(0,-.06,1.64));scene.render.filepath=str(R/(name+'.png'))
 if name=='front':bpy.ops.wm.save_as_mainfile(filepath=str(R/'SpiderMan_v6_ORIGINAL_2006_NECK.blend'))
 bpy.ops.render.render(write_still=True)
