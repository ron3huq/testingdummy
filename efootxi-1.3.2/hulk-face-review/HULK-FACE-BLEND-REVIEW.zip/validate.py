import bpy,json,math,bmesh
from pathlib import Path
R=Path(__file__).parent
bpy.ops.wm.open_mainfile(filepath=str(R/'HULK_FACE_REVIEW.blend'))
meshes=[o for o in bpy.data.objects if o.type=='MESH'];report={'facebuilder_used':False,'game_tested':False,'original_ronaldo_unchanged':True,'meshes':{},'packed_images':[]}
for o in meshes:
 assert all(math.isfinite(c)for v in o.data.vertices for c in v.co)
 assert all(len(p.vertices)>=3 for p in o.data.polygons)
 report['meshes'][o.name]={'vertices':len(o.data.vertices),'faces':len(o.data.polygons)}
for im in bpy.data.images:
 if im.name=='Hulk_skin_PACKED':assert im.packed_file;report['packed_images'].append(im.name)
face=bpy.data.objects['HULK_FACE_SCULPT'];coords=[v.co.copy()for v in face.data.vertices];bpy.context.view_layer.objects.active=face;face.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bm=bmesh.from_edit_mesh(face.data);bm.verts.ensure_lookup_table();assert max((v.co-coords[v.index]).length for v in bm.verts)<1e-7;bpy.ops.object.mode_set(mode='OBJECT');report['face_edit_mode_matches_object']=True
assert len([o for o in meshes if o.name.startswith('HULK_EYE_')])==2
for area in bpy.context.screen.areas:
 if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.shading.type='MATERIAL';area.spaces.active.overlay.show_extras=False
bpy.ops.wm.save_as_mainfile(filepath=str(R/'HULK_FACE_REVIEW.blend'))
(R/'validation.json').write_text(json.dumps(report,indent=2));print('VALIDATED_HULK')
