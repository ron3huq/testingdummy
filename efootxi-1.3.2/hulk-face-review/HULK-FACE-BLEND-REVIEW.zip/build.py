import bpy,math,random,json,bmesh
from mathutils import Vector
from pathlib import Path
R=Path(__file__).parent
bpy.ops.wm.open_mainfile(filepath='/workspace/analysis/ronaldo-v2-editfix/Ronaldo_V2_TAB_STABLE.blend')
random.seed(17)
for o in list(bpy.data.objects):
 if o.type!='MESH' or o.name not in ['face_high_0_fox_skin_mat','face_high_2_fox_skin_mat','hair_high_0_fox_skin_mat']:
  bpy.data.objects.remove(o,do_unlink=True)
def ga(x,z,cx,cz,rx,rz):return math.exp(-((x-cx)/rx)**2-((z-cz)/rz)**2)
def deform(v):
 x,y,z=v;ax=abs(x);front=1/(1+math.exp(min(50,(y+.105)*110)))
 # Broad jaw, compact midface and thick neck: actual geometry, not colour alone.
 jaw=math.exp(-((z-1.60)/.056)**2);neck=1/(1+math.exp((z-1.565)*65))
 nx=x*(1.24+.39*jaw+.42*neck)
 nz=1.69+(z-1.69)*.92
 ny=-.075+(y+.075)*(1.04+.18*jaw+.25*neck)
 # Chin block, muzzle, broad nose, cheek planes and heavy brow ridge.
 ny-=front*(.021*ga(x,z,0,1.581,.054,.025)+.008*ga(x,z,0,1.657,.045,.020))
 nx+=math.copysign(.013*ga(ax,z,.015,1.687,.018,.018)*front,x)
 ny-=front*(.018*ga(ax,z,.033,1.737,.034,.018)+.007*ga(ax,z,.055,1.690,.024,.025))
 nz-=front*.009*ga(ax,z,.017,1.732,.025,.017)
 # Upper lip raised toward the corners; compressed lower forehead.
 nz+=front*.0025*ga(ax,z,.026,1.660,.026,.012)
 return Vector((nx,ny,nz))
# Colourise packed diffuse in linear space, preserving source pores / brows / lip variation.
skin=bpy.data.materials.new('HULK olive green skin with micro pores');skin.use_nodes=True
n=skin.node_tree.nodes;l=skin.node_tree.links;bs=n.get('Principled BSDF');bs.inputs['Roughness'].default_value=.48;bs.inputs['Subsurface Weight'].default_value=.055
src=next(n.image for n in bpy.data.objects['face_high_2_fox_skin_mat'].data.materials[0].node_tree.nodes if n.type=='TEX_IMAGE' and n.image and 'warm' in n.image.name)
import numpy as np
pix=np.array(src.pixels[:],dtype=np.float32).reshape(-1,4);lum=pix[:,:3]@np.array([.3,.59,.11]);pix[:,:3]=lum[:,None]*np.array([.55,.76,.29])[None,:]
im=bpy.data.images.new('Hulk_skin_PACKED',width=src.size[0],height=src.size[1]);im.pixels.foreach_set(pix.ravel());im.pack();tex=n.new('ShaderNodeTexImage');tex.image=im;l.new(tex.outputs['Color'],bs.inputs['Base Color'])
noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=850;noise.inputs['Detail'].default_value=3
bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.24;bump.inputs['Distance'].default_value=.00035;l.new(noise.outputs['Fac'],bump.inputs['Height']);l.new(bump.outputs['Normal'],bs.inputs['Normal'])
skins=[]
for o in list(bpy.data.objects):
 if o.type!='MESH':continue
 for v in o.data.vertices:v.co=deform(v.co)
 o.data.materials.clear();o.data.materials.append(skin)
 for p in o.data.polygons:p.use_smooth=True;p.material_index=0
 o.data.normals_split_custom_set_from_vertices([Vector((0,0,0)) for v in o.data.vertices])
 for mod in list(o.modifiers):o.modifiers.remove(mod)
 mod=o.modifiers.new('Sculpt surface refinement','SUBSURF');mod.levels=2;mod.render_levels=2
 skins.append(o)
face=bpy.data.objects['face_high_2_fox_skin_mat'];face.name='HULK_FACE_SCULPT'
# Sculpt forehead furrows into a dense editable mesh.
bpy.context.view_layer.objects.active=face;face.select_set(True);bpy.ops.object.modifier_apply(modifier=face.modifiers[0].name)
for v in face.data.vertices:
 x,y,z=v.co
 if y<-.13 and 1.715<z<1.785:
  f=math.exp(-((x/.07)**6))*math.exp(-((y+.16)/.05)**2)
  grooves=0
  for side in [-1,1]:
   for k in range(2):
    target=side*(.007+k*.010+(z-1.735)*.10)
    grooves+=math.exp(-((x-target)/.0016)**2)*math.exp(-((z-1.752)/.021)**4)
  v.co.y+=.0018*grooves*f
# Short dark hair grown on a cap selected from the original anatomical scalp.
def mat(name,color,rough=.5):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*color,1);b.inputs['Roughness'].default_value=rough;return m
hairmat=mat('Hulk charcoal black hair',(.003,.005,.002),.8);hairmat.node_tree.nodes.get('Principled BSDF').inputs['Specular IOR Level'].default_value=.15
scalp=bpy.data.objects['hair_high_0_fox_skin_mat'];deps=bpy.context.evaluated_depsgraph_get();em=scalp.evaluated_get(deps).to_mesh();em.calc_loop_triangles();vs=[];fs=[];capvs=[];capfs=[]
for tri in em.loop_triangles:
 coords=[em.vertices[i].co for i in tri.vertices];c=sum(coords,Vector())/3
 # Higher at forehead, lower around back and temples.
 hairline=1.735+.035/(1+math.exp((c.y+.09)*90))
 if c.z<hairline:continue
 normal=tri.normal
 offcap=len(capvs);capvs.extend(coords);capfs.append((offcap,offcap+1,offcap+2))
 for j in range(14):
  a=random.random();b=random.random()
  if a+b>1:a=1-a;b=1-b
  p=coords[0]*(1-a-b)+coords[1]*a+coords[2]*b
  length=random.uniform(.006,.028);direction=(normal*.35+Vector((random.uniform(-.65,.65),random.uniform(-.7,.3),random.uniform(.15,.7)))).normalized()
  tangent=direction.cross(Vector((0,1,0))).normalized()*.0010
  off=len(vs);vs.extend([p-tangent,p+tangent,p+direction*length+Vector((random.uniform(-.003,.003),0,0))]);fs.append((off,off+1,off+2))
me=bpy.data.meshes.new('Short layered hair strands');me.from_pydata(vs,[],fs);ob=bpy.data.objects.new('HULK_SHORT_HAIR',me);bpy.context.collection.objects.link(ob);me.materials.append(hairmat)
cap=bpy.data.meshes.new('Dark cropped hair roots');cap.from_pydata(capvs,[],capfs);cap.materials.append(hairmat);capo=bpy.data.objects.new('HULK_HAIR_ROOTS',cap);bpy.context.collection.objects.link(capo)
for p in cap.polygons:p.use_smooth=True
scalp.evaluated_get(deps).to_mesh_clear()
def sphere(name,loc,scale,ma):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=40,ring_count=24,location=loc);o=bpy.context.object;o.name=name;o.scale=scale;o.data.materials.append(ma)
 for p in o.data.polygons:p.use_smooth=True
 return o
white=mat('Warm sclera',(.45,.46,.32),.28);iris=mat('Hazel green iris',(.075,.085,.019),.25);pupil=mat('Pupil',(.001,.002,.001),.2)
for side in [-1,1]:
 c=deform((side*.029,-.1335,1.7135));sphere('HULK_EYE_'+str(side),c,(.018,.012,.010),white)
 sphere('IRIS_'+str(side),c+Vector((0,-.0118,0)),(.0064,.0013,.0064),iris)
 sphere('PUPIL_'+str(side),c+Vector((0,-.0130,0)),(.0026,.0005,.0034),pupil)
# Presentation scene.
s=bpy.context.scene;s.world.color=(.045,.045,.045)
for o in bpy.context.selected_objects:o.select_set(False)
bpy.ops.object.camera_add();cam=bpy.context.object;cam.name='Portrait camera';s.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=.46
for name,loc,power,size,col in [('Key',(-.35,-.50,2.10),15,.40,(1,.86,.70)),('Fill',(.4,-.25,1.8),6,.35,(.68,.8,1)),('Rim',(.2,.2,1.95),20,.3,(.8,1,.78))]:
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.data.color=col;o.rotation_euler=(Vector((0,-.07,1.65))-o.location).to_track_quat('-Z','Y').to_euler()
s.render.engine='CYCLES';s.cycles.samples=48;s.cycles.use_denoising=False;s.render.resolution_x=800;s.render.resolution_y=900;s.render.resolution_percentage=100
s.view_settings.view_transform='AgX';s['asset_status']='Hulk sculpt study; not FaceBuilder; not game converted or tested';s['reference']='User Hulk front three-quarter stills'
for area in bpy.context.screen.areas:
 if area.type=='VIEW_3D':area.spaces.active.shading.type='MATERIAL';area.spaces.active.overlay.show_extras=False
for name,angle in [('front',0),('three_quarter',35),('profile',90),('back',180)]:
 a=math.radians(angle);cam.location=(.65*math.sin(a),-.07-.65*math.cos(a),1.72);cam.rotation_euler=(Vector((0,-.07,1.66))-cam.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(R/(name+'.png'))
 if name=='three_quarter':bpy.ops.wm.save_as_mainfile(filepath=str(R/'HULK_FACE_REVIEW.blend'))
 bpy.ops.render.render(write_still=True)
(R/'validation.json').write_text(json.dumps({'facebuilder_used':False,'game_tested':False,'packed_skin':im.packed_file is not None,'hair_triangles':len(fs),'face_vertices':len(face.data.vertices),'eyes':2,'ronaldo_original_modified':False},indent=2))
