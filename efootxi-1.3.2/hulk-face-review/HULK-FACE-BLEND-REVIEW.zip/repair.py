import bpy,bmesh,math
from pathlib import Path
from mathutils import Vector
R=Path(__file__).parent;bpy.ops.wm.open_mainfile(filepath=str(R/'HULK_FACE_REVIEW.blend'))
for name in ['face_high_0_fox_skin_mat','hair_high_0_fox_skin_mat']:
 o=bpy.data.objects[name];bm=bmesh.new();bm.from_mesh(o.data);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.00012);edges=[e for e in bm.edges if e.is_boundary];res=bmesh.ops.holes_fill(bm,edges=edges,sides=20);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(o.data);bm.free()
 for p in o.data.polygons:p.use_smooth=True
s=bpy.context.scene
for name,ang in [('front',0),('three_quarter',35),('profile',90),('back',180)]:
 a=math.radians(ang);s.camera.location=(.65*math.sin(a),-.07-.65*math.cos(a),1.72);s.camera.rotation_euler=(Vector((0,-.07,1.66))-s.camera.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(R/(name+'.png'))
 if name=='three_quarter':bpy.ops.wm.save_as_mainfile(filepath=str(R/'HULK_FACE_REVIEW.blend'))
 bpy.ops.render.render(write_still=True)
