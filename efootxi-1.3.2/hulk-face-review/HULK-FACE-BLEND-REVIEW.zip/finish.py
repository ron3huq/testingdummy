import bpy,math
from pathlib import Path
from mathutils import Vector
R=Path(__file__).parent;bpy.ops.wm.open_mainfile(filepath=str(R/'HULK_FACE_REVIEW.blend'))
b=bpy.data.materials['HULK olive green skin with micro pores'].node_tree.nodes.get('Principled BSDF');b.inputs['Roughness'].default_value=.65;b.inputs['Specular IOR Level'].default_value=.22
cap=bpy.data.objects['HULK_HAIR_ROOTS']
for v in cap.data.vertices:v.co+=v.normal*.0008
s=bpy.context.scene;s.cycles.samples=24
for name,angle in [('front',0),('three_quarter',35),('profile',90),('back',180)]:
 a=math.radians(angle);s.camera.location=(.65*math.sin(a),-.07-.65*math.cos(a),1.72);s.camera.rotation_euler=(Vector((0,-.07,1.66))-s.camera.location).to_track_quat('-Z','Y').to_euler();s.render.filepath=str(R/(name+'.png'))
 if name=='three_quarter':bpy.ops.wm.save_as_mainfile(filepath=str(R/'HULK_FACE_REVIEW.blend'))
 bpy.ops.render.render(write_still=True)
