Open .blend files in Blender 4.3 or newer.
Two Ronaldo cards reference the same native Epic Ronaldo face; the IDs and source hashes are stored in the scene. UV, skeleton and weights are retained.
Coach files reconstruct the supplied PC archives for inspection. Standalone preview eyes were added; this is not a port of a 3D sideline manager. The game update installs coach card portraits rendered from these sources.
Do not copy these .blend files into the APK.
