/* RC30.12 · Kit studio. Pick a My League club, Home or Away, give a picture: the phone lays it onto the game's kit layout
   (like the RC30 Juventus kits) and the club wears it after the app is reopened.  Python: editor op "celebrations" + rc30kit. */
(() => {
  "use strict";
  // Launcher (no file picker in its web view): shortcuts that open the card studio on the right panel.
  // Card studio (/api/models/search reaches Python as diy_model_list): the full Kit Studio.
  const IN_LAUNCHER = !!(window.EditorUI && window.LauncherApi);
  const api = async body => {
    let r;
    if (IN_LAUNCHER) r = await window.EditorUI.U.api("celebrations", body);
    else r = await fetch("/api/models/search", {method: "POST", body: JSON.stringify(body)}).then(x => x.json());
    if (r && r.error) throw new Error(r.error); return r;
  };
  const el = (t, a = {}, ...k) => { const e = document.createElement(t); for (const [n, v] of Object.entries(a)) { if (n === "class") e.className = v; else if (n in e) e[n] = v; else e.setAttribute(n, v); } k.forEach(x => x != null && e.append(x)); return e; };
  const css = `
  #kits{position:fixed;inset:0;z-index:9002;display:flex;flex-direction:column;background:var(--bg);color:var(--text);font:14px/1.45 var(--disp)}
  #kits[hidden]{display:none}
  #kits .k-top{display:flex;align-items:center;gap:10px;padding:calc(12px + env(safe-area-inset-top)) 16px 10px;border-bottom:1px solid var(--line);background:linear-gradient(180deg,#0b2540,#071a2d)}
  #kits .k-top h2{flex:1;margin:0;font-size:19px;letter-spacing:.2px}
  #kits .k-top small{display:block;color:var(--muted);font-size:12px;font-weight:400}
  #kits .k-x{border:1px solid var(--line2);background:var(--s2);color:var(--text);border-radius:12px;padding:8px 14px;font:600 14px var(--disp)}
  #kits .k-body{flex:1;overflow:auto;padding:14px 16px calc(24px + env(safe-area-inset-bottom))}
  #kits .k-chips{display:flex;gap:8px;overflow-x:auto;padding-bottom:4px;scrollbar-width:none}
  #kits .k-chip{flex:none;border:1px solid var(--line2);background:var(--s1);color:var(--muted);border-radius:999px;padding:8px 14px;font:600 13px var(--disp)}
  #kits .k-chip.on{background:var(--grad);border-color:transparent;color:#fff;box-shadow:0 6px 18px rgba(37,99,235,.35)}
  #kits .k-search{width:100%;box-sizing:border-box;margin:12px 0 10px;padding:11px 14px;border:1px solid var(--line2);border-radius:12px;background:var(--s1);color:var(--text);font:14px var(--disp)}
  #kits .k-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px}
  #kits .k-team{position:relative;display:flex;flex-direction:column;align-items:flex-start;gap:4px;min-height:64px;padding:11px 12px;border:1px solid var(--line);border-radius:14px;background:linear-gradient(160deg,var(--s2),var(--s1));color:var(--text);text-align:left;font:600 14px var(--disp)}
  #kits .k-team small{color:var(--muted);font-weight:400;font-size:11.5px}
  #kits .k-team .k-tags{display:flex;gap:4px}
  #kits .k-tag{padding:1px 7px;border-radius:999px;background:rgba(56,189,248,.16);color:#7dd3fc;font:700 10.5px var(--disp)}
  #kits .k-sheet{margin-top:6px;padding:14px;border:1px solid var(--line2);border-radius:18px;background:linear-gradient(180deg,#0d2641,#0a1d31)}
  #kits .k-sheet h3{margin:0 0 2px;font-size:18px} #kits .k-sheet p.k-s{margin:0 0 12px;color:var(--muted);font-size:12.5px}
  #kits .k-seg{display:grid;grid-auto-flow:column;grid-auto-columns:1fr;gap:4px;padding:4px;border-radius:12px;background:var(--s1);border:1px solid var(--line)}
  #kits .k-seg button{border:0;border-radius:9px;padding:9px 6px;background:transparent;color:var(--muted);font:600 13px var(--disp)}
  #kits .k-seg button.on{background:var(--s3);color:#fff;box-shadow:inset 0 0 0 1px var(--line2)}
  #kits label.k-l{display:block;margin:14px 0 6px;color:#7dd3fc;font:700 11.5px var(--disp);letter-spacing:.7px;text-transform:uppercase}
  #kits .k-pick{display:flex;align-items:center;gap:10px;width:100%;box-sizing:border-box;padding:10px 12px;border:1px dashed #2f6aa3;border-radius:12px;background:#071a2c;color:#cfe8ff;font:600 13.5px var(--disp);text-align:left}
  #kits .k-pick img{width:42px;height:42px;object-fit:cover;border-radius:8px;background:#0a2440}
  #kits input[type=file]{display:none}
  #kits .k-cols{display:grid;grid-template-columns:repeat(auto-fill,minmax(92px,1fr));gap:8px}
  #kits .k-col{display:flex;align-items:center;gap:8px;padding:6px 8px;border:1px solid var(--line);border-radius:10px;background:var(--s1);font-size:12.5px;color:var(--muted)}
  #kits .k-col input{width:30px;height:30px;padding:0;border:0;border-radius:8px;background:none}
  #kits .k-prev{display:grid;grid-template-columns:1fr;gap:10px;margin-top:12px}
  @media (min-width:560px){#kits .k-prev{grid-template-columns:1.3fr 1fr}}
  #kits .k-card{border:1px solid var(--line);border-radius:14px;background:radial-gradient(circle at 50% 30%,#14365a,#071a2d);padding:10px;min-height:120px;display:flex;align-items:center;justify-content:center}
  #kits .k-card img{max-width:100%;display:block;border-radius:6px}
  #kits .k-row{display:flex;gap:8px;margin-top:14px}
  #kits .k-btn{flex:1;padding:12px;border:1px solid var(--line2);border-radius:12px;background:var(--s2);color:var(--text);font:700 14px var(--disp)}
  #kits .k-btn.p{border:0;background:var(--grad);color:#fff}
  #kits .k-btn:disabled{opacity:.45}
  #kits .k-bar{height:7px;margin-top:12px;border-radius:99px;background:#0a2440;overflow:hidden}
  #kits .k-bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#22d3ee,#2563eb);transition:width .3s}
  #kits .k-msg{min-height:18px;margin-top:8px;font-size:13px;color:#cfe8ff} #kits .k-msg.err{color:var(--danger)}
  #kits .k-have{display:flex;align-items:center;gap:10px;margin-top:12px;padding:8px 10px;border-radius:12px;background:#0b2a46;font-size:12.5px;color:#a9d4f5}
  #kits .k-have img{width:34px;height:48px;object-fit:cover;border-radius:6px} #kits .k-have b{flex:1;font-weight:600}
  #kits .k-have button{padding:6px 10px;border:1px solid #8a3346;border-radius:9px;background:transparent;color:var(--danger);font:600 12px var(--disp)}
  #kits .k-note{margin-top:14px;padding:10px 12px;border-radius:12px;background:#0b2a46;color:#a9d4f5;font-size:12px}`;

  let root, state = {comp: 122, teams: [], team: null, slot: 0, mode: "photo", front: null, back: null, cols: {}, auto: {}};
  const COLS = [["sleeves", "Sleeves"], ["shorts", "Shorts"], ["socks", "Socks"], ["trim", "Collar"], ["numbers", "Numbers"]];

  function readImage(file, maxSide, png) {
    return new Promise((ok, bad) => {
      const url = URL.createObjectURL(file), img = new Image();
      img.onload = () => {
        const s = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
        const c = document.createElement("canvas"); c.width = Math.round(img.naturalWidth * s); c.height = Math.round(img.naturalHeight * s);
        const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(img, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url); ok(c.toDataURL(png ? "image/png" : "image/jpeg", .93));
      };
      img.onerror = () => { URL.revokeObjectURL(url); bad(new Error("This picture cannot be opened")); };
      img.src = url;
    });
  }

  function open() {
    if (!root) build();
    root.hidden = false; loadTeams();
  }

  function build() {
    document.head.append(el("style", {textContent: css}));
    root = el("section", {id: "kits", hidden: true});
    const close = el("button", {class: "k-x", type: "button", textContent: "Close"}); close.onclick = () => { root.hidden = true; };
    const head = el("div", {class: "k-top"}, el("h2", {}, "Kit Studio", el("small", {textContent: "Picture → home or away kit · My League clubs"})), close);
    const chips = el("div", {class: "k-chips", id: "k-chips"});
    const search = el("input", {class: "k-search", type: "search", placeholder: "Search club"});
    search.oninput = () => renderTeams(search.value);
    const body = el("div", {class: "k-body"}, chips, search, el("div", {id: "k-sheet-slot"}), el("div", {class: "k-grid", id: "k-grid"}),
      el("div", {class: "k-note", textContent: "Shirt photo: a front picture of the real shirt on a plain background (back photo optional). Kit template: a PES / eFootball uniform texture (square). Saved kits show in game after closing and reopening the app."}));
    root.append(head, body); document.body.append(root);
    api({rc30kit: "comps"}).then(r => {
      chips.replaceChildren(...r.comps.map(c => { const b = el("button", {class: "k-chip" + (c.id === state.comp ? " on" : ""), type: "button", textContent: c.name}); b.onclick = () => { state.comp = c.id; [...chips.children].forEach(x => x.classList.toggle("on", x === b)); state.team = null; root.querySelector("#k-sheet-slot").replaceChildren(); loadTeams(); }; return b; }));
    }).catch(e => chips.replaceChildren(el("div", {class: "k-msg err", textContent: e.message})));
  }

  async function loadTeams() {
    const grid = root.querySelector("#k-grid"); grid.replaceChildren(el("div", {class: "k-msg", textContent: "Loading clubs…"}));
    try { state.teams = (await api({rc30kit: "teams", competition: state.comp})).teams; renderTeams(root.querySelector(".k-search").value); }
    catch (e) { grid.replaceChildren(el("div", {class: "k-msg err", textContent: e.message})); }
  }

  function renderTeams(q) {
    const grid = root.querySelector("#k-grid"); q = (q || "").trim().toLowerCase();
    grid.replaceChildren(...state.teams.filter(t => !q || t.name.toLowerCase().includes(q) || String(t.id) === q).map(t => {
      const tags = el("span", {class: "k-tags"}); if (t.kits["0"]) tags.append(el("i", {class: "k-tag", textContent: "HOME"})); if (t.kits["1"]) tags.append(el("i", {class: "k-tag", textContent: "AWAY"}));
      const b = el("button", {class: "k-team", type: "button"}, t.name, el("small", {textContent: "ID " + t.id}), tags);
      b.onclick = () => { state.team = t; state.front = state.back = null; state.cols = {}; sheet(); root.querySelector(".k-body").scrollTo({top: 0, behavior: "smooth"}); };
      return b;
    }));
  }

  function seg(options, value, onpick) {
    const s = el("div", {class: "k-seg"});
    options.forEach(([v, label]) => { const b = el("button", {type: "button", class: v === value ? "on" : "", textContent: label}); b.onclick = () => { [...s.children].forEach(x => x.classList.toggle("on", x === b)); onpick(v); }; s.append(b); });
    return s;
  }

  function sheet() {
    const t = state.team, slotBox = root.querySelector("#k-sheet-slot");
    const msg = el("div", {class: "k-msg"}), bar = el("div", {class: "k-bar"}, el("i"));
    const show = (text, bad) => { msg.textContent = text || ""; msg.className = "k-msg" + (bad ? " err" : ""); };
    const tex = el("div", {class: "k-card"}, el("small", {textContent: "Kit texture preview"})), mock = el("div", {class: "k-card"}, el("small", {textContent: "Front · Back"}));
    const have = el("div");
    const renderHave = () => {
      const k = t.kits[String(state.slot)]; have.replaceChildren();
      if (!k) return;
      const rm = el("button", {type: "button", textContent: "Remove"});
      rm.onclick = async () => { rm.disabled = true; try { await api({rc30kit: "remove", team: t.id, slot: state.slot}); delete t.kits[String(state.slot)]; renderHave(); renderTeams(root.querySelector(".k-search").value); show("Removed. Reopen the app to restore the original kit."); } catch (e) { show(e.message, true); } };
      have.append(el("div", {class: "k-have"}, el("img", {src: k.thumb, alt: ""}), el("b", {textContent: "Custom " + (state.slot ? "away" : "home") + " kit in use"}), rm));
    };
    const fileFront = el("input", {type: "file", accept: "image/*"}), fileBack = el("input", {type: "file", accept: "image/*"});
    const pickFront = el("button", {class: "k-pick", type: "button"}, el("img", {alt: ""}), "Choose picture"), pickBack = el("button", {class: "k-pick", type: "button"}, el("img", {alt: ""}), "Back of the shirt (optional)");
    pickFront.onclick = () => fileFront.click(); pickBack.onclick = () => fileBack.click();
    const setPick = (btn, data, name) => { btn.querySelector("img").src = data; btn.lastChild.textContent = "✓ " + name; };
    fileFront.onchange = async () => { const f = fileFront.files[0]; if (!f) return; try { state.front = await readImage(f, state.mode === "template" ? 1024 : 1400, state.mode === "template"); setPick(pickFront, state.front, f.name); state.cols = {}; preview(); } catch (e) { show(e.message, true); } };
    fileBack.onchange = async () => { const f = fileBack.files[0]; if (!f) return; try { state.back = await readImage(f, 1400, false); setPick(pickBack, state.back, f.name); preview(); } catch (e) { show(e.message, true); } };
    const backRow = el("div", {}, el("label", {class: "k-l", textContent: "Back"}), pickBack, fileBack);
    const colWrap = el("div", {class: "k-cols"});
    const renderCols = () => {
      colWrap.replaceChildren(...COLS.map(([k, label]) => {
        const i = el("input", {type: "color", value: state.cols[k] || state.auto[k] || "#ffffff"});
        i.onchange = () => { state.cols[k] = i.value; preview(); };
        return el("label", {class: "k-col"}, i, label);
      }));
    };
    const body = () => ({team: t.id, slot: state.slot, mode: state.mode, front: state.front, back: state.mode === "photo" ? state.back : null, ...state.cols});
    let busy = false;
    async function preview() {
      if (!state.front || busy) return;
      busy = true; show("Building preview…");
      try {
        const r = await api({rc30kit: "preview", ...body()});
        state.auto = r.auto; renderCols();
        tex.replaceChildren(el("img", {src: r.texture, alt: "kit texture"})); mock.replaceChildren(el("img", {src: r.mockup, alt: "kit"}));
        show("Check the colours, then save.");
      } catch (e) { show(e.message, true); }
      busy = false;
    }
    const save = el("button", {class: "k-btn p", type: "button", textContent: "Save kit"}), again = el("button", {class: "k-btn", type: "button", textContent: "Preview"});
    again.onclick = preview;
    save.onclick = async () => {
      if (!state.front) return show("Choose a picture first.", true);
      save.disabled = again.disabled = true; bar.firstChild.style.width = "5%";
      try {
        await api({rc30kit: "apply", ...body()});
        for (;;) {
          await new Promise(r => setTimeout(r, 900));
          const j = (await api({rc30kit: "status"})).job; bar.firstChild.style.width = (j.percent || 0) + "%"; show(j.message, j.state === "ERROR");
          if (j.state !== "BUILDING") break;
        }
        const fresh = (await api({rc30kit: "teams", competition: state.comp})).teams; state.teams = fresh;
        state.team = fresh.find(x => x.id === t.id) || t; t.kits = state.team.kits; renderHave(); renderTeams(root.querySelector(".k-search").value);
      } catch (e) { show(e.message, true); }
      save.disabled = again.disabled = false;
    };
    const modeSeg = seg([["photo", "Shirt photo"], ["template", "Kit template"]], state.mode, v => { state.mode = v; backRow.hidden = v !== "photo"; preview(); });
    const slotSeg = seg([[0, "Home"], [1, "Away"]], state.slot, v => { state.slot = v; renderHave(); });
    backRow.hidden = state.mode !== "photo"; renderCols(); renderHave();
    slotBox.replaceChildren(el("div", {class: "k-sheet"},
      el("h3", {textContent: t.name}), el("p", {class: "k-s", textContent: "ID " + t.id + " · the kit is used in every competition"}),
      slotSeg, have,
      el("label", {class: "k-l", textContent: "Picture type"}), modeSeg,
      el("label", {class: "k-l", textContent: "Picture"}), pickFront, fileFront, backRow,
      el("label", {class: "k-l", textContent: "Colours"}), colWrap,
      el("div", {class: "k-prev"}, tex, mock), bar, msg, el("div", {class: "k-row"}, again, save)));
  }

  function mount() {
    if (IN_LAUNCHER) {
      const grid = document.querySelector("#home .quick-grid"); if (!grid || document.getElementById("rc30-kits")) return;
      const go = async which => {
        const L = window.LauncherApi;
        if (L.gameEntered && L.gameEntered()) { L.notice && L.notice("Close the game and reopen this app before using Card studio."); return; }
        try { await api({rc30kit: "intent", open: which}); } catch (e) { /* the panel still opens */ }
        L.call("openPanel", {name: "designer"}).catch(() => {});
      };
      const mk = (id, svg, title, sub, which) => { const b = el("button", {class: "quick", id, type: "button"}); b.innerHTML = svg + "<b>" + title + "</b><small>" + sub + "</small>"; b.onclick = () => go(which); return b; };
      const kits = mk("rc30-kits", '<svg viewBox="0 0 24 24"><path d="M8 3l-5 3 2 5 2-1v11h10V10l2 1 2-5-5-3a4 4 0 0 1-8 0z"/></svg>', "Kit Studio", "Picture → home / away kit · UCL · Saudi · World · Y17 · Y08", "kits");
      const glb = mk("rc30-glb", '<svg viewBox="0 0 24 24"><circle cx="12" cy="10" r="6"/><path d="M6 21c1.5-3 3.5-4 6-4s4.5 1 6 4M9 9h.01M15 9h.01"/></svg>', "GLB Face", "Import a .glb head onto any card · copy card pictures", "glb");
      const transfer = document.getElementById("private-transfer");
      if (transfer) transfer.after(kits, glb); else grid.prepend(kits, glb);
      return;
    }
    // card studio: floating button above the GLB one, and open straight away when the launcher asked for it
    document.head.append(el("style", {textContent: "#rc30k-fab{position:fixed;right:14px;bottom:calc(140px + env(safe-area-inset-bottom));z-index:9000;border:0;border-radius:999px;padding:12px 18px;background:linear-gradient(135deg,#22d3ee,#38bdf8 45%,#2563eb);color:#fff;font:700 14px system-ui;box-shadow:0 8px 24px rgba(37,99,235,.45)}" +
      ":root{--bg:#051220;--s1:#0a1d31;--s2:#0e2740;--s3:#14365a;--line:#173353;--line2:#21476f;--text:#e8f4ff;--muted:#86a6c4;--danger:#fb7185;--grad:linear-gradient(135deg,#22d3ee 0%,#38bdf8 45%,#2563eb 100%);--disp:system-ui,-apple-system,'Segoe UI',Roboto,sans-serif}"}));
    const fab = el("button", {id: "rc30k-fab", type: "button", textContent: "👕 Kit Studio"}); fab.onclick = open; document.body.append(fab);
    api({rc30kit: "intent_take"}).then(r => {
      if (r.open === "kits") open();
      else if (r.open === "glb") { const g = document.getElementById("rc30g-fab"); if (g) g.click(); }
    }).catch(() => {});
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount); else mount();
  window.RC30Kits = {open};
})();
