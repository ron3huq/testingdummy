/* RC30 · GLB face import (card studio).  Upload a .glb head, choose the card, the phone converts it (V32 converter) and
   the card wears it after the app is reopened.  Talks to Python through the existing /api/models/search route. */
(() => {
  const api = body => fetch('/api/models/search', {method: 'POST', body: JSON.stringify(body)}).then(r => r.json()).then(r => { if (r.error) throw new Error(r.error); return r; });
  const css = `
  #rc30g-fab{position:fixed;right:14px;bottom:calc(84px + env(safe-area-inset-bottom));z-index:9000;border:0;border-radius:999px;padding:12px 18px;
    background:linear-gradient(135deg,#22d3ee,#38bdf8 45%,#2563eb);color:#fff;font:700 14px system-ui;box-shadow:0 8px 24px rgba(37,99,235,.45)}
  #rc30g{position:fixed;inset:0;z-index:9001;display:flex;align-items:flex-end;justify-content:center;background:rgba(2,10,20,.6)}
  #rc30g[hidden]{display:none}
  #rc30g .box{width:min(520px,100%);max-height:90vh;overflow:auto;margin:10px;padding:18px;border:1px solid #21476f;border-radius:20px;
    background:linear-gradient(180deg,#0d2641,#0a1d31);color:#e8f4ff;font:14px/1.45 system-ui}
  #rc30g h2{margin:0 0 4px;font-size:19px} #rc30g p.s{margin:0 0 14px;color:#86a6c4;font-size:12.5px}
  #rc30g label{display:block;margin:10px 0 6px;font-size:12px;font-weight:700;letter-spacing:.6px;text-transform:uppercase;color:#7dd3fc}
  #rc30g input[type=text],#rc30g input[type=file]{width:100%;box-sizing:border-box;padding:11px 12px;border:1px solid #21476f;border-radius:12px;background:#071a2c;color:#e8f4ff;font:14px system-ui}
  #rc30g .row{display:flex;gap:8px;margin-top:14px}
  #rc30g button.b{flex:1;padding:12px;border:1px solid #21476f;border-radius:12px;background:#0e2740;color:#e8f4ff;font:700 14px system-ui}
  #rc30g button.p{border:0;background:linear-gradient(135deg,#22d3ee,#38bdf8 45%,#2563eb);color:#fff}
  #rc30g button:disabled{opacity:.45}
  #rc30g .bar{height:8px;margin:14px 0 6px;border-radius:99px;background:#0a2440;overflow:hidden}
  #rc30g .bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#22d3ee,#2563eb);transition:width .3s}
  #rc30g .msg{min-height:20px;font-size:13px;color:#cfe8ff} #rc30g .err{color:#fb7185}
  #rc30g ul{list-style:none;margin:8px 0 0;padding:0} #rc30g li{display:flex;align-items:center;gap:10px;padding:10px 12px;margin-top:6px;border:1px solid #18395c;border-radius:12px;background:#0a1f35}
  #rc30g li b{flex:1;font-size:13px} #rc30g li small{display:block;color:#86a6c4;font-weight:400}
  #rc30g li button{padding:7px 12px;border:1px solid #8a3346;border-radius:10px;background:transparent;color:#fb7185;font:600 12px system-ui}
  #rc30g input[type=file]{position:absolute!important;width:1px!important;height:1px!important;opacity:0!important;display:block!important}
  #rc30g .pick{display:block;width:100%;box-sizing:border-box;padding:12px;border:1px dashed #2f6aa3;border-radius:12px;background:#071a2c;color:#7dd3fc;font:600 14px system-ui;text-align:left}
  #rc30g .tip{margin-top:14px;padding:10px 12px;border-radius:12px;background:#0b2a46;color:#a9d4f5;font-size:12px}`;
  const el = (t, a = {}, ...k) => { const e = document.createElement(t); Object.assign(e, a); k.forEach(x => e.append(x)); return e; };
  function mount() {
    document.head.append(el('style', {textContent: css}));
    const fab = el('button', {id: 'rc30g-fab', type: 'button', textContent: '◉ GLB Face'});
    const card = el('input', {type: 'text', inputMode: 'numeric', placeholder: 'Card ID, e.g. 89138556572074'});
    const file = el('input', {type: 'file', accept: '.glb,model/gltf-binary'});
    const pick = el('button', {type: 'button', className: 'pick', textContent: '⬆  Choose .glb file'});
    pick.onclick = () => file.click();
    file.onchange = () => { const f = file.files && file.files[0]; pick.textContent = f ? '✓  ' + f.name + ' · ' + (f.size / 1048576).toFixed(1) + ' MB' : '⬆  Choose .glb file'; };
    const go = el('button', {type: 'button', className: 'b p', textContent: 'Import face'});
    const close = el('button', {type: 'button', className: 'b', textContent: 'Close'});
    const bar = el('div', {className: 'bar'}, el('i')), msg = el('div', {className: 'msg'}), list = el('ul');
    const box = el('div', {className: 'box'},
      el('h2', {textContent: 'GLB face → card'}),
      el('p', {className: 's', textContent: 'One merged, skinned head in .glb (max 32 MB). The phone converts it offline; up to 8 cards.'}),
      el('label', {textContent: 'Card ID'}), card, el('label', {textContent: 'Model (.glb)'}), pick, file,
      bar, msg, el('div', {className: 'row'}, close, go),
      el('label', {textContent: 'Imported faces'}), list,
      el('div', {className: 'tip', textContent: 'After importing: close and reopen the app (the face is loaded at login), then open the card or play a match.'}));
    const sheet = el('div', {id: 'rc30g', hidden: true}, box);
    document.body.append(fab, sheet);
    const busy = on => { go.disabled = on; file.disabled = on; pick.disabled = on; card.disabled = on; };
    const show = (text, bad) => { msg.textContent = text; msg.className = 'msg' + (bad ? ' err' : ''); };
    const pct = p => { bar.firstChild.style.width = Math.max(0, Math.min(100, p)) + '%'; };
    async function refresh() {
      try {
        const r = await api({rc30face: 'list'}); list.replaceChildren();
        if (!r.slots.length) list.append(el('li', {}, el('b', {textContent: 'No GLB faces yet'})));
        r.slots.forEach(s => {
          const rm = el('button', {type: 'button', textContent: 'Remove'});
          rm.onclick = async () => { rm.disabled = true; await api({rc30face: 'remove', slot: s.slot}).catch(e => show(e.message, true)); refresh(); };
          list.append(el('li', {}, el('b', {textContent: s.name || 'Face ' + s.slot}, el('small', {textContent: 'Card ' + s.card + ' · slot ' + s.slot})), rm));
        });
        return r;
      } catch (e) { show(e.message, true); }
    }
    async function poll() {
      for (;;) {
        const r = await api({rc30face: 'list'}); const j = r.job || {};
        pct(j.percent || 0); show(j.message || '', j.state === 'ERROR');
        if (j.state !== 'CONVERTING' && j.state !== 'CANCELLING') { busy(false); refresh(); return; }
        await new Promise(res => setTimeout(res, 1500));
      }
    }
    go.onclick = async () => {
      const f = file.files && file.files[0], id = card.value.trim();
      if (!/^[0-9]{4,18}$/.test(id)) return show('Enter the card ID (numbers only).', true);
      if (!f || !/\.glb$/i.test(f.name)) return show('Choose a .glb file.', true);
      if (f.size > 32 * 1024 * 1024) return show('GLB must be at most 32 MB.', true);
      busy(true); pct(0);
      try {
        const b = await api({rc30face: 'begin', card: id, size: f.size, name: f.name.replace(/\.glb$/i, '')});
        const CH = 3 * 1024 * 1024;
        for (let o = 0; o < f.size; o += CH) {
          const buf = new Uint8Array(await f.slice(o, o + CH).arrayBuffer()); let s = '';
          for (let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
          await api({rc30face: 'chunk', job: b.job, offset: o, data: btoa(s)});
          pct(Math.round(Math.min(o + CH, f.size) / f.size * 15)); show('Uploading… ' + Math.round(Math.min(o + CH, f.size) / f.size * 100) + '%');
        }
        await api({rc30face: 'start', job: b.job}); show('Converting model…'); poll();
      } catch (e) { show(e.message, true); busy(false); }
    };
    fab.onclick = () => { sheet.hidden = false; refresh().then(r => { if (r && r.job && (r.job.state === 'CONVERTING')) { busy(true); poll(); } }); };
    close.onclick = () => { sheet.hidden = true; };
    sheet.onclick = e => { if (e.target === sheet) sheet.hidden = true; };
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount); else mount();
})();
