"use strict";
/* Full-database picker (PlayerEditorPanel.catalog / confirmAdd). Filtering runs on the host so tens of
   thousands of cards never cross the bridge at once; the page asks for 60 rows at a time. */
(() => {
  const {h, t, tx} = window.EditorUI.U, U = window.EditorUI.U, W = window.EditorUI.W, Store = window.EditorUI.Store;
  const PAGE = 60, sharedCart=new Map();

  window.EditorUI.catalog = function (schema, host) {
    const positions = schema.positions || [];
    const list = W.container(), count = h("p", {class: "ed-note"}), more = h("button", {type: "button", class: "ed-btn wide", hidden: true});
    let F = W.emptyFilter(), board = 1, selecting=false;const cart=sharedCart;
    const abils = (schema.abilities || []).map(a => ({label: a.label}));
    const sb = W.searchBar("Name / Card ID / Position / Card type", async () => { const next = await W.filterSheet(positions, types, F, abils); if (next) { F = next; query(true); } });
    // Boards are presets over the host query: sort order plus an ownership filter.
    const BOARDS = [["Top rated", 0, ""], ["Favorites", 0, "fav"], ["Not owned", 3, "unowned"], ["Owned", 0, "owned"], ["Name: A–Z", 1, ""], ["Cart",0,"cart"]];
    const boards = W.pills(BOARDS.map(b => b[0]), 1, i => { board = i; order.value = BOARDS[i][1]; query(true); });
    const q = sb.input;
    const sel = labels => h("select", {class: "ed-in"}, labels.map((l, i) => { const o = h("option", {value: i}); o.textContent = tx(l); return o; }));
    const order = sel(["Overall: highest first", "Name: A–Z", "Level limit: highest first", "Unowned first"]);
    let types = [], total = 0, shown = 0, gen = 0, squad = null, timer = 0, lastCards = [];
    t(more, "Show more");

    const row = c => {const el=W.entry(c, positions, [`${c.id} · Overall ${c.overall} · ${c.card_type_label}`, `${positions[c.position] || ""} · Level limit ${c.level_limit} · Owned: ${c.owned} cards`],()=>{if(selecting||BOARDS[board][2]==='cart')toggle(c);else view(c);});el.classList.add('catalog-card');el.dataset.cardId=String(c.id);el.append(h('span',{class:'cart-order',hidden:true}));return el;};
    function paintSelected(){const order=new Map([...cart.keys()].map((id,i)=>[id,i+1]));for(const el of list.querySelectorAll('.catalog-card')){const n=order.get(el.dataset.cardId);el.classList.toggle('cart-selected',!!n);el.setAttribute('aria-pressed',String(!!n));el.hidden=!!n&&BOARDS[board][2]!=='cart';const badge=el.querySelector('.cart-order');badge.hidden=!n;badge.textContent=n?'✓ '+n:'';}}
    function toggle(c){if(!c.editable){U.toast('This card cannot be added');return;}const id=String(c.id);if(cart.has(id))cart.delete(id);else{if(cart.size>=50){U.toast('Add the current 50 selections first');return;}cart.set(id,c);}paintCart();paintSelected();if(BOARDS[board][2]==='cart')query(true);}
    const choose=h('button',{type:'button',class:'ed-btn',on:{click:()=>{if(BOARDS[board][2]==='cart'){selecting=true;board=0;boards.set(0);order.value=0;q.value='';query(true);}else selecting=!selecting;paintCart();}}});const help=h('p',{class:'ed-note',hidden:true});

    const queryCache = new Map(); let running = false, queued = null, cacheEpoch = 0;
    function appendRows(cards) { const fragment=document.createDocumentFragment(); cards.forEach(c=>fragment.append(row(c))); list.append(fragment); }
    function cached(args) { const hit=queryCache.get(JSON.stringify(args));return hit && performance.now()-hit.time<10000 ? hit.value : null; }
    function remember(args,value) { const key=JSON.stringify(args);queryCache.delete(key);queryCache.set(key,{value,time:performance.now()});while(queryCache.size>12)queryCache.delete(queryCache.keys().next().value); }
    function renderQuery(job,r) {
      if (job.my!==gen) return;
      total=r.total;appendRows(r.cards);shown+=r.cards.length;paintSelected();lastCards=job.reset?r.cards.slice():lastCards.concat(r.cards);
      count.textContent=tx(total===0?(BOARDS[board][2]==="fav"?"No favorites yet. Open a card and tap the star.":"No cards found. Try another search."):`${shown} / ${total} · Owned cards: Owned tab`);
      more.hidden=shown>=total;
    }
    async function fetchQuery(job) {
      running=true; more.disabled=true;
      try {
        let r=cached(job.args);
        if (!r) { r=await U.api("catalogQuery",job.args); if(job.epoch===cacheEpoch)remember(job.args,r); }
        renderQuery(job,r);
      } catch(e) { if(job.my===gen)count.textContent=e.message; }
      finally { running=false;more.disabled=false;job.resolve();const next=queued;queued=null;if(next)fetchQuery(next); }
    }
    function query(reset) {
      clearTimeout(timer);timer=0;
      if(!reset&&running)return Promise.resolve();
      const my=++gen;paintCart();sb.mark(W.filterActive(F));
      if(reset){W.setMode(list);U.clearPortraits(list);list.replaceChildren();shown=0;more.hidden=true;}
      if(queued){queued.resolve();queued=null;}
      if(BOARDS[board][2]==='cart'){
        order.disabled=true;const cards=[...cart.values()];appendRows(cards);shown=total=cards.length;lastCards=cards;
        count.textContent=cards.length?'Selected order · '+cards.length+' cards':'Your cart is empty. Enable Select multiple and tap player cards.';more.hidden=true;paintSelected();return Promise.resolve();
      }
      order.disabled=false;count.textContent='Loading players…';
      const args={q:q.value,positions:[...F.pos],types:[...F.type],omin:F.omin,omax:F.omax,ab:F.ab,own:BOARDS[board][2]==="owned"?"owned":"unowned",only:BOARDS[board][2]==="fav"?Store.favs:undefined,order:+order.value,offset:shown,limit:PAGE};
      const hit=cached(args);if(hit){renderQuery({my,reset},hit);return Promise.resolve();}
      return new Promise(resolve=>{const job={my,args,reset,resolve,epoch:cacheEpoch};if(running)queued=job;else fetchQuery(job);});
    }
    const later = () => { clearTimeout(timer); timer = setTimeout(() => query(true), 200); };
    [q].forEach(e => e.addEventListener("input", later)); order.addEventListener("change", () => { boards.set(-1); query(true); });
    more.onclick = () => query(false);

    // Read-only look at a card (ratings and abilities) before deciding to add it.
    async function view(c) {
      const names = {}; (schema.abilities || []).forEach((a, i) => { names[i] = a.label; });
      const art = U.portrait(c, 0); art.classList.add("ed-art");
      const card = h("div", {class: "ed-card3"}, art, h("span", {class: "ed-c-ovr"}, String(c.overall), h("small", {}, positions[c.position] || "")));
      const meta = h("div", {class: "ed-info"}, h("h2", {class: "ed-name"}, c.name));
      const roles = h("div", {class: "ed-roles"}); roles.textContent = tx([positions[c.position], c.card_type_label].filter(Boolean).join("  ·  "));
      const sub = h("p", {class: "ed-plans"}); sub.textContent = tx(`${c.id} · Level limit ${c.level_limit} · Owned: ${c.owned}  cards`);
      const star = h("button", {type: "button", class: "ed-star"});
      const paintStar = () => { star.classList.toggle("on", Store.isFav(c.id)); star.textContent = tx(Store.isFav(c.id) ? "★ Saved" : "☆ Save"); };
      star.onclick = async () => { await Store.toggleFav(c.id); paintStar(); if (BOARDS[board][2] === "fav") query(true); };
      paintStar();
      meta.append(roles, sub, star);
      Store.touch({id: c.id, name: c.name, overall: c.overall, position: c.position, kind: "card"});
      const body = h("div", {}, h("div", {class: "ed-hero3"}, card, meta));
      if (Array.isArray(c.ab)) {
        const grid = h("div", {class: "ed-abil"});
        c.ab.forEach((v, i) => { const chip = h("b", {class: "ed-chip"}, String(v)); chip.dataset.band = window.EditorCore.abilityBand(v);
          const cell = h("div", {class: "ed-cell"}, h("span", {}, tx(names[i] || "")), chip); cell.dataset.band = chip.dataset.band; grid.append(cell); });
        body.append(grid);
      }
      const cmp = window.EditorUI.compare, inCmp = cmp && cmp.has("c" + c.id);
      const go = await U.sheet("Card details", "", [{label: "Back", value: false}, {label: inCmp ? "Remove from compare" : "Add to compare", value: "compare"}, {label: c.editable ? "Add to inventory…" : "Remove from compare", value: true, kind: "primary"}], body);
      if (go === "compare") { cmp.setSchema(schema); const on = cmp.add(cmp.fromCard(c)); if (on) U.toast("Added to compare"); return; }
      if (go === true && c.editable) await confirmAdd(c);
    }

    const cartBar=h("div",{class:"ed-submit private-cart"});
    const cartCount=h("span",{}),cartAdd=h("button",{type:"button",class:"ed-btn primary"},"Add selected to storage");
    const clear=h('button',{type:'button',class:'ed-btn',on:{click:()=>{cart.clear();paintCart();paintSelected();if(BOARDS[board][2]==='cart')query(true);}}},'Clear cart');
    const paintCart=()=>{cartBar.hidden=!cart.size&&!selecting;cartCount.textContent=cart.size+' selected';cartAdd.disabled=!cart.size;clear.disabled=!cart.size;choose.textContent=BOARDS[board][2]==='cart'?(cart.size?'Choose more players':'Choose players'):(selecting?'Done selecting':'Select multiple');choose.classList.toggle('on',selecting);choose.setAttribute('aria-pressed',String(selecting));help.hidden=!selecting;help.textContent='Tap cards in the order you want. Selected cards move to Cart. Open Cart to review or remove them.';U.t(boards.el.lastChild,'Cart ('+cart.size+')');};
    cartAdd.onclick=()=>U.run("Adding selected players…",async()=>{
      if(!cart.size)return;
      const ok=await U.sheet("Add selected players",[...cart.values()].map(c=>c.name).join("\n"),[{label:"Cancel",value:false},{label:"Add to storage",value:true,kind:"primary"}]);
      if(!ok)return;
      for(const [id,c]of [...cart]){await U.api("add",{card_id:c.id,destination:"inventory"});cart.delete(id);paintCart();paintSelected();}
      cacheEpoch++;queryCache.clear();await query(true);U.toast("Players added to storage");
    });
    cartBar.append(cartCount,clear,cartAdd);paintCart();
    async function confirmAdd(c) {
      if(!c.editable)return;
      if(cart.size>=50&&!cart.has(String(c.id)))throw new Error("Add the current 50 selections first");
      cart.set(String(c.id),c);paintCart();paintSelected();U.toast("Added to cart · Continue choosing players");
    }

    const head = h("div", {class: "ed-head"}, h("h2", {}, ""));
    return {el: h("div", {}, h("button",{type:"button",class:"ed-btn",on:{click:()=>window.EditorUI.back()}},"← Back to players"), head, sb.el, boards.el,help, h("div", {class: "ed-bar rc30-bar"}, choose, order, W.viewToggle(() => query(true))), count, list, more, cartBar),
      setQuery(v) { q.value = v; },
      viewOnly() { if (total === 1 && lastCards[0]) view(lastCards[0]); },
      async open() {
        const r = await U.api("catalogOpen"); types = r.types || []; squad = r.squad || null;
        const title = head.firstChild; title.textContent = tx(`Player Catalogue · ${r.count}  cards`);
        await query(true);
      }};
  };
})();
