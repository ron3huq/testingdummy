/* RC30.21 · Team tactics for My League clubs: playstyle, team chemistry (playstyle proficiency) and form A–E.
   Python: editor op "celebrations" with {"rc30tac": op, ...} (rc30_tactics.py). */
(() => {
  "use strict";
  if (!(window.EditorUI && window.LauncherApi)) return;
  const api = async body => { const r = await window.EditorUI.U.api("celebrations", body); if (r && r.error) throw new Error(r.error); return r; };
  const el = (t, a = {}, ...k) => { const e = document.createElement(t); for (const [n, v] of Object.entries(a)) { if (n === "class") e.className = v; else if (n in e) e[n] = v; else e.setAttribute(n, v); } k.forEach(x => x != null && e.append(x)); return e; };
  const css = `
  #tac{position:fixed;inset:0;z-index:9002;display:flex;flex-direction:column;background:var(--bg);color:var(--text);font:14px/1.45 var(--disp)}
  #tac[hidden]{display:none}
  #tac .t-top{display:flex;align-items:center;gap:10px;padding:calc(12px + env(safe-area-inset-top)) 16px 10px;border-bottom:1px solid var(--line);background:linear-gradient(180deg,#0b2540,#071a2d)}
  #tac .t-top h2{flex:1;margin:0;font-size:19px} #tac .t-top small{display:block;color:var(--muted);font-size:12px;font-weight:400}
  #tac .t-x{border:1px solid var(--line2);background:var(--s2);color:var(--text);border-radius:12px;padding:8px 14px;font:600 14px var(--disp)}
  #tac .t-body{flex:1;overflow:auto;padding:14px 16px calc(24px + env(safe-area-inset-bottom))}
  #tac .t-chips{display:flex;gap:8px;overflow-x:auto;padding-bottom:4px;scrollbar-width:none}
  #tac .t-chip{flex:none;border:1px solid var(--line2);background:var(--s1);color:var(--muted);border-radius:999px;padding:8px 14px;font:600 13px var(--disp)}
  #tac .t-chip.on{background:var(--grad);border-color:transparent;color:#fff}
  #tac .t-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px;margin-top:12px}
  #tac .t-team{display:flex;flex-direction:column;align-items:flex-start;gap:3px;padding:11px 12px;border:1px solid var(--line);border-radius:14px;background:linear-gradient(160deg,var(--s2),var(--s1));color:var(--text);text-align:left;font:600 14px var(--disp)}
  #tac .t-team small{color:var(--muted);font-weight:400;font-size:11.5px}
  #tac .t-team.ed{border-color:#2f6aa3;box-shadow:inset 0 0 0 1px #2f6aa3}
  #tac .t-badges{display:flex;gap:4px;flex-wrap:wrap}
  #tac .t-b{padding:1px 7px;border-radius:999px;background:rgba(56,189,248,.16);color:#7dd3fc;font:700 10.5px var(--disp)}
  #tac .t-sheet{margin-top:4px;padding:14px;border:1px solid var(--line2);border-radius:18px;background:linear-gradient(180deg,#0d2641,#0a1d31)}
  #tac .t-sheet h3{margin:0 0 2px;font-size:18px} #tac .t-sheet p{margin:0 0 10px;color:var(--muted);font-size:12.5px}
  #tac label.t-l{display:block;margin:14px 0 6px;color:#7dd3fc;font:700 11.5px var(--disp);letter-spacing:.7px;text-transform:uppercase}
  #tac .t-styles{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:6px}
  #tac .t-style{padding:10px;border:1px solid var(--line);border-radius:12px;background:var(--s1);color:var(--muted);font:600 13px var(--disp);text-align:left}
  #tac .t-style small{display:block;font-weight:400;font-size:11px;color:#5f86ab}
  #tac .t-style.on{background:var(--s3);color:#fff;border-color:#38bdf8}
  #tac .t-range{display:flex;align-items:center;gap:12px} #tac .t-range input{flex:1;accent-color:#38bdf8}
  #tac .t-range b{min-width:42px;text-align:center;font-size:20px}
  #tac .t-forms{display:grid;grid-template-columns:repeat(6,1fr);gap:6px}
  #tac .t-form{padding:10px 0;border:1px solid var(--line);border-radius:12px;background:var(--s1);color:var(--muted);font:800 15px var(--disp)}
  #tac .t-form.on{color:#fff;border-color:transparent}
  #tac .t-form.on[data-f=A]{background:#16a34a} #tac .t-form.on[data-f=B]{background:#65a30d} #tac .t-form.on[data-f=C]{background:#ca8a04}
  #tac .t-form.on[data-f=D]{background:#ea580c} #tac .t-form.on[data-f=E]{background:#dc2626} #tac .t-form.on[data-f=""]{background:var(--s3)}
  #tac .t-row{display:flex;gap:8px;margin-top:16px}
  #tac .t-btn{flex:1;padding:12px;border:1px solid var(--line2);border-radius:12px;background:var(--s2);color:var(--text);font:700 14px var(--disp)}
  #tac .t-btn.p{border:0;background:var(--grad);color:#fff} #tac .t-btn:disabled{opacity:.45}
  #tac .t-msg{min-height:18px;margin-top:8px;font-size:13px;color:#cfe8ff} #tac .t-msg.err{color:var(--danger)}
  #tac .t-note{margin-top:14px;padding:10px 12px;border-radius:12px;background:#0b2a46;color:#a9d4f5;font-size:12px}`;
  const DESC = ["Short passes, keep the ball", "Win it high, attack fast", "Sit deep, break with long balls", "Long balls to the forwards", "Attack down the flanks", "Crowd one side, switch play"];
  let root, body, state = {comp: 122, comps: [], styles: [], teams: [], team: null};

  function build() {
    document.head.append(el("style", {textContent: css}));
    root = el("div", {id: "tac", hidden: true});
    const x = el("button", {class: "t-x", type: "button", textContent: "Close"}); x.onclick = () => { root.hidden = true; };
    const head = el("div", {class: "t-top"}, el("h2", {}, "Team Tactics", el("small", {textContent: "Playstyle · Team chemistry · Form A–E"})), x);
    body = el("div", {class: "t-body"});
    root.append(head, body); document.body.append(root);
  }
  async function open() {
    if (!root) build();
    root.hidden = false; body.textContent = "Loading…";
    try { const r = await api({rc30tac: "comps"}); state.comps = r.comps; state.styles = r.styles; await loadTeams(); }
    catch (e) { body.textContent = e.message; }
  }
  async function loadTeams() {
    const r = await api({rc30tac: "teams", competition: state.comp}); state.teams = r.teams; state.team = null; render();
  }
  function render() {
    body.textContent = "";
    const chips = el("div", {class: "t-chips"});
    state.comps.forEach(c => { const b = el("button", {type: "button", class: "t-chip" + (c.id === state.comp ? " on" : ""), textContent: c.name}); b.onclick = () => { state.comp = c.id; loadTeams().catch(e => alert(e.message)); }; chips.append(b); });
    body.append(chips);
    if (state.team) body.append(sheet(state.team));
    const list = el("div", {class: "t-list"});
    state.teams.forEach(t => {
      const b = el("button", {type: "button", class: "t-team" + (t.edited ? " ed" : "")}, t.name, el("small", {textContent: "Coach " + (t.coach || "—")}));
      const badges = el("span", {class: "t-badges"}, el("i", {class: "t-b", textContent: state.styles[t.style]}), el("i", {class: "t-b", textContent: "Chem " + t.chemistry}));
      if (t.form) badges.append(el("i", {class: "t-b", textContent: "Form " + t.form}));
      b.append(badges); b.onclick = () => { state.team = Object.assign({}, t); render(); body.scrollTop = 0; };
      list.append(b);
    });
    body.append(list);
    body.append(el("div", {class: "t-note", textContent: "Playstyle and chemistry are written into the game's own team tables while it runs; form is applied to every player of the club in My League matches. Changes apply from the next match (no restart needed). Advanced instructions are not part of this game's team data: eFootball sets them per match, in game."}));
  }
  function sheet(t) {
    const s = el("div", {class: "t-sheet"}, el("h3", {textContent: t.name}), el("p", {textContent: "Coach " + (t.coach || "—") + " · native " + state.styles[t.native_style] + " " + t.native_prof[t.native_style]}));
    s.append(el("label", {class: "t-l", textContent: "Playstyle"}));
    const st = el("div", {class: "t-styles"});
    state.styles.forEach((name, i) => {
      const b = el("button", {type: "button", class: "t-style" + (i === t.style ? " on" : "")}, name, el("small", {textContent: DESC[i] + " · coach " + t.native_prof[i]}));
      b.onclick = () => { t.style = i; if (!t.chemTouched) t.chemistry = Math.max(t.chemistry, t.native_prof[i]); state.team = t; render(); };
      st.append(b);
    });
    s.append(st, el("label", {class: "t-l", textContent: "Team chemistry (playstyle proficiency)"}));
    const val = el("b", {textContent: t.chemistry});
    const rng = el("input", {type: "range", min: 1, max: 99, value: t.chemistry}); rng.oninput = () => { t.chemistry = +rng.value; t.chemTouched = true; val.textContent = rng.value; };
    s.append(el("div", {class: "t-range"}, rng, val), el("label", {class: "t-l", textContent: "Form (condition) in My League"}));
    const fm = el("div", {class: "t-forms"});
    ["", "A", "B", "C", "D", "E"].forEach(f => { const b = el("button", {type: "button", class: "t-form" + ((t.form || "") === f ? " on" : ""), textContent: f || "Auto"}); b.dataset.f = f; b.onclick = () => { t.form = f || null; [...fm.children].forEach(x => x.classList.toggle("on", x === b)); }; fm.append(b); });
    s.append(fm);
    const msg = el("div", {class: "t-msg"});
    const save = el("button", {type: "button", class: "t-btn p", textContent: "Save"});
    const reset = el("button", {type: "button", class: "t-btn", textContent: "Reset to native"});
    save.onclick = async () => { save.disabled = true; msg.className = "t-msg"; msg.textContent = "Saving…"; try { await api({rc30tac: "save", team: t.id, style: t.style, chemistry: t.chemistry, form: t.form || ""}); await loadTeams(); } catch (e) { msg.className = "t-msg err"; msg.textContent = e.message; save.disabled = false; } };
    reset.onclick = async () => { reset.disabled = true; try { await api({rc30tac: "reset", team: t.id}); await loadTeams(); } catch (e) { msg.className = "t-msg err"; msg.textContent = e.message; reset.disabled = false; } };
    s.append(el("div", {class: "t-row"}, reset, save), msg);
    return s;
  }
  function addButton() {
    const grid = document.querySelector("#home .quick-grid"); if (!grid || document.getElementById("rc30-tactics")) return !!grid;
    const b = el("button", {class: "quick", id: "rc30-tactics", type: "button"});
    b.innerHTML = '<svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M12 3v18M3 12h4M17 12h4"/><circle cx="12" cy="12" r="3"/></svg><b>Team Tactics</b><small>Playstyle · Chemistry · Form A–E</small>';
    b.onclick = open;
    const transfer = document.getElementById("private-transfer");
    if (transfer && transfer.parentNode === grid) transfer.after(b); else grid.append(b);
    return true;
  }
  const t0 = Date.now(); (function tick() { if (!addButton() && Date.now() - t0 < 20000) setTimeout(tick, 400); })();
})();
