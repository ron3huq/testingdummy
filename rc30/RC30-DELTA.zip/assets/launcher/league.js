/* RC30: My League page (table, top scorers, top assists, season review). Data: editor bridge op "list" with {rc30:"league"}. */
(() => {
  const $ = (id) => document.getElementById(id);
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const L = { d: null, tab: "table", busy: false, crests: null, seenReview: "" };
  const short = (n) => { const p = String(n || "").split(" "); return p.length < 2 || /^(Jr|Júnior)$/.test(p[p.length - 1]) ? n : `${p[0][0]}. ${p.slice(1).join(" ")}`; };

  // club crests: assets/cup-crests/crests.bin = "CRST", count, [id, offset, size] x count, PNG data
  async function crests() {
    if (L.crests) return L.crests;
    L.crests = {};
    try {
      const buf = await (await fetch("../cup-crests/crests.bin")).arrayBuffer(), v = new DataView(buf), n = v.getUint32(4, true);
      for (let i = 0; i < n; i++) {
        const id = v.getUint32(8 + 12 * i, true), off = v.getUint32(12 + 12 * i, true), size = v.getUint32(16 + 12 * i, true);
        L.crests[id] = URL.createObjectURL(new Blob([new Uint8Array(buf, off, size)], { type: "image/png" }));
      }
    } catch (e) { /* no crest pack: short codes instead */ }
    return L.crests;
  }
  const T = (id) => (L.d && L.d.teams && L.d.teams[String(id)]) || { name: "#" + id, short: "?" };
  const crest = (id, cls = "") => { const t = T(id), u = L.crests && L.crests[t.crest]; return u ? `<img class="lg-cr ${cls}" src="${u}" alt="">` : `<i class="lg-cr lg-crx ${cls}">${esc((t.short || "?").slice(0, 3))}</i>`; };
  const face = (pid, size = 34) => `<span class="lg-face" data-lgface="1" data-id="${esc(pid)}" style="width:${size}px;height:${size}px"></span>`;


  async function load() {
    if (L.busy) return; L.busy = true;
    const root = $("lg-root"); if (!root.innerHTML) root.innerHTML = `<div class="lg-empty">Loading My League…</div>`;
    try {
      await crests();
      L.d = await window.LauncherApi.call("editor", { op: "list", payload: { rc30: "league" } });
    } catch (e) { L.d = { error: e.message }; }
    L.busy = false; draw();
  }

  function rowsTable(d) {
    const me = d.team, n = d.table.length;
    return `<table class="lg-tbl"><thead><tr><th>#</th><th class="lg-club">Club</th><th>P</th><th>W</th><th>D</th><th>L</th><th>GD</th><th>Pts</th></tr></thead><tbody>${d.table.map((r, i) =>
      `<tr class="${r.team === me ? "me" : ""} ${i === 0 ? "z1" : i < 4 ? "z4" : i >= n - 2 ? "zl" : ""}"><td class="lg-rk"><i>${i + 1}</i></td><td class="lg-club"><span>${crest(r.team)}<b>${esc(T(r.team).name)}</b></span></td><td>${r.p}</td><td>${r.w}</td><td>${r.d}</td><td>${r.l}</td><td>${r.gf - r.ga > 0 ? "+" : ""}${r.gf - r.ga}</td><td class="lg-pts">${r.pts}</td></tr>`).join("")}</tbody></table>`;
  }
  function rowsPlayers(list, unit) {
    if (!list.length) return `<div class="lg-empty">No ${unit === "G" ? "goals" : "assists"} yet - play a matchday</div>`;
    const top = list[0].n;
    return `<div class="lg-pl">${list.map((p, i) => `<div class="lg-pr${p.team === L.d.team ? " me" : ""}${i === 0 ? " lead" : ""}"><i class="lg-n">${p.rank}</i>${face(p.pid, i < 3 ? 44 : 34)}<div class="lg-who"><b>${esc(p.name)}</b><small>${crest(p.team, "sm")}${esc(T(p.team).name)}</small></div><span class="lg-bar"><i style="width:${Math.round(p.n / top * 100)}%"></i></span><b class="lg-v">${p.n}</b></div>`).join("")}</div>`;
  }

  function draw() {
    const root = $("lg-root"), d = L.d;
    if (!root) return;
    if (!d || d.error) { root.innerHTML = `<div class="lg-empty">My League data is not available${d && d.reason ? ": " + esc(d.reason) : ""}.</div>`; return; }
    if (!d.season) { root.innerHTML = `<div class="lg-empty"><b>No My League season yet</b><br>Start My League in the game (UEFA Champion League, Y17, Y08, World Nation League...) and play a matchday.</div>`; return; }
    const me = d.table.find((r) => r.team === d.team) || {}, pos = d.table.indexOf(me) + 1;
    const tabs = [["table", "Table"], ["scorers", "Top scorers"], ["assists", "Top assists"]];
    root.innerHTML = `<section class="lg-head">${crest(d.team, "xl")}<div><small>${esc(d.competition_name)} · Season ${d.season}</small><b>${esc(T(d.team).name)}</b>
        <span class="lg-chips"><em>${d.done ? "Season over" : `Matchday ${d.round} / ${d.rounds}`}</em><em>${pos ? pos + (pos === 1 ? "st" : pos === 2 ? "nd" : pos === 3 ? "rd" : "th") : "—"}</em><em>${me.pts ?? 0} pts</em>${(d.form || []).map((f) => `<i class="lg-f f${f}">${f}</i>`).join("")}</span></div>
        ${d.done ? `<button class="lg-review" id="lg-review">Season review</button>` : ""}</section>
      <nav class="lg-tabs">${tabs.map(([k, n]) => `<button class="${L.tab === k ? "on" : ""}" data-lgtab="${k}">${n}</button>`).join("")}</nav>
      <section class="lg-card">${L.tab === "table" ? rowsTable(d) : L.tab === "scorers" ? rowsPlayers(d.scorers, "G") : rowsPlayers(d.assists, "A")}</section>`;
    root.querySelectorAll("[data-lgtab]").forEach((b) => b.onclick = () => { L.tab = b.dataset.lgtab; draw(); });
    if ($("lg-review")) $("lg-review").onclick = () => review();
    rescan(root);
    const key = d.competition + ":" + d.season;
    if (d.done && d.summary && localStorage.getItem("rc30-review") !== key) { try { localStorage.setItem("rc30-review", key); } catch (e) {} review(); }
  }
  function rescan(root) {          // portraits are lazy: the editor's observer picks them up once they are in the DOM
    const U = window.EditorUI && window.EditorUI.U;
    if (!U || !U.portrait) return;
    root.querySelectorAll('[data-lgface="1"]').forEach((el) => { const n = U.portrait({ id: el.dataset.id }, parseInt(el.style.width) || 34); n.classList.add("lg-face"); el.replaceWith(n); });
  }

  // season review: a short story in five cards, one tap each
  function review() {
    const d = L.d, s = d.summary; if (!s) return;
    const me = s.you || {}, pos = d.table.findIndex((r) => r.team === d.team) + 1;
    const boot = s.boot[0], pm = s.playmaker[0];
    const verdict = pos === 1 ? "Champions. A season nobody will forget." : pos <= 3 ? "On the podium - close enough to taste it." : pos <= Math.ceil(d.table.length / 2) ? "Solid, but the giants stayed out of reach." : "A season to learn from.";
    const cards = [
      `<div class="rv-k">Champions</div>${crest(s.champion, "xxl")}<h2>${esc(T(s.champion).name)}</h2><p>${s.champion_pts} points · ${esc(d.competition_name)} season ${d.season}</p>`,
      `<div class="rv-k">Your season</div>${crest(d.team, "xxl")}<h2>${pos}${pos === 1 ? "st" : pos === 2 ? "nd" : pos === 3 ? "rd" : "th"} · ${me.pts ?? 0} pts</h2><p>${me.w ?? 0} wins · ${me.d ?? 0} draws · ${me.l ?? 0} defeats · ${me.gf ?? 0}-${me.ga ?? 0}</p><p class="rv-v">${verdict}</p>`,
      boot ? `<div class="rv-k">Golden Boot</div>${face(boot.pid, 110)}<h2>${esc(boot.name)}</h2><p>${boot.n} goals · ${esc(T(boot.team).name)}</p>${s.boot.slice(1, 3).map((p) => `<p class="rv-s">${esc(short(p.name))} ${p.n}</p>`).join("")}` : "",
      pm ? `<div class="rv-k">Playmaker</div>${face(pm.pid, 110)}<h2>${esc(pm.name)}</h2><p>${pm.n} assists · ${esc(T(pm.team).name)}</p>` : "",
      `<div class="rv-k">Numbers</div><div class="rv-grid"><span><small>Best attack</small>${crest(s.best_attack)}<b>${esc(T(s.best_attack).short)}</b></span><span><small>Best defence</small>${crest(s.best_defence)}<b>${esc(T(s.best_defence).short)}</b></span>${(s.your_top || []).slice(0, 2).map((p) => `<span><small>Your top scorer</small>${face(p.pid, 40)}<b>${esc(short(p.name))} · ${p.n}</b></span>`).join("")}</div>`,
    ].filter(Boolean);
    let i = 0;
    const sheet = document.createElement("div"); sheet.className = "rv"; document.body.appendChild(sheet);
    const paint = () => {
      sheet.innerHTML = `<div class="rv-box"><button class="rv-x" aria-label="Close">✕</button><div class="rv-card">${cards[i]}</div>
        <div class="rv-dots">${cards.map((_, k) => `<i class="${k === i ? "on" : ""}"></i>`).join("")}</div>
        <button class="rv-next">${i < cards.length - 1 ? "Next ›" : "Close"}</button></div>`;
      rescan(sheet);
      sheet.querySelector(".rv-x").onclick = () => sheet.remove();
      sheet.querySelector(".rv-next").onclick = () => { if (i < cards.length - 1) { i++; paint(); } else sheet.remove(); };
    };
    paint();
  }

  document.addEventListener("DOMContentLoaded", () => {
    const page = $("league"); if (!page) return;
    new MutationObserver(() => { if (!page.hidden) load(); }).observe(page, { attributes: true, attributeFilter: ["hidden"] });
  });
})();
