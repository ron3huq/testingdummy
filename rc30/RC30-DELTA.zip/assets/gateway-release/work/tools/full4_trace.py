"""Keep compact last-active hook counters across launcher restarts; no save rows."""
from pathlib import Path
import json,os,time
HERE=Path(__file__).resolve().parent
KEYS={
 'face':('identity_profiles','shirt_name_changes','shirt_name_failures','shirt_name_last_card','native_ui_name_changes','native_ui_name_last_card','native_shirt_setter_intercepts','record_name_fields_updated','record_name_field_rejections','shirt_render_text_replaced','font_name_resource_paths','shirt_resource_key_calls',
  # RC30.16: face hook evidence for the GLB / RC30 profiles (kept after the game closes)
  'rc30_stats','rc30_face_cards','rc30_glb_table','rc30_glb_status','rc30_last_face','rc30_last_profile','rc30_last_path','rc30_last_redirect','rc30_probe_error','load_calls','target_calls','redirects','nonnull_callbacks','null_callbacks','skipped_face_id','face_profile_reads','last_target_id','last_face_id','last_face_profile','last_asset_path','last_redirected_asset_path','last_common_head_mesh'),
 'accessories':('wrist_loader','accessory_vector_status','accessory_packed_status','editor_status','appearance_error','editor_error','cached_gameplan')}
def record(kind,state,data):
 if state!='HOOK_ACTIVE'or kind not in KEYS:return
 try:
  out={'version':'V19.1-FULL8-RC7','historical':True,'pid':os.getpid(),'captured_unix':time.time(),'state':state,'counters':{k:data[k]for k in KEYS[kind]if k in data}}
  p=HERE/('full4-last-active-'+kind+'.json');tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(out,separators=(',',':')));tmp.replace(p)
 except Exception:pass

def previous():
 out={}
 for kind in KEYS:
  try:
   p=HERE/('full4-last-active-'+kind+'.json')
   if p.stat().st_size<=32768:out[kind]=json.loads(p.read_text())
  except (OSError,ValueError):pass
 return out
