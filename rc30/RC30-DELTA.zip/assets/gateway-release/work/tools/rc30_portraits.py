"""RC30: launcher portraits without waiting on the network every time.

The launcher asks editor_portrait for each visible card; most cards have no portrait inside the game files, so the page
fetched efimg.com for every card on every visit (2.5 s timeout, four at a time).  Here a miss is downloaded once in the
background and kept on the device (files/embedded-gateway/work/portrait-cache/<id>.png, at most ~60 MB, oldest first out);
the next request for that card is answered locally.  Card photos imported by the user still win: they come from the
original handler, which runs first.
"""
import base64, functools, json, os, queue, re, threading, time
from pathlib import Path

DIR = Path(__file__).resolve().parents[1] / 'portrait-cache'
URL = 'https://efimg.com/efootballhub22/images/player_cards/%s_l.png'
LIMIT = 60 * 1024 * 1024
_q = queue.Queue(maxsize=400)
_pending = set()
_lock = threading.Lock()
_started = False
_state = {'hits': 0, 'downloads': 0, 'failures': 0}


def _path(pid):
    return DIR / ('%s.png' % pid)


def _trim():
    try:
        files = sorted(DIR.glob('*.png'), key=lambda p: p.stat().st_mtime)
        total = sum(p.stat().st_size for p in files)
        while files and total > LIMIT:
            p = files.pop(0); total -= p.stat().st_size; p.unlink()
    except OSError:
        pass


def _worker():
    import urllib.request
    while True:
        pid = _q.get()
        try:
            dst = _path(pid)
            if not dst.exists():
                req = urllib.request.Request(URL % pid, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(req, timeout=8) as r:
                    data = r.read(2 * 1024 * 1024)
                if data[:8] == b'\x89PNG\r\n\x1a\n':
                    tmp = dst.with_suffix('.tmp'); tmp.write_bytes(data); tmp.replace(dst)
                    _state['downloads'] += 1
                    if _state['downloads'] % 50 == 0:
                        _trim()
                else:
                    _state['failures'] += 1
        except Exception:
            _state['failures'] += 1
        finally:
            with _lock:
                _pending.discard(pid)


def _start():
    global _started
    if _started:
        return
    DIR.mkdir(parents=True, exist_ok=True)
    for _ in range(6):
        threading.Thread(target=_worker, daemon=True, name='rc30-portrait').start()
    _started = True


def lookup(pid):
    """Local copy or None; a miss is queued for download."""
    if not re.fullmatch(r'[0-9]{1,18}', pid):
        return None
    p = _path(pid)
    if p.exists():
        _state['hits'] += 1
        try:
            os.utime(p, None)
        except OSError:
            pass
        return p.read_bytes()
    _start()
    with _lock:
        if pid not in _pending:
            try:
                _q.put_nowait(pid); _pending.add(pid)
            except queue.Full:
                pass
    return None


def install(module):
    if getattr(module.manage, '_rc30_portraits', False):
        return
    old = module.manage

    @functools.wraps(old)
    def manage(action, payload=''):
        out = old(action, payload)
        if action == 'editor_portrait':
            try:
                r = json.loads(out)
                if isinstance(r, dict) and not r.get('found'):
                    pid = str(json.loads(payload or '{}').get('id', ''))
                    data = lookup(pid)
                    if data:
                        return json.dumps({'found': True, 'png': base64.b64encode(data).decode(), 'source': 'rc30-cache'})
            except Exception:
                pass
        return out
    manage._rc30_portraits = True
    module.manage = manage
