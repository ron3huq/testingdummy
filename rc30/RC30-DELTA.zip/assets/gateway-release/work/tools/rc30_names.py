"""RC30.15: player name and name on the shirt for any card from Transfer · Edit Member (owned or not).
Stored in the same per-card identity profiles as the player editor (ui711_profiles), which the game applies
natively by card id (noodle_identity_add) at the next game launch."""
import copy, functools, json


def _current(pid):
    import profile_editor as P
    row = P.merged().get(pid, {})
    name = row.get('name')
    if not name:
        try:
            import editor_names
            name = editor_names.NAMES.get(pid)
        except Exception:
            name = None
    if not name:
        try:
            import motion_editor
            name = motion_editor.donors().get(pid, {}).get('name')
        except Exception:
            pass
    return {'id': pid, 'name': name or '', 'shirt': row.get('shirt', '')}


def handle(conn, action, req):
    import profile_editor as P, body_dimensions as body
    pid = str(req.get('id', '')).strip()
    if not pid.isdigit() or len(pid) > 18:
        raise ValueError('Invalid card ID')
    with P._lock:
        P.load(conn)
        if action == 'rc30_name_get':
            return _current(pid)
        if body.engine_loaded():
            raise ValueError('Close and reopen the app; edit before Enter Game')
        if conn.in_transaction:
            raise ValueError('Another save operation is active')
        name = str(req.get('name', '')).strip(); shirt = str(req.get('shirt', '')).strip().upper()
        changes = {}
        if name:
            changes['name'] = name
        if shirt:
            changes['shirt'] = shirt
        if not changes:
            raise ValueError('Enter a name or a shirt name')
        P.validate(changes)
        updated = copy.deepcopy(P.profiles); updated[pid] = dict(P.profiles.get(pid, {}), **changes)
        if len(updated) > 1024:
            raise ValueError('Maximum 1024 customized card profiles')
        conn.execute('BEGIN IMMEDIATE')
        try:
            conn.execute('INSERT OR REPLACE INTO meta(key,value)VALUES(?,?)', (P.KEY, json.dumps(updated, separators=(',', ':'))))
            conn.commit()
        except Exception:
            conn.rollback(); raise
        P.profiles = updated; P.refresh()
        return {'saved': True, 'id': pid, 'name': updated[pid].get('name', ''), 'shirt': updated[pid].get('shirt', '')}


def install(module):
    if getattr(module.manage, '_rc30_names', False):
        return
    old = module.manage

    @functools.wraps(old)
    def manage(action, payload=''):
        if action in ('rc30_name_get', 'rc30_name_apply'):
            try:
                return json.dumps(handle(module._logic.conn, action, json.loads(payload or '{}')), ensure_ascii=False)
            except Exception as exc:
                return json.dumps({'error': str(exc)[:300]})
        return old(action, payload)
    manage._rc30_names = True
    module.manage = manage
