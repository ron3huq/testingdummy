"""Minimal UE4.26 IoStore (utoc/ucas) reader: AES-256-ECB + zlib (game data research)."""
import struct,sys,zlib
from cryptography.hazmat.primitives.ciphers import Cipher,algorithms,modes
KEY=bytes.fromhex('4552d45005dfe94964893f4925ec747d3d591401e060ed8b3d58be5721c81295')
def dec(b):
    d=Cipher(algorithms.AES(KEY),modes.ECB()).decryptor();return d.update(b)+d.finalize()
class Toc:
    def __init__(s,utoc):
        d=open(utoc,'rb').read();s.ucas=utoc[:-4]+'ucas'
        hs,ents,blocks,bes,ncm,cml,bs,dirsz,parts=struct.unpack_from('<IIIIIIIII',d,20)
        s.flags=d[16+4+36+8+16];s.bs=bs;o=hs
        s.ids=[d[o+i*12:o+i*12+12] for i in range(ents)];o+=ents*12
        s.offlen=[]
        for i in range(ents):
            x=d[o+i*10:o+i*10+10];off=int.from_bytes(x[0:5],'big');ln=int.from_bytes(x[5:10],'big');s.offlen.append((off,ln))
        o+=ents*10
        s.blocks=[]
        for i in range(blocks):
            x=d[o+i*12:o+i*12+12];off=int.from_bytes(x[0:5],'little');csz=int.from_bytes(x[5:8],'little');usz=int.from_bytes(x[8:11],'little');m=x[11];s.blocks.append((off,csz,usz,m))
        o+=blocks*12
        s.methods=[d[o+i*cml:o+(i+1)*cml].split(b'\0')[0].decode() for i in range(ncm)];o+=ncm*cml
        di=dec(d[o:o+dirsz]) if s.flags&2 else d[o:o+dirsz]
        s.files=s._dir(di)
    def _dir(s,b):
        p=0
        def i32():
            nonlocal p;v=struct.unpack_from('<i',b,p)[0];p+=4;return v
        def fstr():
            nonlocal p;n=i32()
            if n<0:r=b[p:p-2*n].decode('utf-16-le').rstrip('\0');p+=-2*n
            else:r=b[p:p+n].decode('latin1').rstrip('\0');p+=n
            return r
        mount=fstr();nd=i32();dirs=[struct.unpack_from('<IIII',b,p+16*i) for i in range(nd)];p+=16*nd
        nf=i32();files=[struct.unpack_from('<III',b,p+12*i) for i in range(nf)];p+=12*nf
        ns=i32();strs=[fstr() for _ in range(ns)]
        out={}
        NONE=0xffffffff
        def walk(di,path):
            name,child,sib,ff=dirs[di]
            here=path+(strs[name]+'/' if name!=NONE else '')
            f=ff
            while f!=NONE:
                n,nxt,ud=files[f];out[here+strs[n]]=ud;f=nxt
            c=child
            while c!=NONE:walk(c,here);c=dirs[c][2]
        walk(0,mount);return out
    def read(s,idx):
        off,ln=s.offlen[idx];bs=s.bs;first=off//bs;last=(off+ln-1)//bs
        out=bytearray();f=open(s.ucas,'rb')
        for bi in range(first,last+1):
            boff,csz,usz,m=s.blocks[bi];f.seek(boff);raw=f.read((csz+15)&~15)
            if s.flags&2:raw=dec(raw)
            raw=raw[:csz]
            out+=raw if m==0 else zlib.decompress(raw)
        st=off-first*bs;return bytes(out[st:st+ln])
if __name__=='__main__':
    t=Toc(sys.argv[1]);print(len(t.files),t.methods)
    for k in t.files:
        if any(x in k.lower() for x in sys.argv[2:]):print(k,t.files[k])
