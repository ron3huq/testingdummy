"""RC30.12 kit studio: turn a picture into a home or away kit for a My League club (UCL, Saudi Pro League, World Nation
League, Y17, Y08), the way the RC30 Juventus / PSG kits were made.

Launcher -> editor op "celebrations" with {"rc30kit": op, ...} (Java passes it to editor_celebrations; we answer it).
Picture -> 1024x1024 texture in the game's uniform layout:
  * "template": a PES / eFootball uniform template (same layout as the game) is used as it is;
  * "photo": a picture of the real shirt (front, optional back) is laid onto the layout: chest panel from the photo,
    back from the photo's back or the shirt pattern without the chest logos, sleeves / shorts / socks / trim in colours.
Each kit gets one of 80 virtual kits (teams 5101-5140, slots 1st/2nd; realUni in dt870 from the build) and is written as
T_u51xxp*_Uni_D + recoloured numbers + menu pictures into container pc9540 (livedata/rc30-kits, advertised at login).
Native: before the Transfer editor commits its kit table, editor_kit_add(team, 0, slot, virtual kit) for every kit,
so the club wears it in every competition.  Takes effect after closing and reopening the app.
"""
import base64, functools, hashlib, io, json, pickle, shutil, struct, threading, time, traceback, types
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DATA = ROOT / 'rc30-kits'
LIVE = ROOT / 'livedata' / 'rc30-kits'
REG = DATA / 'kits.json'
CNAME = 'pc9540'
COMPS = [(122, 'UEFA Champion League'), (125, 'Saudi Pro League'), (128, 'World Nation League'), (518, 'Y17 Champion League'),
         (473, 'Y08 Champion League')]
POOL = [(v, k) for v in range(5101, 5141) for k in (0, 1)]
LOW = 'character/Uniform/LowTextures/'
TH = 'ui/Data/Thumbnail/Uniform/'
MAX_IMAGE = 12 * 1024 * 1024
_lock = threading.RLock()
_job = {'state': 'IDLE'}
_status = {'native': None, 'error': None}


# ---------------- registry ----------------
def _registry():
    try:
        r = json.loads(REG.read_text())
        r.setdefault('kits', {})
        return r
    except Exception:
        return {'kits': {}}


def _save(reg):
    DATA.mkdir(parents=True, exist_ok=True)
    tmp = REG.with_suffix('.tmp'); tmp.write_text(json.dumps(reg, indent=1)); tmp.replace(REG)


def _key(team, slot):
    return '%d:%d' % (int(team), int(slot))


# ---------------- names ----------------
def _config():
    import myleague_worlds
    return myleague_worlds.config()


def _team_name(cfg, tid):
    n = cfg.get('team_names', {}).get(str(tid))
    if n and n.get('name'):
        return n['name']
    try:
        import transfer_editor
        return transfer_editor.team_names().get(int(tid)) or 'Team %s' % tid
    except Exception:
        return 'Team %s' % tid


def teams(cid):
    cfg = _config(); reg = _registry()['kits']
    league = cfg['leagues'].get(str(cid)) or {}
    out = []
    for t in league.get('teams', []):
        t = int(t)
        out.append({'id': t, 'name': _team_name(cfg, t),
                    'kits': {str(s): _public(reg[_key(t, s)]) for s in (0, 1) if _key(t, s) in reg}})
    return out


def _public(row):
    return {k: row.get(k) for k in ('team', 'slot', 'name', 'thumb', 'created', 'state')}


# ---------------- images ----------------
def _image(b64):
    from PIL import Image, ImageOps
    raw = base64.b64decode(b64.split(',', 1)[-1])
    if len(raw) > MAX_IMAGE:
        raise ValueError('Picture is larger than 12 MB')
    im = Image.open(io.BytesIO(raw)); im = ImageOps.exif_transpose(im)
    if im.mode in ('RGBA', 'LA', 'P'):
        im = im.convert('RGBA'); bg = Image.new('RGBA', im.size, (255, 255, 255, 255)); bg.alpha_composite(im); im = bg
    return im.convert('RGB')


def _hex(c, default):
    try:
        c = str(c).lstrip('#')
        return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4)) if len(c) == 6 else default
    except Exception:
        return default


def _to_hex(c):
    return '#%02x%02x%02x' % tuple(int(x) for x in c[:3])


def _shirt_mask(im):
    """Foreground (the shirt) of a product photo: everything that differs from the border colour, largest blob box."""
    import numpy as np
    a = np.asarray(im.convert('RGB')).astype(np.int32)
    border = np.concatenate([a[0], a[-1], a[:, 0], a[:, -1]])
    bg = np.median(border, axis=0)
    d = np.abs(a - bg).sum(2)
    m = d > 48
    if m.mean() < .2 or m.mean() > .97:           # no clean background (the shirt fills the frame): the whole picture is the shirt
        m = np.ones(m.shape, bool)
    ys, xs = np.nonzero(m)
    y0, y1 = np.percentile(ys, [.5, 99.5]).astype(int); x0, x1 = np.percentile(xs, [.5, 99.5]).astype(int)
    return m, (int(x0), int(y0), int(x1) + 1, int(y1) + 1)


def _dominant(a, mask):
    import numpy as np
    px = a[mask]
    if len(px) == 0:
        return (200, 200, 200)
    q = (px // 24).astype(np.int32)
    keys = q[:, 0] * 10000 + q[:, 1] * 100 + q[:, 2]
    vals, counts = np.unique(keys, return_counts=True)
    top = vals[np.argmax(counts)]
    sel = px[keys == top]
    return tuple(int(x) for x in np.median(sel, axis=0))


def analyse(front):
    """Colours read from the shirt photo: body, sleeves, trim (collar/cuffs)."""
    import numpy as np
    a = np.asarray(front).astype(np.int32)
    m, (x0, y0, x1, y1) = _shirt_mask(front)
    w, h = x1 - x0, y1 - y0
    region = np.zeros(m.shape, bool)
    region[y0 + int(h * .45):y0 + int(h * .95), x0 + int(w * .30):x0 + int(w * .70)] = True
    body = _dominant(a, m & region)
    sl = np.zeros(m.shape, bool)
    sl[y0 + int(h * .12):y0 + int(h * .38), x0:x0 + int(w * .16)] = True
    sl[y0 + int(h * .12):y0 + int(h * .38), x1 - int(w * .16):x1] = True
    sleeve = _dominant(a, m & sl) if (m & sl).sum() > 50 else body
    col = np.zeros(m.shape, bool)
    col[y0:y0 + int(h * .10), x0 + int(w * .38):x0 + int(w * .62)] = True
    trim = _dominant(a, m & col) if (m & col).sum() > 30 else sleeve
    lum = .299 * body[0] + .587 * body[1] + .114 * body[2]
    return {'body': body, 'sleeves': sleeve, 'trim': trim, 'numbers': (24, 24, 24) if lum > 150 else (245, 245, 245),
            'box': (x0, y0, x1, y1)}


# game uniform layout (1024 x 1024, the layout of every RC26 kit texture)
FRONT = (330, 470, 694, 1000)       # chest panel, upright
BACK = (330, 40, 694, 470)          # back panel, upside down
SIDES = ((0, 40, 330, 355), (694, 40, 1024, 355))           # sleeves
SOCKS = ((0, 355, 205, 605), (819, 355, 1024, 605))
SHORTS = ((0, 605, 330, 1004), (694, 605, 1024, 1004))
TRIM = (0, 0, 260, 40)


def texture(req):
    """The 1024 x 1024 uniform texture and the colours used (for the numbers and menu pictures)."""
    from PIL import Image, ImageFilter
    import numpy as np
    front = _image(req['front'])
    mode = req.get('mode', 'photo')
    if mode == 'template':
        w, h = front.size
        if abs(w - h) > .08 * max(w, h):        # crop a centred square
            s = min(w, h); front = front.crop(((w - s) // 2, (h - s) // 2, (w - s) // 2 + s, (h - s) // 2 + s))
        tex = front.resize((1024, 1024), Image.LANCZOS)
        a = np.asarray(tex).astype(np.int32)
        body = _dominant(a, np.zeros(a.shape[:2], bool) | True)
        shorts = _dominant(a[605:1004, 0:330], np.ones((399, 330), bool))
        socks = _dominant(a[355:605, 0:205], np.ones((250, 205), bool))
        lum = .299 * body[0] + .587 * body[1] + .114 * body[2]
        auto = {'body': body, 'sleeves': body, 'trim': body, 'shorts': shorts, 'socks': socks,
                'numbers': (24, 24, 24) if lum > 150 else (245, 245, 245)}
        cols = {k: _hex(req.get(k), v) for k, v in auto.items()}
        return tex, cols, auto
    info = analyse(front)
    auto = {'body': info['body'], 'sleeves': info['sleeves'], 'trim': info['trim'], 'shorts': info['body'], 'socks': info['body'],
            'numbers': info['numbers']}
    cols = {k: _hex(req.get(k), v) for k, v in auto.items()}
    tex = Image.new('RGB', (1024, 1024), cols['body'])
    x0, y0, x1, y1 = info['box']; w, h = x1 - x0, y1 - y0
    # chest: the torso between the sleeves, from below the collar
    torso = front.crop((x0 + int(w * .24), y0 + int(h * .13), x1 - int(w * .24), y1 - int(h * .02)))
    fw, fh = FRONT[2] - FRONT[0], FRONT[3] - FRONT[1]
    tex.paste(torso.resize((fw, fh), Image.LANCZOS), FRONT[:2])
    # back: the back photo if given, else the lower torso (pattern without chest logos) repeated
    if req.get('back'):
        b = _image(req['back']); bi = analyse(b); bx0, by0, bx1, by1 = bi['box']; bw, bh = bx1 - bx0, by1 - by0
        back = b.crop((bx0 + int(bw * .24), by0 + int(bh * .13), bx1 - int(bw * .24), by1 - int(bh * .02)))
    else:
        strip = torso.crop((0, int(torso.size[1] * .62), torso.size[0], torso.size[1]))
        back = Image.new('RGB', (strip.size[0], strip.size[1] * 3))
        for k in range(3):
            back.paste(strip if k % 2 == 0 else strip.transpose(Image.FLIP_TOP_BOTTOM), (0, k * strip.size[1]))
    bw_, bh_ = BACK[2] - BACK[0], BACK[3] - BACK[1]
    tex.paste(back.resize((bw_, bh_), Image.LANCZOS).rotate(180), BACK[:2])
    for box in SIDES:
        tex.paste(cols['sleeves'], box)
    for box in SOCKS:
        tex.paste(cols['socks'], box)
    for box in SHORTS:
        tex.paste(cols['shorts'], box)
    tex.paste(cols['trim'], TRIM)
    # soften the seams between the photo panels and the flat colours
    blur = tex.filter(ImageFilter.GaussianBlur(2))
    m = Image.new('L', (1024, 1024), 0)
    from PIL import ImageDraw
    d = ImageDraw.Draw(m)
    for bx in (FRONT, BACK):
        d.rectangle(bx, outline=255, width=4)
    tex.paste(blur, (0, 0), m)
    return tex, cols, auto


def _png_url(img, size=None):
    if size:
        img = img.copy(); img.thumbnail(size)
    b = io.BytesIO(); img.save(b, 'PNG', optimize=False)
    return 'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode()


def mockup(tex, cols):
    """A small flat front / back view for the launcher."""
    from PIL import Image, ImageDraw
    W, H = 360, 230
    out = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    front = tex.crop(FRONT).resize((120, 150)); back = tex.crop(BACK).rotate(180).resize((120, 150))
    for k, panel in enumerate((front, back)):
        ox = 30 + k * 180
        sh = Image.new('RGBA', (160, 200), (0, 0, 0, 0)); d = ImageDraw.Draw(sh)
        d.polygon([(0, 30), (40, 8), (60, 8), (60, 50), (0, 70)], fill=cols['sleeves'])
        d.polygon([(160, 30), (120, 8), (100, 8), (100, 50), (160, 70)], fill=cols['sleeves'])
        sh.paste(panel, (20, 8))
        d.ellipse((62, 2, 98, 18), fill=cols['trim'])
        d.rectangle((24, 160, 136, 196), fill=cols['shorts'])
        out.alpha_composite(sh, (ox - 10, 4))
        d2 = ImageDraw.Draw(out)
        d2.rectangle((ox + 20, 202, ox + 48, 228), fill=cols['socks']); d2.rectangle((ox + 92, 202, ox + 120, 228), fill=cols['socks'])
    return out


# ---------------- ETC2 helpers ----------------
def _tex_info(b):
    for fmt in (b'PF_ETC2_RGBA\0', b'PF_ETC2_RGB\0', b'PF_B8G8R8A8\0'):
        i = b.rfind(fmt)
        if i > 0:
            break
    w, h, _, n = struct.unpack_from('<IIIi', b, i - 16)
    size = {b'PF_ETC2_RGBA\0': w * h, b'PF_ETC2_RGB\0': w * h // 2, b'PF_B8G8R8A8\0': w * h * 4}[fmt]
    j = b.rfind(struct.pack('<III', w, h, 1))
    if j <= i + len(fmt):
        raise ValueError('texture layout')
    return {'w': w, 'h': h, 'fmt': fmt[:-1].decode(), 'off': j - size, 'size': size}


def _tex_replace(b, data):
    i = _tex_info(b)
    if len(data) != i['size']:
        raise ValueError('texture size %d != %d' % (len(data), i['size']))
    return b[:i['off']] + bytes(data) + b[i['off'] + i['size']:]


def _encode(img, alpha):
    rgba = img.convert('RGBA').tobytes()
    try:
        import v32_diy_face_codec as C
        return bytes(C.encode(rgba, img.size[0], img.size[1], bool(alpha)))
    except Exception:
        import etcpak                                   # desktop test harness only
        return (etcpak.compress_etc2_rgba if alpha else etcpak.compress_etc2_rgb)(rgba, img.size[0], img.size[1])


def _solid_block(rgb):
    """One ETC2 colour block (differential mode, table 0) as close as possible to a flat colour."""
    best = None
    base = [max(0, min(31, round(c * 31 / 255))) for c in rgb]
    exp = [(b << 3) | (b >> 2) for b in base]
    for idx, mod in enumerate((2, 8, -2, -8)):
        err = sum(abs(max(0, min(255, e + mod)) - c) for e, c in zip(exp, rgb))
        if best is None or err < best[0]:
            best = (err, idx)
    idx = best[1]
    msb = 0xFFFF if idx & 2 else 0; lsb = 0xFFFF if idx & 1 else 0
    return bytes([base[0] << 3, base[1] << 3, base[2] << 3, 0b00000010]) + struct.pack('>HH', msb, lsb)


def _recolour_font(data, rgb):
    i = _tex_info(data)
    if i['fmt'] != 'PF_ETC2_RGBA':
        raise ValueError('font format')
    px = bytearray(data[i['off']:i['off'] + i['size']]); blk = _solid_block(rgb)
    for o in range(0, len(px), 16):
        px[o + 8:o + 16] = blk
    return data[:i['off']] + bytes(px) + data[i['off'] + i['size']:]


def _thumbs(tex, cols):
    """Menu kit pictures: the game's silhouettes filled with this kit's chest / shorts / socks."""
    from PIL import Image
    import numpy as np
    front = tex.crop((330, 470, 694, 940))
    out = []
    for name in ('r', 'full_r'):
        src = Image.open(HERE / ('rc30_kit_ref_%s.png' % name)).convert('RGBA')
        al = np.array(src)[:, :, 3]; lum = np.array(src.convert('L')).astype(np.float32)
        ys, xs = np.nonzero(al > 8)
        canvas = np.zeros((src.size[1], src.size[0], 4), np.uint8)
        y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
        if src.size[0] == src.size[1]:
            parts = [(y0, y1, front)]
        else:
            span = y1 - y0
            parts = [(y0, y0 + int(span * .40), front), (y0 + int(span * .40), y0 + int(span * .63), Image.new('RGB', (8, 8), cols['shorts'])),
                     (y0 + int(span * .63), y1, Image.new('RGB', (8, 8), cols['socks']))]
        for a, b, img in parts:
            if b <= a:
                continue
            fill = np.array(img.resize((x1 - x0, b - a), Image.LANCZOS)).astype(np.float32)
            sh = lum[a:b, x0:x1]; m = al[a:b, x0:x1] > 8
            shade = np.clip(0.80 + 0.35 * (sh - sh[m].mean()) / 255., .6, 1.1) if m.any() else 1
            canvas[a:b, x0:x1, :3] = np.clip(fill * shade[..., None], 0, 255).astype(np.uint8); canvas[a:b, x0:x1, 3] = al[a:b, x0:x1]
        out.append(_encode(Image.fromarray(canvas, 'RGBA'), True))
    return out


# ---------------- containers ----------------
def _toc(name):
    from rc30_iostore import Toc
    p = ROOT / 'livedata' / (name + '_mobile_and.utoc')
    t = Toc(str(p)); t.raw = p.read_bytes(); t.hs = struct.unpack_from('<I', t.raw, 20)[0]; t.path = str(p)
    return t


def _header(t):
    i = next(i for i, x in enumerate(t.ids) if x[11] == 10)
    b = t.read(i)
    p = 12
    names = struct.unpack_from('<i', b, p)[0]; p += 4 + names
    hn = struct.unpack_from('<i', b, p)[0]; p += 4 + hn
    cnt = struct.unpack_from('<i', b, p)[0]; p += 4
    pids = list(struct.unpack_from('<%dQ' % cnt, b, p)); p += 8 * cnt
    slen = struct.unpack_from('<i', b, p)[0]; p += 4; st = b[p:p + slen]
    entries = {}
    for k, pk in enumerate(pids):
        e = st[16 * k:16 * k + 16]
        num, rel = struct.unpack_from('<II', e, 8)
        entries[pk] = (e[:8], list(struct.unpack_from('<%dQ' % num, st, 16 * k + 8 + rel)) if num else [])
    return entries


_tpl = {}


def _template(container, rel):
    """(bytes, store entry) of a package of one of the shipped containers."""
    if container not in _tpl:
        t = _toc(container); _tpl[container] = (t, _header(t))
    t, entries = _tpl[container]
    i = t.files['../../../PesMobile/Content/Assets/' + rel]
    return t.read(i), entries[int.from_bytes(t.ids[i][:8], 'little')]


def _writer():
    import photo_codec as P0
    src = Path(P0.__file__).read_text().replace("name='pc9311_mobile_and'", "name='%s_mobile_and'" % CNAME)
    W = types.ModuleType('rc30_' + CNAME); W.__file__ = P0.__file__
    exec(compile(src, 'rc30_' + CNAME, 'exec'), W.__dict__)
    return W


def _named(P, rel, old, new, data, entry):
    oldname = rel.rsplit('/', 1)[-1][:-7]; newname = oldname.replace(old, new)
    own = '/Game/Assets/' + rel[:-7]; dest = own.replace(old, new)
    data = P.rename(data, {oldname: newname, own: dest}, own, dest)
    return dest.split('/Game/Assets/', 1)[1] + '.uasset', struct.pack('<Q', P.pid(dest)) + b'\0\0\0\2', data, entry


def packages(tex, cols, v, vk):
    """Every package of one virtual kit: texture, five number fonts, two menu pictures."""
    P = _writer()
    key = 'u%04dp%d' % (v, vk + 1); uid = v * 16384 + vk
    out = []
    data, entry = _template('pc9298', LOW + 'T_u0351p1_Uni_D.uasset')
    out.append(_named(P, LOW + 'T_u0351p1_Uni_D.uasset', 'u0351p1', key, _tex_replace(data, _encode(tex, False)), entry))
    for f in ('FontName', 'FontLeg', 'FontChest', 'FontBack'):
        rel = LOW + 'T_u0352p1_%s_D.uasset' % f
        data, entry = _template('pc9298', rel)
        out.append(_named(P, rel, 'u0352p1', key, _recolour_font(data, cols['numbers']), entry))
    rel = LOW + 'T_u0352p1_FontName_Ex_D.uasset'
    data, entry = _template('pc9300', rel)
    out.append(_named(P, rel, 'u0352p1', key, _recolour_font(data, cols['numbers']), entry))
    r, fu = _thumbs(tex, cols)
    for sfx, px in (('_r', r), ('_full_r', fu)):
        rel = TH + 'uni20119552%s.uasset' % sfx
        data, entry = _template('pc9303', rel)
        out.append(_named(P, rel, 'uni20119552' + sfx, 'uni%d%s' % (uid, sfx), _tex_replace(data, px), entry))
    return out


def rebuild():
    """Write pc9540 from the stored packages of every kit; returns the container's file table."""
    reg = _registry(); W = _writer()
    t = _toc('pc9303')
    o = W.Bundle.__new__(W.Bundle); o.base = t; o.files = {}; o.entries = {}
    want = {}
    for k, row in sorted(reg['kits'].items()):
        p = DATA / 'packages' / (row['id'] + '.pkl')
        if not p.is_file():
            continue
        for path, idb, data, entry in pickle.loads(p.read_bytes()):
            o.put(path, idb, data, entry); want[path.rsplit('/', 1)[-1][:-7]] = data
    if not want:
        shutil.rmtree(LIVE, ignore_errors=True); reg['container'] = None; _save(reg)
        return None
    tmp = LIVE.with_name('rc30-kits.tmp')
    shutil.rmtree(tmp, ignore_errors=True); tmp.mkdir(parents=True)
    o.write(tmp)
    shutil.copyfile(ROOT / 'livedata' / 'pc9303_mobile_and.pak', tmp / (CNAME + '_mobile_and.pak'))
    h = hashlib.sha256()
    for ext in ('utoc', 'ucas'):
        h.update((tmp / ('%s_mobile_and.%s' % (CNAME, ext))).read_bytes())
    W.stamp_empty_pak(tmp / (CNAME + '_mobile_and.pak'), h.hexdigest())
    from rc30_iostore import Toc
    t2 = Toc(str(tmp / (CNAME + '_mobile_and.utoc')))
    got = {k.rsplit('/', 1)[-1][:-7]: t2.read(i) for k, i in t2.files.items()}
    if got != want:
        raise ValueError('Kit container read-back mismatch')
    shutil.rmtree(LIVE, ignore_errors=True); tmp.replace(LIVE)
    files = {}
    for ext in ('pak', 'utoc', 'ucas'):
        p = LIVE / ('%s_mobile_and.%s' % (CNAME, ext)); b = p.read_bytes()
        files[p.name] = {'size': len(b), 'sha256': hashlib.sha256(b).hexdigest(), 'relative': 'rc30-kits/' + p.name}
    reg = _registry(); reg['container'] = files; _save(reg)
    return files


# ---------------- jobs ----------------
def _free(reg, team, slot):
    row = reg['kits'].get(_key(team, slot))
    if row:
        return row['v'], row['vk']
    used = {(r['v'], r['vk']) for r in reg['kits'].values()}
    for v, k in POOL:
        if (v, k) not in used:
            return v, k
    raise ValueError('All 80 custom kit slots are used - remove a kit first')


def _apply(job, req):
    try:
        team, slot = int(req['team']), int(req['slot'])
        job.update(state='BUILDING', percent=10, message='Building the kit texture…')
        tex, cols, _ = texture(req)
        with _lock:
            reg = _registry(); v, vk = _free(reg, team, slot)
        job.update(percent=30, message='Compressing textures…')
        pk = packages(tex, cols, v, vk)
        kid = '%d-%d-%d' % (team, slot, int(time.time()))
        (DATA / 'packages').mkdir(parents=True, exist_ok=True)
        (DATA / 'packages' / (kid + '.pkl')).write_bytes(pickle.dumps(pk))
        cfg = _config()
        with _lock:
            reg = _registry(); old = reg['kits'].get(_key(team, slot))
            reg['kits'][_key(team, slot)] = {'id': kid, 'team': team, 'slot': slot, 'v': v, 'vk': vk, 'uid': v * 16384 + vk,
                                             'name': _team_name(cfg, team) + (' · Home' if slot == 0 else ' · Away'),
                                             'thumb': _png_url(tex.crop(FRONT), (90, 130)), 'created': int(time.time()),
                                             'colours': {k: _to_hex(c) for k, c in cols.items()}}
            _save(reg)
            job.update(percent=70, message='Writing the kit pack…')
            rebuild()
            if old and old.get('id') != kid:
                try:
                    (DATA / 'packages' / (old['id'] + '.pkl')).unlink()
                except OSError:
                    pass
        job.update(state='DONE', percent=100, message='Kit saved. Close and reopen the app, then play a My League match.')
    except Exception as exc:
        job.update(state='ERROR', message=str(exc)[:300], trace=traceback.format_exc()[-1500:])


def handle(req):
    op = req.get('rc30kit')
    if op == 'comps':
        return {'comps': [{'id': c, 'name': n} for c, n in COMPS], 'used': len(_registry()['kits']), 'max': len(POOL),
                'status': dict(_status)}
    if op == 'teams':
        cid = int(req.get('competition', 122))
        if cid not in dict(COMPS):
            raise ValueError('Unknown competition')
        return {'teams': teams(cid)}
    if op == 'preview':
        tex, cols, auto = texture(req)
        return {'texture': _png_url(tex, (512, 512)), 'mockup': _png_url(mockup(tex, cols)),
                'colours': {k: _to_hex(c) for k, c in cols.items()}, 'auto': {k: _to_hex(c) for k, c in auto.items()}}
    if op == 'apply':
        with _lock:
            if _job.get('state') == 'BUILDING':
                raise ValueError('Another kit is being built')
            _job.clear(); _job.update(state='BUILDING', percent=0, message='Starting…', team=req.get('team'), slot=req.get('slot'))
        threading.Thread(target=_apply, args=(_job, dict(req)), daemon=True, name='rc30-kit').start()
        return {'job': dict(_job)}
    if op == 'status':
        return {'job': {k: v for k, v in _job.items() if k != 'trace'}}
    if op == 'list':
        return {'kits': [_public(r) for r in sorted(_registry()['kits'].values(), key=lambda r: -r.get('created', 0))]}
    if op == 'remove':
        with _lock:
            reg = _registry(); row = reg['kits'].pop(_key(req['team'], req['slot']), None); _save(reg)
            if row:
                try:
                    (DATA / 'packages' / (row['id'] + '.pkl')).unlink()
                except OSError:
                    pass
            rebuild()
        return {'removed': bool(row)}
    raise ValueError('Unknown kit action')


# ---------------- native registration (called before the Transfer editor commits its kit table) ----------------
def configure(hook):
    import ctypes as C
    reg = _registry()
    if not reg['kits'] or not reg.get('container'):
        return
    real = hook.editor_kit_add; real.argtypes = [C.c_uint] * 4; real.restype = C.c_uint
    mine = {}
    for row in reg['kits'].values():
        mine[(int(row['team']), int(row['slot']))] = int(row['uid'])
    ok = 0
    for (team, slot), uid in mine.items():
        ok += real(team, 0, slot, uid) == 1
    _status['native'] = '%d/%d' % (ok, len(mine))

    def add(team, comp, slot, uid):
        if (int(team), int(slot)) in mine:
            return 1                     # the kit studio's kit wins over a Transfer-editor kit for the same slot
        return real(team, comp, slot, uid)
    add.argtypes = real.argtypes; add.restype = real.restype
    hook.editor_kit_add = add


def restore(hook):
    try:
        del hook.editor_kit_add
    except Exception:
        pass


def local_file(fname):
    files = _registry().get('container') or {}
    meta = files.get(fname)
    return ROOT / 'livedata' / meta['relative'] if meta else None


# ---------------- login advertisement ----------------
def advertise(value, port):
    reg = _registry(); files = reg.get('container')
    if not files or not isinstance(value, dict) or not isinstance(value.get('version_file'), str):
        return value
    r = {}
    for ext in ('pak', 'utoc', 'ucas'):
        meta = files['%s_mobile_and.%s' % (CNAME, ext)]
        p = ROOT / 'livedata' / meta['relative']
        if not p.is_file() or p.stat().st_size != meta['size']:
            return value
        r[ext] = meta
    ver = json.loads(value['version_file']); out = dict(value)
    item = {'name': CNAME, 'hash': r['pak']['sha256'], 'hashFileSize': r['pak']['size'], 'ucas': r['ucas']['sha256'],
            'ucasFileSize': r['ucas']['size'], 'utoc': r['utoc']['sha256'], 'utocFileSize': r['utoc']['size']}
    ver['dt880'] = [x for x in ver.get('dt880', []) if not isinstance(x, dict) or x.get('name') != CNAME] + [item]
    names = {'%s_mobile_and.%s' % (CNAME, ext) for ext in r}
    files_list = [x for x in (value.get('livedata_list') or []) if not isinstance(x, dict) or x.get('name') not in names]
    files_list += [{'name': '%s_mobile_and.%s' % (CNAME, ext), 'size': m['size'], 'url': 'http://127.0.0.1:%s/livedata/%s' % (port, m['relative'])}
                   for ext, m in r.items()]
    ver['version'] = int(ver.get('version', 0)) + 900 + int(r['utoc']['sha256'][:3], 16) % 997
    out['version_file'] = json.dumps(ver, separators=(',', ':')); out['livedata_list'] = files_list
    return out


def install(module):
    if getattr(module.manage, '_rc30_kits', False):
        return
    old = module.manage

    @functools.wraps(old)
    def manage(action, payload=''):
        if action == 'editor_celebrations' and payload and '"rc30kit"' in payload[:400]:
            try:
                return json.dumps(handle(json.loads(payload)))
            except Exception as exc:
                return json.dumps({'error': str(exc)[:300]})
        return old(action, payload)
    manage._rc30_kits = True
    module.manage = manage
    try:
        import photo_editor
        if not getattr(photo_editor.advertise, '_rc30_kits', False):
            prev = photo_editor.advertise

            def adv(value, port):
                out = prev(value, port)
                try:
                    return advertise(out, port)
                except Exception as exc:
                    _status['error'] = 'advertise: ' + str(exc)[:160]
                    return out
            adv._rc30_kits = True
            photo_editor.advertise = adv
    except Exception as exc:
        _status['error'] = str(exc)[:200]
