"""RC30.21 Team tactics for My League clubs: team playstyle, playstyle proficiency (team chemistry) and form A-E.

Playstyle   -> the club's two Tactics rows (byte 0: 0 Possession Game, 1 Quick Counter, 2 Long Ball Counter, 3 Long Ball,
               4 Out Wide, 5 Overload).  Measured on dt870: across 992 clubs byte 0 matches the manager's best proficiency.
Chemistry   -> the club manager's proficiency for that playstyle (Coach row, 7-bit fields; V32 diy_coach layout).
Both tables are patched in the game's memory once the engine has loaded its database (found by their first 4 KiB, written
through /proc/self/mem, re-checked every 20 s), so no game file changes and nothing happens if the tables are not found.
Form A-E    -> libselect_team.so condition hook reads a card -> level table (RW 0x10d0100) for every player of the club.
Launcher: editor op "celebrations" with {"rc30tac": op, ...}.
"""
import ctypes, functools, hashlib, json, re, struct, threading, time, traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CFG = ROOT / 'rc30-tactics.json'
DB_PATH = HERE / 'rc30_tactics_db.json'
STYLES = ['Possession Game', 'Quick Counter', 'Long Ball Counter', 'Long Ball', 'Out Wide', 'Overload']
FORMS = {'A': 4, 'B': 3, 'C': 2, 'D': 1, 'E': 0}
COMPS = [(122, 'UEFA Champion League'), (125, 'Saudi Pro League'), (128, 'World Nation League'), (518, 'Y17 Champion League'),
         (473, 'Y08 Champion League')]
TABLE_OFF, TABLE_MAX = 0x10d0100, 2040
_lock = threading.RLock()
_hook = None
_status = {'tactics_table': None, 'coach_table': None, 'applied': 0, 'scans': 0, 'form_rows': 0, 'error': None}
_addr = {}


@functools.lru_cache(maxsize=1)
def db():
    return json.loads(DB_PATH.read_text())


def config():
    try:
        d = json.loads(CFG.read_text())
        if isinstance(d, dict) and isinstance(d.get('teams'), dict):
            return d
    except Exception:
        pass
    return {'schema': 1, 'teams': {}}


def _save(d):
    tmp = CFG.with_suffix('.tmp'); tmp.write_text(json.dumps(d, indent=1)); tmp.replace(CFG)


def _team_list(cid):
    import rc30_kits
    return [{'id': t['id'], 'name': t['name']} for t in rc30_kits.teams(cid)]


def _row(tid):
    base = db()['teams'].get(str(tid))
    if base is None:
        return None
    cur = config()['teams'].get(str(tid), {})
    if cur.get('reset'):
        cur = {}
    style = int(cur.get('style', base['style']))
    prof = list(base.get('prof', [50] * 6))
    chem = int(cur.get('chemistry', prof[style]))
    return {'id': int(tid), 'style': style, 'chemistry': chem, 'form': cur.get('form'), 'coach': base.get('coach_name', ''),
            'native_style': base['style'], 'native_prof': prof, 'edited': bool(cur)}


# ---------------- memory tables ----------------
def _regions():
    out = []
    for line in open('/proc/self/maps'):
        p = line.split()
        if len(p) < 5 or not p[1].startswith('rw'):
            continue
        name = p[5] if len(p) > 5 else ''
        if name and not (name.startswith('[anon') or name == '[heap]' or name.startswith('/dev/ashmem') or 'scudo' in name
                         or 'malloc' in name or 'jemalloc' in name):
            continue
        a, b = (int(x, 16) for x in p[0].split('-'))
        if b - a >= 4096:
            out.append((a, b))
    return out


_CHUNK = bytearray(32 << 20)
_BLK = bytearray(4096)
_VER = bytearray(1 << 19)     # whole-table checks, also reused (no stray copies)


def _own_buffers():
    out = []
    for buf in (_CHUNK, _BLK, _VER):
        a = ctypes.addressof((ctypes.c_char * len(buf)).from_buffer(buf)); out.append((a, a + len(buf)))
    return out


def _find(sig, mem):
    """Addresses of the table (first 4 KiB identical), read through /proc/self/mem into two reused buffers only, so the
    scan never leaves copies of the table behind in the heap (they would be found and written later)."""
    head = bytes.fromhex(sig['head']); found = []; own = _own_buffers(); view = memoryview(_CHUNK)
    for a, b in _regions():
        if b - a < sig['bytes']:
            continue
        pos = a
        while pos < b:
            n = min(len(_CHUNK) - 64, b - pos)
            try:
                mem.seek(pos); got = mem.readinto(view[:n + 63] if pos + n < b else view[:n])
            except OSError:
                break
            i = _CHUNK.find(head, 0, got or 0)
            while i >= 0:
                at = pos + i
                if not any(lo <= at < hi for lo, hi in own) and _check(mem, at, sig):
                    found.append(at)
                i = _CHUNK.find(head, i + 1, got)
            pos += n
    return sorted(set(found))


def _check(mem, at, sig):
    try:
        mem.seek(at); n = mem.readinto(_BLK)
    except OSError:
        return False
    return n == 4096 and hashlib.sha256(_BLK).hexdigest() == sig['sha4k']


def _desired():
    """Row index -> packed value for every club ever edited; a reset club keeps an entry that restores its native row."""
    d = db(); want_tac, want_coach = {}, {}
    for t, cur in config()['teams'].items():
        base = d['teams'].get(t)
        if base is None:
            continue
        style = int(cur.get('style', base['style'])) if not cur.get('reset') else base['style']
        for idx, p in base['tactics']:
            want_tac[idx] = (p & ~0xff) | (style if not cur.get('reset') else (p & 0xff))
        if 'coach_row' in base:
            v = int.from_bytes(bytes.fromhex(base['coach_bits']), 'little')
            if not cur.get('reset') and 'chemistry' in cur:
                sh = d['prof_bits'][style]; v = (v & ~(127 << sh)) | (max(1, min(99, int(cur['chemistry']))) << sh)
            want_coach[base['coach_row']] = v
    return want_tac, want_coach


def _apply_memory():
    d = db(); want_tac, want_coach = _desired()
    with open('/proc/self/mem', 'r+b', buffering=0) as mem:
        if (not _addr.get('tactics') or not _addr.get('coach')) and _status['scans'] < 15 and time.time() - _addr.get('last_scan', 0) > 60:
            _status['scans'] += 1; _addr['last_scan'] = time.time()
            if not _addr.get('tactics'):
                _addr['tactics'] = _find(d['tactics'], mem)
            if not _addr.get('coach'):
                _addr['coach'] = _find(d['coach'], mem)
            _status['tactics_table'] = [hex(a) for a in _addr['tactics']] or None
            _status['coach_table'] = [hex(a) for a in _addr['coach']] or None
        n = 0
        for key, sig in (('tactics', d['tactics']), ('coach', d['coach'])):
            _addr[key] = [a for a in (_addr.get(key) or []) if _check_live(mem, a, key)]
        for base in _addr.get('tactics') or []:
            for idx, packed in want_tac.items():
                mem.seek(base + 12 * idx + 8); cur = mem.read(4)
                if len(cur) == 4 and struct.unpack('<I', cur)[0] != packed:
                    mem.seek(base + 12 * idx + 8); mem.write(struct.pack('<I', packed)); n += 1
        for base in _addr.get('coach') or []:
            for row, v in want_coach.items():
                at = base + d['coach_row'] * row + 16
                mem.seek(at); raw = mem.read(16)
                if len(raw) == 16 and int.from_bytes(raw, 'little') != v:
                    mem.seek(at); mem.write(v.to_bytes(16, 'little')); n += 1
        _status['applied'] += n


def _check_live(mem, at, key):
    """Still the game's table?  Sampled row ids (Tactics: club + plan, Coach: coach id) must be where they were."""
    d = db(); size = d[key]['bytes']; view = memoryview(_VER)
    try:
        mem.seek(at)
        if mem.readinto(view[:size]) != size:
            return False
    except OSError:
        return False
    rows = list(d['teams'].values())
    if key == 'tactics':
        return all(struct.unpack_from('<I', _VER, 12 * idx)[0] == int(tid) and (struct.unpack_from('<I', _VER, 12 * idx + 8)[0] & ~0xff) == (pk & ~0xff)
                   for tid, t in list(d['teams'].items())[::50] for idx, pk in t['tactics'])
    return all(struct.unpack_from('<Q', _VER, d['coach_row'] * t['coach_row'])[0] == t['coach'] for t in rows[::40] if 'coach' in t)


def _form_rows():
    rows = {}
    try:
        import transfer_editor
    except Exception:
        transfer_editor = None
    teams = config()['teams']
    for cid, _ in COMPS:
        for t in (_team_list(cid) if any(v.get('form') for v in teams.values()) else []):
            lvl = teams.get(str(t['id']), {}).get('form')
            if lvl not in FORMS:
                continue
            ids = set()
            try:
                row = transfer_editor.source(t['id'], cid) if transfer_editor else None
                ids |= {int(p['id']) for p in (row or {}).get('roster', [])}
            except Exception:
                pass
            for r in (transfer_editor.captures().values() if transfer_editor else []):
                if r.get('team_id') == t['id']:
                    ids |= {int(p['id']) for p in r.get('roster', [])}
            for c in ids:
                rows[c] = FORMS[lvl]
    return rows


def _write_form():
    if _hook is None:
        return
    rows = sorted(_form_rows().items())[:TABLE_MAX]
    base = ctypes.cast(_hook.condition_set_hook, ctypes.c_void_p).value - 0x2ce04
    t = base + TABLE_OFF
    ctypes.c_uint32.from_address(t).value = 0
    for i, (card, lvl) in enumerate(rows):
        ctypes.c_uint64.from_address(t + 8 + 16 * i).value = card
        ctypes.c_uint32.from_address(t + 16 + 16 * i).value = lvl
    ctypes.c_uint32.from_address(t).value = len(rows)
    _status['form_rows'] = len(rows)


def configure(hook):
    """select_team_runtime passes its libselect_team handle once the hooks are in."""
    global _hook
    _hook = hook
    try:
        _write_form()
    except Exception as exc:
        _status['error'] = 'form: ' + str(exc)[:160]


def _worker():
    last = None
    while True:
        try:
            import body_dimensions
            loaded = body_dimensions.engine_loaded()
        except Exception:
            loaded = False
        try:
            if loaded and config()['teams']:
                with _lock:
                    _apply_memory()
            stamp = (CFG.stat().st_mtime_ns if CFG.exists() else 0, int(time.time() // 60))
            if stamp != last and _hook is not None:
                last = stamp; _write_form()
        except Exception as exc:
            _status['error'] = str(exc)[:200]; _status['trace'] = traceback.format_exc()[-600:]
        time.sleep(20)


def handle(req):
    op = req.get('rc30tac')
    if op == 'comps':
        return {'comps': [{'id': c, 'name': n} for c, n in COMPS], 'styles': STYLES, 'forms': list(FORMS), 'status': dict(_status)}
    if op == 'teams':
        cid = int(req.get('competition', 122))
        if cid not in dict(COMPS):
            raise ValueError('Unknown competition')
        out = []
        for t in _team_list(cid):
            r = _row(t['id'])
            if r:
                r['name'] = t['name']; out.append(r)
        return {'teams': out}
    if op == 'save':
        tid = str(int(req['team']))
        if tid not in db()['teams']:
            raise ValueError('This club has no native tactics')
        style = int(req.get('style', 0)); chem = int(req.get('chemistry', 70)); form = req.get('form') or None
        if not 0 <= style < len(STYLES) or not 1 <= chem <= 99 or (form is not None and form not in FORMS):
            raise ValueError('Invalid tactics')
        with _lock:
            d = config(); d['teams'][tid] = {'style': style, 'chemistry': chem, **({'form': form} if form else {})}; _save(d)
        try:
            _write_form()
        except Exception:
            pass
        return {'saved': True, 'team': _row(tid)}
    if op == 'reset':
        tid = str(int(req['team']))
        with _lock:
            d = config(); d['teams'][tid] = {'reset': True}; _save(d)
            try:
                if _addr.get('tactics') or _addr.get('coach'):
                    _apply_memory()
            except Exception as exc:
                _status['error'] = str(exc)[:200]
        try:
            _write_form()
        except Exception:
            pass
        return {'reset': True, 'team': _row(tid)}
    if op == 'status':
        return dict(_status)
    raise ValueError('Unknown tactics action')


def install(module):
    if getattr(module.manage, '_rc30_tactics', False):
        return
    old = module.manage

    @functools.wraps(old)
    def manage(action, payload=''):
        if action in ('editor_celebrations', 'diy_model_list') and payload and '"rc30tac"' in payload[:400]:
            try:
                return json.dumps(handle(json.loads(payload)))
            except Exception as exc:
                return json.dumps({'error': str(exc)[:300]})
        return old(action, payload)
    manage._rc30_tactics = True
    module.manage = manage
    threading.Thread(target=_worker, daemon=True, name='rc30-tactics').start()
