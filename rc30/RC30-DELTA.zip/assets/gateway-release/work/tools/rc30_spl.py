"""RC30.13 Saudi Pro League: Al Qadsiah (team 117, on Feyenoord's native squad) plays with Julián Quiñones up front.
Once the game has captured the club's native squad (Transfer snapshot), its starting striker becomes Quiñones' card,
saved as an ordinary Transfer edit of competition 125 (so the user can still change it in Transfer).  Once per device."""
import json, threading
QADSIAH, COMP = 117, 125
QUINONES = '105624788652267'
UEDA = '132979'
MARK = 'rc30_spl_quinones_v1'
_status = {'state': 'IDLE'}


def seed(conn):
    import transfer_editor as T
    if conn.execute('SELECT 1 FROM meta WHERE key=?', (MARK,)).fetchone():
        _status['state'] = 'DONE'; return
    def mark():
        if not conn.in_transaction:
            conn.execute('INSERT OR REPLACE INTO meta(key,value)VALUES(?,?)', (MARK, '1')); conn.commit()
    if T.key(QADSIAH, COMP) in T.profiles:          # the user already edited the club: leave it alone
        mark(); _status['state'] = 'USER_EDIT'; return
    cur = T.source(QADSIAH, COMP)
    if cur is None:
        _status['state'] = 'WAITING_FOR_SNAPSHOT'; return
    team = json.loads(json.dumps(cur))
    ids = [p['id'] for p in team['roster']]
    if QUINONES in ids:
        mark(); _status['state'] = 'ALREADY'; return
    idx = ids.index(UEDA) if UEDA in ids[:11] else next((i for i, p in enumerate(team['roster'][:11]) if p.get('role') == 12), None)
    if idx is None:
        idx = next((i for i, p in enumerate(team['roster'][:11]) if p.get('role') in (11, 10, 9)), None)
    if idx is None:
        _status['state'] = 'NO_STRIKER'; return
    old = team['roster'][idx]['id']
    team['roster'][idx]['id'] = QUINONES
    team['captain'] = QUINONES if team.get('captain') == old else team.get('captain')
    team['kickers'] = [QUINONES if k == old else k for k in team.get('kickers', [])]
    T.save(conn, [{'team_id': QADSIAH, 'competition': COMP, 'revision': T.revision(cur), 'team': team}])
    mark(); _status.update(state='SAVED', replaced=old)


def install(module):
    try:
        seed(module._logic.conn)
    except Exception as exc:
        _status.update(state='ERROR', error=str(exc)[:200])
