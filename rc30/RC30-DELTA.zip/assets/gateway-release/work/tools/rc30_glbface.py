"""RC30: import a GLB head onto any card from the card studio, like V32's face import, on the RC26 face hook.

Upload: card studio -> POST /api/models/search {"rc30face": op, ...} (Java passes the body to diy_model_list; we answer it).
Convert: V32's own GLB converter (v32_diy_face_*, renamed so RC26's modules stay untouched) -> nine RealFace packages,
renamed to the RC26 profile RU0<slot> -> container pc95<20+slot> under livedata/rc30-glb/<slot>/ (served at login).
Native: libnoodle_hair.so has eight runtime slots; the card id of slot i is written into its table (0x110040 + 8*i) as soon
as the face hook is loaded, so the card renders profile RU0<i+1>.  Takes effect after closing and reopening the app.
"""
import base64, functools, hashlib, json, re, shutil, struct, threading, time, traceback, types
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DATA = ROOT / 'rc30-glb'
LIVE = ROOT / 'livedata' / 'rc30-glb'
TEMPLATE = ROOT / 'face-conversion'
ALLOW = ROOT / 'face-allowlist.json'
REG = DATA / 'faces.json'
SLOTS = 8
MAX_GLB = 32 * 1024 * 1024
_lock = threading.RLock()
_job = {'state': 'IDLE'}
_status = {'table_written': False, 'error': None}


def _registry():
    try:
        return json.loads(REG.read_text())
    except Exception:
        return {'slots': {}}


def _save(reg):
    DATA.mkdir(parents=True, exist_ok=True)
    tmp = REG.with_suffix('.tmp'); tmp.write_text(json.dumps(reg, indent=1)); tmp.replace(REG)


def container_name(slot):
    return 'pc95%02d' % (20 + slot)


# ---------- conversion ----------
def _v32():
    import v32_diy_face_convert as fc, v32_diy_face_packs as fp, v32_diy_face_pack_iostore as F, v32_diy_face_identity as I
    return fc, fp, F, I


def _retarget(F, I, packages, key, prof):
    names = {'SK_%s_Face' % key: 'SK_%s_Face' % prof, 'T_%s_Face_D' % key: 'T_%s_Face_D' % prof,
             'T_%s_Face_N' % key: 'T_%s_Face_N' % prof, 'T_%s_Face_SRO' % key: 'T_%s_Face_SRO' % prof,
             'T_%s_Hair_D' % key: 'T_%s01_Hair_D' % prof,
             'MI_%s_Head_FaceLegacy_HQ' % key: 'MI_%s01_Head_FaceLegacy_HQ' % prof, 'MI_%s_Head_FaceLegacy_MQ' % key: 'MI_%s01_Head_FaceLegacy_MQ' % prof,
             'MI_%s_Head_Hair_HQ' % key: 'MI_%s01_Head_Hair_HQ' % prof, 'MI_%s_Head_Hair_MQ' % key: 'MI_%s01_Head_Hair_MQ' % prof}
    if set(names) != set(packages):
        raise ValueError('Converted face is incomplete')
    mount = '/Game/Assets/character/RealFace/'
    strings = {mount + o: mount + n for o, n in names.items()}; strings.update(names)
    package_ids = {F.face_pid(o): F.face_pid(n) for o, n in names.items()}
    object_ids = {}
    for o, blob in packages.items():
        pn = F.package_names(blob); _, es, ee = struct.unpack_from('<3I', blob, 40)
        for at in range(es, ee, 72):
            g = struct.unpack_from('<Q', blob, at + 56)[0]
            if g == I.SENTINEL:
                continue
            obj = pn[struct.unpack_from('<I', blob, at + 16)[0] & 0x3fffffff]
            object_ids[g] = F.face_gid(names[o], names.get(obj, obj))
    out = {n: I._rename_package(packages[o], strings, package_ids, object_ids)[0] for o, n in names.items()}
    # RC26 faces use the simple hair material for HQ too (V32's HQ hair needs CR7 data RC26 does not ship)
    import photo_codec as P
    mq, hq = 'MI_%s01_Head_Hair_MQ' % prof, 'MI_%s01_Head_Hair_HQ' % prof
    out[hq] = P.rename(out[mq], {mount + mq: mount + hq, mq: hq}, mount + mq, mount + hq)
    for blob in out.values():
        if any(str(key) in x or '4522' in x for x in F.package_names(blob)):
            raise ValueError('Converted face still references its source identity')
    return out


def _writer(cname):
    import photo_codec as P0
    src = Path(P0.__file__).read_text().replace("name='pc9311_mobile_and'", "name='%s_mobile_and'" % cname)
    W = types.ModuleType('rc30_%s' % cname); W.__file__ = P0.__file__
    exec(compile(src, 'rc30_' + cname, 'exec'), W.__dict__)
    return W


def _container(F, packages, slot):
    from rc30_iostore import Toc
    cname = container_name(slot)
    tpl = ROOT / 'livedata' / 'pc9457_mobile_and.utoc'
    t = Toc(str(tpl)); t.raw = tpl.read_bytes(); t.hs = struct.unpack_from('<I', t.raw, 20)[0]; t.path = str(tpl)
    W = _writer(cname)
    o = W.Bundle.__new__(W.Bundle); o.base = t; o.files = {}; o.entries = {}
    for n, blob in packages.items():
        exports, bundles, imports = F.package_row(blob)
        o.put('character/RealFace/%s.uasset' % n, struct.pack('<Q', F.face_pid(n)) + b'\0\0\0\2', blob,
              (struct.pack('<II', exports, bundles), list(imports)))
    out = LIVE / str(slot); tmp = LIVE / ('%d.tmp' % slot)
    shutil.rmtree(tmp, ignore_errors=True); tmp.mkdir(parents=True)
    o.write(tmp)
    shutil.copyfile(str(tpl)[:-5] + '.pak', tmp / (cname + '_mobile_and.pak'))
    h = hashlib.sha256()
    for ext in ('utoc', 'ucas'):
        h.update((tmp / ('%s_mobile_and.%s' % (cname, ext))).read_bytes())
    W.stamp_empty_pak(tmp / (cname + '_mobile_and.pak'), h.hexdigest())
    t2 = Toc(str(tmp / (cname + '_mobile_and.utoc')))
    got = {k.rsplit('/', 1)[-1][:-7]: t2.read(i) for k, i in t2.files.items()}
    if got != packages:
        raise ValueError('Face container read-back mismatch')
    shutil.rmtree(out, ignore_errors=True); tmp.replace(out)
    files = {}
    for ext in ('pak', 'utoc', 'ucas'):
        p = out / ('%s_mobile_and.%s' % (cname, ext)); b = p.read_bytes()
        files[p.name] = {'size': len(b), 'sha256': hashlib.sha256(b).hexdigest(), 'relative': 'rc30-glb/%d/%s' % (slot, p.name)}
    return files


def _convert(job):
    try:
        fc, fp, F, I = _v32()
        man = hashlib.sha256((TEMPLATE / 'manifest.json').read_bytes()).hexdigest()
        allow = fp.load_allowlist(ALLOW)
        efp = DATA / 'last.efp'; efp.unlink(missing_ok=True)

        def progress(p, msg):
            _job.update(percent=int(p * 0.85), message=msg)
        r = fc.convert(str(DATA / 'upload.glb'), efp, job['name'][:40] or 'face', TEMPLATE, man, allow, progress=progress,
                       cancelled=lambda: _job.get('state') == 'CANCELLING')
        _job.update(percent=88, message='Packing face for the game')
        e = F.read_efp(efp, allow)
        slot = job['slot']
        pk = _retarget(F, I, e['packages'], e['manifest']['key'], 'RU%02d' % slot)
        files = _container(F, pk, slot)
        with _lock:
            reg = _registry()
            reg['slots'][str(slot)] = {'card': job['card'], 'name': job['name'], 'files': files, 'created': int(time.time()),
                                      'source_sha256': job.get('sha256', '')}
            _save(reg)
        write_table()
        _job.update(state='DONE', percent=100, message='Done. Close and reopen the app, then open the card.')
    except Exception as exc:
        _job.update(state='ERROR', message=str(exc)[:300], trace=traceback.format_exc()[-1500:])
    finally:
        try:
            (DATA / 'upload.glb').unlink(missing_ok=True)
        except OSError:
            pass


def _free_slot(reg, card):
    for s, row in reg['slots'].items():
        if row.get('card') == card:
            return int(s)
    used = {int(s) for s in reg['slots']}
    for s in range(1, SLOTS + 1):
        if s not in used:
            return s
    raise ValueError('All %d GLB face slots are used; remove one first' % SLOTS)


def handle(req):
    op = req.get('rc30face')
    with _lock:
        if op == 'list':
            reg = _registry()
            return {'slots': [dict(slot=int(s), card=r['card'], name=r.get('name', ''), created=r.get('created', 0)) for s, r in sorted(reg['slots'].items(), key=lambda x: int(x[0]))],
                    'max': SLOTS, 'job': {k: v for k, v in _job.items() if k != 'trace'}, 'native': dict(_status)}
        if op == 'begin':
            if _job.get('state') in ('UPLOADING', 'CONVERTING'):
                raise ValueError('Another face import is running')
            card = str(req.get('card', '')).strip()
            if not re.fullmatch(r'[0-9]{4,18}', card):
                raise ValueError('Enter the card ID (numbers only)')
            size = int(req.get('size', 0))
            if not 0 < size <= MAX_GLB:
                raise ValueError('GLB must be at most 32 MB')
            reg = _registry(); slot = _free_slot(reg, card)
            DATA.mkdir(parents=True, exist_ok=True); (DATA / 'upload.glb').write_bytes(b'')
            _job.clear(); _job.update(state='UPLOADING', id=hashlib.sha256(('%s%f' % (card, time.time())).encode()).hexdigest()[:16],
                                      card=card, slot=slot, size=size, received=0, name=str(req.get('name', ''))[:60], percent=0, message='Uploading')
            return {'job': _job['id'], 'slot': slot}
        if op == 'chunk':
            if _job.get('id') != req.get('job') or _job.get('state') != 'UPLOADING':
                raise ValueError('Upload is not active')
            data = base64.b64decode(req.get('data', ''), validate=True)
            if int(req.get('offset', -1)) != _job['received'] or _job['received'] + len(data) > _job['size']:
                raise ValueError('Upload chunk out of order')
            with (DATA / 'upload.glb').open('ab') as f:
                f.write(data)
            _job['received'] += len(data); _job['percent'] = 0
            return {'received': _job['received']}
        if op == 'start':
            if _job.get('id') != req.get('job') or _job.get('received') != _job.get('size'):
                raise ValueError('Upload incomplete')
            _job['sha256'] = hashlib.sha256((DATA / 'upload.glb').read_bytes()).hexdigest()
            _job.update(state='CONVERTING', message='Converting model', percent=1)
            threading.Thread(target=_convert, args=(dict(_job),), daemon=True, name='rc30-glb').start()
            return {'started': True}
        if op == 'cancel':
            if _job.get('state') == 'CONVERTING':
                _job['state'] = 'CANCELLING'
            return {'ok': True}
        if op == 'remove':
            reg = _registry(); s = str(int(req.get('slot', 0)))
            if s in reg['slots']:
                reg['slots'].pop(s); _save(reg); shutil.rmtree(LIVE / s, ignore_errors=True); write_table()
            return {'removed': True}
    raise ValueError('Unknown face import action')


# ---------- native slot table ----------
def write_table():
    try:
        import ctypes, noodle_hair
        h = noodle_hair._handle
        if h is None:
            return False
        base = ctypes.cast(h.noodle_enable, ctypes.c_void_p).value - 0x13334
        if bytes((ctypes.c_char * 4).from_address(base + 0x110080).raw) != b'RU01':
            raise ValueError('face hook build without runtime slots')
        reg = _registry()['slots']
        for i in range(SLOTS):
            row = reg.get(str(i + 1))
            ok = bool(row) and all((LIVE / str(i + 1) / n).exists() for n in row['files'])
            ctypes.c_uint64.from_address(base + 0x110040 + 8 * i).value = int(row['card']) if ok else 0xFFFFFFFFFFFFFFFF
        _status.update(table_written=True, error=None)
        return True
    except Exception as exc:
        _status['error'] = str(exc)[:200]
        return False


def _table_worker():
    try:
        import noodle_hair
        for _ in range(600):
            if noodle_hair._handle is not None and write_table():
                return
            time.sleep(1)
    except Exception as exc:
        _status['error'] = str(exc)[:200]


# ---------- login advertisement (same pattern as the photo container pc9311) ----------
def advertise(value, port):
    reg = _registry()['slots']
    if not reg or not isinstance(value, dict) or not isinstance(value.get('version_file'), str):
        return value
    ver = json.loads(value['version_file']); out = dict(value); changed = False
    files_list = list(value.get('livedata_list') or [])
    for s, row in sorted(reg.items()):
        cname = container_name(int(s)); r = {}
        try:
            for ext in ('pak', 'utoc', 'ucas'):
                meta = row['files']['%s_mobile_and.%s' % (cname, ext)]
                p = ROOT / 'livedata' / meta['relative']
                if p.stat().st_size != meta['size']:
                    raise ValueError('size')
                r[ext] = meta
        except Exception:
            continue
        item = {'name': cname, 'hash': r['pak']['sha256'], 'hashFileSize': r['pak']['size'], 'ucas': r['ucas']['sha256'],
                'ucasFileSize': r['ucas']['size'], 'utoc': r['utoc']['sha256'], 'utocFileSize': r['utoc']['size']}
        if not any(x == item for x in ver.get('dt880', [])):
            changed = True
        ver['dt880'] = [x for x in ver.get('dt880', []) if not isinstance(x, dict) or x.get('name') != cname] + [item]
        names = {'%s_mobile_and.%s' % (cname, ext) for ext in r}
        files_list = [x for x in files_list if not isinstance(x, dict) or x.get('name') not in names]
        files_list += [{'name': '%s_mobile_and.%s' % (cname, ext), 'size': m['size'], 'url': 'http://127.0.0.1:%s/livedata/%s' % (port, m['relative'])} for ext, m in r.items()]
    if changed:
        ver['version'] = int(ver.get('version', 0)) + 730 + len(reg)
    out['version_file'] = json.dumps(ver, separators=(',', ':')); out['livedata_list'] = files_list
    return out


def install(module):
    if getattr(module.manage, '_rc30_glbface', False):
        return
    old = module.manage

    @functools.wraps(old)
    def manage(action, payload=''):
        if action == 'diy_model_list' and payload and '"rc30face"' in payload[:200]:
            try:
                return json.dumps(handle(json.loads(payload)))
            except Exception as exc:
                return json.dumps({'error': str(exc)[:300]})
        return old(action, payload)
    manage._rc30_glbface = True
    module.manage = manage
    try:
        import photo_editor
        if not getattr(photo_editor.advertise, '_rc30_glbface', False):
            prev = photo_editor.advertise

            def adv(value, port):
                out = prev(value, port)
                try:
                    return advertise(out, port)
                except Exception as exc:
                    _status['error'] = 'advertise: ' + str(exc)[:160]
                    return out
            adv._rc30_glbface = True
            photo_editor.advertise = adv
    except Exception as exc:
        _status['error'] = str(exc)[:200]
    threading.Thread(target=_table_worker, daemon=True, name='rc30-glb-table').start()
