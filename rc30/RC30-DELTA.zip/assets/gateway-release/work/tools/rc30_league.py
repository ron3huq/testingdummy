"""RC30: My League season page for the launcher (table, top scorers, top assists, season summary).

Read-only.  The launcher asks through the editor bridge it already has: action editor_list with payload {"rc30": "league"}.
Data: the main store's My League season (my_league.state) - the table from my_league.ranking, scorers and assists from every
played round (CPU games: cpu_player_stats; your games: the real scorers / assists of the match you played, user_match).
"""
import json, functools

_cache = {}


def _cfg():
    try:
        import myleague_worlds as W
        return W.config()
    except Exception:
        return {}


def _names():
    if 'names' not in _cache:
        try:
            import my_league_opponents as mo
            _cache['names'] = mo._names()
        except Exception:
            _cache['names'] = {}
    return _cache['names']


def _pname(pid, classic):
    if pid in classic:
        return classic[pid][0]
    v = _names().get(str(pid))
    return (v[0] if isinstance(v, list) else v) or str(pid)


def season_view(conn):
    import my_league as ML
    s = ML.state(conn)
    if not isinstance(s, dict) or not s.get('schedule_v2'):
        return {'season': None}
    cfg = _cfg()
    cid = int(s.get('competition_id') or 0)
    me = int(s.get('team_id') or 0)
    tn = cfg.get('team_names', {})
    classic = {}
    visual = {}
    for tid, ct in (cfg.get('classic_teams') or {}).items():
        visual[int(tid)] = int(ct.get('visual_team') or tid)
        for sl in ct.get('slots', []):
            classic[int(sl['player_id'])] = (sl['name'], int(tid), sl.get('shirt'), sl.get('role'))
    league = (cfg.get('leagues') or {}).get(str(cid), {})
    teams = {}

    def team(tid):
        tid = int(tid)
        if tid not in teams:
            n = tn.get(str(tid)) or {}
            teams[tid] = {'id': tid, 'name': n.get('name') or str(tid), 'short': n.get('short') or '', 'crest': visual.get(tid, tid)}
        return teams[tid]
    table = []
    try:
        for r in ML.ranking(s):
            team(r['team_id'])
            table.append({'team': int(r['team_id']), 'p': int(r.get('wins', 0)) + int(r.get('draws', 0)) + int(r.get('losses', 0)), 'w': r.get('wins', 0), 'd': r.get('draws', 0), 'l': r.get('losses', 0),
                          'gf': r.get('goals', 0), 'ga': r.get('goals_against', 0), 'pts': r.get('winning_points', 0), 'rank': r.get('rank')})
    except Exception as exc:
        table = []
        _cache['table_error'] = repr(exc)[:200]
    goals, assists, owner, apps = {}, {}, {}, {}
    played = s.get('played') or {}
    form = {}
    for key in sorted(played, key=lambda k: int(k) if str(k).isdigit() else 0):
        rec = played[key] or {}
        for r in rec.get('cpu_player_stats') or []:
            pid = int(r.get('player_id') or 0)
            if not pid:
                continue
            owner[pid] = int(r.get('team_id') or 0)
            goals[pid] = goals.get(pid, 0) + int(r.get('goal') or 0)
            assists[pid] = assists.get(pid, 0) + int(r.get('assist') or 0)
        um = rec.get('user_match') or {}
        for g in um.get('goals') or []:
            try:
                pid, serial = int(g[0]), int(g[1])
            except Exception:
                continue
            if serial:                           # a card of yours (opponent cards have serial 0 and come in cpu stats)
                owner.setdefault(pid, me)
                goals[pid] = goals.get(pid, 0) + 1
        for a in um.get('assists') or []:
            try:
                pid, serial = int(a[0]), int(a[1])
            except Exception:
                continue
            if pid and serial:
                owner.setdefault(pid, me)
                assists[pid] = assists.get(pid, 0) + 1
        for m in rec.get('matches') or []:
            h, a_ = int(m['home_team_id']), int(m['away_team_id'])
            if me in (h, a_):
                gf, ga = (m['home_goals'], m['away_goals']) if h == me else (m['away_goals'], m['home_goals'])
                form[int(key)] = 'W' if gf > ga else 'L' if gf < ga else 'D'

    def board(d, n=25):
        rows = sorted(((pid, v) for pid, v in d.items() if v > 0), key=lambda x: (-x[1], _pname(x[0], classic)))[:n]
        out, prev, rank = [], None, 0
        for i, (pid, v) in enumerate(rows):
            if v != prev:
                rank, prev = i + 1, v
            t = owner.get(pid) or (classic.get(pid) or (0, 0))[1]
            team(t) if t else None
            out.append({'rank': rank, 'pid': pid, 'name': _pname(pid, classic), 'team': t, 'n': v, 'g': goals.get(pid, 0), 'a': assists.get(pid, 0)})
        return out
    rounds = len(s.get('schedule_v2') or [])
    done = bool(s.get('completed')) or (len(played) >= rounds and rounds > 0)
    out = {'season': int(s.get('season') or 1), 'competition': cid, 'competition_name': {518: 'Champions League 2016/17', 122: 'UEFA Champions League'}.get(cid) or league.get('name') or (cfg.get('league_names') or {}).get(str(cid)) or 'My League',
           'team': me, 'round': min(len(played) + 1, rounds), 'rounds': rounds, 'played': len(played), 'done': done,
           'table': table, 'scorers': board(goals), 'assists': board(assists), 'ga': board({p: goals.get(p, 0) + assists.get(p, 0) for p in set(goals) | set(assists)}),
           'form': [form[k] for k in sorted(form)][-6:], 'teams': {str(k): v for k, v in teams.items()}}
    if done and table:
        mine = next((r for r in table if r['team'] == me), None)
        out['summary'] = {'champion': table[0]['team'], 'champion_pts': table[0]['pts'], 'runner': table[1]['team'] if len(table) > 1 else None,
                          'boot': out['scorers'][:3], 'playmaker': out['assists'][:3], 'you': mine,
                          'best_attack': max(table, key=lambda r: r['gf'])['team'], 'best_defence': min(table, key=lambda r: r['ga'])['team'],
                          'your_top': [r for r in out['scorers'] if r['team'] == me][:3]}
    return out


def install(module):
    if getattr(module.manage, '_rc30_league', False):
        return
    old = module.manage

    @functools.wraps(old)
    def manage(action, payload=''):
        if action == 'editor_list' and payload and '"rc30"' in payload:
            try:
                req = json.loads(payload or '{}')
                if req.get('rc30') == 'league':
                    return json.dumps(season_view(module._logic.conn), ensure_ascii=False)
            except Exception as exc:
                return json.dumps({'error': 'rc30-league', 'reason': repr(exc)[:200]})
        return old(action, payload)
    manage._rc30_league = True
    module.manage = manage
