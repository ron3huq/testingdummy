V19.1 FULL-1 — BOOT FIX

Dành cho APK V19.1 đã chép FULL-1.
1. Mở đúng APK đang dùng bằng MT Manager.
2. Chép classes5.dex trong ZIP này vào gốc APK, thay file cũ.
3. Ký lại bằng đúng khóa trước, cài cập nhật.
Không thay assets, không gỡ game, không xóa dữ liệu.

Sửa lỗi kiểu thanh ghi trong EmbeddedGateway.serve có thể khiến Android từ chối lớp ngay khi khởi động.
Đã kiểm tra đọc lại DEX và đường truyền kiểu chuỗi. Chưa thử trực tiếp trên Android.
Nếu vẫn văng, cần log crash Android; bản vá này không khẳng định loại bỏ mọi nguyên nhân khác.
