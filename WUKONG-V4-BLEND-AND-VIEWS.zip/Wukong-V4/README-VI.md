# Wukong V4 — tóc quanh đầu dày hơn, giữ khuôn hiện tại

Áp vào thẻ Wukong cũ `105756321970183`, profile native `NWK9`. Cả bốn biến thể face và hai LOD giữ 166 bone, UV, chỉ số đỉnh, trọng số và bind pose cũ.

Tăng bề ngang phần gốc của 4.296 cụm tóc vùng trên đầu và sau đầu. Không thay râu quanh mặt; giữ các đỉnh đầu nhọn, đường bao convex hull và chiều dài. Mức dịch đỉnh bên trong thêm tối đa 2,5 mm so với V3. Màu lông nâu xám olive trầm theo ảnh tham khảo, giữ các lớp sắc độ cũ và alpha ETC2 từng mip. Da mặt, miệng và mắt không đổi texture.

`geometry-validation.json`, `native-validation.json`, `independent-validation.json` ghi các kiểm tra thực hiện. Ảnh front/front-left/left/back/right là render Blender để xem trước; chưa phải ảnh chụp trong Android. Không khẳng định màu dưới mọi ánh sáng trong game giống tuyệt đối ảnh tham chiếu.

`native/pc9314_mobile_and.{pak,utoc,ucas}` thay gói face Wukong đã có. Đây là tài nguyên cho bộ đóng gói chính; không chứa save người dùng và không sửa CPK loading.
