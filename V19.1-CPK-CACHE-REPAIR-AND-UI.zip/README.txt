V19.1 FULL-2 / startup-probe: exact old CPK cache repair + editor UI
Copy assets/ and classes5.dex to the existing FULL-2 V19.1 APK, replace duplicates, sign with the same key and install as an update. Do not uninstall or clear app data.
Before Enter Game, the repair checks the two explicit dt870 cache names. Only the exact released old CPK SHA256 e3c02c2847797eb19825e928b4059732b83ca9adfdf7914aa59adc4763775d4f can be replaced. It retains a verified recovery copy, verifies the rebased source, then replaces atomically. Unknown files, save data and version.bin are preserved.
Runtime Diagnostics now includes dt870_cache and cpk_cache_repair in the client resource probe, plus the first32 HTTP startup requests. The title-screen fix still needs device confirmation. If it keeps spinning, paste those two sections after retrying.
Includes Back/Refresh, lazy tabs, the complete catalogue/Favorites/cart and a focus guard for10-second idle entry so native dialogs are not interrupted.
